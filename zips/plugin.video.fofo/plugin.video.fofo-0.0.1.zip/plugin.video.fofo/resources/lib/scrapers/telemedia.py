
# -*- coding: utf-8 -*-
import json
import random
import time
import urllib.request
import urllib
import base64
import re
import xbmcaddon
from urllib.parse import urlencode
from modules import source_utils
from modules.kodi_utils import addon_fanart, logger
from modules.utils import clean_file_name

def _strip_diacritics(text):
	""" מנקה לחלוטין סימני ניקוד עבריים מהטקסט לצורך השוואה אמינה """
	if not text:
		return ""
	if isinstance(text, bytes):
		text = text.decode("utf-8", "ignore")
	# הסרת תווים בטווח הניקוד העברי (U+05B0 עד U+05C7)
	return re.sub(r'[\u05b0-\u05c7]', '', text)
def _hebrew_to_translit(text):
	""" ממיר עברית לאנגלית פונטית כולל הזרקת תנועות למילים נפוצות בשמות קבצים """
	if not text:
		return ""
	try:
		# מילון תעתיק חכם עם תנועות מובנות לאותיות
		translit_map = {
			'א': 'a', 'ב': 'b', 'ג': 'g', 'ד': 'd', 'ה': 'h', 'ו': 'o', 'ז': 'z',
			'ח': 'ch', 'ט': 't', 'י': 'i', 'כ': 'k', 'ל': 'l', 'מ': 'm', 'נ': 'n',
			'ס': 's', 'ע': 'e', 'פ': 'p', 'צ': 'ts', 'ק': 'k', 'ר': 'r', 'ש': 'sh', 'ת': 't',
			'ך': 'ch', 'ם': 'm', 'ן': 'n', 'ף': 'p', 'ץ': 'ts'
		}
		
		clean_text = str(text).replace(':', '').replace('-', ' ').replace('.', ' ')
		words = clean_text.split()
		result_words = []
		
		for word in words:
			# טיפול ממוקד במילים ספציפיות כדי לקבל התאמה מושלמת
			if word == "מלך":
				result_words.append("melech")
				continue
			elif word == "ליום":
				result_words.append("leyom")
				continue
			elif word == "אחד":
				result_words.append("echad")
				continue
			elif word == "חצי":
				result_words.append("fifty") # גיבוי לסרט חצי חצי שמופיע כ-fifty fifty בשם הקובץ
				continue
			elif word == "לופו":
				result_words.append("lupo")
				continue
				
			# המרה רגילה לשאר המילים
			translated_word = ""
			for char in word:
				translated_word += translit_map.get(char, char.lower())
				
			if translated_word:
				result_words.append(translated_word)
				
		final_translit = " ".join(result_words)
		return final_translit
	except Exception:
		return ""




class source:
	def __init__(self):

		self.scrape_provider = "telemedia"
		self.sources = []
		
		# רשימה שחורה לחסימת ערוצים ותכנים לא רצויים (באותיות קטנות)
		self.blocked_sources = [
			"axma4_v6ugs3mdiy", 
			"free porn channels"
		]

		
		# מילון חתימות מהיר לזיהוי המעלים - מונע חנק מעבד בסטרימרים
		self.uploader_signatures = [
			("סדרות", ["✅⬆️", "✅☝️"]),
			("נתי מדיה", ["נתי מדיה", "nati"]),
			("The Ghost", ["the ghost", "hebsub.by.the.ghost."]),
			("TgBoxOffice", ["@tgboxoffice"]),
			("MoviiWrld", ["@moviiwrld"]),
			("Tiger Media", ["tiger media"]),
			("לולו סרטים", ["לולו סרטים", "lulusratim1", "לולו-סרטי", "לולו עי גיגי"]),
			("זירה מדיה", ["⏩    ⏪", "זירה מדיה", "ז.מ"]),
			("דרגון מדיה", ["dragonmedia"]),
			(" boss", ["ת.מובנה🇮🇱", "י ~"]),
			("דב סרטים", ["דב סרטים", "דב.ס"]),
			("מלך הטלגרם", ["https://t.me/thekingofthetelegramjoinbot", "👑 מלך הטלגרם 👑"]),
			("אוכלים סרטים", ["אוכלים סרטים"]),
			("נתי סדרות", ["נתי סדרות", "ת.מ נ.ס"]),
			("מונופול הסרטים", ["מונופול הסרטים"]),
			("לוי מדיה", ["לוי מדיה", "לוי_מדיה"]),
			("לוי סדרות", ["לוי סדרות", "♨️ לוי סדרות ♨️"]),
			("לאמין ימאל", ["לאמין ימאל"]),
			("הצוות", ["הועלה הצוות"]),
			("יהודה בן גביר", ["יהודה בן גביר"]),
			("פופקורן טיים", ["פופקורן טיים"]),
			("אייל סרטים", ["אייל סרטים"]),
			("RickyChannel", ["@rickychannel"]),
			("MoviesHD", ["@movieshdchannel"]),
			("PrakyTV", ["@prakytv"]),
			("טרנר & הקרטל", ["https://t.me/+apjs0rv-i-e0ztk8"]),
			("כל הסדרות", ["כל הסדרות"]),
			("שמוליק סרטים", ["שמוליק סרטים"]),
			("צוות אריאל", ["צוות אריאל בטלגרם", "צוות_אריאל"]),
			("תמיד חושב", ["תמיד חושב"]),
			("אלי עמרה", ["אלי עמרה"]),
			("הקולנוע הטלגרמי", ["הקולנוע הטלגרמי"]),
			("השימיה", ["השימיה"]),
			("קינג סרט", ["קינג סרט"]),
			("שלו סדרות", ["שלו סדרות"]),
			("הברנש", ["הועלה על ידי הברנש"]),
			("מאמממממיה", ["מאמממממיה"]),
			("נריה סרטים", ["נריה סרטים"]),
			("ערוץ הסדרות", ["isrteleg"]),
			("ציקו מדיה", ["ציקו מדיה"]),
			("המדיה המנומסת", ["המדיה המנומסת"]),
			("טרמינל הסרטים]", ["טרמינל הסרטים", " 🎞סופרמן🎞"]),
			("הקרטל", ["הקרטל", "הקרטל בטלגרם"]),
			("הכל כלול", ["הכל כלול"]),
			("שלום מדיה", ["שלום מדיה"]),
			("שבי מדיה", ["שבי מדיה", "צוות שבי", "שבי מדיה ברשת", "shabi movies"]),
			("משה מזרחי", ["משה מזרחי"]),
			("הפנינה השחורה", ["הפנינה השחורה"]),
			("מאסטר]", ["מאסטר", "https://t.me/saret13"]),
			("כל המדיה", ["כל המדיה"]),
			("גוזלן", ["גוזלן"]),
			("אלי ה סרטים", ["אלי סרטים"]),
			("המעלה", ["מעלה📤"]),
			("משה סדרות", ["משה סדרות"]),
			("Zovex8", ["https://t.me/zovex8"]),
			("Premiumcontentil", ["https://t.me/premiumcontentil"]),
			("עוף החול", ["עוף החול"]),
			("חן סרטים", ["חן סרטים"]),
			("חננאל סרטים", ["חננאל סרטים"]),
			("RD-VIP", ["rd-vip"]),
			("ORIYA TV", ["oriya tv"]),
			("מדיה VOD", ["מדיה vod"]),
			("אמסלם סרטים", ["amsi77"]),
			("סדרות ישראליות", ["סדרות ישראליות פרקים חדשים"]),
			("סרטים חדשים וישנים", ["sratimnowandold34", "תרגום מובנה 1"]),
			("סרטים חדשים במהירות שיא", ["סרטים חדשים במהירות שיא"]),
			("גל שביט", ["גל שביט", "shavit"]),
			("חיים מדיה", ["haim media", "צפייה מהנה...😎"]),
			("סדרות ישראליות", ["sdarot il", "sdarot.il"]),
			("אנונימוס", ["אנונימוס", "anvip"]),
			("סדרות טיוי", ["sdarot vr", "סדרות טיוי"]),
			("גיבוי פירו", [" | ⏳ ", "multi audio", "💬 english"]),
			("אלי סרטים", ["💠 אלי", "@join eli bot"]),
			("Planco", ["planco"]),
			("WorldMoviss", ["worldmoviss"])
		]
		
		# חתימות טכניות (כמו טורט חינם) שייבדקו רק אם לא נמצא אף מעלה קשיח אחר
		self.tech_uploaders = [
			("טורט חינם", [" esubs ~ ", "@wayneentertainment", "@allforoneoff ", "esub -", "ערוצי סרטים"])
		]


	def results(self, info):
		try:
			logger("Forge Debug Info", str(info))
			import xbmc
			
			t_title = info.get("title")
			t_year = info.get("year")
			self.tmdb_id = str(info.get("tmdb_id") or "")
			self.imdb_id = info.get("imdb_id") or ""
			
			if self.tmdb_id and self.tmdb_id.startswith("tt"):
				self.imdb_id = self.tmdb_id

			if not t_title or t_title == "None" or t_title is None:
				if self.imdb_id and self.imdb_id != "tt0000000":
					try:
						from resources.lib.modules.kodi_utils import info_meta
						meta = info_meta(self.imdb_id)
						if meta:
							t_title = meta.get("title") or meta.get("name")
							t_year = meta.get("year")
					except Exception:
						try:
							from resources.lib.modules import metadata
							meta = metadata.get_meta_by_imdb(self.imdb_id)
							if meta:
								t_title = meta.get("title")
								t_year = meta.get("year")
						except Exception:
							pass

			if not t_title or t_title == "None" or t_title is None:
				try: t_title = xbmc.Player().getVideoInfoTag().getTitle()
				except Exception: t_title = ""
			if not t_year or t_year == "None" or t_year is None:
				try: t_year = xbmc.Player().getVideoInfoTag().getYear()
				except Exception: t_year = ""

			self.media_type = info.get("media_type") or info.get("video_type") or info.get("type") or ("episode" if (info.get("season") or info.get("episode")) else "movie")
			
			self.title = _strip_diacritics(t_title or "")
			self.year = str(t_year or "")
			self.season = info.get("season") or ""
			self.episode = info.get("episode") or ""
			self.aliases = source_utils.get_aliases_titles(info.get("aliases", []))
			self.poster = info.get("poster") or ""
			self.fanart = info.get("fanart") or addon_fanart()
			
			queries = self._queries()
			all_links = []

			from concurrent.futures import ThreadPoolExecutor, as_completed
			
			# 🌟 מנגנון יציבות מקסימלית: מעלים את זמן הנשימה הכללי ומאפשרים לכל חוט לסיים באופן מובטח
			max_timeout = 15.0 
			max_threads = max(1, min(len(queries), 3)) # העלאה ל-3 חוטים מאוזנים למקסום מהירות ללא חנק
			
			with ThreadPoolExecutor(max_workers=max_threads) as executor:
				# שליחת כל השאילתות במקביל
				futures = [executor.submit(self._search, q) for q in queries]
				
				# שינוי אסטרטגיה: במקום לחתוך אקראית, מחכים שכל החוטים יסיימו בתוך מסגרת הזמן הכללית
				for future in futures:
					try:
						# לכל חוט יש את הזמן שלו לסיים, מה שמונע איבוד מקורות של חוטים "איטיים"
						res = future.result(timeout=max_timeout)
						if res:
							all_links.extend(res)
					except Exception:
						continue

			# --- 🛡️ החדרת מנגנון סינון רשימה שחורה (Blacklist) בזמן אמת ---
			filtered_links = []
			for link in all_links:
				# הפיכת פרטי הקישור לטקסט לצורך סריקה גלובלית (שם קובץ, קישור, כיתוב)
				link_str_lower = str(link).lower()
				
				# בדיקה האם הקישור מכיל מילה חסומה מהרשימה השחורה שהגדרנו ב-init
				if any(blocked in link_str_lower for blocked in getattr(self, 'blocked_sources', [])):
					continue # דילוג מוחלט - הקובץ נזרק ולא מתווסף לתוצאות
					
				filtered_links.append(link)
						
			# עיבוד הקישורים הנקיים בלבד
			self.sources = list(self._process_links(filtered_links))
			logger("Forge Telemedia", "results=%s" % len(self.sources))
		except Exception as e:
			logger("Forge Telemedia Exception", str(e))
			
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources



	def _queries(self):
		queries = []
		add_query = queries.append
		
		def clean_special_chars(text):
			if not text: return ""
			return text.replace("'", "").replace("׳", "").replace('"', "").replace("״", "").replace("`", "")

		raw_title = str(self.title or "").replace(':', '')
		
		title_clean = raw_title.replace('&', ' ').replace('-', ' ').replace('.', ' ')
		title_clean = " ".join(title_clean.split()).strip()
		if title_clean:
			add_query(title_clean)
			no_q_space = title_clean.replace("'", " ").replace("׳", " ")
			no_q_dot = title_clean.replace("'", ".").replace("׳", ".")
			add_query(" ".join(no_q_space.split()))
			add_query(".".join([p for p in no_q_dot.split('.') if p]))
			
		if '&' in raw_title:
			title_with_and = raw_title.replace('&', ' and ')
			title_with_and = " ".join(title_with_and.replace('-', ' ').replace('.', ' ').split()).strip()
			if title_with_and:
				add_query(title_with_and)

		eng_dot = raw_title.replace('-', '.').replace(' ', '.').replace('&', '.')
		eng_dot = ".".join([p for p in eng_dot.split('.') if p]).strip('.')
		if eng_dot:
			add_query(clean_special_chars(eng_dot))

		if hasattr(self, 'aliases') and self.aliases:
			for alias in self.aliases:
				if alias:
					alias_str = alias.get("title") if isinstance(alias, dict) else str(alias)
					if not alias_str or alias_str == "None":
						continue
					alias_low = alias_str.lower()
					if "deadpools" in alias_low or "tidal wave" in alias_low or "dogpool" in alias_low:
						continue
					alias_str = alias_str.replace("'", " ").replace("׳", " ")
					clean_alias = _strip_diacritics(alias_str).replace(':', '').replace('-', ' ').replace('&', ' ').strip()
					clean_alias = " ".join([w for w in clean_alias.split() if w.upper() not in ("IL", "US", "UK", "CA", "3D")])
					if clean_alias:
						add_query(clean_alias)
						alias_dot = clean_alias.replace(" ", ".")
						add_query(".".join([p for p in alias_dot.split('.') if p]))

		base_queries = list(dict.fromkeys(queries))
		final_queries = []
		is_episode = (self.media_type == "episode" or (self.season and str(self.season).isdigit() and int(self.season) > 0))

		for q in base_queries:
			if not q: 
				continue
			
			q = ".".join([p for p in q.split('.') if p])
			q = " ".join(q.split()).strip()
			is_heb = any(u'\u0590' <= c <= u'\u05ea' for c in q)
			
			if is_episode:
				season = int(self.season or 0)
				episode = int(self.episode or 0)
				season_n = str(season).zfill(2)
				episode_n = str(episode).zfill(2)
				
				if is_heb:
					# הזרקת השאילתות המלאות למניעת פספוס בטלגרם ישראל
					final_queries.append("%s עונה %d פרק %d" % (q, season, episode))
					final_queries.append("%s עונה %d" % (q, season))
					final_queries.append("%s ע%d פ%d" % (q, season, episode))
					final_queries.append("%s ע%dפ%d" % (q, season, episode))
					final_queries.append("%s S%sE%s" % (q, season_n, episode_n))
				else:
					q_dot = q.replace(" ", ".")
					final_queries.append("%s.S%sE%s" % (q_dot, season_n, episode_n))
					final_queries.append("%s S%sE%s" % (q, season_n, episode_n))
					final_queries.append("%s.%dx%s" % (q_dot, season, episode_n))
			else:
				final_queries.append(q)
				if self.year:
					final_queries.append("%s %s" % (q, self.year))
				if not is_heb:
					q_dot = q.replace(" ", ".")
					final_queries.append(q_dot)
					if self.year: 
						final_queries.append("%s.%s" % (q_dot, self.year))
						
		return list(dict.fromkeys(final_queries))








	def _get_listen_port(self):
		try:
			import xbmcaddon
			return xbmcaddon.Addon("plugin.video.telemedia").getSetting("port")
		except Exception:
			return ""

	def _td_send(self, payload, query):
		port = self._get_listen_port()
		if not port:
			return {}
		try:
			request = urllib.request.Request(
				f"http://127.0.0.1:{port}/",
				data=json.dumps(payload).encode("utf-8"),
				headers={"Content-Type": "application/json"},
			)
			# 🌟 העלאת ה-timeout ל-12.0 שניות כדי למנוע את ה-timed out בשאילתות כבדות
			with urllib.request.urlopen(request, timeout=12.0) as response:
				content = response.read().decode("utf-8", "ignore")
				return json.loads(content) if content else {}
		except Exception as e:
			logger("Forge Telemedia request failed", f"port={port} query={query} error={e}")
			return {}





	def _search(self, query):
		all_links = []
		if isinstance(query, bytes):
			query = query.decode("utf-8")
		query = query.replace('%20', ' ').replace('%27', "'").replace('%3a', ":").replace('!', '').strip()
		query = " ".join(query.split()).strip()
		
		if not query:
			return all_links
		
		is_movie = (self.media_type == "movie") or (not self.season)
		
		# 🌟 החזרת הפילטרים המלאים כדי לקבל את כל 50 המקורות ולא לפספס אף קובץ
		for filter_type in ("searchMessagesFilterVideo", "searchMessagesFilterDocument"):
			num = random.randint(1, 10001)
			data = {
				"type": "td_send",
				"info": json.dumps({
					"@type": "searchMessages",
					"query": query,
					"offset_message_id": "0",
					"offset_chat_id": "0",
					"filter": {"@type": filter_type},
					"limit": 100,
					"@extra": num,
				}),
			}
			event = self._td_send(data, query)
			
			# 🌟 הגנה מחנק: אם הפילטרים החזירו מידע, מעבדים אותו מיד בזיכרון. 
			# ביטלנו את הבקשה השלישית הכללית המיותרת שהייתה מעמיסה על הסטרימר.
			if event and "messages" in event and isinstance(event["messages"], list):
				for item in event["messages"]:
					try:
						if not item or "content" not in item:
							continue
							
						content = item["content"]
						name = ""
						file_data = None
						caption_text = ""
						
						if "document" in content:
							doc_node = content["document"]
							if doc_node and "file_name" in doc_node:
								name = str(doc_node["file_name"])
								file_data = doc_node.get("document")
						elif "video" in content:
							vid_node = content["video"]
							if vid_node and "file_name" in vid_node:
								name = str(vid_node["file_name"])
								file_data = vid_node.get("video")
								
						if "caption" in content and content["caption"] and "text" in content["caption"]:
							caption_text = str(content["caption"]["text"])

						if not name and caption_text:
							if 'upfile' in caption_text or 'drive.google' in caption_text:
								txt_lines = [l.strip() for l in caption_text.split('\n') if l.strip()]
								if txt_lines:
									if is_movie and any(kw in caption_text.lower() for kw in ["s0", "s1", "s2", "e0", "e1", "עונה", "פרק"]):
										continue
									ext_links = [l for l in txt_lines if 'upfile' in l or 'drive.google' in l]
									if ext_links:
										link_data = {"is_external": True, "urls": ext_links}
										all_links.append({"name": txt_lines if txt_lines else "External Link", "caption": caption_text, "link_data": link_data, "size": 0})
										continue

						if not name or not file_data:
							continue
							
						name_low = name.lower()
						if self.media_type == "movie":
							if any(kw in name_low for kw in ["עונה", "פרק", "ע1", "ע2", "ע3", "ע4", "ע5", "ע6", "ע7", "ע8", "ע9", "ע0"]):
								continue
							if re.search(r'\bs\d+e\d+\b|\b\d+x\d+\b', name_low):
								continue

						local_id = str(file_data.get("id", ""))
						if not local_id:
							continue

						size = int(file_data.get("size", 0))
						if size < (40 * 1024 * 1024): 
							continue
							
						link_data = {
							"id": local_id,
							"m_id": item["id"], 
							"c_id": item["chat_id"],
							"is_external": False
						}
						
						all_links.append({"name": name, "caption": caption_text, "link_data": link_data, "size": size})

					except Exception:
						continue
		return all_links



	def _process_links(self, links):
		seen_names = set()
		seen_sizes = set()
		size_types_map = {}
		
		target_title = str(self.title or "").lower().strip()
		target_title_clean = target_title.replace(":", "").replace("-", "").replace(".", "").replace(" ", "")
		target_year = str(self.year or "")
		is_movie = (self.media_type == "movie") or (not self.season)

		req_season = int(self.season or 0)
		req_episode = int(self.episode or 0)
		season_n = str(req_season).zfill(2)
		episode_n = str(req_episode).zfill(2)

		aliases_clean = []
		if hasattr(self, 'aliases') and self.aliases:
			for alias in self.aliases:
				if alias:
					aliases_clean.append(_strip_diacritics(str(alias)).lower().replace(":", "").replace("-", "").replace(".", "").replace(" ", ""))

		raw_processed_items = []

		for item in links:
			try:
				absolute_raw_name = str(item.get("name", ""))
				raw_name = _strip_diacritics(item.get("name", ""))
				caption = _strip_diacritics(item.get("caption", ""))

				link_info = item.get("link_data", {})
				size_bytes = item.get("size", 0)
				
				size = round(float(size_bytes) / 1073741824, 2) if size_bytes > 0 else 0
				if not link_info.get("is_external") and (size <= 0.01 or size > 45.0):
					continue
				
				raw_name_lower = str(raw_name).lower() if isinstance(raw_name, str) else "".join(raw_name).lower()
				caption_lower = caption.lower()
				# הגנת שנה מותאמת לסרטים וסדרות - מוגן מקריסות
				year_is_incorrect = False
				no_year_found = False
				if target_year:
					found_years = re.findall(r'(19\d{2}|20\d{2})', raw_name_lower)
					if not found_years:
						found_years = re.findall(r'(19\d{2}|20\d{2})', caption_lower)
						
					if found_years:
						try:
							t_yr = int(target_year)
							clean_years = [int(y) for y in found_years if int(y) != 2160 and int(y) != 1080 and str(y) not in target_title]
							
							if clean_years:
								if is_movie:
									if any(abs(y - t_yr) > 2 for y in clean_years):
										continue
									if any(y != t_yr for y in clean_years):
										year_is_incorrect = True
								else:
									if any(abs(y - t_yr) > 1 for y in clean_years):
										continue
						except Exception:
							pass
					else:
						if is_movie:
							no_year_found = True





				# חסימת תוצאות של סדרות מלהשתלב בתוך חיפוש סרטים - הגנה הרמטית כולל רווחים
				if is_movie:
					combined_search_text = raw_name_lower + " " + caption_lower
					if any(kw in combined_search_text for kw in ["עונה", "פרק", "ע1", "ע2", "ע3", "ע4", "ע5", "ע6", "ע7", "ע8", "ע9", "ע0"]):
						continue
					# 🌟 ה-Regex המעודכן תופס כעת גם s01e04, גם s01 e04, וגם s01.e04 או s 01 e 04
					if re.search(r's\s*\d+[\s._]*e\s*\d+|e\d+e\d+|\d+x\d+|ep\d+|season|episode', combined_search_text):
						continue






				# סינון קדימונים וטריילרים
				trailer_words = ["trailer", "teaser", "קדימון", "טריילר", "promo"]
				if any(tw in raw_name_lower or tw in caption_lower for tw in trailer_words):
					continue

				# סינון חלקי קבצים (CD/Part) אלא אם כן שם הסרט מכיל את המילה חלק
				part_words = ["חלק", "part", "cd", "ח1", "ח2", "ח3", "ח4", "ח5", "ראשון", "שני", "שלישי", "רביעי", "חמישי"]
				search_contains_part = any(pw in target_title or pw in target_title_clean for pw in ["חלק", "part"])
				
				# 🌟 רשת ביטחון חדשה: חוסמים קבצי CD מפוצלים באופן אבסולוטי (כמו CD1, CD2, CD3) ללא קשר לשם הסרט
				is_split_cd_file = re.search(r'\bcd\s*[1-5]\b|part\s*[1-5]', raw_name_lower + " " + caption_lower)
				
				if is_split_cd_file:
					continue

				if not search_contains_part:
					file_words_clean = raw_name_lower.replace(".", " ").replace("_", " ").replace("-", " ").split()
					if any(pw in file_words_clean for pw in part_words):
						continue
					
					# רשת ביטחון ממוקדת: חסימת הצמדות מפורשות של חלקים (כמו חלק 1, חלק-1, חלק1)
					combined_part_text = raw_name_lower + " " + caption_lower
					if re.search(r'חלק[.\s_-]*\d+|part[.\s_-]*\d+|cd[.\s_-]*\d+|\bח[1-5]\b', combined_part_text):
						continue

				if raw_name in seen_names:
					continue



				# בניית רשימה נקייה של שורות התוכן בלבד לצורך סינון התקציר המבלבל
				clean_content_lines = []
				story_indicators = ["תקציר", "עלילה", "סיפורו", "מטמינים", "המשך ישיר", "ערוצי סרטים", "כאשר ", "קארה "]

				line_count = 0
				for line in caption.split('\n'):
					line_strip = line.strip()
					if not line_strip:
						continue
					line_count += 1
					
					# חוקי הברזל לחיתוך התקציר המבלבל
					if line_count > 4 or any(indicator in line_strip for indicator in story_indicators):
						break
					if line_count == 4 and len(line_strip) > 70:
						break
						
					clean_content_lines.append(line_strip)

				caption_metadata_only = " ".join(clean_content_lines).lower()
				caption_top_3 = caption_metadata_only
				# הגדרה מחדש של הטקסט המשולב לצורך סריקת המעלים
				combined_text_for_uploaders = (raw_name + " " + caption).lower().replace("_", " ")



				# הגדרת ברירת מחדל - אם לא יימצא מעלה מהרשימות, השם יהיה telemedia
				uploader_name = "telemedia"

				# סריקה מהירה של המעלים מתוך המילון
				for name_tag, signatures in self.uploader_signatures:
					if any(sig in combined_text_for_uploaders for sig in signatures):
						uploader_name = name_tag
						break
				
				# בדיקת קבוצות טכניות (כמו טורט חינם) רק אם לא נמצא מזהה קשיח קודם
				if uploader_name == "telemedia":
					for name_tag, signatures in self.tech_uploaders:
						if any(sig in combined_text_for_uploaders for sig in signatures):
							uploader_name = name_tag
							break

				# חילוץ מעלה דינמי משם הקובץ - יתבצע רק אם עדיין לא זוהה מעלה קשיח או טכני
				if uploader_name == "telemedia":
					parts = [p.strip() for p in raw_name.replace(" ", ".").split(".") if p.strip()]
					for i, part in enumerate(parts):
						part_lower = part.lower()
						if "ע" in part_lower and "פ" in part_lower or "s" in part_lower and "e" in part_lower:
							if i + 1 < len(parts):
								next_part = parts[i+1]
								if next_part and not next_part.isdigit() and next_part.lower() not in ("mkv", "mp4", "avi", "1080p web-d", "1080p", "540p", "480p", "720p", "x264", "x265", "hevc", "2160p", "4k", "sd"):
									uploader_name = next_part
									break

				# --- 🛡️ החדרת סינון משקל מינימלי למקורות RD-VIP בלבד ---
				if uploader_name == "RD-VIP":
					# המרת משקל ה-GB הקיים (size) למגה-בייט (MB) לצורך בדיקה פשוטה
					file_size_mb = size * 1024
					
					if is_movie:
						# סרטים של RD-VIP שקטנים מ-300MB ייזרקו
						if file_size_mb < 300:
							# logger("Forge Filter", f"Dropped RD-VIP movie: {raw_name} ({file_size_mb}MB)")
							continue
					else:
						# סדרות (פרקים) של RD-VIP שקטנים מ-100MB ייזרקו
						if file_size_mb < 100:
							# logger("Forge Filter", f"Dropped RD-VIP episode: {raw_name} ({file_size_mb}MB)")
							continue


				# 🌟 רשת ביטחון לקבצים בעברית עם קווים תחתונים ואמפרסנד (כמו דדפול וולברין של שמוליק גוזלן)
				exact_title_match = False

				clean_raw_text = raw_name_lower.replace("_", " ").replace(".", " ").replace("-", " ").replace("'", " ").replace("׳", " ").replace("&", " ")
				clean_caption_text = caption_metadata_only.replace("_", " ").replace(".", " ").replace("-", " ").replace("'", " ").replace("׳", " ").replace("&", " ")
				
				file_words_set = set(clean_raw_text.split() + clean_caption_text.split())
				clean_target_title = target_title.replace(".", " ").replace("-", " ").replace("&", " ").replace("_", " ")
				target_words = [w for w in clean_target_title.split() if len(w) > 2]
				
				if target_words:
					matches_count = sum(1 for w in target_words if w in file_words_set)
					if (matches_count / len(target_words)) >= 0.7:
						exact_title_match = True

				match_targets = [target_title_clean, target_title.replace(" ", "")]
				if aliases_clean:
					match_targets.extend([a for a in aliases_clean if a])
				
				for t in list(match_targets):
					if "-" in t or "_" in t or "'" in t or "׳" in t:
						match_targets.append(t.replace("-", "").replace("_", "").replace("'", "").replace("׳", ""))
							
				if not exact_title_match:
					clean_raw_name_no_spaces = raw_name_lower.replace(".", "").replace("_", "").replace("-", "").replace(" ", "").replace("'", "").replace("׳", "")
					exact_title_match = any(t in clean_raw_name_no_spaces for t in match_targets)

				if not exact_title_match and (target_title in raw_name_lower or target_title in caption_metadata_only):
					exact_title_match = True

				if not exact_title_match:
					continue

				# זיהוי שפות וסוג מקור (מניעת קריסות סנכרון משתנים)
				dub_keywords = ("מדובב", "דיבוב", "hebdub", "heb.dub", "hebrew.dub", "hebrew_dub")
				
				# רשימת מילים המעידות על תרגום לעברית (הסרנו את "sub" הגנרי)
				sub_keywords = (
					"hebsub", "heb.sub", "hebrew.sub", "Hebrew sub", "HEB Sub", "hebrew", "תרגום ai", "hebrew_sub", 
					"ת_מ", "ת-מ", "ת m", "ת.מ", "כולל.כתוביות", "תרגום-מוצמד", "dragonmedia", 
					"haim-media", "amsi77", "תרגום_בצד", "premiumcontentil", "sdarot_vr", "תרגום בצד", "ת. מוצמד", "-t.s ", 
					"תרגום מובנה", "סדרות ישראליות פרקים חדשים", "✅☝️", "✅⬆️", "עוף החול", "תרגום.מובנה", "תרגום מוצמד", "sratimnowandold34", 
					"כולל_כתוביות", "תרגום_רשמי_לפי_שמיעה", "תרגום_רשמי_משמיעה", "כתוביות בעברית", 
					"תרגום אולפנים", "כולל כתוביות", "תרגום_מובנה"
				)
				
				# מילת חסימה לתכנים פרסיים/ערביים שהיו מטעים את המערכת
				farsi_keywords = ("زیرنویس", "فیلم", "کیفیت", "بدون سانسور")
				
				# המרה לעברית תקנית של הטקסטים לצורך בדיקה
				raw_name_lower = raw_name_lower.lower()
				caption_lower = caption.lower()
				
				# בדיקה האם המקור מכיל מילים בפרסית - אם כן, נדלג עליו או נסמן כקובץ גולמי רגיל
				is_farsi = any(kw in raw_name_lower or kw in caption_lower for kw in farsi_keywords)
				
				# זיהוי סופי של סוג המקור
				is_dubbed = any(kw in raw_name_lower or kw in caption_lower for kw in dub_keywords)
				
				# התנאי מוודא שיש מילת מפתח בעברית, ושהקובץ אינו פרסי
				is_subbed = any(kw in raw_name_lower or kw in caption_lower for kw in sub_keywords) and not is_farsi
				
				# לוגיקה משופרת ורחבה לזיהוי קבצים עם כתוביות פנימיות רכות בעברית (Multi-Subs)
				# הבדיקה מוודאת אם רשום multi בשם, או אם התיאור מכיל את המילה hebrew לצד אמוג'י הכתוביות או לצד שפות נפוצות אחרות ברשימה (כדי לתפוס את הקובץ השני)
				has_embedded_hebrew_sub = (
					("multi" in raw_name_lower) or 
					("hebrew" in caption_lower and (
						"💬" in caption_lower or 
						"subtitles" in caption_lower or 
						"arabic" in caption_lower or 
						"english" in caption_lower
					))
				)
				
				source_type = "raw"
				if is_dubbed: 
					source_type = "dub"
				elif is_subbed or has_embedded_hebrew_sub: 
					source_type = "sub"

				if size > 0 and size in seen_sizes:
					if size_types_map.get(size) == source_type: continue

				seen_names.add(raw_name)
				if size > 0:
					seen_sizes.add(size)
					size_types_map[size] = source_type

				# --- תהליכון רקע: סריקת אינדקסים כירורגית לאחר 5 שניות של ניגון ---
				if has_embedded_hebrew_sub:
					import threading
					import xbmc
					
					def delayed_index_enforcement(is_dubbed_file):
						import time
						player = xbmc.Player()
						monitor = xbmc.Monitor()
						
						# שלב 1: המתנה בלולאה עד שהנגן יציג תמונה על המסך
						video_started = False
						for _ in range(60):
							if monitor.abortRequested():
								return
							if player.isPlayingVideo():
								video_started = True
								break
							time.sleep(0.5)
							
						# שלב 2: המתנה יציבה של 5 שניות בדיוק (מצוין לחוויית משתמש ונעילת WASAPI)
						if video_started:
							for _ in range(5):
								if monitor.abortRequested() or not player.isPlayingVideo():
									return
								time.sleep(1.0)
								
							try:
								# שלב 3: סריקת רצועות השמע הפנימיות בנגן ובחירת אנגלית (eng/english)
								if not is_dubbed_file:
									audio_streams = player.getAvailableAudioStreams()
									for idx, stream in enumerate(audio_streams):
										stream_lower = stream.lower()
										if "eng" in stream_lower or "english" in stream_lower:
											player.setAudioStream(idx)
											break
								
								# שלב 4: סריקת רצועות הכתוביות, בחירת עברית (heb/hebrew) ואילוץ הדלקה קשיח
								sub_streams = player.getAvailableSubtitleStreams()
								for idx, stream in enumerate(sub_streams):
									stream_lower = stream.lower()
									if "heb" in stream_lower or "hebrew" in stream_lower:
										player.setSubtitleStream(idx)
										player.showSubtitles(True)
										break
							except Exception:
								pass

					# הפעלת תהליך הרקע העצמאי
					threading.Thread(target=delayed_index_enforcement, args=(is_dubbed,)).start()







				# הגנת פרקים ועונות עבור סדרות
				if not is_movie:
					if req_episode < 10:
						if re.search(r'\b(?:פרק|e|פ)\s*0?' + str(req_episode) + r'\d', raw_name_lower) or re.search(r'\b(?:פרק|e|פ)\s*0?' + str(req_episode) + r'\d', caption_lower):
							continue

					text_to_check = raw_name_lower + " " + caption_lower
					for technical_word in ["10bit", "10-bit", "2ch", "6ch", "8ch", "x265", "x264", "h264", "h265", "hevc", "2160p", "1080p", "720p", "480p", "540p", "4k"]:
						text_to_check = text_to_check.replace(technical_word, "")

					all_seasons_found = re.findall(r's(\d+)|עונה[\s._-]*(\d+)|ע(\d+)פ', text_to_check)
					if all_seasons_found:
						seasons_list = [int(x) for tup in all_seasons_found for x in tup if x]
						if seasons_list and any(s != req_season for s in seasons_list):
							continue

					all_eps_found = re.findall(r'e(\d+)|\b\d+x(\d+)\b|פרק[\s._-]*(\d+)|ע\d+פ(\d+)', text_to_check)
					if all_eps_found:
						eps_list = [int(x) for tup in all_eps_found for x in tup if x]
						if eps_list and any(e != req_episode for e in eps_list):
							continue

# --- זיווג רזולוציה ואיכות מדויק ומוגן מפני דריסות שגויות ---
				res_num = 0
				text_to_scan_res = raw_name_lower + " " + caption_top_3
				
				# ניקוי השנים שחולצו כדי למנוע מצב שהשנה תזוהה כרזולוציה
				if 'found_years' in locals() or 'found_years' in globals():
					for yr in found_years:
						text_to_scan_res = text_to_scan_res.replace(yr, "")

				# ניקוי ביטויים מטעים שכוללים את המספר 4
				for false_group in ("friday4kpopcorn", "4kpopcorn", "ds4k", "ds-4k"):
					text_to_scan_res = text_to_scan_res.replace(false_group, "")

				# ה-Regex המספרי המקורי והחזק שלך שמחלץ את הרזולוציה במדויק (למשל 720, 1080, 480)
				res_match = re.search(r'\b(\d{3,4})(?:\s*p|\s*i|\s*k)?\b', text_to_scan_res)
				res_found_explicit = False
				
				if res_match:
					res_num = int(res_match.group(1))
					# סימון שמצאנו ערך מספרי אמיתי ומפורש בתוך שם הקובץ או הטקסט
					if res_num in (2160, 1080, 720, 540, 480):
						res_found_explicit = True

				resolution_tag = "[SD]"
				quality_score = 1
				kodi_quality = "SD"
				
				# ... הפרדה קשיחה - סינון Telesync (איכות קולנוע נמוכה) ...
				is_low_quality_ts = ("-ts" in raw_name_lower and not raw_name_lower.endswith(".ts")) or "hdtv-ts" in raw_name_lower or "camrip" in raw_name_lower or "telesync" in raw_name_lower

				if is_low_quality_ts or uploader_name == "איכות נמוכה":
					resolution_tag = ""
					quality_score = 0
					kodi_quality = "SD"
					uploader_name = "איכות נמוכה"
				else:
					is_actual_4k = ("2160" in raw_name_lower or "4k" in raw_name_lower or "uhd" in raw_name_lower or "2160" in caption_top_3 or "4k" in caption_top_3) and "ds4k" not in raw_name_lower

					# 1. עדיפות עליונה: אם נמצאה תגית מספרית מפורשת - היא קובעת באופן אבסולוטי!
					if res_found_explicit:
						if (res_num == 2160 or is_actual_4k) and "1080" not in raw_name_lower and "720" not in raw_name_lower and "480" not in raw_name_lower:
							resolution_tag = "[4K]"
							quality_score = 4
							kodi_quality = "4K"
						elif 721 <= res_num <= 1440:
							resolution_tag = "[1080p]"
							quality_score = 3
							kodi_quality = "1080p"
						elif 541 <= res_num <= 720:
							resolution_tag = "[720p]"
							quality_score = 2
							kodi_quality = "720p"
						elif res_num <= 540:
							resolution_tag = "[SD]"
							quality_score = 1
							kodi_quality = "SD"
							
					# 2. רשת ביטחון: רק אם אין שום מספר מפורש (לא 480 ולא 720) בקובץ, קובעים לפי משקל
					else:
						if is_actual_4k:
							resolution_tag = "[4K]"
							quality_score = 4
							kodi_quality = "4K"
						elif is_movie:
							if size >= 2.5:
								resolution_tag = "[1080p]"
								quality_score = 3
								kodi_quality = "1080p"
							elif size >= 0.8:
								resolution_tag = "[720p]"
								quality_score = 2
								kodi_quality = "720p"
						else: # סדרות
							if size >= 0.6:
								resolution_tag = "[1080p]"
								quality_score = 3
								kodi_quality = "1080p"
							elif size >= 0.25:
								resolution_tag = "[720p]"
								quality_score = 2
								kodi_quality = "720p"

				# הגנת תווי עברית מקורית
				any_heb_char = any(u'\u0590' <= c <= u'\u05ea' for c in raw_name)

				# הגגרת ציוני בסיס ומשתני עזר למיון
				type_score = 0
				if uploader_name == "איכות נמוכה":
					type_score = -10000
				elif no_year_found:
					type_score = -500
				elif year_is_incorrect:
					type_score = -1000
				else:
					if is_dubbed: type_score = 3000
					elif is_subbed: type_score = 2000
					elif any_heb_char: type_score = 1000
					else: type_score = 0

				# --- בניית שורת המקור הנקייה והחדשה ---
				hebrew_info = []
				
				# חילוץ השנה האמיתית מתוך הקובץ/טקסט לצורך תצוגה צבעונית דינמית
				file_year_label = ""
				if found_years:
					clean_file_years = [y for y in found_years if y not in ["2160", "1080"]]
					if clean_file_years:
						file_year_label = "[B][COLOR lightblue](%s)[/COLOR][/B]" % clean_file_years

				# 1. סטטוס שנה או מקור (מופיע ראשון) + הזרקת השנה הדינמית מהקובץ
				if uploader_name == "איכות נמוכה":
					hebrew_info.append("[B][COLOR purple][TS איכות נמוכה][/COLOR][/B]")
				elif no_year_found:
					hebrew_info.append("[B][COLOR purple][ללא שנה][/COLOR][/B]")
				elif year_is_incorrect:
					err_label = "[B][COLOR purple][שנה לא תואמת][/COLOR][/B]"
					if file_year_label:
						err_label += " %s" % file_year_label
					hebrew_info.append(err_label)
				else:
					if file_year_label:
						hebrew_info.append(file_year_label)
					elif not is_dubbed and not is_subbed and not any_heb_char:
						hebrew_info.append("[B][COLOR gray][אנגלית/מקור][/COLOR][/B]")

				# --- לוגיקה קשיחה: בידוד מוחלט של שורת השמע בין 🔊 ל-💬 ---
				foreign_languages_map = {
					"hindi": "הינדי", "tamil": "טאמיל", "telugu": "טלוגו", "ita": "איטלקית", 
					"italian": "איטלקית", "spa": "ספרדית", "spanish": "ספרדית", "fre": "צרפתית", 
					"french": "צרפתית", "ger": "גרמנית", "german": "גרמנית", "rus": "רוסית", 
					"russian": "רוסית", "lat": "לטינית", "latino": "לטינית", "jpn": "יפנית", 
					"japanese": "יפנית", "kor": "קוריאנית", "korean": "קוריאנית", "chinese": "סינית",
					r'\bchi\b': "סינית"
				}
				
				detected_foreign_lang = ""
				audio_text_zone = ""
				
				# חילוץ הטקסט שנמצא בדיוק בין שני האייקונים
				if "🔊" in caption_lower and "💬" in caption_lower:
					try:
						start_idx = caption_lower.find("🔊") + len("🔊")
						end_idx = caption_lower.find("💬")
						if start_idx < end_idx:
							audio_text_zone = caption_lower[start_idx:end_idx].strip()
					except Exception:
						audio_text_zone = ""
				
				# רשת ביטחון: אם אין אייקונים בתיאור, נשתמש בשם הקובץ לבדיקה רגילה
				if not audio_text_zone:
					audio_text_zone = raw_name_lower
				else:
					# נוסיף את שם הקובץ למקרה שהשפה רשומה רק בשם
					audio_text_zone = raw_name_lower + " " + audio_text_zone

				# בדיקה אבסולוטית מעודכנת: הוספנו את "original audio" ו-"original" לרשת הביטחון של השמע
				has_standard_audio = (
					"unknown" in audio_text_zone or "und" in audio_text_zone or
					"eng" in audio_text_zone or "english" in audio_text_zone or 
					"heb" in audio_text_zone or "hebrew" in audio_text_zone or
					"original" in audio_text_zone or "original audio" in audio_text_zone
				)
				
				# סריקת השפה הזרה בשמע המבודד בלבד
				if not has_standard_audio and "multi" not in raw_name_lower:
					for lang_key, lang_hebrew in foreign_languages_map.items():
						if lang_key.startswith(r'\b'):
							if re.search(lang_key, audio_text_zone):
								detected_foreign_lang = lang_hebrew
								break
						elif lang_key in audio_text_zone:
							detected_foreign_lang = lang_hebrew
							break

				# 2. תגית תרגום / שמע (בצבע זהב)
				if is_dubbed:
					hebrew_info.append("[B][COLOR gold]מדובב[/COLOR][/B]")
				elif is_subbed or any_heb_char:
					if detected_foreign_lang:
						hebrew_info.append("[B][COLOR gold]תרגום מובנה (%s)[/COLOR][/B]" % detected_foreign_lang)
					else:
						hebrew_info.append("[B][COLOR gold]תרגום מובנה[/COLOR][/B]")
				elif detected_foreign_lang:
					hebrew_info.append("[B][COLOR coral][שמע: %s][/COLOR][/B]" % detected_foreign_lang)

				# 3. שם המעלה (בצבע אדום)
				if uploader_name and uploader_name != "איכות נמוכה":
					hebrew_info.append("[B][COLOR red]%s[/COLOR][/B]" % uploader_name)

				# 4. תגית האיכות (בצבע ירוק)
				if resolution_tag:
					hebrew_info.append("[B][COLOR lime]%s[/COLOR][/B]" % resolution_tag)

				# 5. גודל הקובץ (בצבע לבן)
				size_label = "%.2f GB" % size if size else "N/A"
				hebrew_info.append("[B][COLOR white]%s[/COLOR][/B]" % size_label)

				# חיבור סופי ונקי של השורה החדשה ללא שם סרט, ללא קידודים וללא HDR
				details_combined = " | ".join(hebrew_info)
				display_name = details_combined

				if uploader_name == "איכות נמוכה":
					display_name += " "
				elif year_is_incorrect:
					display_name += " "
				elif no_year_found:
					display_name += " "

				has_media_tags = (is_subbed or is_dubbed or any_heb_char)
				url = self._plugin_url(raw_name, link_info, size, has_media_tags)

				forced_quality = kodi_quality
				size_score = min(size / 50.0, 0.99) if size else 0.0

				# חישוב הבונוס הפנימי עבור איכות, שפה וגודל
				internal_bonus = (quality_score * 100) + (30 if is_dubbed else (20 if (is_subbed or any_heb_char) else 0)) + size_score

				if uploader_name == "איכות נמוכה":
					final_score = -100000 + internal_bonus
				elif year_is_incorrect:
					final_score = -20000 + internal_bonus
				elif no_year_found:
					final_score = -10000 + internal_bonus
				else:
					final_score = type_score + internal_bonus

				# החזרת המפתחות למצב הנקי שלהם
				raw_processed_items.append({
					"score": int(final_score),  
					"data": {
						"name": str(absolute_raw_name),      # שם הקובץ הנקי בלבד
						"display_name": str(display_name),  # נתוני ה-Info הנקיים בלבד
						"quality": str(forced_quality), 
						"size": float(size) if size else 0.0,
						"size_label": "%.2f GB" % size if size else "N/A",
						"debrid": self.scrape_provider,
						"extraInfo": str(display_name),     
						"url": str(url),
						"url_dl": str(url),
						"down_url": str(url),
						"id": str(url),
						"local": False,
						"direct": True,
						"direct_debrid_link": True,
						"source": self.scrape_provider,
						"scrape_provider": self.scrape_provider,
					}
				})






			except Exception as e:
				logger("Forge process link inner exception", str(e))
				continue

		# מיון סופי והחזרת מערך הנתונים הטהור ("data") בצורה מוגנת
		try:
			raw_processed_items = sorted(raw_processed_items, key=lambda x: x["score"], reverse=True)
			return [item["data"] for item in raw_processed_items]
		except Exception as e:
			logger("Forge sort failed", str(e))
			return []

	def _plugin_url(self, name, link_data, size, has_sub_or_dub=False):
		no_subs_val = "1" if has_sub_or_dub else "0"
		subs_val = "0" if has_sub_or_dub else "1"
		
		# תמיכה בקישור חיצוני (Upfile/Drive) או פנימי לנגן של טלמדיה
		if link_data.get("is_external"):
			final_payload = "Direct_link$$$TELE%%%" + "$$$".join(link_data.get("urls", []))
		else:
			final_payload = json.dumps({
				"id": link_data.get("id"),
				"m_id": link_data.get("m_id"),
				"c_id": link_data.get("c_id")
			})

		params = {
			"url": final_payload,
			"name": name,
			"iconimage": self.poster,
			"fanart": self.fanart,
			"description": "%.2f GB" % size if size else "",
			"no_subs": no_subs_val,
			"subs": subs_val,
			"subtitles": subs_val,
			"season": str(self.season or " "),
			"episode": str(self.episode or " "),
			"mode": "3",
			"original_title": self.title,
			"id": self.tmdb_id,
			"data": "",
		}
		return "plugin://plugin.video.telemedia/?%s" % urlencode(params)
