# -*- coding: utf-8 -*-
import sys
import urllib.parse
import datetime

# ייבוא הרכיבים המקוריים של התוסף
from modules.router import routing, sys_exit_check

# --- החדרת תיקון תאריך ופרמטרים דינמיים לתפריטי Discover ---
if len(sys.argv) > 2 and sys.argv[2]:
    # 1. פירוק הפרמטרים ש-Kodi מעביר לתוסף לדיקשנרי פייתון מובנה
    # lstrip('?') מסיר את סימן השאלה מתחילת מחרוזת הארגומנטים
    raw_params = sys.argv[2].lstrip('?')
    query_params = urllib.parse.parse_qs(raw_params)
    
    # 2. בדיקה האם מדובר בפעולה של TMDB Discover
    if query_params.get('action') == ['tmdb_movies_discover']:
        # שליפת ה-URL הפנימי של TMDB מתוך הפרמטרים
        tmdb_url_list = query_params.get('url')
        
        if tmdb_url_list:
            tmdb_url = tmdb_url_list[0]
            
            # בדיקה האם הקישור מכיל את מחרוזת התאריך הלא מתורגמת
            if '[current_date]' in tmdb_url:
                # יצירת תאריך נוכחי בפורמט ש-TMDB דורש (YYYY-MM-DD)
                today_str = datetime.date.today().strftime('%Y-%m-%d')
                
                # החלפת הבלוק הסטטי בתאריך הדינמי של היום
                fixed_tmdb_url = tmdb_url.replace('[current_date]', today_str)
                
                # עדכון ה-URL המתוקן חזרה לתוך הפרמטרים
                query_params['url'] = [fixed_tmdb_url]
                
                # 3. בנייה מחדש של sys.argv[2] עם הנתונים המעודכנים ללא תווים שבורים
                sys.argv[2] = '?' + urllib.parse.urlencode(query_params, doseq=True)

# --- המשך הרצת הלוגיקה המקורית והרשמית של Forge ---
routing(sys)
if sys_exit_check():
    sys.exit(1)
