# -*- coding: utf-8 -*-
import json

from caches.settings_cache import default_setting_values, get_setting, set_default, set_setting
from modules import kodi_utils, settings

# logger = kodi_utils.logger


def window_theme_choice(params):
	if params["type"] == "theme":
		choices = kodi_utils.addon_themes()
		list_items = [{"line1": i["name"], "icon": kodi_utils.get_icon(i["icon"], "themes")} for i in choices]
		kwargs = {"items": json.dumps(list_items), "heading": "בחר ערכת נושא", "narrow_window": "true"}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice == None:
			return
		window_theme, window_theme_contrast, window_theme_name = choice["value"][0][2:], choice["value"][1], choice["name"]
		window_theme_opacity = get_setting("forge.window_theme_opacity", "CC")
		set_setting("window_theme_name", window_theme_name)
	else:
		choices = kodi_utils.addon_themes_opacity()
		list_items = [{"line1": i["name"]} for i in choices]
		kwargs = {"items": json.dumps(list_items), "heading": "בחר רמת שקיפות", "narrow_window": "true"}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice == None:
			return
		window_theme_opacity, window_theme_opacity_name = choice["value"], choice["name"]
		window_theme = get_setting("forge.window_theme", "FF1F2020")[2:]
		window_theme_contrast = get_setting("forge.window_theme_contrast", "FF4a4347")
		set_setting("window_theme_opacity", window_theme_opacity)
		set_setting("window_theme_opacity_name", window_theme_opacity_name)
	set_setting("window_theme", window_theme_opacity + window_theme)
	set_setting("window_theme_contrast", window_theme_contrast)


def rpdb_poster_format_choice(params):
	choices = [{"name": "default", "value": ""}, {"name": "blocks", "value": "&theme=blocks"}, {"name": "rounded", "value": "&theme=rounded-blocks"}]
	list_items = [{"line1": i["name"], "icon": kodi_utils.get_icon("rpdb_%s" % i["name"], "rpdb_posters", "jpg")} for i in choices]
	kwargs = {"items": json.dumps(list_items)}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return
	set_setting("rpdb_format", choice["value"])
	set_setting("rpdb_format_name", choice["name"])


def navigate_to_page_choice(params):
	def _builder():
		for item in start_list:
			if item == current_page:
				line1 = "[COLOR blue][B]עמוד %s   |   עמוד נוכחי[/B][/COLOR]" % item
			else:
				line1 = "עמוד %s" % item
			yield {"line1": line1}

	try:
		current_page, total_pages = int(params.get("current_page")), int(params.get("total_pages"))
		start_list = [i for i in range(1, total_pages + 1)]
		list_items = list(_builder())
		kwargs = {"items": json.dumps(list_items), "narrow_window": "true", "set_focus": current_page - 1}
		new_page = kodi_utils.select_dialog(start_list, **kwargs)
		if new_page == None or new_page == current_page:
			return
		url_params = json.loads(params["url_params"])
		url_params.update({"new_page": new_page, "refreshed": "true"})
		kodi_utils.container_update(url_params)
	except:
		return


def list_display_order_choice(params):
	from modules.meta_lists import list_display_choices

	list_type = params["list_type"]
	info = list_display_choices(list_type)
	choices = info["choices"]
	list_items = [{"line1": i[0]} for i in choices]
	kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return
	set_setting("%s.list_sort_name" % info["setting"], choice[0])
	set_setting("%s.list_sort" % info["setting"], choice[1])


def language_invoker_choice(params):
	from xml.dom.minidom import parse as mdParse

	kodi_utils.close_all_dialog()
	addon_xml = kodi_utils.translate_path("special://home/addons/plugin.video.fofo/addon.xml")
	root = mdParse(addon_xml)
	invoker_instance = root.getElementsByTagName("reuselanguageinvoker")[0].firstChild
	current_invoker_setting = invoker_instance.data
	new_value = {"true": "false", "false": "true"}[current_invoker_setting]
	if not kodi_utils.confirm_dialog(text="לשנות את [B]שימוש חוזר במפעיל השפה[/B] ל-%s?" % ("מופעל" if new_value == "true" else "כבוי")):
		return
	invoker_instance.data = new_value
	new_xml = str(root.toxml()).replace('<?xml version="1.0" ?>', "")
	with open(addon_xml, "w") as f:
		f.write(new_xml)
	set_setting("reuse_language_invoker", new_value)
	kodi_utils.execute_builtin("ActivateWindow(Home)", True)
	kodi_utils.update_local_addons()
	kodi_utils.disable_enable_addon()


def rescrape_actions_choice(params):
	set_focus = params.get("set_focus", 0)
	action_values, order_values = {0: "כבוי", 1: "אוטומטי", 2: "שאל"}, {0: "הכי גבוה", 1: "גבוה", 2: "בינוני", 3: "נמוך", 4: "הכי נמוך"}
	rescrape_settings = settings.all_rescrape_settings()
	choices = [
		dict(
			i,
			**{
				"line1": "%02d, %s" % (int(k[2]) + 1, i["name"]),
				"line2": "נוכחי | פעולה: [B]%s[/B] | סדר: [B]%s[/B]" % (action_values[k[1]], order_values[k[2]]),
				"value": i["value"],
				"action": k[1],
				"order": k[2],
			},
		)
		for i in kodi_utils.rescrape_items()
		for k in rescrape_settings
		if k[0] == i["value"]
	]
	choices = [dict(i, **{"position": c}) for c, i in enumerate(sorted(choices, key=lambda k: k["order"]))]
	kwargs = {
		"items": json.dumps(choices),
		"heading": "בחר מאפיינים עבור פונקציות סריקה מחדש",
		"multi_line": "true",
		"narrow_window": "true",
		"set_focus": set_focus,
	}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return
	choice_value, choice_action, choice_order = choice["value"], choice["action"], choice["order"]
	params["set_focus"] = choice["position"]
	choices = [{"line1": "הגדר פעולה", "action": "set_action"}, {"line1": "הגדר סדר", "action": "set_order"}]
	kwargs = {"items": json.dumps(choices), "heading": "בחר מאפיינים עבור פונקציות סריקה מחדש", "narrow_window": "true", "set_focus": set_focus}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return rescrape_actions_choice(params)
	action = choice["action"]
	if action == "set_action":
		choices = [{"line1": "כבוי", "value": "0"}, {"line1": "אוטומטי", "value": "1"}, {"line1": "שאל", "value": "2"}]
		heading, setting = "בחר ערך פעולה", "rescrape.%s" % choice_value
		kwargs = {"items": json.dumps(choices), "heading": heading, "narrow_window": "true"}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice == None:
			return rescrape_actions_choice(params)
		setting_value = choice["value"]
		set_setting(setting, setting_value)
	else:
		choices = [
			{"line1": "הכי גבוה", "value": "0"},
			{"line1": "גבוה", "value": "1"},
			{"line1": "בינוני", "value": "2"},
			{"line1": "נמוך", "value": "3"},
			{"line1": "הכי נמוך", "value": "4"},
		]
		heading, setting = "בחר סדר", "rescrape.%s.order"
		kwargs = {"items": json.dumps(choices), "heading": heading, "narrow_window": "true"}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice == None:
			return rescrape_actions_choice(params)
		setting_value = choice["value"]
		new_settings = list(rescrape_settings)
		new_settings.remove((choice_value, choice_action, choice_order))
		new_settings.insert(int(setting_value), (choice_value, choice_action, setting_value))
		for item in [(i[0], str(c)) for c, i in enumerate(new_settings)]:
			set_setting(setting % item[0], item[1])
		params["set_focus"] = int(setting_value)
	return rescrape_actions_choice(params)


def context_menu_choice(params):
	choices = kodi_utils.context_menu_items()
	current_settings = settings.cm_enabled()
	try:
		preselect = [choices.index(i) for i in choices if i["value"] in current_settings]
	except:
		preselect = []
	list_items = [{"line1": i["name"]} for i in choices]
	kwargs = {"items": json.dumps(list_items), "heading": "אפשר תוכן עבור תפריט ההקשר", "multi_choice": "true", "preselect": preselect}
	selection = kodi_utils.select_dialog(choices, **kwargs)
	if selection == []:
		kodi_utils.ok_dialog(text="עליך לבחור לפחות פריט אחד")
		return context_menu_choice(params)
	elif selection == None:
		return
	selection = [i["value"] for i in selection]
	set_setting("context_menu.enabled", ",".join(selection))


def context_menu_order_choice(params):
	set_focus = params.get("set_focus", 0)
	all_items = kodi_utils.context_menu_items()
	enabled_items = settings.cm_enabled()
	current_order = settings.cm_current_order()
	active_items = [i for i in all_items if i["value"] in enabled_items]
	sorted_active_items = sorted(active_items, key=lambda k: current_order.index(k["value"]))
	choices = [
		{
			"line1": "מיקום %02d" % (count + 1),
			"line2": "כרגע [B]%s[/B]" % (item["name"]),
			"current_item": item,
			"display_position": count + 1,
			"position": count,
		}
		for count, item in enumerate(sorted_active_items)
	]
	kwargs = {"items": json.dumps(choices), "heading": "בחר סדר עבור תפריט ההקשר", "multi_line": "true", "narrow_window": "true", "set_focus": set_focus}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return
	current_item = choice["current_item"]
	position = choice["position"]
	display_position = choice["display_position"]
	choices = [{"line1": item["name"], "value": item["value"]} for item in active_items if item != current_item]
	kwargs = {"items": json.dumps(choices), "narrow_window": "true", "heading": "בחר פריט תפריט הקשר עבור מיקום %02d" % display_position}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice != None:
		value = choice["value"]
		current_order.remove(value)
		current_order.insert(position, value)
		current_order = [str(i) for i in current_order]
		set_setting("context_menu.order", ",".join(current_order))
		params["set_focus"] = position
	return context_menu_order_choice(params)


def personallists_manager_choice(params):
	from indexers.personal_lists import get_all_personal_lists, make_new_personal_list, new_list_check

	icon = params.get("icon", None) or kodi_utils.get_icon("lists")
	list_type = params["list_type"]
	all_lists = get_all_personal_lists(get_setting("forge.personal_list.list_sort", "0"))
	choices = []
	if not all_lists:
		action = "add_new"
	else:
		choices = [("הוסף לרשימה אישית...", "add"), ("הסר מרשימה אישית...", "remove"), ("הוסף לרשימה אישית [B]חדשה[/B]...", "add_new")]
		list_items = [{"line1": item[0], "icon": icon} for item in choices]
		kwargs = {"items": json.dumps(list_items), "heading": "מנהל רשימות אישיות"}
		action = kodi_utils.select_dialog([i[1] for i in choices], **kwargs)
		if action == None:
			return
	if action == "add_new":
		list_name, author = make_new_personal_list({"external_creation": "true"})
		if not list_name:
			return kodi_utils.notification("שגיאה ביצירת הרשימה", 3000)
		action = "add"
	else:
		new_template, normal_template = "[COLOR FF008EB2]%s [I](x%02d)[/I][/COLOR]", "%s [I](x%02d)[/I]"
		choices = [((new_template if new_list_check(i["seen"]) else normal_template) % (i["name"], i["total"]), (i["name"], i["author"])) for i in all_lists]
		list_items = [{"line1": i[0]} for i in choices]
		kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
		try:
			list_name, author = kodi_utils.select_dialog([i[1] for i in choices], **kwargs)
		except:
			return
	if action == "add":
		new_contents = {
			"media_id": params["tmdb_id"],
			"title": params["title"],
			"type": list_type,
			"release_date": params["premiered"],
			"date_added": params["current_time"],
		}
	else:
		new_contents = params["tmdb_id"]
	from caches.personal_lists_cache import personal_lists_cache

	result = personal_lists_cache.add_remove_list_item(list_name, author, action, new_contents)
	kodi_utils.notification(result, 3000)
	if action == "remove":
		kodi_utils.refresh_after_action(list_name)


def tmdblists_manager_choice(params):
	from caches.tmdb_lists import tmdb_lists_cache
	from indexers.tmdb_lists import (
		add_remove_watchfavs,
		add_to_tmdb_list,
		check_item_status,
		check_item_status_watchfav,
		get_all_tmdb_lists,
		make_new_tmdb_list,
		remove_from_tmdb_list,
	)

	icon = params.get("icon", None) or kodi_utils.get_icon("tmdb")
	media_type, tmdb_id = params["media_type"], params["tmdb_id"]
	choices = [
		("הוסף לרשימת TMDb...", "list_add"),
		("הסר מרשימת TMDb...", "list_remove"),
		("הוסף לרשימת TMDb [B]חדשה[/B]...", "list_add_new"),
		("הוסף ל[B]רשימת צפייה[/B]", "watchlist_add"),
		("הסר מ[B]רשימת צפייה[/B]", "watchlist_remove"),
		("הוסף ל[B]מועדפים[/B]", "favorites_add"),
		("הסר מ[B]מועדפים[/B]", "favorites_remove"),
	]
	list_items = [{"line1": item[0], "icon": icon} for item in choices]
	kwargs = {"items": json.dumps(list_items), "heading": "מנהל רשימות TMDb"}
	action = kodi_utils.select_dialog([i[1] for i in choices], **kwargs)
	if action == None:
		return
	if action.startswith(("watchlist", "favorites")):
		from indexers.tmdb_lists import check_item_status_watchfav

		list_id = action.split("_")[0]
		status = True if "add" in action else False
		item_in_list = check_item_status_watchfav(list_id, media_type, tmdb_id)
		if item_in_list and status:
			return kodi_utils.notification("הפריט כבר נמצא ב-%s" % list_id.capitalize())
		if not item_in_list and not status:
			return kodi_utils.notification("הפריט אינו נמצא ב-%s" % list_id.capitalize())
		success = add_remove_watchfavs(media_type, tmdb_id, list_id, status)
		tmdb_lists_cache.clear_watchfavrecs(list_id, media_type)
	else:
		from indexers.tmdb_lists import add_to_tmdb_list, check_item_status, get_all_tmdb_lists, make_new_tmdb_list, remove_from_tmdb_list

		all_lists = get_all_tmdb_lists("0")
		if not all_lists:
			action = "list_add_new"
		if action == "list_add_new":
			list_id = make_new_tmdb_list({"external_creation": "true"})
			if not list_id:
				return kodi_utils.notification("שגיאה ביצירת הרשימה")
			action, item_in_list = "list_add", False
		else:
			choices = [("%s [I](x%02d)[/I]" % (i["name"], i["number_of_items"]), i["id"]) for i in all_lists]
			list_items = [{"line1": i[0]} for i in choices]
			kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
			list_id = kodi_utils.select_dialog([i[1] for i in choices], **kwargs)
			if list_id == None:
				return
			item_in_list = check_item_status(list_id, media_type, tmdb_id)
		new_contents = {"items": [{"media_type": media_type, "media_id": tmdb_id}]}
		if action == "list_add":
			if item_in_list:
				return kodi_utils.notification("הפריט כבר נמצא ברשימה")
			success = add_to_tmdb_list(list_id, new_contents)
		elif action == "list_remove":
			if not item_in_list:
				return kodi_utils.notification("הפריט אינו נמצא ברשימה")
			success = remove_from_tmdb_list(list_id, new_contents)
		tmdb_lists_cache.clear_list(list_id)
		tmdb_lists_cache.clear_all_lists()
	kodi_utils.notification("הצליח" if success else "נכשל", 3000)
	if "remove" in action:
		kodi_utils.refresh_after_action(str(list_id))


def favorites_manager_choice(params):
	from caches.favorites_cache import favorites_cache

	media_type, tmdb_id, title = params.get("media_type"), params.get("tmdb_id"), params.get("title")
	current_favorites = favorites_cache.get_favorites(media_type)
	people_favorite = media_type == "people"
	current_favorite = any(i["tmdb_id"] == tmdb_id for i in current_favorites)
	if current_favorite:
		function, text = favorites_cache.delete_favourite, "להסיר מהמועדפים?"
		param_refresh = params.get("refresh", None)
		if param_refresh == None:
			refresh = any(i in kodi_utils.folder_path() for i in ("action=favorites_movies", "action=favorites_tvshows", "action=favorites_anime"))
		else:
			refresh = param_refresh == "true"
	else:
		function, text, refresh = favorites_cache.set_favourite, "להוסיף למועדפים?", False
	heading = title.split("|")[0] if people_favorite else title
	if not kodi_utils.confirm_dialog(heading=heading, text=text):
		return
	success = function(media_type, tmdb_id, title)
	if success:
		if refresh:
			kodi_utils.refresh_after_action(refresh_when_internal=True)
		kodi_utils.notification("הצליח", 3500)
	else:
		kodi_utils.notification("שגיאה", 3500)
	if people_favorite and success:
		return text


def quick_add_toggle_choice(params):
	from modules.quick_add import run_toggle

	return run_toggle(params)


def quick_add_target_choice(params):
	from modules import quick_add

	icon = kodi_utils.get_icon("lists")
	kinds = [
		("רשימת צפייה Trakt", "trakt_watchlist"),
		("אוסף Trakt", "trakt_collection"),
		("רשימת צפייה TMDb", "tmdb_watchlist"),
		("מועדפי TMDb", "tmdb_favorites"),
		("מועדפי Forge", "forge_favorites"),
		("רשימה אישית Trakt...", "pick_trakt_list"),
		("רשימת TMDb...", "pick_tmdb_list"),
		("רשימה אישית Forge...", "pick_forge_list"),
	]
	list_items = [{"line1": item[0], "icon": icon} for item in kinds]
	kwargs = {"items": json.dumps(list_items), "heading": "יעד הוספה מהירה"}
	choice = kodi_utils.select_dialog([item[1] for item in kinds], **kwargs)
	if choice is None:
		return
	if choice in quick_add.STATIC_KINDS:
		token, label = quick_add.encode_target(choice), quick_add.REGISTRY[choice]["friendly"]
	elif choice == "pick_trakt_list":
		if not settings.trakt_user_active():
			return kodi_utils.notification("אין חשבון Trakt פעיל", 3500)
		from apis import trakt_api

		selected = trakt_api.get_trakt_list_selection(["personal"])
		if not selected:
			return
		token, label = quick_add.encode_target("trakt_list", user=selected["user"], slug=selected["slug"]), selected["name"]
	elif choice == "pick_tmdb_list":
		if not settings.tmdblist_user_active():
			return kodi_utils.notification("אין חשבון TMDb פעיל", 3500)
		from indexers.tmdb_lists import get_all_tmdb_lists

		all_lists = get_all_tmdb_lists("0")
		if not all_lists:
			return kodi_utils.notification("לא נמצאו רשימות TMDb", 3500)
		choices = [("%s [I](x%02d)[/I]" % (i["name"], i["number_of_items"]), (str(i["id"]), i["name"])) for i in all_lists]
		selection = kodi_utils.select_dialog([i[1] for i in choices], **{"items": json.dumps([{"line1": i[0]} for i in choices]), "narrow_window": "true"})
		if not selection:
			return
		token, label = quick_add.encode_target("tmdb_list", list_id=selection[0]), selection[1]
	else:
		from indexers.personal_lists import get_all_personal_lists

		all_lists = get_all_personal_lists(get_setting("forge.personal_list.list_sort", "0"))
		if not all_lists:
			return kodi_utils.notification("לא נמצאו רשימות אישיות", 3500)
		choices = [("%s [I](x%02d)[/I]" % (i["name"], i["total"]), (i["name"], i["author"])) for i in all_lists]
		selection = kodi_utils.select_dialog([i[1] for i in choices], **{"items": json.dumps([{"line1": i[0]} for i in choices]), "narrow_window": "true"})
		if not selection:
			return
		token, label = quick_add.encode_target("forge_list", name=selection[0], author=selection[1]), selection[0]
	set_setting("context_menu.quick_add_target", token)
	set_setting("context_menu.quick_add_target_label", label)
	kodi_utils.notification("יעד הוספה מהירה: %s" % label, 3000)


def extras_lists_choice(params={}):
	current_settings = settings.extras_enabled()
	choices = kodi_utils.extras_items()
	list_items = [{"line1": i["name"]} for i in choices]
	try:
		preselect = [choices.index(i) for i in choices if i["value"] in current_settings]
	except:
		preselect = []
	kwargs = {"items": json.dumps(list_items), "heading": "אפשר תוכן עבור רשימות תוספות", "multi_choice": "true", "preselect": preselect}
	selection = kodi_utils.select_dialog(choices, **kwargs)
	if selection == []:
		kodi_utils.ok_dialog(text="עליך לבחור לפחות פריט אחד")
		return extras_lists_choice(params)
	elif selection == None:
		return
	selection = [str(i["value"]) for i in selection]
	set_setting("extras.enabled", ",".join(selection))


def extras_order_choice(params={}):
	all_items = kodi_utils.extras_items()
	enabled_items = settings.extras_enabled()
	current_order = settings.extras_order()
	active_items = [i for i in all_items if i["value"] in enabled_items]
	active_items = sorted(active_items, key=lambda k: current_order.index(k["value"]))
	choices = [
		{
			"line1": "מיקום %02d" % (count + 1),
			"line2": "כרגע [B]%s[/B]" % (item["name"]),
			"current_item": item,
			"display_position": count + 1,
			"position": count,
		}
		for count, item in enumerate(active_items)
	]
	kwargs = {"items": json.dumps(choices), "heading": "בחר סדר עבור רשימות תוספות", "multi_line": "true", "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		if params.get("remake", False):
			from windows.base_window import ExtrasUtils

			ExtrasUtils().run()
		return
	current_item = choice["current_item"]
	position = choice["position"]
	display_position = choice["display_position"]
	choices = [{"line1": item["name"], "value": item["value"]} for item in active_items if item != current_item]
	kwargs = {"items": json.dumps(choices), "narrow_window": "true", "heading": "בחר פריט רשימה עבור מיקום %02d" % display_position}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice != None:
		value = choice["value"]
		current_order.remove(value)
		current_order.insert(position, value)
		current_order = [str(i) for i in current_order]
		set_setting("extras.order", ",".join(current_order))
		params["remake"] = True
	return extras_order_choice(params)


def preferred_filters_choice(params):
	from modules.source_utils import include_exclude_filters, source_filters

	def _default_choices():
		return [
			{"name": "מיון 1", "value": "בחר פרמטר מיון ראשון"},
			{"name": "מיון 2", "value": "בחר פרמטר מיון שני"},
			{"name": "מיון 3", "value": "בחר פרמטר מיון שלישי"},
			{"name": "מיון 4", "value": "בחר פרמטר מיון רביעי"},
			{"name": "מיון 5", "value": "בחר פרמטר מיון חמישי"},
		]

	def _beginning_choices():
		defaults = _default_choices()
		for count, item in enumerate(auto_settings):
			defaults[count]["value"] = item
		return defaults

	def _rechoose_checker(choice):
		if choice["value"].startswith("בחר"):
			return (choice, True)
		clear_choice = kodi_utils.confirm_dialog(
			heading="פרמטר נוכחי פעיל",
			text="משבצת מיון זו כבר מלאה.[CR]אנא בחר איזו פעולה לבצע.",
			ok_label="בנה מחדש",
			cancel_label="נקה משבצת",
		)
		if clear_choice == None:
			new_default, ask_params = (choice, False)
		else:
			choice_index = choices.index(choice)
			new_default = _default_choices()[choice_index]
			choices[choice_index] = new_default
		return (new_default, clear_choice)

	def _param_choices(choice):
		filter_keys = include_exclude_filters()
		disabled_filters = [v for k, v in filter_keys.items() if settings.filter_status(k) == 1]
		s_filters = source_filters()
		filters_choice = [(i[0], i[1].replace("[B]", "").replace("[/B]", "")) for i in s_filters]
		filters_choice = [i for i in filters_choice if i[1] not in disabled_filters]
		unused_filters = [i for i in filters_choice if i[1] not in auto_settings]
		param_list_items = [{"line1": i[0], "line2": i[1]} for i in unused_filters]
		param_kwargs = {
			"items": json.dumps(param_list_items),
			"multi_line": "true",
			"heading": "בחר פרמטרים למיון לראש הרשימה בנגינה אוטומטית",
			"narrow_window": "true",
		}
		param_choice = kodi_utils.select_dialog(unused_filters, **param_kwargs)
		if param_choice == None:
			return ""
		choice["value"] = param_choice[1]
		return choice

	def _make_settings():
		new_settings = [i["value"] for i in choices if not i["value"].startswith("בחר")]
		if not new_settings:
			set_setting("filter.preferred_filters", "empty_setting")
		else:
			set_setting("filter.preferred_filters", ", ".join(new_settings))

	auto_settings = settings.preferred_filters()
	choices = params.get("choices") or _beginning_choices()
	list_items = [{"line1": i["name"], "line2": i["value"]} for i in choices]
	kwargs = {"items": json.dumps(list_items), "multi_line": "true", "heading": "בחר פרמטרים למיון לראש הרשימה בנגינה אוטומטית", "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return _make_settings()
	choice, ask_params = _rechoose_checker(choice)
	if not ask_params:
		return preferred_filters_choice({"choices": choices})
	param_choice = _param_choices(choice)
	if not param_choice:
		return preferred_filters_choice({"choices": choices})
	choices[choices.index(choice)] = param_choice
	_make_settings()
	return preferred_filters_choice({"choices": choices})


def tmdb_api_check_choice(params):
	from apis.tmdb_api import movie_details

	data = movie_details("299534", settings.tmdb_api_key())
	if not data.get("success", True):
		text = 'ישנה בעיה עם מפתח ה-API שלך.[CR][B]"שגיאה: %s"[/B]' % data.get("status_message", "")
	else:
		text = "מפתח ה-API של TMDb מאופשר ועובד כראוי"
	return kodi_utils.ok_dialog(text=text)


def clear_sources_folder_choice(params):
	setting_id = params["setting_id"]
	set_default(["%s.display_name" % setting_id, "%s.movies_directory" % setting_id, "%s.tv_shows_directory" % setting_id])


def widget_refresh_timer_choice(params):
	choices = [{"name": "כבוי", "value": "0"}]
	choices.extend([{"name": "כל %s דקות" % i, "value": str(i)} for i in range(5, 25, 5)])
	choices.extend([{"name": "כל %s דקות" % i, "value": str(i)} for i in range(30, 65, 10)])
	choices.extend([{"name": "כל %s שעות" % (float(i) / 60), "value": str(i)} for i in range(90, 720, 30)])
	list_items = [{"line1": i["name"]} for i in choices]
	kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return
	set_setting("widget_refresh_timer", choice["value"])
	set_setting("widget_refresh_timer_name", choice["name"])


def limit_number_quality_choice(params):
	choices = [{"name": "כבוי", "value": "0"}]
	choices.extend([{"name": "%sx לכל איכות" % i, "value": str(i)} for i in range(1, 5)])
	choices.extend([{"name": "%sx לכל איכות" % i, "value": str(i)} for i in range(5, 205, 5)])
	list_items = [{"line1": i["name"]} for i in choices]
	kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return
	set_setting("results.limit_number_quality", choice["value"])
	set_setting("results.limit_number_quality_name", choice["name"])


def limit_number_total_choice(params):
	choices = [{"name": "כבוי", "value": "0"}]
	choices.extend([{"name": "%sx סך הכל תוצאות" % i, "value": str(i)} for i in range(1, 10)])
	choices.extend([{"name": "%sx סך הכל תוצאות" % i, "value": str(i)} for i in range(10, 1000, 5)])
	list_items = [{"line1": i["name"]} for i in choices]
	kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return
	set_setting("results.limit_number_total", choice["value"])
	set_setting("results.limit_number_total_name", choice["name"])


def external_scraper_choice(params):
	from modules.utils import append_module_to_syspath, manual_function_import

	try:
		results = kodi_utils.jsonrpc_get_addons("xbmc.python.module")
		results = [i for i in results if kodi_utils.addon_enabled(i["addonid"])]
	except:
		return
	list_items = [{"line1": i["name"], "icon": i["thumbnail"]} for i in results]
	kwargs = {"items": json.dumps(list_items)}
	choice = kodi_utils.select_dialog(results, **kwargs)
	if choice == None:
		return
	module_id, module_name = choice["addonid"], choice["name"]
	success = False
	try:
		append_module_to_syspath("special://home/addons/%s/lib" % module_id)
		main_folder_name = module_id.split(".")[-1]
		sourceDict = manual_function_import(main_folder_name, "sources")(specified_folders=["torrents"])
		success = True
	except:
		pass
	if success:
		try:
			set_setting("external_scraper.module", module_id)
			set_setting("external_scraper.name", module_name)
			set_setting("provider.external", "true")
			kodi_utils.ok_dialog(text="הצליח.[CR][B]%s[/B] הוגדר כסורק חיצוני" % module_name)
		except:
			kodi_utils.ok_dialog(text="שגיאה")
	else:
		kodi_utils.ok_dialog(text="הרכיב [B]%s[/B] אינו תואם.[CR]אנא בחר רכיב אחר..." % module_name.upper())
		return external_scraper_choice(params)


def audio_filters_choice(params={}):
	from modules.source_utils import audio_filter_choices

	icon = kodi_utils.get_icon("audio")
	audio_filters = audio_filter_choices()
	list_items = [{"line1": item[0], "line2": item[1], "icon": icon} for item in audio_filters]
	try:
		preselect = [audio_filters.index(item) for item in audio_filters if item[1] in settings.audio_filters()]
	except:
		preselect = []
	kwargs = {
		"items": json.dumps(list_items),
		"heading": "בחר מאפייני שמע להחרגה",
		"multi_choice": "true",
		"multi_line": "true",
		"preselect": preselect,
	}
	selection = kodi_utils.select_dialog([i[1] for i in audio_filters], **kwargs)
	if selection == None:
		return
	if selection == []:
		set_setting("filter_audio", "empty_setting")
	else:
		set_setting("filter_audio", ", ".join(selection))


def genres_choice(params):
	genres_list, genres, poster = params["genres_list"], params["genres"], params["poster"]
	genre_list = [i for i in genres_list if i["name"] in genres]
	if not genre_list:
		kodi_utils.notification("אין תוצאות", 2500)
		return None
	list_items = [{"line1": i["name"], "icon": poster} for i in genre_list]
	kwargs = {"items": json.dumps(list_items)}
	return kodi_utils.select_dialog([i["id"] for i in genre_list], **kwargs)


def keywords_choice(params):
	media_type, meta = params["media_type"], params["meta"]
	keywords, tmdb_id, poster = meta.get("keywords", []), meta["tmdb_id"], meta["poster"]
	if keywords:
		keywords = keywords.get("keywords") or keywords.get("results")
	else:
		kodi_utils.show_busy_dialog()
		from apis.tmdb_api import tmdb_movie_keywords, tmdb_tv_keywords

		if media_type == "movie":
			function, key = tmdb_movie_keywords, "keywords"
		else:
			function, key = tmdb_tv_keywords, "results"
		try:
			keywords = function(tmdb_id)[key]
		except:
			keywords = []
		kodi_utils.hide_busy_dialog()
	if not keywords:
		kodi_utils.notification("אין תוצאות", 2500)
		return None
	list_items = [{"line1": i["name"], "icon": poster} for i in keywords]
	kwargs = {"items": json.dumps(list_items)}
	return kodi_utils.select_dialog([i["id"] for i in keywords], **kwargs)


def random_choice(params):
	meta, poster, return_choice = params.get("meta"), params.get("poster"), params.get("return_choice", "false")
	meta = params.get("meta", None)
	list_items = [{"line1": "ניגון אקראי בודד", "icon": poster}, {"line1": "ניגון אקראי מתמשך", "icon": poster}]
	choices = ["play_random", "play_random_continual"]
	kwargs = {"items": json.dumps(list_items), "heading": "בחר סוג ניגון אקראי..."}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if return_choice == "true":
		return choice
	if choice == None:
		return
	from modules.episode_tools import EpisodeTools

	exec("EpisodeTools(meta).%s()" % choice)


def trakt_manager_choice(params):
	if not settings.trakt_user_active():
		return kodi_utils.notification("אין חשבון Trakt פעיל", 3500)
	tmdb_id, tvdb_id, imdb_id, media_type = params["tmdb_id"], params["tvdb_id"], params["imdb_id"], params["media_type"]
	icon = params.get("icon", None) or kodi_utils.get_icon("trakt")
	choices = [
		("הוסף ל[B]רשימת צפייה[/B]", "add_watchlist"),
		("הסר מ[B]רשימת צפייה[/B]", "remove_watchlist"),
		("הוסף ל[B]אוסף[/B]", "add_collection"),
		("הסר מ[B]אוסף[/B]", "remove_collection"),
		("הוסף ל[B]רשימה אישית[/B]...", "add"),
		("הסר מ[B]רשימה אישית[/B]...", "remove"),
	]
	list_items = [{"line1": item[0], "icon": icon} for item in choices]
	kwargs = {"items": json.dumps(list_items), "heading": "מנהל רשימות Trakt"}
	choice = kodi_utils.select_dialog([i[1] for i in choices], **kwargs)
	if choice == None:
		return
	from apis import trakt_api

	if media_type == "movie":
		key, media_key, media_id = ("movies", "tmdb", int(tmdb_id))
	else:
		key = "shows"
		media_ids = [(tmdb_id, "tmdb"), (imdb_id, "imdb"), (tvdb_id, "tvdb")]
		media_id, media_key = next(item for item in media_ids if item[0] not in ("None", None, ""))
		if media_id in (tmdb_id, tvdb_id):
			media_id = int(media_id)
	data = {key: [{"ids": {media_key: media_id}}]}
	if choice == "add_watchlist":
		return trakt_api.add_to_watchlist(data)
	if choice == "remove_watchlist":
		return trakt_api.remove_from_watchlist(data)
	if choice == "add_collection":
		return trakt_api.add_to_collection(data)
	if choice == "remove_collection":
		return trakt_api.remove_from_collection(data)
	selected = trakt_api.get_trakt_list_selection(["personal"])
	if selected == None:
		return
	trakt_api.add_to_list(selected["user"], selected["slug"], data) if choice == "add" else trakt_api.remove_from_list(selected["user"], selected["slug"], data)


def episode_groups_choice(params):
	from modules.metadata import episode_groups

	episode_group_types = {1: "תאריך שידור מקורי", 2: "מוחלט", 3: "DVD", 4: "דיגיטלי", 5: "קשת סיפורית", 6: "הפקה", 7: "טלוויזיה"}
	meta = params.get("meta")
	poster = params.get("poster") or kodi_utils.get_icon("box_office")
	groups = episode_groups(meta["tmdb_id"])
	if not groups:
		kodi_utils.notification("אין קבוצות פרקים לבחירה.")
		return None
	list_items = [
		{
			"line1": "%s | סדר %s | %d קבוצות | %02d פרקים"
			% (item["name"], episode_group_types[item["type"]], item["group_count"], item["episode_count"]),
			"line2": item["description"],
			"icon": poster,
		}
		for item in groups
	]
	kwargs = {"items": json.dumps(list_items), "heading": "קבוצות פרקים", "enable_context_menu": "true", "enumerate": "true", "multi_line": "true"}
	choice = kodi_utils.select_dialog([i["id"] for i in groups], **kwargs)
	return choice


def assign_episode_group_choice(params):
	from caches.episode_groups_cache import episode_groups_cache
	from modules import metadata

	tmdb_id = params["meta"]["tmdb_id"]
	current_group = episode_groups_cache.get(tmdb_id)
	if current_group:
		action = kodi_utils.confirm_dialog(text="להגדיר קבוצה חדשה או לנקות את הקבוצה הנוכחית?", ok_label="הגדר חדש", cancel_label="נקה", default_control=10)
		if action == None:
			return
		if not action:
			episode_groups_cache.delete(tmdb_id)
			return kodi_utils.notification("הצליח", 2000)
	choice = episode_groups_choice(params)
	if choice == None:
		return
	group_details = metadata.group_details(choice)
	group_data = {"name": group_details["name"], "id": group_details["id"]}
	episode_groups_cache.set(tmdb_id, group_data)
	kodi_utils.notification("הצליח", 2000)


def playback_choice(params):
	from modules import metadata
	from modules.debrid import debrid_for_ext_cache_check
	from modules.source_utils import get_aliases_titles, make_alias_dict
	from modules.utils import get_datetime

	media_type, season, episode, episode_id = params.get("media_type"), params.get("season", ""), params.get("episode", ""), params.get("episode_id", None)
	playcount = params.get("playcount", "0")
	playback_key = settings.playback_key()
	play_mode = "playback.%s" % playback_key
	meta = params.get("meta")
	try:
		meta = json.loads(meta)
	except:
		pass
	if not isinstance(meta, dict):
		function = metadata.movie_meta if media_type == "movie" else metadata.tvshow_meta
		meta = function("tmdb_id", meta, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	poster = meta.get("poster") or kodi_utils.get_icon("box_office")
	aliases = get_aliases_titles(make_alias_dict(meta, meta["title"]))
	check_cache_status, check_cache_toggle = ("כבוי", "false") if settings.external_cache_check() else ("מופעל", "true")
	items = [{"line": "בחר מקור", "function": "scrape"}, {"line": "סרוק מחדש ובחר מקור", "function": "clear_and_rescrape"}]
	if debrid_for_ext_cache_check():
		items.append({"line": "סרוק מחדש עם בדיקת מטמון חיצונית [B]%s[/B]" % check_cache_status, "function": "rescrape_external_cache_check"})
	items.extend(
		[
			{"line": "נקה מטמון Debrid והצג תוצאות", "function": "clear_debrid_cache_and_show"},
			{"line": "סרוק עם כל הסורקים החיצוניים", "function": "scrape_with_disabled"},
			{"line": "סרוק תוך התעלמות מכל המסננים", "function": "scrape_with_filters_ignored"},
		]
	)
	if media_type == "episode":
		items.append({"line": "סרוק עם ערך קבוצות פרקים מותאם אישית", "function": "scrape_with_episode_group"})
	if aliases:
		items.append({"line": "סרוק עם שם נרדף (Alias)", "function": "scrape_with_aliases"})
	items.append({"line": "סרוק עם ערכים מותאמים אישית", "function": "scrape_with_custom_values"})
	list_items = [{"line1": i["line"], "icon": poster} for i in items]
	kwargs = {"items": json.dumps(list_items), "heading": "אפשרויות ניגון"}
	choice = kodi_utils.select_dialog([i["function"] for i in items], **kwargs)
	if choice == None:
		return kodi_utils.notification("בוטל", 2500)
	if choice in ("clear_and_rescrape", "scrape_with_custom_values"):
		kodi_utils.show_busy_dialog()
		from caches.base_cache import clear_cache
		from caches.external_cache import ExternalCache

		clear_cache("internal_scrapers", silent=True)
		ExternalCache().delete_cache_single(media_type, str(meta["tmdb_id"]))
		kodi_utils.hide_busy_dialog()
	if choice == "scrape":
		if media_type == "movie":
			play_params = {"mode": play_mode, "media_type": "movie", "tmdb_id": meta["tmdb_id"], "autoplay": "false", "prescrape": "false"}
		else:
			play_params = {
				"mode": play_mode,
				"media_type": "episode",
				"tmdb_id": meta["tmdb_id"],
				"season": season,
				"episode": episode,
				"autoplay": "false",
				"prescrape": "false",
			}
	elif choice == "clear_and_rescrape":
		if media_type == "movie":
			play_params = {"mode": play_mode, "media_type": "movie", "tmdb_id": meta["tmdb_id"], "autoplay": "false", "prescrape": "false"}
		else:
			play_params = {
				"mode": play_mode,
				"media_type": "episode",
				"tmdb_id": meta["tmdb_id"],
				"season": season,
				"episode": episode,
				"autoplay": "false",
				"prescrape": "false",
			}
	elif choice == "rescrape_external_cache_check":
		if media_type == "movie":
			play_params = {
				"mode": play_mode,
				"media_type": "movie",
				"tmdb_id": meta["tmdb_id"],
				"external_cache_check": check_cache_toggle,
				"prescrape": "false",
			}
		else:
			play_params = {
				"mode": play_mode,
				"media_type": "episode",
				"tmdb_id": meta["tmdb_id"],
				"season": season,
				"episode": episode,
				"external_cache_check": check_cache_toggle,
				"prescrape": "false",
			}
	elif choice == "clear_debrid_cache_and_show":
		from caches.debrid_cache import debrid_cache

		debrid_cache.clear_cache()
		if media_type == "movie":
			play_params = {"mode": play_mode, "media_type": "movie", "tmdb_id": meta["tmdb_id"], "autoplay": "false", "prescrape": "false"}
		else:
			play_params = {
				"mode": play_mode,
				"media_type": "episode",
				"tmdb_id": meta["tmdb_id"],
				"season": season,
				"episode": episode,
				"autoplay": "false",
				"prescrape": "false",
			}
	elif choice == "scrape_with_disabled":
		if media_type == "movie":
			play_params = {
				"mode": play_mode,
				"media_type": "movie",
				"tmdb_id": meta["tmdb_id"],
				"disabled_ext_ignored": "true",
				"prescrape": "false",
				"autoplay": "false",
			}
		else:
			play_params = {
				"mode": play_mode,
				"media_type": "episode",
				"tmdb_id": meta["tmdb_id"],
				"season": season,
				"episode": episode,
				"disabled_ext_ignored": "true",
				"prescrape": "false",
				"autoplay": "false",
			}
	elif choice == "scrape_with_filters_ignored":
		if media_type == "movie":
			play_params = {
				"mode": play_mode,
				"media_type": "movie",
				"tmdb_id": meta["tmdb_id"],
				"ignore_scrape_filters": "true",
				"prescrape": "false",
				"autoplay": "false",
			}
		else:
			play_params = {
				"mode": play_mode,
				"media_type": "episode",
				"tmdb_id": meta["tmdb_id"],
				"season": season,
				"episode": episode,
				"ignore_scrape_filters": "true",
				"prescrape": "false",
				"autoplay": "false",
			}
		kodi_utils.set_property("fs_filterless_search", "true")
	elif choice == "scrape_with_episode_group":
		choice = episode_groups_choice({"meta": meta, "poster": poster})
		if choice == None:
			return playback_choice(params)
		episode_details = metadata.group_episode_data(metadata.group_details(choice), episode_id, season, episode)
		if not episode_details:
			kodi_utils.notification("אין פרק תואם")
			return playback_choice(params)
		play_params = {
			"mode": play_mode,
			"media_type": "episode",
			"tmdb_id": meta["tmdb_id"],
			"season": season,
			"episode": episode,
			"prescrape": "false",
			"custom_season": episode_details["season"],
			"custom_episode": episode_details["episode"],
		}
	elif choice == "scrape_with_aliases":
		if len(aliases) == 1:
			custom_title = aliases[0]
		else:
			list_items = [{"line1": i, "icon": poster} for i in aliases]
			kwargs = {"items": json.dumps(list_items)}
			custom_title = kodi_utils.select_dialog(aliases, **kwargs)
			if custom_title == None:
				return kodi_utils.notification("בוטל", 2500)
		custom_title = kodi_utils.kodi_dialog().input("כותרת", defaultt=custom_title)
		if not custom_title:
			return kodi_utils.notification("בוטל", 2500)
		if media_type in ("movie", "movies"):
			play_params = {"mode": play_mode, "media_type": "movie", "tmdb_id": meta["tmdb_id"], "custom_title": custom_title, "prescrape": "false"}
		else:
			play_params = {
				"mode": play_mode,
				"media_type": "episode",
				"tmdb_id": meta["tmdb_id"],
				"season": season,
				"episode": episode,
				"custom_title": custom_title,
				"prescrape": "false",
			}
	elif choice == "scrape_with_custom_values":
		default_title, default_year = meta["title"], str(meta["year"])
		if media_type in ("movie", "movies"):
			play_params = {"mode": play_mode, "media_type": "movie", "tmdb_id": meta["tmdb_id"], "prescrape": "false"}
		else:
			play_params = {"mode": play_mode, "media_type": "episode", "tmdb_id": meta["tmdb_id"], "season": season, "episode": episode, "prescrape": "false"}
		if aliases:
			if len(aliases) == 1:
				alias_title = aliases[0]
			list_items = [{"line1": i, "icon": poster} for i in aliases]
			kwargs = {"items": json.dumps(list_items)}
			alias_title = kodi_utils.select_dialog(aliases, **kwargs)
			if alias_title:
				custom_title = kodi_utils.kodi_dialog().input("כותרת", defaultt=alias_title)
			else:
				custom_title = kodi_utils.kodi_dialog().input("כותרת", defaultt=default_title)
		else:
			custom_title = kodi_utils.kodi_dialog().input("כותרת", defaultt=default_title)
		if not custom_title:
			return kodi_utils.notification("בוטל", 2500)

		def _process_params(default_value, custom_value, param_value):
			if custom_value and custom_value != default_value:
				play_params[param_value] = custom_value

		_process_params(default_title, custom_title, "custom_title")
		custom_year = kodi_utils.kodi_dialog().input("שנה", type=1, defaultt=default_year)
		_process_params(default_year, custom_year, "custom_year")
		if media_type == "episode":
			custom_season = kodi_utils.kodi_dialog().input("עונה", type=1, defaultt=season)
			_process_params(season, custom_season, "custom_season")
			custom_episode = kodi_utils.kodi_dialog().input("פרק", type=1, defaultt=episode)
			_process_params(episode, custom_episode, "custom_episode")
			if any(i in play_params for i in ("custom_season", "custom_episode")):
				if settings.autoplay_next_episode():
					_process_params("", "true", "disable_autoplay_next_episode")
		all_choice = kodi_utils.confirm_dialog(heading=meta.get("rootname", ""), text="לסרוק עם כל הסורקים החיצוניים?", ok_label="כן", cancel_label="לא")
		if all_choice == None:
			return kodi_utils.notification("בוטל", 2500)
		if all_choice:
			_process_params("", "true", "disabled_ext_ignored")
		disable_filters_choice = kodi_utils.confirm_dialog(
			heading=meta.get("rootname", ""), text="לבטל את כל המסננים עבור החיפוש?", ok_label="כן", cancel_label="לא"
		)
		if disable_filters_choice == None:
			return kodi_utils.notification("בוטל", 2500)
		if disable_filters_choice:
			_process_params("", "true", "ignore_scrape_filters")
			kodi_utils.set_property("fs_filterless_search", "true")
	if media_type == "episode":
		play_params["playcount"] = playcount
	play_params[playback_key] = playback_key
	from modules.sources import Sources

	Sources().playback_prep(play_params)


def set_quality_choice(params):
	quality_setting = params.get("setting_id")
	icon = params.get("icon", None) or ""
	dl = ["כלול 4K", "כלול 1080p", "כלול 720p", "כלול SD"]
	fl = ["4K", "1080p", "720p", "SD"]
	q_setting = get_setting("forge.%s" % quality_setting).split(", ")
	try:
		preselect = [fl.index(i) for i in q_setting]
	except:
		preselect = []
	list_items = [{"line1": item, "icon": icon} for item in dl]
	kwargs = {"items": json.dumps(list_items), "heading": "בחר את האיכויות הכלולות", "multi_choice": "true", "preselect": preselect}
	choice = kodi_utils.select_dialog(fl, **kwargs)
	if choice is None:
		return
	if choice == []:
		kodi_utils.ok_dialog(text="עליך לבחור לפחות איכות אחת")
		return set_quality_choice(params)
	set_setting(quality_setting, ", ".join(choice))


def extras_buttons_choice(params):
	extras_button_label_values = kodi_utils.extras_button_label_values()
	media_type, button_dict, orig_button_dict = params.get("media_type", None), params.get("button_dict", {}), params.get("orig_button_dict", {})
	if not orig_button_dict:
		for _type in ("movie", "tvshow"):
			setting_id_base = "extras.%s.button" % _type
			for item in range(10, 18):
				setting_id = "extras.%s.button%s" % (_type, item)
				try:
					button_action = get_setting("forge.%s" % setting_id)
					button_label = extras_button_label_values[_type][button_action]
				except:
					set_setting(setting_id.replace("forge.", ""), default_setting_values(setting_id)["setting_default"])
					button_action = get_setting("forge.%s" % setting_id)
					button_label = extras_button_label_values[_type][button_action]
				button_dict[setting_id] = {"button_action": button_action, "button_label": button_label, "button_name": "לחצן %s" % str(item - 9)}
				orig_button_dict[setting_id] = {"button_action": button_action, "button_label": button_label, "button_name": "לחצן %s" % str(item - 9)}
	if media_type == None:
		choices = [
			("הגדר לחצני [B]סרטים[/B]", "movie"),
			("הגדר לחצני [B]סדרות[/B]", "tvshow"),
			("שחזר לחצני [B]סרטים[/B] לברירת מחדל", "restore.movie"),
			("שחזר לחצני [B]סדרות[/B] לברירת מחדל", "restore.tvshow"),
			("שחזר לחצני [B]סרטים וסדרות[/B] לברירת מחדל", "restore.both"),
		]
		list_items = [{"line1": i[0]} for i in choices]
		kwargs = {"items": json.dumps(list_items), "heading": "בחר סוג מדיה להגדרת לחצנים", "narrow_window": "true"}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice == None:
			if button_dict != orig_button_dict:
				for k, v in button_dict.items():
					set_setting(k, v["button_action"])
			return
		media_type = choice[1]
		if "restore" in media_type:
			restore_type = media_type.split(".")[1]
			if restore_type in ("movie", "both"):
				for item in [(i, default_setting_values(i)["setting_default"]) for i in ("extras.movie.button%s" % i for i in range(10, 18))]:
					set_setting(item[0], item[1])
			if restore_type in ("tvshow", "both"):
				for item in [(i, default_setting_values(i)["setting_default"]) for i in ("extras.tvshow.button%s" % i for i in range(10, 18))]:
					set_setting(item[0], item[1])
			return extras_buttons_choice({})
	choices = [
		("[B]%s[/B]   |   %s" % (v["button_name"], v["button_label"]), v["button_name"], v["button_label"], k)
		for k, v in button_dict.items()
		if media_type in k
	]
	list_items = [{"line1": i[0]} for i in choices]
	kwargs = {"items": json.dumps(list_items), "heading": "בחר לחצן להגדרה", "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return extras_buttons_choice({"button_dict": button_dict, "orig_button_dict": orig_button_dict})
	button_name, button_label, button_setting = choice[1:]
	choices = [(v, k) for k, v in extras_button_label_values[media_type].items() if not v == button_label]
	choices = [i for i in choices if not i[0] == button_label]
	list_items = [{"line1": i[0]} for i in choices]
	kwargs = {"items": json.dumps(list_items), "heading": "בחר פעולה עבור %s" % button_name, "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		return extras_buttons_choice({"button_dict": button_dict, "orig_button_dict": orig_button_dict, "media_type": media_type})
	button_label, button_action = choice
	button_dict[button_setting] = {"button_action": button_action, "button_label": button_label, "button_name": button_name}
	return extras_buttons_choice({"button_dict": button_dict, "orig_button_dict": orig_button_dict, "media_type": media_type})


def extras_ratings_choice(params={}):
	choices = [
		("Metacritic", "Meta", "metacritic.png"),
		("Tomato Rating Critic", "Tom/Critic", "rtcertified.png"),
		("Tomato Rating User", "Tom/User", "popcorn.png"),
		("IMDb", "IMDb", "imdb.png"),
		("TMDb", "TMDb", "tmdb.png"),
	]
	list_items = [{"line1": i[0], "icon": "forge_flags/ratings/%s" % i[2]} for i in choices]
	current_settings = settings.extras_enabled_ratings()
	try:
		preselect = [choices.index(i) for i in choices if i[1] in current_settings]
	except:
		preselect = []
	kwargs = {"items": json.dumps(list_items), "heading": "דירוגים להצגה", "multi_choice": "true", "preselect": preselect}
	selection = kodi_utils.select_dialog(choices, **kwargs)
	if selection == None:
		return
	if selection == []:
		kodi_utils.ok_dialog(text="עליך לבחור לפחות ספק דירוגים אחד")
		return extras_ratings_choice()
	set_setting("extras.enabled_ratings", ", ".join([i[1] for i in selection]))


def set_language_filter_choice(params):
	from modules.meta_lists import language_choices

	filter_setting_id, multi_choice, include_none = params.get("filter_setting_id"), params.get("multi_choice", "false"), params.get("include_none", "false")
	lang_choices = language_choices()
	if include_none == "false":
		lang_choices.pop("None")
	dl, fl = list(lang_choices.keys()), list(lang_choices.values())
	set_filter = get_setting("forge.%s" % filter_setting_id).split(", ")
	try:
		preselect = [fl.index(i) for i in set_filter]
	except:
		preselect = []
	list_items = [{"line1": item} for item in dl]
	kwargs = {"items": json.dumps(list_items), "multi_choice": multi_choice, "preselect": preselect}
	choice = kodi_utils.select_dialog(fl, **kwargs)
	if choice == None:
		return
	if multi_choice == "true":
		if choice == []:
			set_setting(filter_setting_id, "eng")
		else:
			set_setting(filter_setting_id, ", ".join(choice))
	else:
		set_setting(filter_setting_id, choice)


def enable_scrapers_choice(params={}):
	icon = params.get("icon", None) or kodi_utils.get_icon("forge")
	scrapers = ["external", "easynews", "rd_cloud", "pm_cloud", "ad_cloud", "tb_cloud", "folders"]
	cloud_scrapers = {"rd_cloud": "rd.enabled", "pm_cloud": "pm.enabled", "ad_cloud": "ad.enabled", "tb_cloud": "tb.enabled"}
	scraper_names = ["סורקים חיצוניים", "EASYNEWS", "ענן RD", "ענן PM", "ענן AD", "ענן TB", "תיקיות 1-5"]
	set_scrapers = settings.active_internal_scrapers()
	preselect = [scrapers.index(i) for i in set_scrapers]
	list_items = [{"line1": item, "icon": icon} for item in scraper_names]
	kwargs = {"items": json.dumps(list_items), "multi_choice": "true", "preselect": preselect}
	choice = kodi_utils.select_dialog(scrapers, **kwargs)
	if choice is None:
		return
	for i in scrapers:
		set_setting("provider.%s" % i, ("true" if i in choice else "false"))
		if i in cloud_scrapers and i in choice:
			set_setting(cloud_scrapers[i], "true")


def sources_folders_choice(params):
	from windows.base_window import open_window

	return open_window(("windows.settings_manager", "SettingsManagerFolders"), "settings_manager_folders.xml")


def results_sorting_choice(params):
	choices = [
		("איכות, ספק, גודל", "0"),
		("איכות, גודל, ספק", "1"),
		("ספק, איכות, גודל", "2"),
		("ספק, גודל, איכות", "3"),
		("גודל, איכות, ספק", "4"),
		("גודל, ספק, איכות", "5"),
		("מדובב  תרגום מובנה  מיון מדורג", "0"), # מונע קריסה על ידי החזרת 0
	]
	list_items = [{"line1": item[0]} for item in choices]
	kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice is None:
		return
	
	# שמירת הטקסט המלא - בו נשתמש בתוך הקוד של טלגרם
	set_setting("results.sort_order_display", choice[0])
	# שמירת המספר עבור המנוע הראשי של פורג' למניעת ה-IndexError
	set_setting("results.sort_order", choice[1])





def results_format_choice(params):
	choices = [
		("רשימה", kodi_utils.get_icon("results_list", "results")),
		("שורות", kodi_utils.get_icon("results_row", "results")),
		("רשימה רחבה", kodi_utils.get_icon("results_widelist", "results")),
	]
	list_items = [{"line1": item[0], "icon": item[1]} for item in choices]
	kwargs = {"items": json.dumps(list_items), "heading": "בחר פורמט תוצאות"}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice is None:
		return
	set_setting("results.list_format", choice[0])


def clear_favorites_choice(params):
	fl = [("נקה מועדפי סרטים", "movie"), ("נקה מועדפי סדרות", "tvshow"), ("נקה מועדפי אנשים", "people")]
	list_items = [{"line1": item[0]} for item in fl]
	kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
	media_type = kodi_utils.select_dialog([item[1] for item in fl], **kwargs)
	if media_type == None:
		return
	if not kodi_utils.confirm_dialog():
		return
	from caches.favorites_cache import favorites_cache

	favorites_cache.clear_favorites(media_type)
	kodi_utils.notification("הצליח", 3000)


def scraper_color_choice(params):
	setting = params.get("setting_id")
	current_setting, original_highlight = get_setting("forge.%s" % setting), default_setting_values(setting)["setting_default"]
	if current_setting != original_highlight:
		action = kodi_utils.confirm_dialog(
			text="להגדיר הדגשה חדשה או לשחזר להדגשת ברירת המחדל?", ok_label="הגדר חדש", cancel_label="שחזר ברירת מחדל", default_control=10
		)
		if action == None:
			return
		if not action:
			return set_setting(setting, original_highlight)
	chosen_color = color_choice({"current_setting": current_setting})
	if chosen_color:
		set_setting(setting, chosen_color)


def personal_list_unseen_color_choice(params):
	setting = "personal_list.unseen_highlight"
	current_setting, original_highlight = get_setting("forge.%s" % setting), default_setting_values(setting)["setting_default"]
	if current_setting != original_highlight:
		action = kodi_utils.confirm_dialog(
			text="להגדיר הדגשה חדשה או לשחזר להדגשת ברירת המחדל?", ok_label="הגדר חדש", cancel_label="שחזר ברירת מחדל", default_control=10
		)
		if action == None:
			return
		if not action:
			return set_setting(setting, original_highlight)
	chosen_color = color_choice({"current_setting": current_setting})
	if chosen_color:
		set_setting(setting, chosen_color)


def color_choice(params):
	from windows.base_window import open_window

	return open_window(("windows.color", "SelectColor"), "color.xml", current_setting=params.get("current_setting", None))


def mpaa_region_choice(params={}):
	from modules.meta_lists import regions as rg

	regions = rg()
	regions.sort(key=lambda x: x["name"])
	list_items = [{"line1": i["name"]} for i in regions]
	kwargs = {"items": json.dumps(list_items), "heading": "הגדר אזור MPAA", "narrow_window": "true"}
	choice = kodi_utils.select_dialog(regions, **kwargs)
	if choice == None:
		return None
	from caches.meta_cache import delete_meta_cache

	set_setting("mpaa_region", choice["id"])
	set_setting("mpaa_region_display_name", choice["name"])
	delete_meta_cache(silent=True)


def lists_cache_duration_choice(params={}):
	durations = [
		{"name": "6 שעות", "duration": "6"},
		{"name": "12 שעות", "duration": "12"},
		{"name": "18 שעות", "duration": "18"},
		{"name": "יום אחד", "duration": "24"},
		{"name": "יומיים", "duration": "48"},
		{"name": "3 ימים", "duration": "72"},
		{"name": "4 ימים", "duration": "96"},
		{"name": "5 ימים", "duration": "120"},
		{"name": "6 ימים", "duration": "144"},
		{"name": "שבוע אחד", "duration": "168"},
	]
	list_items = [{"line1": i["name"]} for i in durations]
	kwargs = {"items": json.dumps(list_items), "heading": "הגדר משך מטמון רשימות כללי", "narrow_window": "true"}
	choice = kodi_utils.select_dialog(durations, **kwargs)
	if choice == None:
		return None
	set_setting("lists_cache_duraton", choice["duration"])
	set_setting("lists_cache_duraton_display_name", choice["name"])


def options_menu_choice(params, meta=None):
	from caches.episode_groups_cache import episode_groups_cache
	from modules import metadata
	from modules.utils import get_datetime

	params_get = params.get
	tmdb_id, content, poster = params_get("tmdb_id", None), params_get("content", None), params_get("poster", None)
	is_external, from_extras = params_get("is_external") in (True, "True", "true"), params_get("from_extras", "false") == "true"
	season, episode = params_get("season", ""), params_get("episode", "")
	single_ep_list = (
		"episode.progress",
		"episode.recently_watched",
		"episode.next_trakt",
		"episode.next_forge",
		"episode.trakt_recently_aired",
		"episode.trakt_calendar",
	)
	if not content:
		content = kodi_utils.container_content()[:-1]
	menu_type = content
	if content.startswith("episode."):
		content = "episode"
	if not meta:
		function = metadata.movie_meta if content == "movie" else metadata.tvshow_meta
		meta = function("tmdb_id", tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	meta_get = meta.get
	rootname, title, imdb_id, tvdb_id = meta_get("rootname", None), meta_get("title"), meta_get("imdb_id", None), meta_get("tvdb_id", None)
	window_function = kodi_utils.activate_window if is_external else kodi_utils.container_update
	listing = []
	listing_append = listing.append
	if from_extras:
		if menu_type in ("movie", "episode"):
			listing_append(("אפשרויות ניגון", "Scrapers Options", "playback_choice"))
		if settings.trakt_user_active():
			listing_append(("מנהל רשימות Trakt", "", "trakt_manager"))
		listing_append(("מנהל רשימות אישיות", "", "personallists_manager_choice"))
		listing_append(("מנהל רשימות TMDb", "", "tmdblists_manager_choice"))
		listing_append(("מנהל מועדפים", "", "favorites_manager_choice"))
	if menu_type == "tvshow":
		listing_append(("נגן אקראי", "מבוסס על %s" % rootname, "random"))
	if menu_type in ("tvshow", "season"):
		listing_append(("שייך קבוצת פרקים אל %s" % rootname, "כרגע %s" % episode_groups_cache.get(tmdb_id).get("name", "None"), "episode_group"))
	if menu_type in ("movie", "episode") or menu_type in single_ep_list:
		base_str1, base_str2, on_str, off_str = "%s%s", "כרגע: [B]%s[/B]", "מופעל", "כבוי"
		if settings.auto_play(content):
			autoplay_status, autoplay_toggle, quality_setting = on_str, "false", "autoplay_quality_%s" % content
		else:
			autoplay_status, autoplay_toggle, quality_setting = off_str, "true", "results_quality_%s" % content
		set_active = settings.active_internal_scrapers()
		active_int_scrapers = [i.replace("_", "") for i in set_active]
		current_scrapers_status = ", ".join([i for i in active_int_scrapers]) if len(active_int_scrapers) > 0 else "N/A"
		current_quality_status = ", ".join(settings.quality_filter(quality_setting))
		autoplay_next_status, autoplay_next_toggle = (on_str, "false") if settings.autoplay_next_episode() else (off_str, "true")
		listing_append((base_str1 % ("נגינה אוטומטית", " (%s)" % content), base_str2 % autoplay_status, "toggle_autoplay"))
		if menu_type == "episode" or menu_type in single_ep_list:
			if autoplay_status == on_str:
				autoplay_next_status, autoplay_next_toggle = (on_str, "false") if settings.autoplay_next_episode() else (off_str, "true")
				listing_append((base_str1 % ("נגינה אוטומטית של הפרק הבא", ""), base_str2 % autoplay_next_status, "toggle_autoplay_next"))
			else:
				autoscrape_next_status, autoscrape_next_toggle = (on_str, "false") if settings.autoscrape_next_episode() else (off_str, "true")
				listing_append((base_str1 % ("סריקה אוטומטית של הפרק הבא", ""), base_str2 % autoscrape_next_status, "toggle_autoscrape_next"))
		listing_append((base_str1 % ("מגבלת איכות", " (%s)" % content), base_str2 % current_quality_status, "set_quality"))
		listing_append((base_str1 % ("", "אפשר סורקים"), base_str2 % current_scrapers_status, "enable_scrapers"))
		if menu_type == "episode" or menu_type in single_ep_list:
			listing_append(("שייך קבוצת פרקים אל %s" % rootname, base_str2 % episode_groups_cache.get(tmdb_id).get("name", "None"), "episode_group"))
	if not from_extras:
		if menu_type in ("movie", "tvshow"):
			listing_append(("רענן מטמון מידע עבור %s" % ("סרטים" if menu_type == "movie" else "סדרות"), "נקה מטמון של %s" % rootname, "clear_media_cache"))
		if menu_type in ("movie", "episode") or menu_type in single_ep_list:
			listing_append(("נקה מטמון סורקים", "", "clear_scrapers_cache"))
		if menu_type in ("tvshow", "season", "episode"):
			listing_append(("מנהל התקדמות סדרות טלוויזיה", "", "nextep_manager"))
		listing_append(("פתח מנהל הורדות", "", "open_download_manager"))
		listing_append(("פתח כלים", "", "open_tools"))
		if menu_type in ("movie", "episode") or menu_type in single_ep_list:
			listing_append(("פתח הגדרות סורק חיצוני", "", "open_external_scraper_settings"))
		listing_append(("פתח הגדרות", "", "open_settings"))
	list_items = [{"line1": item[0], "line2": item[1] or item[0], "icon": poster} for item in listing]
	heading = rootname or "אפשרויות..."
	kwargs = {"items": json.dumps(list_items), "heading": heading, "multi_line": "true"}
	choice = kodi_utils.select_dialog([i[2] for i in listing], **kwargs)
	if choice == None:
		return
	if choice == "clear_media_cache":
		from caches.base_cache import refresh_cached_data

		kodi_utils.close_all_dialog()
		return refresh_cached_data(meta)
	if choice == "clear_scrapers_cache":
		from modules.source_utils import clear_scrapers_cache

		return clear_scrapers_cache()
	if choice == "open_download_manager":
		from modules.downloader import manager

		kodi_utils.close_all_dialog()
		return manager()
	if choice == "open_tools":
		kodi_utils.close_all_dialog()
		return window_function({"mode": "navigator.tools"})
	if choice == "open_settings":
		kodi_utils.close_all_dialog()
		return kodi_utils.open_settings()
	if choice == "open_external_scraper_settings":
		kodi_utils.close_all_dialog()
		return kodi_utils.external_scraper_settings()
	if choice == "playback_choice":
		return playback_choice({"media_type": content, "poster": poster, "meta": meta, "season": season, "episode": episode})
	if choice == "nextep_manager":
		return window_function({"mode": "build_next_episode_manager"})
	if choice == "random":
		kodi_utils.close_all_dialog()
		return random_choice({"meta": meta, "poster": poster})
	if choice == "trakt_manager":
		return trakt_manager_choice({"tmdb_id": tmdb_id, "imdb_id": imdb_id, "tvdb_id": tvdb_id or "None", "media_type": content, "icon": poster})
	if choice == "personallists_manager_choice":
		from modules.utils import get_current_timestamp

		return personallists_manager_choice(
			{
				"list_type": content,
				"tmdb_id": tmdb_id,
				"title": title,
				"premiered": meta_get("premiered"),
				"current_time": get_current_timestamp(),
				"icon": poster,
			}
		)
	if choice == "favorites_manager_choice":
		return favorites_manager_choice({"media_type": content if content in ("movie", "tvshow") else "tvshow", "tmdb_id": tmdb_id, "title": title})
	if choice == "tmdblists_manager_choice":
		return tmdblists_manager_choice({"media_type": content if content in ("movie", "movies") else "tv", "tmdb_id": tmdb_id, "icon": poster})
	if choice == "toggle_autoplay":
		set_setting("auto_play_%s" % content, autoplay_toggle)
	elif choice == "toggle_autoplay_next":
		set_setting("autoplay_next_episode", autoplay_next_toggle)
	elif choice == "toggle_autoscrape_next":
		set_setting("autoscrape_next_episode", autoscrape_next_toggle)
	elif choice == "set_quality":
		set_quality_choice({"setting_id": "autoplay_quality_%s" % content if autoplay_status == on_str else "results_quality_%s" % content, "icon": poster})
	elif choice == "enable_scrapers":
		enable_scrapers_choice({"icon": poster})
	elif choice == "episode_group":
		assign_episode_group_choice({"meta": meta, "poster": poster})
	options_menu_choice(params, meta=meta)


def extras_menu_choice(params):
	from modules import metadata
	from modules.utils import get_datetime
	from windows.base_window import open_window

	stacked = params.get("stacked", "false") == "true"
	if not stacked:
		kodi_utils.show_busy_dialog()
	media_type = params["media_type"]
	function = metadata.movie_meta if media_type == "movie" else metadata.tvshow_meta
	meta = function("tmdb_id", params["tmdb_id"], settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	if not stacked:
		kodi_utils.hide_busy_dialog()
	open_window(
		("windows.extras", "Extras"),
		"extras.xml",
		meta=meta,
		is_external=params.get("is_external", "true" if kodi_utils.external() else "false"),
		options_media_type=media_type,
		starting_position=params.get("starting_position", None),
	)


def play_trailer_choice(params):
	from modules import metadata
	from modules.utils import get_datetime

	media_type = params["media_type"]
	function = metadata.movie_meta if media_type == "movie" else metadata.tvshow_meta
	kodi_utils.show_busy_dialog()
	try:
		meta = function("tmdb_id", params["tmdb_id"], settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	finally:
		kodi_utils.hide_busy_dialog()
	trailer_url = (meta or {}).get("trailer") or ""
	if not trailer_url:
		return kodi_utils.notification("אין קדימון זמין")
	if "plugin.video.youtube" in trailer_url and (
		not kodi_utils.addon_installed("plugin.video.youtube") or not kodi_utils.addon_enabled("plugin.video.youtube")
	):
		return kodi_utils.notification("נדרש תוסף יוטיוב לצורך ניגון")
	# PlayMedia hands off to Kodi's core player so playback survives this short-lived
	# RunPlugin invoker exiting (unlike the Extras window's persistent player thread).
	kodi_utils.execute_builtin("PlayMedia(%s)" % trailer_url)


def open_movieset_choice(params):
	kodi_utils.hide_busy_dialog()
	window_function = kodi_utils.activate_window if params["is_external"] in (True, "True", "true") else kodi_utils.container_update
	return window_function({"mode": "build_movie_list", "action": "tmdb_movies_sets", "key_id": params["key_id"], "name": params["name"]})


def media_extra_info_choice(params):
	from modules.source_utils import get_aliases_titles, make_alias_dict
	from modules.utils import adjust_premiered_date

	media_type, meta = params.get("media_type"), params.get("meta")
	extra_info, listings = meta.get("extra_info", None), []
	append = listings.append
	try:
		if media_type == "movie":
			if meta["tagline"]:
				append("[B]שורת מחץ (Tagline):[/B] %s" % meta["tagline"])
			aliases = get_aliases_titles(make_alias_dict(meta, meta["title"]))
			if aliases:
				append("[B]שמות נרדפים:[/B] %s" % ", ".join(aliases))
			append("[B]סטטוס:[/B] %s" % extra_info["status"])
			append("[B]בכורה:[/B] %s" % meta["premiered"])
			append("[B]דירוג:[/B] %s (%s הצבעות)" % (str(round(meta["rating"], 1)), meta["votes"]))
			append("[B]אורך קטעים:[/B] %s דקות" % int(float(meta["duration"]) / 60))
			append("[B]ז'אנר/ים:[/B] %s" % ", ".join(meta["genre"]))
			append("[B]תקציב:[/B] %s" % extra_info["budget"])
			append("[B]הכנסות:[/B] %s" % extra_info["revenue"])
			append("[B]במאי:[/B] %s" % ", ".join(meta["director"]))
			append("[B]כותב/ים:[/B] %s" % ", ".join(meta["writer"]) or "N/A")
			append("[B]אולפן:[/B] %s" % ", ".join(meta["studio"]) or "N/A")
			if extra_info["collection_name"]:
				append("[B]אוסף סרטים:[/B] %s" % extra_info["collection_name"])
			append("[B]אתר הבית:[/B] %s" % extra_info["homepage"])
		else:
			append("[B]סוג:[/B] %s" % extra_info["type"])
			if meta["tagline"]:
				append("[B]שורת מחץ (Tagline):[/B] %s" % meta["tagline"])
			aliases = get_aliases_titles(make_alias_dict(meta, meta["title"]))
			if aliases:
				append("[B]שמות נרדפים:[/B] %s" % ", ".join(aliases))
			append("[B]סטטוס:[/B] %s" % extra_info["status"])
			append("[B]בכורה:[/B] %s" % meta["premiered"])
			append("[B]דירוג:[/B] %s (%s הצבעות)" % (str(round(meta["rating"], 1)), meta["votes"]))
			append("[B]אורך קטעים:[/B] %d דקות" % int(float(meta["duration"]) / 60))
			append("[B]סיווג הורים:[/B] %s" % meta["mpaa"])
			append("[B]ז'אנר/ים:[/B] %s" % ", ".join(meta["genre"]))
			append("[B]רשתות שידור:[/B] %s" % ", ".join(meta["studio"]))
			append("[B]נוצר על ידי:[/B] %s" % extra_info["created_by"])
			try:
				last_ep = extra_info["last_episode_to_air"]
				append(
					"[B]שודר לאחרונה:[/B] %s - [B]S%.2dE%.2d[/B] - %s"
					% (
						adjust_premiered_date(last_ep["air_date"], settings.date_offset())[0].strftime("%d %B %Y"),
						last_ep["season_number"],
						last_ep["episode_number"],
						last_ep["name"],
					)
				)
			except:
				pass
			try:
				next_ep = extra_info["next_episode_to_air"]
				append(
					"[B]ישודר הבא:[/B] %s - [B]S%.2dE%.2d[/B] - %s"
					% (
						adjust_premiered_date(next_ep["air_date"], settings.date_offset())[0].strftime("%d %B %Y"),
						next_ep["season_number"],
						next_ep["episode_number"],
						next_ep["name"],
					)
				)
			except:
				pass
			append("[B]עונות:[/B] %s" % meta["total_seasons"])
			append("[B]פרקים:[/B] %s" % meta["total_aired_eps"])
			append("[B]אתר הבית:[/B] %s" % extra_info["homepage"])
	except:
		return kodi_utils.notification("שגיאה", 2000)
	return "[CR][CR]".join(listings)


def discover_choice(params):
	from windows.base_window import open_window

	open_window(("windows.discover", "Discover"), "discover.xml", media_type=params["media_type"])