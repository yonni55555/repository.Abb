# -*- coding: utf-8 -*-
import json

from caches._codec import decode as _decode
from caches.base_cache import connect_database
from modules.kodi_utils import clear_property, get_property, set_property

# from modules.kodi_utils import logger


class NavigatorCache:
	root_list = [
		{"name": "סרטים", "mode": "navigator.main", "action": "MovieList", "iconImage": "movies"},
		{"name": "סדרות", "mode": "navigator.main", "action": "TVShowList", "iconImage": "tv"},
		{"name": "אנימה", "mode": "navigator.main", "action": "AnimeList", "iconImage": "anime"},
		{"name": "סרטים וסדרות משולב", "mode": "navigator.mixed", "iconImage": "lists"},
		{"name": "אנשים / שחקנים", "mode": "navigator.people", "iconImage": "empty_person"},
		{"name": "חיפוש", "mode": "navigator.search", "iconImage": "search"},
		{"name": "גילוי תוכן", "mode": "navigator.discover", "iconImage": "discover"},
		{"name": "רשימות אקראיות", "mode": "navigator.random_lists", "iconImage": "random"},
		{"name": "הרשימות שלי", "mode": "navigator.my_content", "iconImage": "lists"},
		{"name": "השירותים שלי", "mode": "navigator.premium", "iconImage": "premium"},
		{"name": "מועדפים", "mode": "navigator.favorites", "iconImage": "favorites"},
		{"name": "הורדות", "mode": "navigator.downloads", "iconImage": "downloads"},
		{"name": "כלים והגדרות", "mode": "navigator.tools", "iconImage": "settings2"},
	]
	movie_list = [
		{"name": "במגמה", "mode": "build_movie_list", "action": "trakt_movies_trending", "random_support": "true", "iconImage": "trending"},
		{
			"name": "במגמה לאחרונה",
			"mode": "build_movie_list",
			"action": "trakt_movies_trending_recent",
			"random_support": "true",
			"iconImage": "trending_recent",
		},
		{"name": "פופולריים", "mode": "build_movie_list", "action": "tmdb_movies_popular", "random_support": "true", "iconImage": "popular"},
		{"name": "פופולריים היום", "mode": "build_movie_list", "action": "tmdb_movies_popular_today", "random_support": "true", "iconImage": "popular_today"},
		{"name": "הקרנות בכורה", "mode": "build_movie_list", "action": "tmdb_movies_premieres", "random_support": "true", "iconImage": "fresh"},
		{"name": "שוחררו לאחרונה", "mode": "build_movie_list", "action": "tmdb_movies_latest_releases", "random_support": "true", "iconImage": "dvd"},
		{"name": "הכי נצפים", "mode": "build_movie_list", "action": "trakt_movies_most_watched", "random_support": "true", "iconImage": "most_watched"},
		{"name": "הכי מועדפים", "mode": "build_movie_list", "action": "trakt_movies_most_favorited", "random_support": "true", "iconImage": "favorites"},
		{"name": "טופ 10 שוברי קופות", "mode": "build_movie_list", "action": "trakt_movies_top10_boxoffice", "iconImage": "box_office"},
		{"name": "שוברי קופות", "mode": "build_movie_list", "action": "tmdb_movies_blockbusters", "random_support": "true", "iconImage": "most_voted"},
		{"name": "בבתי הקולנוע", "mode": "build_movie_list", "action": "tmdb_movies_in_theaters", "random_support": "true", "iconImage": "intheatres"},
		{"name": "סרטים חדשים בקרוב", "mode": "build_movie_list", "action": "tmdb_movies_upcoming", "random_support": "true", "iconImage": "lists"},
		{"name": "זוכי אוסקר", "mode": "build_movie_list", "action": "tmdb_movies_oscar_winners", "random_support": "true", "iconImage": "oscar_winners"},
		{"name": "ז'אנרים", "mode": "navigator.genres", "menu_type": "movie", "random_support": "true", "iconImage": "genres"},
		{"name": "ספקי תוכן", "mode": "navigator.providers", "menu_type": "movie", "random_support": "true", "iconImage": "providers"},
		{"name": "שפות", "mode": "navigator.languages", "menu_type": "movie", "random_support": "true", "iconImage": "languages"},
		{"name": "שנות ייצור", "mode": "navigator.years", "menu_type": "movie", "random_support": "true", "iconImage": "calender"},
		{"name": "עשורים", "mode": "navigator.decades", "menu_type": "movie", "random_support": "true", "iconImage": "calendar_decades"},
		{"name": "סיווג צפייה", "mode": "navigator.certifications", "menu_type": "movie", "random_support": "true", "iconImage": "certifications"},
		{"name": "בגלל שצפית ב...", "iconImage": "because_you_watched", "mode": "navigator.because_you_watched", "menu_type": "movie"},
		{"name": "נצפו", "mode": "build_movie_list", "action": "watched_movies", "iconImage": "watched_1"},
		{"name": "נצפו לאחרונה", "mode": "build_movie_list", "action": "recent_watched_movies", "iconImage": "watched_recent"},
		{"name": "בשלבי צפייה", "mode": "build_movie_list", "action": "in_progress_movies", "iconImage": "player"},
	]
	tvshow_list = [
		{"name": "במגמה", "mode": "build_tvshow_list", "action": "trakt_tv_trending", "random_support": "true", "iconImage": "trending"},
		{
			"name": "במגמה לאחרונה",
			"mode": "build_tvshow_list",
			"action": "trakt_tv_trending_recent",
			"random_support": "true",
			"iconImage": "trending_recent",
		},
		{"name": "פופולריות", "mode": "build_tvshow_list", "action": "tmdb_tv_popular", "random_support": "true", "iconImage": "popular"},
		{"name": "פופולריות היום", "mode": "build_tvshow_list", "action": "tmdb_tv_popular_today", "iconImage": "popular_today"},
		{"name": "הקרנות בכורה", "mode": "build_tvshow_list", "action": "tmdb_tv_premieres", "random_support": "true", "iconImage": "fresh"},
		{"name": "הכי נצפות", "mode": "build_tvshow_list", "action": "trakt_tv_most_watched", "random_support": "true", "iconImage": "most_watched"},
		{"name": "הכי מועדפות", "mode": "build_tvshow_list", "action": "trakt_tv_most_favorited", "random_support": "true", "iconImage": "favorites"},
		{"name": "משודר היום", "mode": "build_tvshow_list", "action": "tmdb_tv_airing_today", "random_support": "true", "iconImage": "live"},
		{"name": "רץ כרגע בטלוויזיה", "mode": "build_tvshow_list", "action": "tmdb_tv_on_the_air", "random_support": "true", "iconImage": "ontheair"},
		{"name": "סדרות חדשות בקרוב", "mode": "build_tvshow_list", "action": "tmdb_tv_upcoming", "random_support": "true", "iconImage": "lists"},
		{"name": "ז'אנרים", "mode": "navigator.genres", "menu_type": "tvshow", "random_support": "true", "iconImage": "genres"},
		{"name": "ספקי תוכן", "mode": "navigator.providers", "menu_type": "tvshow", "random_support": "true", "iconImage": "providers"},
		{"name": "רשתות שידור", "mode": "navigator.networks", "menu_type": "tvshow", "random_support": "true", "iconImage": "networks"},
		{"name": "שפות", "mode": "navigator.languages", "menu_type": "tvshow", "random_support": "true", "iconImage": "languages"},
		{"name": "שנות ייצור", "mode": "navigator.years", "menu_type": "tvshow", "random_support": "true", "iconImage": "calender"},
		{"name": "עשורים", "mode": "navigator.decades", "menu_type": "tvshow", "random_support": "true", "iconImage": "calendar_decades"},
		{"name": "סיווג צפייה", "mode": "navigator.certifications", "menu_type": "tvshow", "random_support": "true", "iconImage": "certifications"},
		{"name": "בגלל שצפית ב...", "mode": "navigator.because_you_watched", "menu_type": "tvshow", "iconImage": "because_you_watched"},
		{"name": "נצפו", "mode": "build_tvshow_list", "action": "watched_tvshows", "iconImage": "watched_1"},
		{"name": "נצפו לאחרונה", "mode": "build_tvshow_list", "action": "recent_watched_tvshows", "iconImage": "watched_recent"},
		{"name": "בשלבי צפייה", "mode": "build_tvshow_list", "action": "in_progress_tvshows", "iconImage": "in_progress_tvshow"},
		{"name": "פרקים שנצפו לאחרונה", "mode": "build_recently_watched_episode", "iconImage": "watched_recent"},
		{"name": "פרקים בשלבי צפייה", "mode": "build_in_progress_episode", "iconImage": "player"},
		{"name": "הפרקים הבאים לצפייה", "mode": "build_next_episode", "iconImage": "next_episodes"},
	]
	anime_list = [
		{"name": "אנימה במגמה", "mode": "build_tvshow_list", "action": "trakt_anime_trending", "random_support": "true", "iconImage": "trending"},
		{
			"name": "אנימה במגמה לאחרונה",
			"mode": "build_tvshow_list",
			"action": "trakt_anime_trending_recent",
			"random_support": "true",
			"iconImage": "trending_recent",
		},
		{"name": "אנימה פופולרית", "mode": "build_tvshow_list", "action": "tmdb_anime_popular", "random_support": "true", "iconImage": "popular"},
		{
			"name": "אנימה פופולרית לאחרונה",
			"mode": "build_tvshow_list",
			"action": "tmdb_anime_popular_recent",
			"random_support": "true",
			"iconImage": "popular_today",
		},
		{"name": "אנימה הקרנות בכורה", "mode": "build_tvshow_list", "action": "tmdb_anime_premieres", "random_support": "true", "iconImage": "fresh"},
		{
			"name": "אנימה הכי נצפית",
			"mode": "build_tvshow_list",
			"action": "trakt_anime_most_watched",
			"random_support": "true",
			"iconImage": "most_watched",
		},
		{
			"name": "אנימה הכי מועדפת",
			"mode": "build_tvshow_list",
			"action": "trakt_anime_most_favorited",
			"random_support": "true",
			"iconImage": "favorites",
		},
		{"name": "אנימה רצה כרגע", "mode": "build_tvshow_list", "action": "tmdb_anime_on_the_air", "random_support": "true", "iconImage": "ontheair"},
		{"name": "אנימה בקרוב", "mode": "build_tvshow_list", "action": "tmdb_anime_upcoming", "random_support": "true", "iconImage": "lists"},
		{"name": "אנימה ז'אנרים", "mode": "navigator.genres", "menu_type": "anime", "random_support": "true", "iconImage": "genres"},
		{"name": "אנימה ספקי תוכן", "mode": "navigator.providers", "menu_type": "anime", "random_support": "true", "iconImage": "providers"},
		{"name": "אנימה שנות ייצור", "mode": "navigator.years", "menu_type": "anime", "random_support": "true", "iconImage": "calender"},
		{"name": "אנימה עשורים", "mode": "navigator.decades", "menu_type": "anime", "random_support": "true", "iconImage": "calendar_decades"},
		{"name": "אנימה סיווג צפייה", "mode": "navigator.certifications", "menu_type": "anime", "random_support": "true", "iconImage": "certifications"},
		{"name": "אנימה נצפתה", "mode": "build_tvshow_list", "action": "watched_tvshows", "is_anime_list": "true", "iconImage": "watched_1"},
		{
			"name": "אנימה נצפתה לאחרונה",
			"mode": "build_tvshow_list",
			"action": "recent_watched_tvshows",
			"is_anime_list": "true",
			"iconImage": "watched_recent",
		},
		{"name": "אנימה בשלבי צפייה", "mode": "build_tvshow_list", "action": "in_progress_tvshows", "is_anime_list": "true", "iconImage": "in_progress_tvshow"},
		{"name": "אנימה פרקים שנצפו לאחרונה", "mode": "build_recently_watched_episode", "is_anime_list": "true", "iconImage": "watched_recent"},
		{"name": "אנימה פרקים בשלבי צפייה", "mode": "build_in_progress_episode", "is_anime_list": "true", "iconImage": "player"},
		{"name": "אנימה הפרקים הבאים", "mode": "build_next_episode", "iconImage": "next_episodes", "is_anime_list": "true"},
	]

	main_menus = {"RootList": root_list, "MovieList": movie_list, "TVShowList": tvshow_list, "AnimeList": anime_list}

	def get_main_lists(self, list_name):
		default_contents = self.get_memory_cache(list_name, "default")
		if not default_contents:
			default_contents = self.get_list(list_name, "default")
			if default_contents == None:
				self.rebuild_database()
				return self.get_main_lists(list_name)
			try:
				edited_contents = self.get_list(list_name, "edited")
			except:
				edited_contents = None
		else:
			edited_contents = self.get_memory_cache(list_name, "edited")
		return default_contents, edited_contents

	def get_list(self, list_name, list_type):
		contents = None
		try:
			dbcon = connect_database("navigator_db")
			contents = _decode(dbcon.execute("SELECT list_contents FROM navigator WHERE list_name = ? AND list_type = ?", (list_name, list_type)).fetchone()[0])
			self.set_memory_cache(list_name, list_type, contents)
		except:
			pass
		return contents

	def set_list(self, list_name, list_type, list_contents):
		dbcon = connect_database("navigator_db")
		dbcon.execute("INSERT OR REPLACE INTO navigator VALUES (?, ?, ?)", (list_name, list_type, json.dumps(list_contents)))
		self.set_memory_cache(list_name, list_type, list_contents)

	def delete_list(self, list_name, list_type):
		dbcon = connect_database("navigator_db")
		dbcon.execute("DELETE FROM navigator WHERE list_name=? and list_type=?", (list_name, list_type))
		self.delete_memory_cache(list_name, list_type)
		dbcon.execute("VACUUM")

	def get_memory_cache(self, list_name, list_type):
		try:
			return _decode(get_property(self._get_list_prop(list_type) % list_name))
		except:
			return None

	def set_memory_cache(self, list_name, list_type, list_contents):
		set_property(self._get_list_prop(list_type) % list_name, json.dumps(list_contents))

	def delete_memory_cache(self, list_name, list_type):
		clear_property(self._get_list_prop(list_type) % list_name)

	def get_shortcut_folders(self):
		try:
			dbcon = connect_database("navigator_db")
			folders = dbcon.execute("SELECT list_name, list_contents FROM navigator WHERE list_type = ?", ("shortcut_folder",)).fetchall()
			folders = sorted([(str(i[0]), _decode(i[1])) for i in folders], key=lambda s: s[0].lower())
		except:
			folders = []
		return folders

	def get_shortcut_folder_contents(self, list_name):
		try:
			dbcon = connect_database("navigator_db")
			contents = _decode(
				dbcon.execute("SELECT list_contents FROM navigator WHERE list_name = ? AND list_type = ?", (list_name, "shortcut_folder")).fetchone()[0]
			)
		except:
			contents = []
		return contents

	def currently_used_list(self, list_name):
		try:
			used_list = (
				self.get_memory_cache(list_name, "edited")
				or self.get_memory_cache(list_name, "default")
				or self.get_list(list_name, "edited")
				or self.get_list(list_name, "default")
			)
		except:
			used_list = []
		if not used_list:
			self.rebuild_database()
			used_list = NavigatorCache.main_menus[list_name]
		return used_list

	def rebuild_database(self):
		dbcon = connect_database("navigator_db")
		main_items = NavigatorCache.main_menus.items()
		for list_name, list_contents in main_items:
			self.set_list(list_name, "default", list_contents)

	def _get_list_prop(self, list_type):
		return {"default": "forge_%s_default", "edited": "forge_%s_edited", "shortcut_folder": "forge_%s_shortcut_folder"}[list_type]

	def random_movie_lists(self):
		m_list = NavigatorCache.movie_list
		movie_random_converts = {
			"navigator.genres": "tmdb_movies_genres",
			"navigator.providers": "tmdb_movies_providers",
			"navigator.languages": "tmdb_movies_languages",
			"navigator.years": "tmdb_movies_year",
			"navigator.decades": "tmdb_movies_decade",
			"navigator.certifications": "tmdb_movies_certifications",
		}
		return [
			dict(
				i,
				**{
					"mode": "random.build_movie_list",
					"action": i.get("action") or movie_random_converts[i["mode"]],
					"random": "true",
					"name": "סרטים אקראיים - %s" % i["name"],
					"menu_type": "movie",
				},
			)
			for i in m_list
			if "random_support" in i
		]

	def random_tvshow_lists(self):
		t_list = NavigatorCache.tvshow_list
		tvshow_random_converts = {
			"navigator.genres": "tmdb_tv_genres",
			"navigator.providers": "tmdb_tv_providers",
			"navigator.networks": "tmdb_tv_networks",
			"navigator.languages": "tmdb_tv_languages",
			"navigator.years": "tmdb_tv_year",
			"navigator.decades": "tmdb_tv_decade",
			"navigator.certifications": "trakt_tv_certifications",
		}
		return [
			dict(
				i,
				**{
					"mode": "random.build_tvshow_list",
					"action": i.get("action") or tvshow_random_converts[i["mode"]],
					"random": "true",
					"name": "סדרות אקראיות - %s" % i["name"],
					"menu_type": "tvshow",
				},
			)
			for i in t_list
			if "random_support" in i
		]

	def random_anime_lists(self):
		a_list = NavigatorCache.anime_list
		anime_random_converts = {
			"navigator.genres": "tmdb_anime_genres",
			"navigator.providers": "tmdb_anime_providers",
			"navigator.years": "tmdb_anime_year",
			"navigator.decades": "tmdb_anime_decade",
			"navigator.certifications": "trakt_anime_certifications",
		}
		return [
			dict(
				i,
				**{
					"mode": "random.build_tvshow_list",
					"action": i.get("action") or anime_random_converts[i["mode"]],
					"random": "true",
					"name": i["name"].replace("אנימה", "אנימה אקראית"),
					"menu_type": "tvshow",
				},
			)
			for i in a_list
			if "random_support" in i
		]

	def random_mixed_lists(self):
		return [
			{
				"mode": "random.build_mixed_list",
				"action": "trakt_mixed_trending",
				"name": "אקראי משולב במגמה",
				"iconImage": "trakt",
				"random": "true",
				"menu_type": "mixed",
			},
			{
				"mode": "random.build_mixed_list",
				"action": "trakt_mixed_trending_recent",
				"name": "אקראי משולב במגמה לאחרונה",
				"iconImage": "trakt",
				"random": "true",
				"menu_type": "mixed",
			},
			{
				"mode": "random.build_mixed_list",
				"action": "trakt_mixed_most_watched",
				"name": "אקראי משולב הכי נצפה",
				"iconImage": "trakt",
				"random": "true",
				"menu_type": "mixed",
			},
			{
				"mode": "random.build_mixed_list",
				"action": "trakt_mixed_most_favorited",
				"name": "אקראי משולב הכי מועדף",
				"iconImage": "trakt",
				"random": "true",
				"menu_type": "mixed",
			},
			{
				"mode": "random.build_mixed_list",
				"action": "tmdb_mixed_popular",
				"name": "אקראי משולב פופולרי",
				"iconImage": "tmdb",
				"random": "true",
				"menu_type": "mixed",
			},
			{
				"mode": "random.build_mixed_list",
				"action": "tmdb_mixed_popular_today",
				"name": "אקראי משולב פופולרי היום",
				"iconImage": "tmdb",
				"random": "true",
				"menu_type": "mixed",
			},
			{
				"mode": "random.build_mixed_list",
				"action": "tmdb_mixed_premieres",
				"name": "אקראי משולב הקרנות בכורה",
				"iconImage": "tmdb",
				"random": "true",
				"menu_type": "mixed",
			},
			{
				"mode": "random.build_mixed_list",
				"action": "tmdb_mixed_upcoming",
				"name": "אקראי משולב בקרוב",
				"iconImage": "tmdb",
				"random": "true",
				"menu_type": "mixed",
			},
		]

	def random_because_you_watched_lists(self):
		return [
			{
				"mode": "random.build_movie_list",
				"action": "because_you_watched",
				"name": "אקראי בגלל שצפית בסרטים",
				"iconImage": "movies",
				"random": "true",
			},
			{
				"mode": "random.build_tvshow_list",
				"action": "because_you_watched",
				"name": "אקראי בגלל שצפית בסדרות",
				"iconImage": "tv",
				"random": "true",
			},
		]

	def random_tmdb_lists(self):
		return [
			{
				"mode": "random.build_tmdb_lists_contents",
				"list_id": "watchlist",
				"media_type": "movie",
				"name": "אקראי רשימת צפייה סרטים TMDb",
				"iconImage": "tmdb",
				"random": "true",
			},
			{
				"mode": "random.build_tmdb_lists_contents",
				"list_id": "watchlist",
				"media_type": "tv",
				"name": "אקראי רשימת צפייה סדרות TMDb",
				"iconImage": "tmdb",
				"random": "true",
			},
			{
				"mode": "random.build_tmdb_lists_contents",
				"list_id": "favorites",
				"media_type": "movie",
				"name": "אקראי מועדפים סרטים TMDb",
				"iconImage": "tmdb",
				"random": "true",
			},
			{
				"mode": "random.build_tmdb_lists_contents",
				"list_id": "favorites",
				"media_type": "tv",
				"name": "אקראי מועדפים סדרות TMDb",
				"iconImage": "tmdb",
				"random": "true",
			},
			{
				"mode": "random.build_tmdb_lists_contents",
				"list_id": "recommendations",
				"media_type": "movie",
				"name": "אקראי המלצות סרטים TMDb",
				"iconImage": "tmdb",
				"random": "true",
			},
			{
				"mode": "random.build_tmdb_lists_contents",
				"list_id": "recommendations",
				"media_type": "tv",
				"name": "אקראי המלצות סדרות TMDb",
				"iconImage": "tmdb",
				"random": "true",
			},
			{"mode": "tmdblist.get_tmdb_lists", "name": "אקראי ומעורבב הרשימות שלי ב-TMDb (הכל)", "iconImage": "tmdb", "random": "true", "shuffle": "true"},
			{"mode": "random.build_tmdb_lists", "name": "אקראי הרשימות שלי ב-TMDb (בודדת)", "iconImage": "tmdb", "random": "true"},
		]

	def random_personal_lists(self):
		return [
			{
				"mode": "personal_lists.get_personal_lists",
				"name": "אקראי ומעורבב רשימות אישיות (הכל)",
				"iconImage": "lists",
				"random": "true",
				"shuffle": "true",
			},
			{"mode": "random.build_personal_lists", "name": "אקראי רשימות אישיות (בודדת)", "iconImage": "lists", "random": "true"},
		]

	def random_trakt_lists_personal(self):
		return [
			{
				"mode": "random.build_movie_list",
				"action": "trakt_collection_lists",
				"name": "אקראי אוסף סרטים ב-Trakt",
				"iconImage": "movies",
				"random": "true",
			},
			{
				"mode": "random.build_tvshow_list",
				"action": "trakt_collection_lists",
				"name": "אקראי אוסף סדרות ב-Trakt",
				"iconImage": "tv",
				"random": "true",
			},
			{
				"mode": "random.build_movie_list",
				"action": "trakt_watchlist_lists",
				"name": "אקראי רשימת צפייה סרטים ב-Trakt",
				"iconImage": "movies",
				"random": "true",
			},
			{
				"mode": "random.build_tvshow_list",
				"action": "trakt_watchlist_lists",
				"name": "אקראי רשימת צפייה סדרות ב-Trakt",
				"iconImage": "tv",
				"random": "true",
			},
			{
				"mode": "random.build_movie_list",
				"action": "trakt_recommendations",
				"new_page": "movies",
				"name": "אקראי סרטים מומלצים ב-Trakt",
				"iconImage": "movies",
				"random": "true",
			},
			{
				"mode": "random.build_tvshow_list",
				"action": "trakt_recommendations",
				"new_page": "shows",
				"name": "אקראי סדרות מומלצות ב-Trakt",
				"iconImage": "tv",
				"random": "true",
			},
			{
				"mode": "trakt.list.get_trakt_lists",
				"list_type": "my_lists",
				"name": "אקראי ומעורבב הרשימות שלי ב-Trakt (הכל)",
				"iconImage": "trakt",
				"random": "true",
				"shuffle": "true",
			},
			{"mode": "random.build_trakt_lists", "list_type": "my_lists", "name": "אקראי הרשימות שלי ב-Trakt (בודדת)", "iconImage": "trakt", "random": "true"},
			{
				"mode": "trakt.list.get_trakt_lists",
				"list_type": "liked_lists",
				"name": "אקראי ומעורבב רשימות שאהבתי ב-Trakt (הכל)",
				"iconImage": "trakt",
				"random": "true",
				"shuffle": "true",
			},
			{
				"mode": "random.build_trakt_lists",
				"list_type": "liked_lists",
				"name": "אקראי רשימות שאהבתי ב-Trakt (בודדת)",
				"iconImage": "trakt",
				"random": "true",
			},
		]

	def random_trakt_lists_public(self):
		return [
			{
				"mode": "trakt.list.get_trakt_user_lists",
				"list_type": "trending",
				"category_name": "Random Trending User Lists",
				"name": "אקראי רשימות משתמשים פופולריות (הכל)",
				"iconImage": "trakt",
				"random": "true",
			},
			{
				"mode": "random.build_trakt_lists",
				"list_type": "trending",
				"category_name": "Random Trending User Lists",
				"name": "אקראי רשימות משתמשים פופולריות (בודדת)",
				"iconImage": "trakt",
				"random": "true",
			},
			{
				"mode": "trakt.list.get_trakt_user_lists",
				"list_type": "popular",
				"category_name": "Random Popular User Lists",
				"name": "אקראי רשימות משתמשים נצפות (הכל)",
				"iconImage": "trakt",
				"random": "true",
			},
			{
				"mode": "random.build_trakt_lists",
				"list_type": "popular",
				"category_name": "Random Popular User Lists",
				"name": "אקראי רשימות משתמשים נצפות (בודדת)",
				"iconImage": "trakt",
				"random": "true",
			},
		]


navigator_cache = NavigatorCache()