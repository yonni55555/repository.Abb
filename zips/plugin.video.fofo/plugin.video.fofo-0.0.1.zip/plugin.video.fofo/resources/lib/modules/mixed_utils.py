# -*- coding: utf-8 -*-
"""עזרי שיתוף עבור ממשקי התפריטים המעורבים (Mixed).

נשמר נקי מתלות ב-Kodi כדי שערכת הבדיקות תוכל לייבא אותו ישירות.
"""

from itertools import zip_longest


def interleave_buckets(*buckets):
	"""מיזוג בשיטת סבב (Round-robin) של שני דליים (Buckets) או יותר, תוך השמטת שומרי מקום מסוג `None`.

	דלי 0 תורם ראשון בכל סבב, לאחר מכן דלי 1, וכן הלאה. דליים ריקים
	מטופלים בצורה שקופה — העברת דלי אנימה ריק תניב את התבנית
	הרגילה `[M, S, M, S, ...]` המשמשת כאשר הגדרת האנימה כבויה.
	"""
	out = []
	for tup in zip_longest(*buckets):
		for item in tup:
			if item is not None:
				out.append(item)
	return out


def dedupe_by_id(items):
	"""הסרת מילוני תוצאות כפולים מ-TMDb לפי ה-``id`` שלהם, תוך שמירה על סדר הופעתם הראשון.

	בשימוש על ידי דלי ה-Mixed Channels TV, אשר מאחד שתי שאילתות /discover/tv
	נפרדות (מקורות רשת + ספקי הזרמה) — TMDb מבצע פעולת AND בין פרמטרי סינון
	שונים, ולכן פעולת OR על פני שני הצירים משמעותה מיזוג שתי תגובות והסרת
	הכותרים המופיעים בשתיהן. פריטים ללא ``id`` מושמטים.
	"""
	seen, out = set(), []
	for it in items:
		i = it.get("id")
		if i is None or i in seen:
			continue
		seen.add(i)
		out.append(it)
	return out


MIXED_LIST_SOURCES = {
	"trakt_trending": {
		"api": "trakt",
		"movie": ("apis.trakt_api", "trakt_movies_trending"),
		"tv": ("apis.trakt_api", "trakt_tv_trending"),
		"anime": ("apis.trakt_api", "trakt_anime_trending"),
	},
	"trakt_trending_recent": {
		"api": "trakt",
		"movie": ("apis.trakt_api", "trakt_movies_trending_recent"),
		"tv": ("apis.trakt_api", "trakt_tv_trending_recent"),
		"anime": ("apis.trakt_api", "trakt_anime_trending_recent"),
	},
	"trakt_most_watched": {
		"api": "trakt",
		"movie": ("apis.trakt_api", "trakt_movies_most_watched"),
		"tv": ("apis.trakt_api", "trakt_tv_most_watched"),
		"anime": ("apis.trakt_api", "trakt_anime_most_watched"),
	},
	"trakt_most_favorited": {
		"api": "trakt",
		"movie": ("apis.trakt_api", "trakt_movies_most_favorited"),
		"tv": ("apis.trakt_api", "trakt_tv_most_favorited"),
		"anime": ("apis.trakt_api", "trakt_anime_most_favorited"),
	},
	"tmdb_popular": {
		"api": "tmdb",
		"movie": ("apis.tmdb_api", "tmdb_movies_popular"),
		"tv": ("apis.tmdb_api", "tmdb_tv_popular"),
		"anime": ("apis.tmdb_api", "tmdb_anime_popular"),
	},
	"tmdb_popular_today": {
		"api": "tmdb",
		"movie": ("apis.tmdb_api", "tmdb_movies_popular_today"),
		"tv": ("apis.tmdb_api", "tmdb_tv_popular_today"),
		# הצד של האנימה ב-TMDb מספק את popular_recent, ולא את popular_today — הצמד הקיים הקרוב ביותר.
		"anime": ("apis.tmdb_api", "tmdb_anime_popular_recent"),
	},
	"tmdb_premieres": {
		"api": "tmdb",
		"movie": ("apis.tmdb_api", "tmdb_movies_premieres"),
		"tv": ("apis.tmdb_api", "tmdb_tv_premieres"),
		"anime": ("apis.tmdb_api", "tmdb_anime_premieres"),
	},
	"tmdb_upcoming": {
		"api": "tmdb",
		"movie": ("apis.tmdb_api", "tmdb_movies_upcoming"),
		"tv": ("apis.tmdb_api", "tmdb_tv_upcoming"),
		"anime": ("apis.tmdb_api", "tmdb_anime_upcoming"),
	},
}


# מקורות מבוססי מפתח עבור Navigator.mixed_keyed_list — הפונקציות מקבלות (key_id, page_no).
# בשימוש על ידי ז'אנרים מעורבים (מזהי ז'אנר של סרטים/סדרות שונים) וספקים מעורבים (מזהה משותף).
# מיועד ל-TMDb בלבד, לכן אין צורך במבחין "api".
MIXED_KEYED_SOURCES = {
	"mixed_genres": {
		"movie": ("apis.tmdb_api", "tmdb_movies_genres"),
		"tv": ("apis.tmdb_api", "tmdb_tv_genres"),
		"anime": ("apis.tmdb_api", "tmdb_anime_genres"),
	},
	"mixed_providers": {
		"movie": ("apis.tmdb_api", "tmdb_movies_providers"),
		"tv": ("apis.tmdb_api", "tmdb_tv_providers"),
		"anime": ("apis.tmdb_api", "tmdb_anime_providers"),
	},
}


MIXED_LIST_MENU = (
	("מגמות מעורב", "trakt_trending", "trending"),
	("מגמות אחרונות מעורב", "trakt_trending_recent", "trending"),
	("הכי נצפים מעורב", "trakt_most_watched", "most_watched"),
	("הכי מועדפים מעורב", "trakt_most_favorited", "favorites"),
	("פופולרי מעורב", "tmdb_popular", "popular"),
	("פופולרי היום מעורב", "tmdb_popular_today", "popular_today"),
	("בכורות מעורב", "tmdb_premieres", "fresh"),
	("הבאים מעורב", "tmdb_upcoming", "lists"),
)


# מקורות אישיים ("הרשימות שלי") עבור Navigator.mixed_my_list. בניגוד ל-MIXED_LIST_SOURCES מקורות אלו
# מושכים את הרשימות של המשתמש עצמו, אשר מחזירות את כל הרשימה בבת אחת (ללא פרמטר עמוד) ומכילות מזהים
# במבנים לא סטנדרטיים. כל הבדל בין המקורות מיוצג כנתון בשורה כדי שמנגנון הטיפול יישאר קל ומבוסס התניות מינימליות —
# רק מנגנון השליפה מתבסס על "api"; חילוץ/בניית המזהה קוראים מתוך השורה:
#   api == "trakt": קריאה ל-fn(media_type, "") לכל צד; המזהים נמצאים תחת "media_ids" (מילון
#                   של {tmdb,imdb,tvdb} הנצרך כ-id_type "trakt_dict"); צד הטלוויזיה הוא "show".
#   api == "tmdb":  שליפה באמצעות get_tmdb_list({"list_id", "media_type"}) לכל צד; המזהים הם "id"
#                   (id_type "tmdb_id"); צד הטלוויזיה הוא "tv".
MIXED_MY_LIST_SOURCES = {
	"trakt_collection": {
		"api": "trakt",
		"label": "אוסף Trakt מעורב",
		"icon": "trakt",
		"fn": ("apis.trakt_api", "trakt_collection"),
		"id_field": "media_ids",
		"id_type": "trakt_dict",
		"tv_media_type": "show",
	},
	"trakt_watchlist": {
		"api": "trakt",
		"label": "רשימת צפייה Trakt מעורב",
		"icon": "trakt",
		"fn": ("apis.trakt_api", "trakt_watchlist"),
		"id_field": "media_ids",
		"id_type": "trakt_dict",
		"tv_media_type": "show",
	},
	"tmdb_watchlist": {
		"api": "tmdb",
		"label": "רשימת צפייה TMDB מעורב",
		"icon": "tmdb",
		"list_id": "watchlist",
		"id_field": "id",
		"id_type": "tmdb_id",
		"tv_media_type": "tv",
	},
	"tmdb_favorites": {
		"api": "tmdb",
		"label": "מועדפים TMDB מעורב",
		"icon": "tmdb",
		"list_id": "favorites",
		"id_field": "id",
		"id_type": "tmdb_id",
		"tv_media_type": "tv",
	},
	"tmdb_recommendations": {
		"api": "tmdb",
		"label": "המלצות TMDB מעורב",
		"icon": "tmdb",
		"list_id": "recommendations",
		"id_field": "id",
		"id_type": "tmdb_id",
		"tv_media_type": "tv",
	},
}

# שורות מסודרות של (תווית, פעולה, אייקון) עבור תפריט המשנה "הרשימות המעורבות שלי", הנגזרות מטבלת
# המקורות כדי שהתפריט ומנגנון הטיפול ישתפו מקור אמת יחיד (ללא רשימות מקבילות שעלולות להשתנות).
MIXED_MY_LIST_MENU = tuple((source["label"], action, source["icon"]) for action, source in MIXED_MY_LIST_SOURCES.items())


def trakt_ids(item, list_key):
	"""חילוץ מילון מזהי Trakt הרשמי מתוך פריט תגובה של רשימה.

	נקודות הקצה של רשימות Trakt עוטפות פריטים בצורה של ``{"movie": {"ids": {...}}}`` או
	``{"show": {"ids": {...}}}``; חלק מנקודות הקצה מחזירות את מילון המזהים ברמת הרשת העליונה.
	פונקציה זו מאחדת את שתי הצורות.
	"""
	try:
		return item[list_key]["ids"]
	except (KeyError, TypeError):
		return item.get("ids")