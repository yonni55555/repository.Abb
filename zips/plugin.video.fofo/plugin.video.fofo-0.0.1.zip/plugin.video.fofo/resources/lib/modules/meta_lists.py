# -*- coding: utf-8 -*-
"""נתוני חיפוש סטטיים עבור תפריטים, מסננים ומסכי סגנון גילוי (Discover).

מרבית הנתונים נמצאים ב-`resources/data/*.json` — ראו את התיקייה הזו עבור
הסכמות הקנוניות. מודול זה הוא טוען דק: כל פונקציה ציבורית
מחזירה את ה-JSON המנותח עבור ערכת הנתונים שלה, שנשמר בזיכרון המטמון לאחר הטעינה הראשונה.

עוזרי השנה/עשור מחושבים (הם תלויים ב-`datetime.now()`) ולכן הם
נשארים בקוד. `list_display_choices(list_type)` נשאר גם הוא מאחר שהוא מנתב
לפי הארגומנט שלו.
"""

import json
import os

_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data")
_cache = {}


def _load(name):
	if name not in _cache:
		with open(os.path.join(_DATA_DIR, "%s.json" % name), encoding="utf-8") as f:
			_cache[name] = json.load(f)
	return _cache[name]


def get_years(start_year):
	from datetime import datetime

	current_year = datetime.now().year
	return [{"name": str(year), "id": year} for year in range(current_year, start_year - 1, -1)]


def get_decades(start_decade):
	from datetime import datetime

	current_year = datetime.now().year
	current_decade = (current_year // 10) * 10
	return [{"name": "%ss" % decade, "id": decade} for decade in range(current_decade, start_decade - 1, -10)]


def years_movies():
	return get_years(1900)


def years_tvshows():
	return get_years(1944)


def years_anime():
	return get_years(1961)


def decades_movies():
	return get_decades(1900)


def decades_tvshows():
	return get_decades(1940)


def decades_anime():
	return get_decades(1960)


def oscar_winners():
	return _load("oscar_winners")


def movie_certifications():
	return _load("certifications")["movie"]


def tvshow_certifications():
	return _load("certifications")["tvshow"]


def languages():
	return _load("languages")


def language_choices():
	return _load("language_choices")


def regions():
	return _load("regions")


def movie_genres():
	return _load("genres")["movie"]


def tvshow_genres():
	return _load("genres")["tvshow"]


def anime_genres():
	return _load("genres")["anime"]


def mixed_genres():
	return _load("genres")["mixed"]


def networks():
	return _load("networks")


# סיומות עבור חנויות דיגיטליות ש-TMDb מוסיף לרשימות הערוצים של מותגים (למשל "Starz Apple TV Channel").
# הן מוסרות כאשר מאחדים גרסאות שונות כדי שהמותג יצטמצם לפריט תפריט יחיד.
_STOREFRONT_SUFFIXES = (" amazon channel", " apple tv channel", " roku premium channel")

# מותגים עם שמות שונים שחוק הסיומת אינו יכול לאחד בעצמו. TMDb מציג את החנות של Amazon עבור MHz Choice
# תחת שגיאת כתיב "MZ Choice" (מזהה 291), בנפרד מהבסיס "Mhz Choice" (מזהה 427); נאחד אותם יחד.
_BRAND_ALIASES = {"mzchoice": "mhzchoice"}

# שמות תצוגה עבור מפתחות מותגים שבהם התווית שנבחרה אוטומטית אינה אידיאלית (הנתונים משתמשים ב-"MGM Plus",
# "AcornTV Amazon Channel", "Mhz Choice"). קוסמטי בלבד — ממופתח לפי מפתח המותג המנורמל.
_BRAND_DISPLAY = {"mgm+": "MGM+", "acorntv": "Acorn TV", "mhzchoice": "MHz Choice"}


def _strip_storefront(name):
	# (stem, had_suffix) — שם המותג כאשר סיומת ערוץ החנות הדיגיטלית הוסרה בסופו.
	stem = name.strip()
	low = stem.lower()
	for suffix in _STOREFRONT_SUFFIXES:
		if low.endswith(suffix):
			return stem[: len(stem) - len(suffix)].strip(), True
	return stem, False


def _brand_key(name):
	# מפתח התאמה: הסרת סיומת חנות, הפיכה לאותיות קטנות, איחוד האסימון המילולי "Plus" עם "+",
	# הסרת רווחים ואז החלת כינוי (alias). ההחלפה של "plus"←"+" מוגבלת לאסימון בלבד (לא החלפת תת-מחרוזת)
	# כדי שמותג ששמו רק מכיל את האותיות "plus" (למשל מותג היפותטי בשם "Surplus TV") לא ישובש למפתח
	# של מותג אחר ויאוחד איתו בטעות.
	stem = _strip_storefront(name)[0]
	key = "".join("+" if tok == "plus" else tok for tok in stem.lower().split())
	return _BRAND_ALIASES.get(key, key)


def _join_ids(ids):
	# תצורת העברה עבור מזהי החברים של מותג: מספר שלם פשוט עבור מזהה בודד, אחרת מחרוזת מחוברת בצינור (|)
	# ששאילתת `with_watch_providers` של TMDb מבצעת עליה פעולת OR (ומטפל התפריט מפצל אותה חזרה ב-"|").
	return ids[0] if len(ids) == 1 else "|".join(str(x) for x in ids)


def _brand_groups(rows):
	# רשימה ממוינת של (brand_key, group) המאחדת גרסאות ערוצי חנויות דיגיטליות של מותג סטרימינג אחד
	# (למשל "Starz", "Starz Apple TV Channel", "Starz Roku Premium Channel") לקבוצה יחידה שרשימת ה-`ids`
	# שלה מכילה כל מזהה חבר (הבסיס ראשון) וה-`id` מחבר אותם בצינור (|), כך ששאילתת `with_watch_providers`
	# של TMDb מבצעת עליהם OR ושום תוכן לא מתפספס. סדר ההופעה הראשונה נשמר; השם/לוגו נלקחים משורת הבסיס
	# של המותג (כזה ללא סיומת חנות) כאשר היא קיימת, אחרת מהגזע המנוקה של הגרסה הראשונה — כך שמותג שקיים
	# רק כערוץ חנות דיגיטלית ישונה שמו (למשל "Hallmark+"), ולעולם לא יישמט. משותף לתפריטי סרטים/טלוויזיה
	# ולהצטלבות של ספקי ערוצים מעורבים (Mixed Providers).
	groups = {}  # key -> {"order": int, "members": [(id, stem, logo, had_suffix)]}
	for i, row in enumerate(rows):
		stem, had_suffix = _strip_storefront(row["name"])
		g = groups.setdefault(_brand_key(row["name"]), {"order": i, "members": []})
		g["members"].append((row["id"], stem, row.get("logo"), had_suffix))
	out = []
	for key, g in sorted(groups.items(), key=lambda kv: kv[1]["order"]):
		members = g["members"]
		base = next((m for m in members if not m[3]), None)  # base = שורה ללא סיומת חנות דיגיטלית
		ordered = [base] + [m for m in members if m is not base] if base else members
		ids = [m[0] for m in ordered]
		out.append(
			(
				key,
				{
					"ids": ids,  # מזהי חברים גולמיים, הבסיס ראשון — עבור איחוד ספקים מעורבים/חיפוש אייקון
					"id": _join_ids(ids),
					"name": _BRAND_DISPLAY.get(key) or (base[1] if base else ordered[0][1]),
					"logo": next((m[2] for m in ordered if m[2]), None),
				},
			)
		)
	return out


def _collapse_variants(rows):
	# מבנה תפריט ציבורי: המותגים המאוחדים כ-{id, name, logo} (משמיט את רשימת המזהים הגולמיים הפנימית).
	return [{"id": g["id"], "name": g["name"], "logo": g["logo"]} for _, g in _brand_groups(rows)]


def watch_providers_movies():
	return _collapse_variants(_load("watch_providers")["movie"])


def watch_providers_tvshows():
	return _collapse_variants(_load("watch_providers")["tvshow"])


# ספקי רשימות מעורבות שצריכים להתרנדר עם אייקון מקומי חד במקום לוגו ה-h100 הקטן של TMDb.
# ממופתח לפי מזהה ספק צפייה ← שם הרשת המתאים ב-networks.json: האייקון נפתר מאותו קובץ PNG שבו משתמשים
# תפריטי רשתות טלוויזיה / ערוצים מעורבים, כך שעדכון עתידי של הגרפיקה ב-networks.json מועבר באופן אוטומטי
# ללא צורך בשמירה על סנכרון של גיבוב (hash) כאן. מספר מזהים חולקים רשת בכוונה תחילה (Netflix Kids משתמש שוב ב-Netflix,
# AMC+ משתמש שוב ב-AMC, FXNow משתמש שוב ב-FX).
_MIXED_ICON_NETWORK = {
	337: "Disney+",
	8: "Netflix",
	175: "Netflix",
	9: "Amazon",  # Amazon Prime Video; מזהה 10 "Amazon Video" שומר על לוגו ה-TMDb שלו כדי שהשניים יהיו שונים
	350: "Apple TV +",
	15: "Hulu",
	386: "Peacock",
	2303: "Paramount+",
	43: "Starz",
	526: "AMC",
	80: "AMC",
	79: "NBC",
	83: "The CW",
	209: "PBS",
	123: "FX",
	211: "Freeform",
	156: "A&E",
	157: "Lifetime",
	87: "Acorn TV",
	584: "Discovery+",
}

# לשני המותגים ברשימה המעורבת ללא ערך ב-networks.json יש שם בסיס מפורש של network_icons,
# המשקף את דריסת ה-`icon` הספציפית לכל מותג ב-mixed_brands.json.
_MIXED_ICON_FILE = {
	34: "mgm_plus_logo",  # MGM Plus
	283: "crunchyroll_logo",  # Crunchyroll
}


def _mixed_icon(ids, net_logos):
	# שם בסיס מקומי חד של network_icons עבור מותג ברשימה מעורבת, או None כדי לחזור ללוגו ה-TMDb שלו.
	# סורק כל מזהה חבר (הבסיס ראשון) כך שאייקון הממופה לגרסת חנות דיגיטלית בלבד עדיין יתחבר
	# גם כאשר מזהה הבסיס של המותג עצמו אינו נמצא במפות. מותגים המגובים ברשת נפתרים דרך networks.json (לפי שם);
	# השאר משתמשים בקובץ מפורש.
	for provider_id in ids:
		network = _MIXED_ICON_NETWORK.get(provider_id)
		if network:
			return net_logos.get(network)
		if provider_id in _MIXED_ICON_FILE:
			return _MIXED_ICON_FILE[provider_id]
	return None


def watch_providers_mixed():
	# מותגים עם תוכן הן בסרטים והן בטלוויזיה, המאוחדים באותו אופן כמו תפריטי סרטים/טלוויזיה: גרסאות של
	# חנויות דיגיטליות מצטמצמות לשורה אחת שה-`id` שלה מחבר בצינור (|) כל מזהה חבר של סרט+טלוויזיה, כך שלחיצה עליו
	# מפעילה OR בשאילתת TMDb (הפונקציה `mixed_providers` מפעילה את אותן קריאות tmdb_*_providers) במקום לפגוע
	# רק בספק הבסיס ולפספס תוכן של גרסאות אחרות. הצטלבות המותגים מונעת קטגוריות מתות שבהן למותג אין סרטים או אין טלוויזיה;
	# אייקון מקומי חד (`icon`) מחובר לפי מזהה הבסיס היכן שקיים כזה (None אחרת); הרשימה ממוינת בסדר אלפביתי — מה ששומר
	# על Netflix לצד Netflix Kids.
	net_logos = {n["name"]: n.get("logo") for n in _load("networks")}
	movie = dict(_brand_groups(_load("watch_providers")["movie"]))
	tv = dict(_brand_groups(_load("watch_providers")["tvshow"]))
	rows = []
	for key, m in movie.items():
		if key not in tv:
			continue
		ids = m["ids"] + [i for i in tv[key]["ids"] if i not in m["ids"]]  # איחוד, סרט/בסיס ראשון
		rows.append(
			{
				"id": _join_ids(ids),
				"name": m["name"],
				"logo": m["logo"] or tv[key]["logo"],
				"icon": _mixed_icon(ids, net_logos),
			}
		)
	rows.sort(key=lambda p: p["name"].strip().lower())
	return rows


def mixed_brands():
	# "מותגי" סטרימינג שנאצרו עבור רשימת הערוצים המעורבים. כל ערך מחבר בצינור (|) מזהי ספקי צפייה
	# של TMDb (ניתנים להזרמה של סרטים + טלוויזיה) ומזהי רשתות (מקור לאלו של טלוויזיה); מטפל הרשימה
	# מבצע עליהם פעולת OR לכל ציר.
	#
	# מקורות אייקונים, האיכות הטובה ביותר תחילה (התפריט בוחר את הראשון שנפתר):
	#   icon         - שם קובץ מקומי מפורש אופציונלי של network_icons ב-mixed_brands.json, עבור
	#                  מותגים ללא ערך רשת ב-TMDb (למשל Crunchyroll, MGM+).
	#   network_logo - גיבוב ה-PNG המקומי החד מתוך networks.json (מרונדר דרך
	#                  get_icon(..., "network_icons")), המותאם למזהה הרשת הראשון של המותג.
	#   logo         - נתיב תמונת ספק הצפייה של TMDb, המותאם למזהה הספק הראשון שיש לו כזה
	#                  (עדיפות לסרטים על פני טלוויזיה). מזהה ספק הבסיס הקנוני של מותג עשוי להיות
	#                  חסר בתת-קבוצת הנתונים של Forge בעוד שלמזהה גרסת הערוץ עדיין יש לוגו.
	# כולם מוגדרים כ-None/חסרים כאשר שום דבר לא נפתר; התפריט אז חוזר לאייקון גנרי.
	wp = _load("watch_providers")
	logos = {}
	for arr in (wp["movie"], wp["tvshow"]):
		for p in arr:
			logos.setdefault(str(p["id"]), p.get("logo"))
	net_logos = {str(n["id"]): n.get("logo") for n in _load("networks")}
	out = []
	for b in _load("mixed_brands"):
		providers = b.get("providers", "")
		networks = b.get("networks", "")
		logo = next((logos[t] for t in providers.split("|") if logos.get(t)), None)
		network_logo = next((net_logos[t] for t in networks.split("|") if net_logos.get(t)), None)
		out.append({"name": b["name"], "providers": providers, "networks": networks, "icon": b.get("icon"), "logo": logo, "network_logo": network_logo})
	return out


def movie_sorts():
	return _load("sorts")["movie"]


def tvshow_sorts():
	return _load("sorts")["tvshow"]


def discover_items():
	return _load("discover_items")


def color_palette():
	return _load("color_palette")


def list_display_choices(list_type):
	return {
		"tmdb": {
			"choices": [
				("כותרת", "0"),
				("תאריך יצירה (עולה)", "1"),
				("תאריך יצירה (יורד)", "2"),
				("עודכן לאחרונה (עולה)", "3"),
				("עודכן לאחרונה (יורד)", "4"),
				("מספר פריטים (עולה)", "5"),
				("מספר פריטים (יורד)", "6"),
				("דירוג ממוצע (עולה)", "7"),
				("דירוג ממוצע (יורד)", "8"),
				("זמן הרצה כולל (עולה)", "9"),
				("זמן הרצה כולל (יורד)", "10"),
				("הכנסה כוללת (עולה)", "11"),
				("הכנסה כוללת (יורד)", "12"),
			],
			"setting": "tmdblist",
		},
		"personal": {
			"choices": [
				("כותרת", "0"),
				("מחבר", "1"),
				("תאריך יצירה (עולה)", "2"),
				("תאריך יצירה (יורד)", "3"),
				("עודכן לאחרונה (עולה)", "4"),
				("עודכן לאחרונה (יורד)", "5"),
				("מספר פריטים (עולה)", "6"),
				("מספר פריטים (יורד)", "7"),
			],
			"setting": "personal_list",
		},
	}[list_type]