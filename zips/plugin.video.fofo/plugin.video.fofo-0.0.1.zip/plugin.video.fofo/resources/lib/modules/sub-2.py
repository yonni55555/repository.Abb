# -*- coding: utf-8 -*-
import sys
import json
import time
import requests
import xbmc
import xbmcvfs
from unicodedata import normalize
from resources.modules.general import tmdb_key

global_var = []

session = requests.Session()
adapter = requests.adapters.HTTPAdapter(pool_connections=20, pool_maxsize=20, max_retries=1)
session.mount('https://', adapter)
session.mount('http://', adapter)
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
})

_IMDB_CACHE = {}


def fetch_imdb_id(tv_movie, media_id):
    if not media_id:
        return ''
    
    cache_key = f"{tv_movie}_{media_id}"
    if cache_key in _IMDB_CACHE:
        return _IMDB_CACHE[cache_key]

    media_type = 'tv' if tv_movie == 'tv' else 'movie'
    url = f'https://api.themoviedb.org/3/{media_type}/{media_id}?api_key={tmdb_key}&append_to_response=external_ids'
    try:
        res = session.get(url, timeout=1.5).json()
        imdb_id = res.get('external_ids', {}).get('imdb_id', '') or ''
        if imdb_id:
            _IMDB_CACHE[cache_key] = imdb_id
        return imdb_id
    except Exception:
        return ''


def GetJson(imdb, season=0, episode=0, version=b'', check_one=False):
    if not imdb:
        return []

    version_str = version.decode('utf-8') if isinstance(version, bytes) else str(version)
    url = f"http://wizdom.xyz/api/search?action=by_id&imdb={imdb}&season={season}&episode={episode}&version={version_str}"

    try:
        response = session.get(url, timeout=2.0)
        json_object = response.json()
        
        if not json_object or not isinstance(json_object, list):
            return []

        subtitle_list = []
        id_all_collection = set()

        for item_data in json_object:
            item_id = item_data.get("id")
            if item_id not in id_all_collection:
                id_all_collection.add(item_id)
                v_name = item_data.get("versioname")
                if v_name:
                    subtitle_list.append(v_name)
                    if check_one:
                        break
        return subtitle_list
    except Exception:
        return []


def get_links(tv_movie, original_title, name, season_n, episode_n, season, episode, show_original_year, id, check_one=False, imdbid=None, sab=None):
    global global_var

    sab_code = sab or \
               xbmc.getInfoLabel('Window(10000).Property(SAB)') or \
               xbmc.getInfoLabel('Window(10000).Property(SAB-2)') or \
               xbmc.getInfoLabel('Window(10000).Property(subs.player_filename)') or \
               xbmc.getInfoLabel('Window(10000).Property(subtitles.player_filename)')

    if sab_code and not name:
        name = sab_code

    clean_title = original_title.replace("%20", " ").replace("%27", "'")
    
    if not imdbid:
        imdbid = fetch_imdb_id(tv_movie, id)

    if not imdbid:
        return []

    s_num = str(season).replace('%20', '0') if season else '0'
    e_num = str(episode).replace('%20', '0') if episode else '0'
    
    version_param = normalize('NFKD', str(name if name else clean_title)).encode('utf-8', 'ignore')

    results = GetJson(imdbid, s_num, e_num, version_param, check_one)

    seen = set()
    global_var = [x for x in results if not (x in seen or seen.add(x))]
    
    return global_var