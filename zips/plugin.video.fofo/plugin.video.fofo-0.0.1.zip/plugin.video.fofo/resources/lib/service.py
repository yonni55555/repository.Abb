# -*- coding: utf-8 -*-
import os
from threading import Thread
from time import time

from caches.settings_cache import get_setting, set_setting, sync_settings
from modules import kodi_utils
from modules.migrations import run_migrations
from xbmc import Monitor

pause_services_prop = "forge.pause_services"
firstrun_update_prop = "forge.firstrun_update"
current_skin_prop = "forge.current_skin"
trakt_service_string = "עדכון שירות TraktMonitor %s - %s"
trakt_success_line_dict = {"success": "בוצע עדכון Trakt", "no account": "(לא מורשה) בוצע עדכון Trakt"}
update_string = "העדכון הבא בעוד %s דקות..."


class ClearStaleProperties:
	"""D8: ניקוי מאפייני חלון שאינם מטמון (non-cache) שנותרו מהרצת שירות קודמת.

	`Window(10000)` נשאר לאורך כל סשן הקודי, ולכן כל מאפיין שנכתב באמצעות
	`kodi_utils.set_property` שורד מעבר לקריאה לתוסף ומעבר לאתחול שירות
	שנגרם מעדכון הרחבה (רק יציאה מלאה מקודי מנקה את הזיכרון). מרבית המאפיינים
	של `forge.*` נופלים לאחת מארבע קטגוריות:

	- **קבועי הרחבה** — נכתבים על ידי `SetAddonConstants` בכל הפעלה, ולכן אין מה לנקות (הם נדרסים).
	- **שיקופי מטמון הגדרות** (`settings_cache.set_setting` משכפל כל הגדרה אל `forge.<id>`) — מטמון, נבנה מחדש בצורה עצלנית. בטוח להשאיר.
	- **אובייקטים דמויי מטמון** (למשל `forge.meta_season_<id>`) — מטמון. בטוח להשאיר.
	- **נועלים (Latches), מצב ממשק משתמש, סימוני תהליך פעיל** — אלו *כן* דולפים בין הפעלות ויכולים להרעיל את הסשן הבא. נקה אותם כאן.

	הנועל של רענון טראקט (trakt refresh) הוסר מאז E5 (הוחלף ב-`threading.Lock`) אך נשאר ברשימה כדי שהתקנות ישנות שמקבלות שדרוג לגרסה זו לא ירשו ערך `"true"` ישן שלעולם לא יתנקה.

	משפחות שמות דינמיות (`forge.internal_results.<provider>`, `forge.download_status.<name>`, מאפייני אחוזים של `forge.<download_name>`) מנוהלות במחזור החיים שלהן על ידי הקוד שבבעלותן (מנקות בסוף הסשן). הדרך היחידה שבה הן דולפות היא קריסה באמצע סריקה או הורדה; כיסוי שלהן ידרוש רישום של שמות פעילים או ניקוי מוחלט (`clearProperties()`) של `Window(10000)`, מה שימחק גם רשומות השייכות להרחבות אחרות. מחוץ לטווח של D8.
	"""

	# נועלים וסימוני תהליך פעיל שלא אמורים לשרוד אתחול שירות.
	_LATCH_PROPS = (
		"forge.trakt_refreshing_token",  # נועל מיושן מ-E5; מנוקה הגנתית עבור התקנות ישנות
		"forge.active_queued_downloads",
		"forge.active_downloads",
		"forge.external_scraper.module",
		"forge.widget_reload_pending",  # בקשת רענון ווידג'ט דחויה; פג תוקף אם לא טופל בכיבוי
	)

	# מצב ממשק משתמש מקריאות לתוסף בסשן הקודם.
	_UI_STATE_PROPS = (
		"forge.window_loaded",
		"forge.window_stack",
		"forge.current_skin",
		"forge.current_font",
		"forge.exit_params",
		"forge.random_episode_history",
		"forge.random_because_you_watched",
		"forge.personal.lists.order",
		"forge.tmdb.lists.order",
		"forge.trakt.lists.order",
	)

	# דגלים ברמת השירות. `pause_services` מנוקה כדי שדגל שומר מסך/מצב שינה שנקבע בסשן הקודם לא ישאיר את השירותים החדשים תקועים במצב מושהה.
	# `firstrun_update` מנוקה כדי ש-`UpdateCheck` באמת ירוץ פעם אחת בהפעלה זו, במקום לעקוף בגלל שההפעלה הקודמת הגדירה אותו.
	# `fresh_install` (J4) הוא אות לכל הפעלה ש-`sync_settings` מגדיר מחדש רק כאשר מסד הנתונים של ההגדרות ריק; ניקוי שלו כאן מונע מערך "true" ישן מאותה הפעלה לתייג בטעות אתחול שירות מאוחר יותר.
	_SERVICE_FLAG_PROPS = (
		pause_services_prop,
		firstrun_update_prop,
		"forge.fresh_install",
	)

	def run(self):
		kodi_utils.logger("Forge", "שירות ClearStaleProperties מתחיל")
		for prop in (*self._LATCH_PROPS, *self._UI_STATE_PROPS, *self._SERVICE_FLAG_PROPS):
			kodi_utils.clear_property(prop)
		return kodi_utils.logger("Forge", "שירות ClearStaleProperties הסתיים")


class SetAddonConstants:
	def run(self):
		kodi_utils.logger("Forge", "שירות SetAddonConstants מתחיל")
		import random

		addon_items = [
			("forge.playback_key", str(random.randint(1000, 10000))),
			("forge.addon_version", kodi_utils.addon_info("version")),
			("forge.addon_path", kodi_utils.addon_info("path")),
			("forge.addon_profile", kodi_utils.translate_path(kodi_utils.addon_info("profile"))),
			("forge.addon_icon", kodi_utils.translate_path(kodi_utils.addon_info("icon"))),
			(
				"forge.addon_icon_mini",
				os.path.join(
					kodi_utils.addon_info("path"),
					"resources",
					"media",
					"addon_icons",
					"minis",
					os.path.basename(kodi_utils.translate_path(kodi_utils.addon_info("icon"))),
				),
			),
			("forge.addon_fanart", kodi_utils.addon_fanart()),
		]
		for item in addon_items:
			kodi_utils.set_property(*item)
		return kodi_utils.logger("Forge", "שירות SetAddonConstants הסתיים")


class DatabaseMaintenance:
	def run(self):
		kodi_utils.logger("Forge", "שירות DatabaseMaintenance מתחיל")
		from caches.base_cache import check_databases_integrity

		check_databases_integrity(silent=True)
		return kodi_utils.logger("Forge", "שירות DatabaseMaintenance הסתיים")


class SyncSettings:
	def run(self):
		kodi_utils.logger("Forge", "שירות SyncSettings מתחיל")
		sync_settings()
		return kodi_utils.logger("Forge", "שירות SyncSettings הסתיים")


def _migrate_rename_mixed_root():
	"""0.2.1: שינוי שם הרשומה השמורה 'Mixed' בתפריט הראשי ל-'Mixed Movies & TV'.

	התפריט הראשי נשמר לכל התקנה ב-navigator_db; עריכת NavigatorCache.root_list
	משפיעה רק על התקנות טריות. ()rebuild_database מרענן את שורת ברירת המחדל;
	שורה מותאמת אישית שנערכה נשתלת במקום. אידמפוטנטי — הרצה חוזרת לא תבצע דבר ברגע שהשם כבר שונה.
	"""
	from caches.navigator_cache import navigator_cache

	navigator_cache.rebuild_database()
	edited = navigator_cache.get_list("RootList", "edited")
	if not edited:
		return
	changed = False
	for entry in edited:
		if entry.get("mode") == "navigator.mixed" and entry.get("name") == "Mixed":
			entry["name"] = "Mixed Movies & TV"
			changed = True
	if changed:
		navigator_cache.set_list("RootList", "edited", edited)


def _migrate_add_play_trailer_to_cm():
	"""0.2.1: שילוב 'play_trailer' לתוך רשימת סדר/הפעלה של תפריט הקשר מותאם אישית
	כך שמשתמשים שהתאימו אישית את התפריט שלהם לפני תכונת "נגן קדימון" עדיין
	יראו את הרשומה החדשה. התקנות טריות/שמעולם לא הותאמו אישית כבר כוללות את זה דרך
	ברירות המחדל של הסכמה, ולכן הרשימות האלו מכילות את זה ומדלגים עליהן. אידמפוטנטי."""
	for sid in ("context_menu.order", "context_menu.enabled"):
		raw = get_setting("forge.%s" % sid, "")
		items = raw.split(",") if raw else []
		if not items or "play_trailer" in items:
			continue
		if "extras" in items:
			items.insert(items.index("extras") + 1, "play_trailer")
		else:
			items.append("play_trailer")
		set_setting(sid, ",".join(items))


def _migrate_add_quick_add_to_cm():
	"""0.2.6: שילוב 'quick_add' לתוך רשימת סדר/הפעלה של תפריט הקשר מותאם אישית
	כך שמשתמשים שהתאימו אישית את התפריט שלהם לפני תכונת "הוספה מהירה" עדיין יראו את
	הרשומה החדשה. התקנות טריות/שמעולם לא הותאמו אישית כבר כוללות את זה דרך ברירות
	המחדל של הסכמה, ולכן הרשימות האלו מכילות את זה ומדלגים עליהן. אידמפוטנטי."""
	for sid in ("context_menu.order", "context_menu.enabled"):
		raw = get_setting("forge.%s" % sid, "")
		items = raw.split(",") if raw else []
		if not items or "quick_add" in items:
			continue
		if "favorites_manager" in items:
			items.insert(items.index("favorites_manager") + 1, "quick_add")
		else:
			items.append("quick_add")
		set_setting(sid, ",".join(items))


# רישום מיגרציות מסודר (J4). הוסף מיגרציות חדשות בתחתית, מפתח לפי גרסת התוסף
# שמפיצה אותן לראשונה, ועדכן את addon.xml בהתאם (מיגרציה שמפתחיה מעל הגרסה המופצת
# לעולם לא תרוץ). מיגרציות חייבות להיות אידמפוטנטיות; אין צורך בדגל settings_schema.
# ראה modules/migrations.py.
MIGRATIONS = (
	("0.2.1", _migrate_rename_mixed_root),
	("0.2.1", _migrate_add_play_trailer_to_cm),
	("0.2.6", _migrate_add_quick_add_to_cm),
)


class OnUpdateChanges:
	def run(self):
		kodi_utils.logger("Forge", "שירות OnUpdateChanges מתחיל")
		try:
			run_migrations(
				MIGRATIONS,
				current_version=kodi_utils.addon_version(),
				stored_version=get_setting("forge.migration_version", ""),
				is_fresh_install=get_setting("forge.fresh_install", "") == "true",
				stamp=self._stamp,
				run=lambda fn: fn(),
				log=lambda msg: kodi_utils.logger("Forge", "OnUpdateChanges %s" % msg),
			)
		except Exception as e:
			kodi_utils.logger("Forge", "ניתוב OnUpdateChanges נכשל: %s" % e)
		return kodi_utils.logger("Forge", "שירות OnUpdateChanges הסתיים")

	def _stamp(self, version):
		try:
			set_setting("migration_version", version)
		except Exception as e:
			kodi_utils.logger("Forge", "OnUpdateChanges לא הצליח להחתים את גרסה %s: %s" % (version, e))


class CacheMaintenance:
	def run(self):
		kodi_utils.logger("Forge", "שירות CacheMaintenance מתחיל")
		from caches.base_cache import clean_databases_silent

		monitor = kodi_utils.kodi_monitor()
		wait_for_abort = monitor.waitForAbort
		# פיזור סריקת ההתחלה כדי שלא תתחרה עם עבודת העלייה של המערכת.
		wait_for_abort(120)
		while not monitor.abortRequested():
			while kodi_utils.get_property(pause_services_prop) == "true":
				if wait_for_abort(10):
					break
			if monitor.abortRequested():
				break
			try:
				clean_databases_silent()
			except Exception as e:
				kodi_utils.logger("CacheMaintenance", "הסריקה נכשלה: %s" % e)
			try:
				interval = max(1, int(get_setting("forge.cache.maintenance_interval_hours", "24")))
			except (ValueError, TypeError):
				interval = 24
			wait_for_abort(interval * 3600)
		try:
			del monitor
		except:
			pass
		return kodi_utils.logger("Forge", "שירות CacheMaintenance הסתיים")


class CustomWindowsPrepare:
	def run(self):
		kodi_utils.logger("Forge", "שירות CustomWindowsPrepare מתחיל")
		from windows.base_window import ExtrasUtils, FontUtils

		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		kodi_utils.clear_property(current_skin_prop)
		ExtrasUtils().run()
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			wait_for_abort(20)
		try:
			del monitor
		except:
			pass
		try:
			del player
		except:
			pass
		return kodi_utils.logger("Forge", "שירות CustomWindowsPrepare הסתיים")


class TraktMonitor:
	def run(self):
		kodi_utils.logger("Forge", "שירות TraktMonitor מתחיל")
		from apis.trakt_api import trakt_sync_activities
		from modules.settings import trakt_sync_interval, trakt_user_active

		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == "true":
				wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				if trakt_user_active:
					status = trakt_sync_activities()
				else:
					status = "no_auth"
				if status == "failed":
					kodi_utils.logger("Forge", trakt_service_string % ("נכשל. שגיאה מ-Trakt", next_update_string))
				elif status == "no_auth":
					kodi_utils.logger("Forge", trakt_service_string % ("לא הופעל. אין חשבון Trakt נוכחי", next_update_string))
				else:
					if status in ("success", "no account"):
						kodi_utils.logger("Forge", trakt_service_string % ("הצלחה. %s" % trakt_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger("Forge", trakt_service_string % ("הצלחה. לא נדרשים שינויים", next_update_string))  # 'לא נחוץ'
					if status == "success" and get_setting("forge.trakt.refresh_widgets", "false") == "true":
						kodi_utils.request_widget_reload()
			except Exception as e:
				kodi_utils.logger("Forge", trakt_service_string % ("נכשל", "התרחשה השגיאה הבאה: %s" % str(e)))
			wait_for_abort(wait_time)
		try:
			del monitor
		except:
			pass
		try:
			del player
		except:
			pass
		return kodi_utils.logger("Forge", "שירות TraktMonitor הסתיים")


class UpdateCheck:
	def run(self):
		return
		if kodi_utils.get_property(firstrun_update_prop) == "true":
			return
		kodi_utils.logger("Forge", "שירות UpdateCheck מתחיל")
		from modules.settings import update_action, update_delay
		from modules.updater import update_check
		end_pause = time() + update_delay()
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while time() < end_pause:
				wait_for_abort(1)
			while kodi_utils.get_property(pause_services_prop) == "true" or is_playing():
				wait_for_abort(1)
			update_check(update_action())
			break
		kodi_utils.set_property(firstrun_update_prop, "true")
		try:
			del monitor
		except:
			pass
		try:
			del player
		except:
			pass
		return kodi_utils.logger("Forge", "שירות UpdateCheck הסתיים")


class WidgetRefresher:
	def run(self):
		kodi_utils.logger("Forge", "שירות WidgetRefresher מתחיל")
		from time import time

		monitor = kodi_utils.kodi_monitor()
		wait_for_abort = monitor.waitForAbort
		wait_for_abort(10)
		self.set_next_refresh(time())
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				offset = int(get_setting("forge.widget_refresh_timer", "60"))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if not kodi_utils.widgets_refresh_safe():
					continue
				# הושג מצב בטוח. טפל קודם כל בבקשת טעינה מפורשת (ללא תלות בטיימר המחזורי, כדי שהיא עדיין תופעל כשהטיימר מושבת)...
				if kodi_utils.get_property("forge.widget_reload_pending"):
					kodi_utils.logger("Forge", "שירות WidgetRefresher - ווידג'טים רועננו (לפי בקשה)")
					# רענן תחילה, ואז נקה: אם ()reload_home_widgets זורק שגיאה (למשל מסד נתונים נעול), הדגל שורד והבקשה מנוסה שוב בפעימה הבאה במקום להיזרק בשקט.
					kodi_utils.reload_home_widgets()
					kodi_utils.clear_property("forge.widget_reload_pending")
					self.set_next_refresh(time())
					continue
				# ...ואז הרענון המחזורי, כאשר הטיימר שלו מופעל והגיע הזמן.
				if self.next_refresh is not None and self.next_refresh < time():
					kodi_utils.logger("Forge", "שירות WidgetRefresher - ווידג'טים רועננו")
					kodi_utils.reload_home_widgets()
					self.set_next_refresh(time())
			except:
				pass
		try:
			del monitor
		except:
			pass
		return kodi_utils.logger("Forge", "שירות WidgetRefresher הסתיים")

	def set_next_refresh(self, _time):
		self.offset = int(get_setting("forge.widget_refresh_timer", "60"))
		if self.offset:
			self.next_refresh = _time + (self.offset * 60)
		else:
			self.next_refresh = None


class AutoStart:
	def run(self):
		kodi_utils.logger("Forge", "שירות AutoStart מתחיל")
		from modules.settings import auto_start_forge

		if auto_start_forge():
			kodi_utils.run_addon()
		return kodi_utils.logger("Forge", "שירות AutoStart הסתיים")


class AddonXMLCheck:
	def run(self):
		kodi_utils.logger("Forge", "שירות AddonXMLCheck מתחיל")
		from xml.dom.minidom import parse as mdParse

		self.addon_xml = kodi_utils.translate_path("special://home/addons/plugin.video.fofo/addon.xml")
		self.root = mdParse(self.addon_xml)
		self.change_list = []
		self.check_property("reuse_language_invoker", "reuselanguageinvoker")
		self.change_xml_file()
		return kodi_utils.logger("Forge", "שירות AddonXMLCheck הסתיים")

	def check_property(self, setting, tag_name):
		current_addon_setting = get_setting("forge.%s" % setting, None)
		if current_addon_setting is None:
			return
		tag_instance = self.root.getElementsByTagName(tag_name)[0].firstChild
		current_property = tag_instance.data
		if current_property != current_addon_setting:
			tag_instance.data = current_addon_setting
			self.change_list.append(tag_name)

	def change_xml_file(self):
		if not self.change_list:
			return
		kodi_utils.notification("מרענן קובץ Addon XML. מאתחל הרחבות")
		new_xml = str(self.root.toxml()).replace('<?xml version="1.0" ?>', "")
		with open(self.addon_xml, "w") as f:
			f.write(new_xml)
		kodi_utils.logger("Forge", "שירות AddonXMLCheck - זוהה שינוי. מאתחל הרחבות")
		kodi_utils.execute_builtin("ActivateWindow(Home)", True)
		kodi_utils.update_local_addons()
		kodi_utils.disable_enable_addon()


class ForgeMonitor(Monitor):
	def __init__(self):
		Monitor.__init__(self)
		self.startServices()

	def startServices(self):
		try:
			ClearStaleProperties().run()
		except Exception as e:
			kodi_utils.logger("ClearStaleProperties", str(e))
		try:
			SetAddonConstants().run()
		except Exception as e:
			kodi_utils.logger("SetAddonConstants", str(e))
		try:
			DatabaseMaintenance().run()
		except Exception as e:
			kodi_utils.logger("DatabaseMaintenance", str(e))
		try:
			SyncSettings().run()
		except Exception as e:
			kodi_utils.logger("SyncSettings", str(e))
		try:
			OnUpdateChanges().run()
		except Exception as e:
			kodi_utils.logger("OnUpdateChanges", str(e))
		try:
			AddonXMLCheck().run()
		except Exception as e:
			kodi_utils.logger("AddonXMLCheck", str(e))
		Thread(target=CustomWindowsPrepare().run).start()
		Thread(target=TraktMonitor().run).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=WidgetRefresher().run).start()
		Thread(target=CacheMaintenance().run).start()
		try:
			AutoStart().run()
		except Exception as e:
			kodi_utils.logger("AutoStart", str(e))

	def onNotification(self, sender, method, data):
		if method in ("GUI.OnScreensaverActivated", "System.OnSleep"):
			kodi_utils.set_property(pause_services_prop, "true")
			kodi_utils.logger("OnNotificationActions", "משהה את שירותי Forge עקב מצב שינה של המכשיר")
		elif method in ("GUI.OnScreensaverDeactivated", "System.OnWake"):
			kodi_utils.clear_property(pause_services_prop)
			kodi_utils.logger("OnNotificationActions", "מחזיר לפעילות את שירותי Forge עקב התעוררות המכשיר")


kodi_utils.logger("Forge", "שירות מוניטור ראשי מתחיל")
ForgeMonitor().waitForAbort()
kodi_utils.logger("Forge", "שירות מוניטור ראשי הסתיים")