import os,re,time
import xbmc,xbmcaddon,xbmcvfs,xbmcgui
import threading
import requests
from urllib.parse import unquote_plus, unquote, quote, urlparse, parse_qs
import unicodedata
from resources.modules import cache
from resources.modules import log

# Optimize: Cache addon info at module level
_addon = xbmcaddon.Addon('service.subtitles.All_Subs')
iconx = _addon.getAddonInfo('icon')
MyScriptName = _addon.getAddonInfo('name') or 'DarkSubs'
xbmc_tranlate_path = xbmcvfs.translatePath
user_dataDir = xbmc_tranlate_path(xbmcaddon.Addon().getAddonInfo("profile"))

# Ensure directories exist
if not os.path.exists(user_dataDir):
    os.makedirs(user_dataDir)
    
CachedSubFolder = xbmc_tranlate_path(os.path.join(user_dataDir, 'Cached_subs'))
MySubFolder = xbmc_tranlate_path(os.path.join(user_dataDir, 'Downloaded_subs'))
TransFolder = xbmc_tranlate_path(os.path.join(user_dataDir, 'trans_subs'))


def ensure_cache_dirs():
    """Cached_subs may be deleted by clean_folders — recreate before listdir."""
    for folder in (user_dataDir, CachedSubFolder, MySubFolder, TransFolder):
        if folder and not os.path.exists(folder):
            try:
                os.makedirs(folder)
            except OSError:
                try:
                    xbmcvfs.mkdirs(folder)
                except Exception:
                    pass


ensure_cache_dirs()

MyScriptID = xbmcaddon.Addon().getAddonInfo('id')
addonPath = xbmc_tranlate_path(xbmcaddon.Addon().getAddonInfo("path"))

# Global variables (consider thread-safety if accessed from multiple threads)
show_msg = ""
progress_msg = 0
break_all = False

# Optimized: Use try/except for settings read with fallback
try:
    DEFAULT_REQUEST_TIMEOUT = int(xbmcaddon.Addon().getSetting('max_search_time')) or 10
except (ValueError, AttributeError):
    DEFAULT_REQUEST_TIMEOUT = 10

class OverlayText:
    """Small centered toast: icon + title line + native progress bar.

    Replaced the old full-width top-center black bar (a single flat
    background.png stretched to 1330x150) with a compact card, and the
    underscore-string "progress bar" hack with a real ControlProgress --
    left textures blank so it renders using the active skin's own
    progress-bar style instead of anything we'd have to draw ourselves.
    """
    def __init__(self):
        log.warning('(Overlay) Initialize overlay text')
        self._shown       = False
        self._window     = xbmcgui.Window(12005)
        (x, y, w, h, x2, y2, w2, h2, x3, y3, w3, h3,
         xp, yp, wp, hp) = self._calculate_the_size()

        self._label      = xbmcgui.ControlLabel(
            x, y, w, h, '', alignment=0x00000001 | 0x00000004, font='font13')

        self._icon = xbmcgui.ControlImage(x2, y2, w2, h2, iconx)
        self._background = xbmcgui.ControlImage(x3, y3, w3, h3, os.path.join(addonPath,"resources","art","background.png"))
        self._background.setColorDiffuse("0xE0000000")
        self._progress = xbmcgui.ControlProgress(xp, yp, wp, hp)

    def __enter__(self):
        return self

    def open(self):
        if not self._shown:
            self._window.addControls([self._background,self._icon, self._label, self._progress])
            self._shown = True

    def isShowing(self):
        return self._shown

    def setText(self, text):
        if self._shown:
            self._label.setLabel(text)

    def setProgress(self, percent):
        if self._shown:
            try:
                self._progress.setPercent(max(0, min(100, int(percent))))
            except Exception:
                pass

    def _calculate_the_size(self):
        # This adds controls to the existing skin-defined Window(12005)
        # (Video OSD) rather than a freshly-created WindowDialog -- unlike
        # SearchProgressDialog's own WindowDialog (which defaults to the
        # full canvas and reliably reports it via getWidth/getHeight), an
        # existing skin-authored window's getWidth/getHeight reflects
        # whatever size the skin gave THAT window (e.g. VideoOSD.xml may not
        # be full-screen), not the coordinate canvas addControls() actually
        # positions new controls in -- querying it moved this off-target.
        # 1920x1080 (the GUI-coordinate canvas virtually every skin uses,
        # auto-scaled by Kodi to the real display) is the right constant here.
        viewport_w = 1920
        viewport_h = 1080

        # Compact card, top-right corner -- a small autosearch notification,
        # distinct from SearchProgressDialog's bigger centered dialog used
        # for the manual "search subtitles" flow.
        w3 = 560
        h3 = 130
        x3 = viewport_w - w3 - 40
        y3 = 40

        w2 = 70
        h2 = 70
        x2 = x3 + 20
        y2 = y3 + 18

        x = x2 + w2 + 18
        y = y3 + 16
        w = x3 + w3 - 20 - x
        h = 42

        xp = x2
        yp = y3 + h3 - 34
        wp = w3 - 40
        hp = 18

        return x, y, w, h, x2, y2, w2, h2, x3, y3, w3, h3, xp, yp, wp, hp

    def __exit__(self, *exc_info):
        self.close()
        return not exc_info[0]

    def __del__(self):
        self.close()

    def close(self):
        if hasattr(self, '_icon') and self._shown:
            self._window.removeControls([self._background,self._icon, self._label, self._progress])
            self._shown = False


class SearchProgressDialog(xbmcgui.WindowDialog):
    """Custom-styled replacement for xbmcgui.DialogProgress, used for the
    manual "search subtitles" flow. Kodi's native DialogProgress is styled
    entirely by whatever skin is active -- this gives a consistent look
    regardless of skin, at the cost of hand-rolling cancel detection.

    Same four-method shape as xbmcgui.DialogProgress (create/update/
    iscanceled/close) so it drops into main.py's existing polling loop
    without changing that loop's structure.
    """

    _ACTION_PREVIOUS_MENU = 10
    _ACTION_NAV_BACK = 92
    _ACTION_SELECT_ITEM = 7

    def __init__(self):
        super().__init__()
        self._canceled = False

        # System.ScreenWidth/Height reports the real display resolution, not
        # the skin's virtualized GUI coordinate space this dialog actually
        # positions itself in (Kodi auto-scales that canvas to whatever the
        # real display is) -- on setups where those differ (e.g. a 4K
        # display with a 1080p-authored skin), centering against it lands
        # the dialog off-center. A fresh WindowDialog with no explicit
        # <width>/<height> defaults to the full canvas, so ask it directly
        # via getWidth()/getHeight() instead of guessing from elsewhere.
        try:
            viewport_w = self.getWidth() or 1920
            viewport_h = self.getHeight() or 1080
        except Exception:
            viewport_w, viewport_h = 1920, 1080

        # Height built bottom-up from each row's own size + a fixed gap above
        # it, instead of a fixed box with rows placed by eyeballed offsets --
        # the old 260px box left ~60px of empty space between the detail
        # label and the progress bar.
        w = 700
        margin_top, margin_bottom = 22, 16
        title_h, gap1 = 30, 10
        detail_h, gap2 = 48, 12
        bar_h, gap3 = 8, 14
        btn_h = 30
        h = margin_top + title_h + gap1 + detail_h + gap2 + bar_h + gap3 + btn_h + margin_bottom
        x = int((viewport_w - w) / 2)
        y = int((viewport_h - h) / 2)
        bg_path = os.path.join(addonPath, "resources", "art", "background.png")

        self._background = xbmcgui.ControlImage(x, y, w, h, bg_path)
        self._background.setColorDiffuse("0xE0000000")

        icon_size = 56
        self._icon = xbmcgui.ControlImage(x + 26, y + margin_top, icon_size, icon_size, iconx)

        text_x = x + 26 + icon_size + 20
        text_w = w - (26 + icon_size + 20 + 26)
        title_y = y + margin_top
        self._title = xbmcgui.ControlLabel(
            text_x, title_y, text_w, title_h, '', font='font14')
        detail_y = title_y + title_h + gap1
        self._detail = xbmcgui.ControlLabel(
            text_x, detail_y, text_w, detail_h, '', font='font12')

        # ControlProgress renders nothing without explicit skin textures --
        # draw the bar ourselves with two ControlImages instead: a dim
        # track and a bright fill whose width we resize on every update().
        # setColorDiffuse multiplies the tint onto the source texture's own
        # pixels, so it must be a WHITE base image (white x color = color) --
        # background.png is solid black (black x anything = black), which is
        # why the bar was invisible. white.png is a plain white fill we ship
        # just for this diffuse-tinting purpose.
        white_path = os.path.join(addonPath, "resources", "art", "white.png")
        percent_w = 54
        bar_y = detail_y + detail_h + gap2
        bar_x, bar_w = x + 26, w - 52 - percent_w - 10
        self._progress_track = xbmcgui.ControlImage(bar_x, bar_y, bar_w, bar_h, white_path)
        self._progress_track.setColorDiffuse("0x50FFFFFF")
        self._progress_fill = xbmcgui.ControlImage(bar_x, bar_y, 1, bar_h, white_path)
        self._progress_fill.setColorDiffuse("0xFFE5A82E")
        self._bar_x, self._bar_w = bar_x, bar_w

        self._percent_label = xbmcgui.ControlLabel(
            bar_x + bar_w + 10, bar_y - 6, percent_w, bar_h + 12, '0%',
            alignment=0x00000001, font='font12')

        # Explicit textures (not the skin default) and explicit text colors
        # in both states -- without these the button fell back to the
        # skin's default focus texture (a bright/white highlight) with no
        # overridden text color, so the label went white-on-white when focused.
        btn_y = bar_y + bar_h + gap3
        self._cancel_btn = xbmcgui.ControlButton(
            x + w - 130, btn_y, 100, btn_h, 'ביטול',
            focusTexture=bg_path, noFocusTexture=bg_path, font='font12',
            textColor='0xFFFFFFFF', focusedColor='0xFFE5A82E')

        self.addControls([
            self._background, self._icon, self._title, self._detail,
            self._progress_track, self._progress_fill, self._percent_label,
            self._cancel_btn,
        ])

    def create(self, title, line=''):
        self._title.setLabel('[B]{0}[/B]'.format(title))
        self._detail.setLabel(line)
        self._progress_fill.setWidth(1)
        self._percent_label.setLabel('0%')
        self.show()
        try:
            self.setFocus(self._cancel_btn)
        except Exception:
            pass

    def update(self, percent, line1='', line2='', line3=''):
        try:
            pct = max(0, min(100, int(percent)))
            self._progress_fill.setWidth(max(1, int(self._bar_w * pct / 100)))
            self._percent_label.setLabel('{0}%'.format(pct))
        except Exception:
            pass
        text = '\n'.join(t for t in (line1, line2, line3) if t)
        if text:
            self._detail.setLabel(text)

    def iscanceled(self):
        return self._canceled

    def close(self):
        try:
            super().close()
        except Exception:
            pass

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (self._ACTION_PREVIOUS_MENU, self._ACTION_NAV_BACK):
            self._canceled = True
            self.close()
        elif action_id == self._ACTION_SELECT_ITEM and self.getFocusId() == self._cancel_btn.getId():
            self._canceled = True
            self.close()

    def onControl(self, control):
        if control == self._cancel_btn:
            self._canceled = True
            self.close()


class Thread (threading.Thread):
   def __init__(self, target, *args):
    super().__init__(target=target, args=args)
    self.result = None
   def run(self, *args):
      self.result = self._target(*self._args)
      return 0
   def exit(self):
        # Python threads have no safe public "kill" API -- a thread still
        # running past the search time budget just keeps running in the
        # background. That's fine: results are read from this Thread
        # instance's own .result (not a shared module-level global), so
        # an abandoned thread finishing late can no longer contaminate a
        # later, unrelated search.
        pass
def show_results():
    global break_all
    break_all=False

    try:
        cond=xbmc.Monitor().abortRequested()
    except:
        cond=xbmc.abortRequested

    close_overlay=False
    time_out=0
    with OverlayText() as _overlay:

      while (not cond) and (xbmc.Player().isPlaying()):
        from resources.modules.general import show_msg, progress_msg
        _overlay.open()
        if close_overlay:
          break

        if _overlay.isShowing():
            if (show_msg!="END"):
                _overlay.setText(show_msg)
                _overlay.setProgress(progress_msg)

        time.sleep(0.1)
        time_out+=1
        if (show_msg=="END") or (time_out>1200):
            close_overlay=True
            _overlay.close()

def notify(msg_id, times=3500, icon=iconx, sound=False):
    try:
        title = MyScriptName
    except NameError:
        title = 'DarkSubs'
    try:
        xbmcgui.Dialog().notification(
            title, f"[COLOR yellow]{msg_id}[/COLOR]", icon, int(times), sound)
    except Exception as e:
        log.warning('notify failed: {0}'.format(e))
        

def extract_season_episode_numbers(subtitle_file_name):

    import re
    optional_separators = r'[\s._\-x+,&:]{0,2}' # 0-2 occurrences
    optional_middle_separators = r'[\s._\-x+,&:]{0,4}' # 0-4 occurrences

    regex_pattern = re.compile(
        r'S[e]?(?:ason)?' + optional_separators +
        '(?P<season_number>\d{1,2})' + optional_middle_separators +
        'E[p]?(?:isode)?' + optional_separators +
        '(?P<episode_number>\d{1,3})',
        re.IGNORECASE
    )
    
    match = regex_pattern.search(subtitle_file_name)
    if match:
        # Fill leading zero if needed
        return match.group('season_number').zfill(2), match.group('episode_number').zfill(2)

    return None, None

def set_media_type(video_data):

    def _translate_media_type(media_type):
        # TV Show
        if media_type in ['tvshow', 'season', 'episode']:
            return 'tv'
            
        # Movie
        # TEMPORARY: 'movies' should be 'movie' in Telemedia's code
        elif media_type in ['movie', 'movies']:
            return 'movie'
            
        return None

    if xbmc.Player().isPlaying():
        try:
            # https://alwinesch.github.io/group__python___info_tag_video.html#gae415e4abfc18ab4178c49953159e1233)
            # Try to get media_type parameter from playing addon's setMediaType function from InfoTagVideo API (From Kodi 20 and above)
            # Example supporting addons: Telemedia, Mando, Fen, Fen Light, Cobra, Kitana, Twilight, Otaku
            video_data['media_type_videoInfoTag'] = xbmc.Player().getVideoInfoTag().getMediaType()
            log.warning(f"DEBUG | get_video_data | set_media_type | media_type_videoInfoTag = {video_data['media_type_videoInfoTag']}")

            media_type = _translate_media_type(video_data['media_type_videoInfoTag'])
            if media_type:
                video_data['media_type'] = media_type
                return video_data
        except:
            pass
            
    else:
            video_data['media_type_ListItem.DBTYPE'] = xbmc.getInfoLabel("ListItem.DBTYPE")
            log.warning(f"DEBUG | get_video_data | set_media_type | media_type_ListItem.DBTYPE = {video_data['media_type_ListItem.DBTYPE']}")

            media_type = _translate_media_type(video_data['media_type_ListItem.DBTYPE'])
            if media_type:
                video_data['media_type'] = media_type
                return video_data
    

    # Fallback - manually determine media_type based on other parameters
    log.warning(f"DEBUG | get_video_data | set_media_type | Fallbacks to manually set media_type.")
    if video_data['TVShowTitle'] and (video_data['season'] != '0' or video_data['episode'] != '0'):
        video_data['media_type'] = 'tv'
    else:
        video_data['media_type'] = 'movie'
    return video_data
        

def get_playing_addon(playing_addon=""):
    playing_addon_temp = xbmc.getInfoLabel("ListItem.FileNameAndPath")
    
    if len(playing_addon_temp) > 0 and any(prefix in playing_addon_temp for prefix in ['plugin://', 'smb://', 'pvr://']):
        if 'pvr://' in playing_addon_temp:
            playing_addon = 'pvr://video' 
        else:
            regex = '//(.+?)/'
            import re
            match = re.findall(regex, playing_addon_temp)
            playing_addon = match[0] if match else playing_addon_temp
            
    return playing_addon
      
def take_title_from_focused_item():
    labelType = xbmc.getInfoLabel("ListItem.DBTYPE")  # movie/tvshow/season/episode
    labelMovieTitle = xbmc.getInfoLabel("ListItem.OriginalTitle")
    labelYear = xbmc.getInfoLabel("ListItem.Year")
    labelTVShowTitle = xbmc.getInfoLabel("ListItem.TVShowTitle")
    labelSeason = xbmc.getInfoLabel("ListItem.Season")
    labelEpisode = xbmc.getInfoLabel("ListItem.Episode")
    isItMovie = xbmc.getCondVisibility("Container.Content(movies)") or labelType == 'movie'
    isItEpisode = xbmc.getCondVisibility("Container.Content(episodes)") or labelType == 'episode'

    title = 'SearchFor...'
    if isItMovie and labelMovieTitle and labelYear:
        title = labelMovieTitle + " " + labelYear
    elif isItEpisode and labelTVShowTitle and labelSeason and labelEpisode:
        title = ("%s S%.2dE%.2d" % (labelTVShowTitle, int(labelSeason), int(labelEpisode)))

    return title


def remove_color_tags(input_string):
    log.warning(f"DEBUG | get_video_data | BEFORE remove_color_tags | input_string={input_string}")
    
    # Example: [COLOR white]הכפיל[/COLOR]
    import re
    output_string = re.sub(r'\[COLOR [^\]]*\]|\[/COLOR\]', '', input_string, flags=re.IGNORECASE)
    
    log.warning(f"DEBUG | get_video_data | AFTER remove_color_tags | output_string={output_string}")
    return output_string

def clean_title(title):
    
    def _remove_diacritics(title):
        # Removing diacritics - Handles titles such as "Shôgun", "Narcos: México" from IMDB/TMDB - To match title in Ktuvit.
        # Example: https://www.ktuvit.me/MovieInfo.aspx?ID=4BAFC19F06D861F298DB6B723A6888C6
        return ''.join([c for c in unicodedata.normalize('NFKD', title) if not unicodedata.combining(c)])

    title =  title.lower().replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('  ',' ')

    title = _remove_diacritics(title)
    
    return title

def remove_release_year_from_title_if_exists(title, year):
    year = str(year)
    if not year:
        log.warning(f"DEBUG | get_video_data | remove_release_year_from_title_if_exists | Year is empty.")
        return title
    # Avoids: "Wonder Woman 1984" --> "Wonder Woman" (Release year is 2020)
    if year not in title:
        log.warning(f"DEBUG | get_video_data | remove_release_year_from_title_if_exists | No release year ({year}) to remove from {title}")
        return title
    log.warning(f"DEBUG | get_video_data | remove_release_year_from_title_if_exists | Removing year {year} from title {title}...")
    
    import re
    # Remove year from title if exists ("Avengers 2012" / "Avengers (2012)" --> "Avengers")
    try:
        title = re.compile(r"([ .\w'\-]+?)(\W" + year + r"\W?.*)").findall(title)[0][0].strip()
        return title
    except:
        return title
def cached_check_api_key():
    new_key="a07324c669cac4d96789197134ce272b"
    test=requests.get("https://api.themoviedb.org/3/tv/603?api_key=b370b60447737762ca38457bd77579b3",timeout=10).json()
    log.warning(test)
    
    result=test.get("error","")
    result2=test.get("success",True)
   
    if result!="" or result2==False:
        _addon.setSetting("tmdb_api", new_key)
        return new_key
    return _addon.getSetting("tmdb_api")
def get_imdb_key():
    return cache.get(cached_check_api_key,72,table='subs')
def manual_search_for_imdb_id(video_data):
                
    ################### Manual Search for IMDb ID using TMDB API #############################
    # Queries TMDB API with media_type, original_title, and year - Gets TMDB ID
    # Queries TMDB API with TMDB ID - Gets IMDb ID
    
    media_type = video_data['media_type']
    original_title = video_data['OriginalTitle']
    year = video_data['year']
    
    
    
    log.warning(f"DEBUG | get_video_data | manual_search_for_imdb_id | Searching manually for IMDb ID | media_type={media_type} | original_title={original_title} | year={year}")
    
    TMDB_API_KEY = get_imdb_key()
    TMDB_API_BASE_URL = 'https://api.themoviedb.org/3/'

    params = {
        'api_key': TMDB_API_KEY,
        'query': original_title,
        'language': 'en'
    }

    search_with_year = False
    if year and int(year) > 0:
        search_with_year = True
        params['year'] = year

    search_for_tmdb_id_url = f'{TMDB_API_BASE_URL}search/{media_type}'

    try:
        response = requests.get(search_for_tmdb_id_url, params=params, timeout=DEFAULT_REQUEST_TIMEOUT)
        log.warning(f"DEBUG | get_video_data | manual_search_for_imdb_id | Full search_for_tmdb_id_url: {response.request.url}")
        data = response.json()
                
        ################### Sort results from TMDB API #############################
        # First by title, then by year
        # title - JSON parameter from TMDB API - For movies: ['title'] | For TV Shows: ['name']
        # year - JSON parameter from TMDB API - For movies: ['release_date'] | For TV Shows: ['first_air_date']
        
        # Define lambda function for title comparison
        title_comparison = lambda x: (
            x['title'].lower() == original_title.lower() if media_type == 'movie' else x['name'].lower() == original_title.lower()
        )
        
        # Define lambda function for year comparison
        year_comparison = lambda x: (
            str(year) in str(x.get('release_date', '')) if media_type == 'movie' else str(year) in str(x.get('first_air_date', ''))
        )

        # Define sorting key based on media type and year
        if search_with_year:
            key = lambda x: (title_comparison(x), year_comparison(x))
        else:
            key = title_comparison

        # Sort results based on sorting key
        sorted_results = sorted(data['results'], key=key, reverse=True)
        ############################################################################

        # Get the first result from the sorted list
        if sorted_results:
            first_result = sorted_results[0]
            # Check if the search result has an ID
            tmdb_id = first_result.get('id')
            # Fetch the details of the movie or TV show to get the IMDb ID
            search_for_imdb_id_url = f'{TMDB_API_BASE_URL}{media_type}/{tmdb_id}'
            params = {
                'api_key': TMDB_API_KEY,
                'append_to_response': 'external_ids',
                'language': 'en'
            }
            
            response = requests.get(search_for_imdb_id_url, params=params, timeout=DEFAULT_REQUEST_TIMEOUT)
            log.warning(f"DEBUG | get_video_data | manual_search_for_imdb_id | Full search_for_imdb_id_url: {response.request.url}")
            data = response.json()
            
            # Extract IMDb ID
            video_data['imdb'] = imdb_id = data['external_ids']['imdb_id']
            log.warning(f"DEBUG | get_video_data | manual_search_for_imdb_id | Found imdb_id={imdb_id} | IMDb URL: https://www.imdb.com/title/{imdb_id}")
            
            if not search_with_year:
                # Extract Release Year
                release_date_key = 'release_date' if media_type == "movie" else 'first_air_date'
                video_data['year'] = release_year = str(data.get(release_date_key, year).split('-')[0])
                log.warning(f"DEBUG | get_video_data | manual_search_for_imdb_id | Found year={release_year}")
                
            return video_data
            
        else:
            log.warning(f"DEBUG | get_video_data | manual_search_for_imdb_id | No TMDB results found.")
            return video_data
            
    except Exception as e:
        log.warning(f"DEBUG | get_video_data | manual_search_for_imdb_id | manual_search_for_imdb_id | Exception: {str(e)}")
        return video_data
      
def _basename_from_url(url):
    if not url:
        return ''
    return os.path.basename(unquote(url).split('?')[0])


def _filename_looks_like_release(name):
    """True when basename looks like a scene/web release (not stream/hash)."""
    if not name:
        return False
    lower = name.lower()
    if lower in ('stream', 'play', 'video', 'file', 'index'):
        return False
    for ext in ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.webm', '.ts', '.m2ts'):
        if lower.endswith(ext):
            return True
    for token in (
            '1080p', '720p', '2160p', '480p', 'bluray', 'blu-ray', 'webrip',
            'web-dl', 'webdl', 'hdtv', 'hdrip', 'remux', 'x264', 'x265',
            'hevc', 'h.265', 'h264', 'amzn', 'nflx', 'dsnp', 'atvp', 'hmax'):
        if token in lower:
            return True
    if re.search(r's\d{1,2}e\d{1,3}', lower):
        return True
    return False


def _filename_looks_like_opaque_hash(name):
    if not name:
        return True
    if _filename_looks_like_release(name):
        return False
    lower = name.lower()
    if re.fullmatch(
            r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
            lower):
        return True
    if (len(name) >= 24 and '.' not in name and ' ' not in name
            and re.fullmatch(r'[0-9a-f-]+', lower)):
        return True
    hex_chars = sum(1 for c in name if c in '0123456789abcdefABCDEF-')
    return hex_chars / max(len(name), 1) > 0.80


def _release_names_from_playing_url(playing_url):
    """Novix/Real-Debrid: outer URL is often .../stream?url=<real file URL>."""
    candidates = []
    seen_urls = set()
    current = unquote(playing_url or '')
    for _ in range(6):
        if not current or current in seen_urls:
            break
        seen_urls.add(current)
        base = _basename_from_url(current)
        if base:
            candidates.append(base)
        parsed = urlparse(current)
        inner = parse_qs(parsed.query).get('url', [None])[0]
        if not inner:
            break
        current = unquote(inner)
    return candidates


def _synthesize_filename_from_metadata():
    title = (
        xbmc.getInfoLabel('VideoPlayer.OriginalTitle')
        or xbmc.getInfoLabel('VideoPlayer.Title')
        or xbmc.getInfoLabel('ListItem.OriginalTitle')
        or xbmc.getInfoLabel('ListItem.Title')
    )
    if not title:
        return ''
    year = xbmc.getInfoLabel('VideoPlayer.Year') or xbmc.getInfoLabel('ListItem.Year')
    season = xbmc.getInfoLabel('VideoPlayer.Season') or xbmc.getInfoLabel('ListItem.Season')
    episode = xbmc.getInfoLabel('VideoPlayer.Episode') or xbmc.getInfoLabel('ListItem.Episode')
    quality = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
    parts = [title.replace(' ', '.')]
    try:
        s, e = int(season), int(episode)
        if s > 0 and e > 0:
            parts.append('S{0:02d}E{1:02d}'.format(s, e))
        elif year:
            parts.append(str(year))
    except (TypeError, ValueError):
        if year:
            parts.append(str(year))
    if quality and str(quality).isdigit():
        parts.append(str(quality) + 'p')
    return '.'.join(parts) + '.mkv'


def _pick_best_release_filename(candidates):
    for name in candidates:
        if _filename_looks_like_release(name):
            return name
    for name in candidates:
        if name and not _filename_looks_like_opaque_hash(name):
            return name
    return candidates[0] if candidates else ''


def resolve_release_name_from_url(playing_url=None):
    """Best release basename from stream URL + metadata (no Window properties)."""
    if playing_url is None:
        try:
            playing_url = unquote(xbmc.Player().getPlayingFile() or '')
        except Exception:
            playing_url = ''

    candidates = _release_names_from_playing_url(playing_url)
    release = _pick_best_release_filename(candidates)
    if release and _filename_looks_like_release(release):
        return release

    outer = _basename_from_url(playing_url)
    if outer and _filename_looks_like_release(outer):
        return outer

    if not release or _filename_looks_like_opaque_hash(release):
        synthetic = _synthesize_filename_from_metadata()
        if synthetic:
            return synthetic

    return release or outer or ''


def _existing_release_ok_for_subs(name):
    if _filename_looks_like_release(name):
        return True
    return bool(name) and not _filename_looks_like_opaque_hash(name)


def get_playing_filename():
    try:
        playing_url = unquote(xbmc.Player().getPlayingFile() or '')
    except Exception:
        playing_url = ''

    try:
        win = xbmcgui.Window(10000)
        picked = (win.getProperty('subs.player_filename') or '').strip()
        stored_url = (win.getProperty('subs.player_file_url') or '').strip()
        if stored_url and playing_url and not (
                stored_url in playing_url or playing_url in stored_url):
            if _existing_release_ok_for_subs(picked):
                win.setProperty('subs.player_file_url', playing_url)
                log.warning('DEBUG | get_playing_filename | property={0} (url updated)'.format(picked))
                return picked
            win.setProperty('subs.player_filename', '')
            win.setProperty('subs.player_file_url', '')
            picked = ''

        if picked and _existing_release_ok_for_subs(picked):
            log.warning('DEBUG | get_playing_filename | property={0}'.format(picked))
            return picked
    except Exception:
        pass

    resolved = resolve_release_name_from_url(playing_url)
    if resolved:
        log.warning('DEBUG | get_playing_filename | resolved={0}'.format(resolved))
    return resolved or 'stream'
    
def get_local_media_data(video_data):

    log.warning(f"DEBUG | get_video_data | get_local_media_data | file_original_path={video_data['file_original_path']}")
    log.warning(f"DEBUG | get_video_data | get_local_media_data | BEFORE PTN | video_data={video_data}")
    
    # Parse torrent title
    from resources.modules import parse_torrent_title
    PTN_results = parse_torrent_title.parse(video_data['file_original_path'])
    
    # Update video_data with PTN results
    video_data['title'] = PTN_results.get('title', video_data['title'])
    video_data['year'] = str(PTN_results.get('year', video_data['year']))
    video_data['season'] = str(PTN_results.get('season', video_data['season']))
    video_data['episode'] = str(PTN_results.get('episode', video_data['episode']))
    
    # Set TVShowTitle if it's a TV media type
    if video_data['season'] != '0' or video_data['episode'] != '0':
        video_data['TVShowTitle'] = video_data['title']

    log.warning(f"DEBUG | get_video_data | get_local_media_data | AFTER PTN | video_data={video_data}")
    
    return video_data

def get_video_data_playing():

    video_data = {}
    

    video_data['state'] = "playing"
    # Get the title of the currently playing video
    video_data['title'] = xbmc.getInfoLabel("VideoPlayer.Title")
    log.warning(f"DEBUG | get_video_data | title={video_data['title']}")
    # Get the original title of the currently playing video
    video_data['OriginalTitle'] = xbmc.getInfoLabel("VideoPlayer.OriginalTitle")
    
    # Get the TMDB unique ID property of the currently playing video
    video_data['tmdb'] = xbmc.getInfoLabel("VideoPlayer.UniqueID(tmdb)")
    
    # Get the IMDBNumber property of the currently playing video
    video_data['IMDBNumber'] = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
    
    # Get the IMDb unique ID property of the currently playing video
    video_data['imdb_UniqueID'] = xbmc.getInfoLabel("VideoPlayer.UniqueID(imdb)")
    
    
    
    # Get the year of release of the currently playing video
    video_data['year'] = xbmc.getInfoLabel("VideoPlayer.Year")
    
    season= xbmc.getInfoLabel("VideoPlayer.Season") or '0'
    episode= xbmc.getInfoLabel("VideoPlayer.Episode") or '0'
    tv_title=xbmc.getInfoLabel("VideoPlayer.TVShowTitle").lower()
    if tv_title and season != '0' or episode != '0':
        video_data['media_type'] = 'tv'
    else:
        video_data['media_type'] = 'movie'
        
    # Get the title of the TV show if the currently playing video is an episode of a TV show
    video_data['TVShowTitle'] = xbmc.getInfoLabel("VideoPlayer.TVShowTitle").lower()
    
    # Get the season number of the currently playing video (if empty - 0)
    video_data['season'] = xbmc.getInfoLabel("VideoPlayer.Season") or '0'
        
        
    # Get the episode number of the currently playing video (if empty - 0)
    video_data['episode'] = xbmc.getInfoLabel("VideoPlayer.Episode") or '0'
    
    if video_data['imdb_UniqueID'].startswith('tt'):
        video_data['imdb'] = video_data['imdb_UniqueID']
    else:
        video_data['imdb'] = video_data['IMDBNumber']


    
    
    


    
        
    
    
        

    
    
    
    
    
    
    # Get the MPAA rating of the currently playing video
    video_data['mpaa'] = xbmc.getInfoLabel("VideoPlayer.mpaa")


    # Get the tagline of the currently playing video
    video_data['VideoPlayer.Tagline'] = xbmc.getInfoLabel("VideoPlayer.Tagline")
    # Fen addon tagline property
    video_data['picked_release'] = xbmcgui.Window(10000).getProperty("subs.player_filename")
    video_data['Tagline_From_Fen'] = video_data['picked_release']
    # Assign video_data['Tagline']
    video_data['Tagline'] = video_data['picked_release'] or video_data['VideoPlayer.Tagline']
    
    
    # Release name for sync-% (Novix stream URLs hide the real filename in ?url=)
    video_data['file_original_path'] = get_playing_filename()
    if _filename_looks_like_release(video_data['file_original_path']):
        if not _filename_looks_like_release(video_data.get('Tagline', '')):
            video_data['Tagline'] = video_data['file_original_path']
    
    return video_data
    
def get_video_data_not_playing():

    video_data = {}
    

    video_data['state'] = "not_playing"


    # Get the IMDb unique ID property of the currently selected item
    video_data['imdb_UniqueID'] = xbmc.getInfoLabel("ListItem.UniqueID(imdb)")
    # Get the IMDBNumber property of the currently selected item
    video_data['IMDBNumber'] = xbmc.getInfoLabel("ListItem.IMDBNumber")
    
    if video_data['imdb_UniqueID'].startswith('tt'):
        video_data['imdb'] = video_data['imdb_UniqueID']
    else:
        video_data['imdb'] = video_data['IMDBNumber']
        
        
    # Get the title of the currently selected item
    video_data['title'] = xbmc.getInfoLabel("ListItem.Title")
    log.warning(xbmc.getInfoLabel("ListItem.Title"))
    
    # Get the original title of the currently selected item
    video_data['OriginalTitle'] = xbmc.getInfoLabel("ListItem.OriginalTitle")
    
    
    # Get the title of the TV show if the currently selected item is an episode of a TV show
    video_data['TVShowTitle'] = xbmc.getInfoLabel("ListItem.TVShowTitle")
    
    
    # Get the year of release of the currently selected item
    video_data['year'] = xbmc.getInfoLabel("ListItem.Year")
    
    
    # Get the season number of the currently selected item (if empty - 0)
    video_data['season'] = xbmc.getInfoLabel("ListItem.Season") or '0'
    
    
    # Get the episode number of the currently selected item (if empty - 0)
    video_data['episode'] = xbmc.getInfoLabel("ListItem.Episode") or '0'
    
    
    # Get the MPAA rating of the currently selected item
    video_data['mpaa'] = xbmc.getInfoLabel("ListItem.Mpaa")
    
    
    # Get the tagline of the currently selected item
    video_data['Tagline'] = xbmc.getInfoLabel("ListItem.Tagline")
        
        
    # Set the full path of the currently selected item to title
    video_data['file_original_path'] = video_data['title']
    video_data['VideoPlayer.Tagline'] = video_data['title']
    
    return video_data

def get_video_data():

    ################### Get Video Data #######################################################
    if xbmc.Player().isPlaying():
        video_data = get_video_data_playing()
    else:
        video_data = get_video_data_not_playing()
    ##########################################################################################
                  

    ################### Local Media / External Player Support ################################
    video_data['is_local_media_playing'] = False
    
    if xbmc.Player().isPlaying():
    
        # When all three keys are empty
        if all(not video_data[key] for key in ['OriginalTitle', 'year', 'TVShowTitle']):
            video_data['is_local_media_playing'] = True
            log.warning(f"DEBUG | get_video_data | is_local_media_playing=True | Running get_local_media_data function.")
            video_data = get_local_media_data(video_data)
            
        # When at least one of the keys has a value
        else:
            log.warning(f"DEBUG | get_video_data | is_local_media_playing=False | Skipping get_local_media_data function.")
    ##########################################################################################


    ################### Set Media Type #######################################################
    video_data = set_media_type(video_data)
    ##########################################################################################


    ################### Fillnull OriginalTitle ###############################################
    if video_data['media_type'] == 'tv':
        video_data['OriginalTitle'] = video_data['OriginalTitle'] or video_data['TVShowTitle']
    else:
        video_data['OriginalTitle'] = video_data['OriginalTitle'] or video_data['title']
    ##########################################################################################


    ################### Clean Titles #########################################################
    video_data['title'] = clean_title(video_data['title'])
    
    video_data['OriginalTitle'] = clean_title(video_data['OriginalTitle'])
    
    if video_data['media_type'] == 'tv':
        video_data['TVShowTitle'] = clean_title(video_data['TVShowTitle'])
    ##########################################################################################


    ################### Telemedia - ListItem Remove Color Tags ###############################
    # Only when NOT playing
    if not xbmc.Player().isPlaying() and get_playing_addon() == 'plugin.video.telemedia':
        video_data['title'] = remove_color_tags(video_data['title'])
        video_data['OriginalTitle'] = remove_color_tags(video_data['OriginalTitle'])
        if video_data['media_type'] == 'tv':
            video_data['TVShowTitle'] = remove_color_tags(video_data['TVShowTitle'])
    ##########################################################################################
    
    
    ################### Remove Year From Titles ##############################################
    # Local media only.
    if video_data['is_local_media_playing'] == True:
        video_data['title'] = remove_release_year_from_title_if_exists(video_data['title'], video_data['year'])
        video_data['OriginalTitle'] = remove_release_year_from_title_if_exists(video_data['OriginalTitle'], video_data['year'])
        if video_data['media_type'] == 'tv':
            video_data['TVShowTitle'] = remove_release_year_from_title_if_exists(video_data['TVShowTitle'], video_data['year'])
    ##########################################################################################


    ################### Manual Search for IMDb ID using TMDB API #############################
    if not video_data['imdb'].startswith('tt'):
        log.warning(f"DEBUG | get_video_data | IMDb ID from video addon not found. searching manually using TMDB API...")
        video_data = manual_search_for_imdb_id(video_data)
    ##########################################################################################
    
    
    log.warning(f"DEBUG | get_video_data | FINAL | video_data={video_data}")
    return video_data

def _subtitle_matches_current_video(sub_name, video_data):
    """Ignore cached subs from a different episode/show."""
    import re
    from urllib.parse import unquote

    name = unquote(sub_name or '')
    imdb = (video_data.get('imdb') or video_data.get('IMDBNumber') or '').strip()
    media_type = video_data.get('media_type') or video_data.get('media_type_videoInfoTag') or ''

    if imdb and imdb not in name and 'SubEmbedded' not in name:
        # External subs usually include release name, not imdb — don't reject on imdb alone.
        pass

    if media_type != 'tv':
        return True

    try:
        season = int(video_data.get('season') or 0)
        episode = int(video_data.get('episode') or 0)
    except (TypeError, ValueError):
        return True

    if season <= 0 or episode <= 0:
        return True

    s2 = str(season).zfill(2)
    e2 = str(episode).zfill(2)
    patterns = (
        rf'S{s2}E{e2}\b',
        rf'S{season}E{episode}\b',
        rf'\b{season}x{e2}\b',
        rf'\b{season}x{episode}\b',
    )
    if any(re.search(p, name, re.IGNORECASE) for p in patterns):
        return True

    if 'SubEmbedded' in name and imdb and imdb in name:
        if str(season) in name and str(episode) in name:
            return True

    return False


def save_file_name(filename, language, video_data):

    tag = (
        video_data.get('Tagline')
        or video_data.get('picked_release')
        or video_data.get('file_original_path')
        or '')
    video_data_tagline = quote(tag)
    video_data_file_original_path = quote(
        video_data.get('file_original_path') or tag)
    
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ("
                  "language TEXT, "
                  "filename TEXT, "
                  "video_data_tagline TEXT, "
                  "video_data_file_original_path TEXT);" % ('list_subs_cache'))


    dbcur.execute("SELECT * FROM list_subs_cache ")
    list_sub = dbcur.fetchall()
    dbcur.execute("INSERT INTO list_subs_cache Values ('{0}','{1}','{2}','{3}')".format(language,quote(filename),video_data_tagline,video_data_file_original_path))

    dbcon.commit()
    dbcon.close()
def get_db_data(video_data):

    video_data_tagline = quote(video_data.get('Tagline', '') or '')
    video_data_file_original_path = quote(video_data.get('file_original_path', '') or '')
    
    try:
      from sqlite3 import dbapi2 as database
    except:
      from pysqlite2 import dbapi2 as database
    
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ("
                  "language TEXT, "
                  "filename TEXT, "
                  "video_data_tagline TEXT, "
                  "video_data_file_original_path TEXT);" % ('list_subs_cache'))
                  
    dbcur.execute("SELECT * FROM list_subs_cache")
    list_sub = dbcur.fetchall()
    dbcur.close()
    dbcon.close()
    
    all_subs = {}
    for sub_language, sub_name, tagline, file_original_path in list_sub:
        path_match = (
            tagline == video_data_tagline
            or file_original_path == video_data_file_original_path
        )
        if path_match and _subtitle_matches_current_video(sub_name, video_data):
            # sub_name is stored URL-quoted (see save_file_name's INSERT), but
            # callers match it against raw filenames (json_value['filename'] /
            # items[8]) which are never quoted -- unquote here once so every
            # caller can compare directly instead of each remembering to.
            all_subs.setdefault(unquote(sub_name), []).append(sub_language)

    last_sub_name_in_cache = ''
    last_sub_language_in_cache = ''

    # Latest cache row for this playback — must match episode/show, not a stale Tagline.
    for sub_language, sub_name, tagline, file_original_path in reversed(list_sub):
        path_match = (
            tagline == video_data_tagline
            or file_original_path == video_data_file_original_path
        )
        if path_match and _subtitle_matches_current_video(sub_name, video_data):
            last_sub_name_in_cache = unquote(sub_name)
            last_sub_language_in_cache = sub_language
            break
    
    return last_sub_name_in_cache,last_sub_language_in_cache,all_subs


################### Future Use ###########################################################
# https://alwinesch.github.io/group__python___info_tag_video.html
# https://github.com/a4k-openproject/a4kSubtitles/pull/80

# if xbmc.Player().isPlaying():
    # videoInfo = xbmc.Player().getVideoInfoTag()
    # log.warning(f"DEBUG | videoInfo.getFilenameAndPath()={videoInfo.getFilenameAndPath()}")
    # log.warning(f"DEBUG | videoInfo.getFile()={videoInfo.getFile()}")
    # log.warning(f"DEBUG | videoInfo.getMediaType()={videoInfo.getMediaType()}")
    # log.warning(f"DEBUG | videoInfo.getTitle()={videoInfo.getTitle()}")
    # log.warning(f"DEBUG | videoInfo.getOriginalTitle()={videoInfo.getOriginalTitle()}")
    # log.warning(f"DEBUG | videoInfo.getTVShowTitle()={videoInfo.getTVShowTitle()}")
    # log.warning(f"DEBUG | videoInfo.getYear()={videoInfo.getYear()}")
    # log.warning(f"DEBUG | videoInfo.getSeason()={videoInfo.getSeason()}")
    # log.warning(f"DEBUG | videoInfo.getEpisode()={videoInfo.getEpisode()}")
    # log.warning(f"DEBUG | videoInfo.getUniqueID('imdb')={videoInfo.getUniqueID('imdb')}")
    # log.warning(f"DEBUG | videoInfo.getIMDBNumber()={videoInfo.getIMDBNumber()}")
    # log.warning(f"DEBUG | videoInfo.getTagLine()={videoInfo.getTagLine()}")
##########################################################################################
