# -*- coding: utf-8 -*-
"""Release filename vs subtitle filename — same % algorithm as Novix he_sub_match."""
import re


def _tokens(name):
    s = re.sub(r'\.[a-z0-9]{2,4}$', '', (name or ''), flags=re.I)
    for ch in '_ +/-':
        s = s.replace(ch, '.')
    return [x.lower() for x in s.split('.') if x]


KTUVIT_MATCH_BONUS = 15


def release_match_percent(release_name, subtitle_name):
    """0–100 match between picked video release and subtitle release name."""
    from difflib import SequenceMatcher
    a = _tokens(release_name)
    b = _tokens(subtitle_name)
    if not a or not b:
        return 0
    try:
        return int(round(SequenceMatcher(None, a, b).ratio() * 100))
    except Exception:
        return 0


def final_match_percent(release_name, subtitle_name, site_id=None):
    """Base match % plus source-specific bonus (Ktuvit +15)."""
    percent = release_match_percent(release_name, subtitle_name)
    if site_id == '[Ktuvit]':
        percent = min(100, percent + KTUVIT_MATCH_BONUS)
    return percent


def pick_release_name(video_data):
    """Novix source pick (subs.player_filename) or DarkSubs video_data fields."""
    if video_data:
        for key in (
                'picked_release', 'file_original_path', 'Tagline',
                'Tagline_From_Fen', 'VideoPlayer.Tagline'):
            val = (video_data.get(key) or '').strip()
            if val:
                return val
    try:
        import xbmcgui
        prop = (xbmcgui.Window(10000).getProperty('subs.player_filename') or '').strip()
        if prop:
            return prop
    except Exception:
        pass
    return ''
