﻿
import random
import xbmc,xbmcgui,time,xbmcplugin
from resources.modules import log
import pkgutil,json
import os,sys,shutil
import xbmcvfs,xbmcaddon
xbmc_tranlate_path=xbmcvfs.translatePath
from urllib.parse import  unquote_plus, unquote,  quote
import threading
import urllib.parse
import chardet
global break_all
from urllib.parse import  unquote_plus, unquote, quote, quote_plus
from resources.modules.general import Thread,CachedSubFolder,TransFolder,user_dataDir
from resources.modules import cache
from resources.modules.general import DEFAULT_REQUEST_TIMEOUT
global trans_result
from concurrent import futures
trans_result=[]
MyScriptID = 'service.subtitles.All_Subs'
try:
    iconx = xbmcaddon.Addon(MyScriptID).getAddonInfo('icon')
except Exception:
    iconx = xbmcaddon.Addon().getAddonInfo('icon')
    MyScriptID = xbmcaddon.Addon().getAddonInfo('id')
break_all=False


from resources.sources import ktuvit
from resources.sources import telesubs
from resources.sources import opensubtitles
from resources.sources import yify
from resources.sources import bsplayer
from resources.sources import subtitlecat
from resources.sources import communitypool
from resources.sources import wizdom
que=urllib.parse.quote_plus
unque=urllib.parse.unquote_plus
Addon=xbmcaddon.Addon(MyScriptID)
addonPath = xbmc_tranlate_path(Addon.getAddonInfo("path"))

# Machine-translation engines (Google/Yandex/Bing/Gemini dispatch) and their
# trans_subs filename/state bookkeeping live in translate_engines.py -- this
# module is the search/rank/place engine, not a translation module. Re-export
# the names other files import from here (`from resources.modules.engine
# import X`) so nothing outside had to change.
from resources.modules.translate_engines import (
    Bing,
    google_send_translate, google_machine_translate,
    yandex_get_random_number, yandex_get_translated, yandex_machine_translate,
    bing_c_get_keys, bing_get_last_key, bing_set_last_key, bing_select_key,
    bing_machine_translate,
    machine_translate_subs,
    _sanitize_sub_basename, _is_unusable_media_name,
    subtitle_needs_machine_translate, _resolve_trans_basename,
    _trans_file_is_hebrew, _mark_trans_done,
)

def sort_subtitles(f_result,video_data, for_autosub=False, fast_mode=False):
    if f_result is None:
        f_result = []

    # For settings changes to take effect.
    Addon=xbmcaddon.Addon(MyScriptID)
    
    from resources.modules import general
    from resources.modules.release_match import final_match_percent, pick_release_name

    playing = False
    try:
        playing = xbmc.Player().isPlaying()
    except Exception:
        pass

    if for_autosub is False:
        try:
            from resources import main
            for_autosub = getattr(main, 'from_autosub', False)
        except Exception:
            pass

    if not fast_mode and (playing or len(f_result or []) > 40):
        fast_mode = True

    if for_autosub and f_result:
        hebrew_only = []
        for r in f_result:
            try:
                if isinstance(r, dict):
                    url = r.get('url', '')
                    label = r.get('label', '')
                    label2 = r.get('label2', '')
                else:
                    label = r[0] if len(r) > 0 else ''
                    url = r[4] if len(r) > 4 else ''
                    label2 = r[1] if len(r) > 1 else ''
                if (
                    'language=Hebrew' in url
                    or 'Hebrew' in label
                    or 'תרגום מכונה' in label2
                ):
                    hebrew_only.append(r)
            except Exception:
                pass
        log.warning(
            'sort_subtitles | autosub fast: {0}/{1} Hebrew subs'.format(
                len(hebrew_only), len(f_result)))
        if hebrew_only:
            f_result = hebrew_only
        elif (Addon.getSetting('auto_translate') == 'true'
              and (Addon.getSetting('language_hebrew') == 'true'
                   or Addon.getSetting('all_lang') == 'true')):
            externals = []
            for r in f_result:
                try:
                    fn = r[8] if isinstance(r, tuple) else r.get('filename', '')
                    if 'SubEmbedded' not in str(fn):
                        externals.append(r)
                except Exception:
                    pass
            if externals:
                f_result = externals
                log.warning(
                    'sort_subtitles | autosub: 0 Hebrew — keep {0} external for translate'.format(
                        len(f_result)))
            else:
                f_result = hebrew_only
        else:
            f_result = hebrew_only

    def _sort_overlay_enabled(n):
        if fast_mode or for_autosub or playing:
            return False
        try:
            from resources import main
            if getattr(main, 'from_autosub', False):
                return False
        except Exception:
            pass
        if n > 80:
            return False
        return (
            Addon.getSetting("enable_autosub_notifications") == 'true'
            or not playing
        )

    n_subs = len(f_result or [])
    show_sort_overlay = _sort_overlay_enabled(n_subs)
    sort_overlay_step = max(1, n_subs // 8) if n_subs else 1

    if show_sort_overlay:
        general.show_msg = f"מסדר כתוביות 0/{n_subs}"
                     
    site_id_order = ['[Ktuvit]', '[Wizdom]', '[Tele]', '[Pool]', '[OpenSubtitles]', '[SubtitleCat]', '[YIFY]', '[SubDL]', '[SubSource]', '[Subscene]', '[BSPlayer]']
    
    hebrew_subtitles = []
    hebrew_gemini_translated_subtitles = []
    hebrew_tele_translated_subtitles = []
    english_subtitles = []
    other_languages_subtitles = []
    count = 0
    
    def append_subtitles(subtitles_list, json_value, percent):
        url = json_value['url']
        if 'sync_pct=' not in url:
            url = '{0}{1}sync_pct={2}'.format(
                url, '&' if '?' in url else '?', int(percent))
        return subtitles_list.append((
            json_value['label'],
            '[COLOR %s]' % json_value['sub_color'] + json_value['label2'] + '[/COLOR]',
            json_value['iconImage'],
            json_value['thumbnailImage'],
            url,
            percent,
            json_value['sync'],
            json_value['hearing_imp'],
            json_value['filename'],
            json_value['site_id']
        ))
      
    release_name = pick_release_name(video_data)
    log.warning('P checking release: {0}'.format(release_name))
    for result_value in f_result:
        
        if show_sort_overlay and (count % sort_overlay_step == 0 or count >= n_subs - 1):
            general.show_msg = f"מסדר כתוביות {count}/{n_subs}"
        count += 1
          
        json_value = json.loads(json.dumps(result_value))
        ################### Calculate Sync Percentage #################################################
        sub_filename = json_value.get('filename', '')
        percent = final_match_percent(
            release_name, sub_filename, json_value.get('site_id'))
        ###############################################################################################
        
      
        
        ################### Append subtitle to corresponding language subs list #######################
        if "תרגום ג'מני" in json_value['label2']:
            # Gemini-translated -- better quality than generic machine
            # translation, so it gets its own tier just above it, but still
            # below genuinely native Hebrew subtitles.
            append_subtitles(hebrew_gemini_translated_subtitles, json_value, percent)

        elif 'תרגום מכונה' in json_value['label2']:
            append_subtitles(hebrew_tele_translated_subtitles, json_value, percent)

        elif 'language=Hebrew' in json_value['url'] or 'Hebrew' in json_value['label']:
            append_subtitles(hebrew_subtitles, json_value, percent)
       
        elif 'language=English' in json_value['url'] or 'English' in json_value['label']:
            append_subtitles(english_subtitles, json_value, percent)
           
        else:
            append_subtitles(other_languages_subtitles, json_value, percent)
        ###############################################################################################
    
    
    ################### Final Subtitles Sorting ###################################################
    def custom_sort(subtitles_list, site_id_order, by_language_name=False):
        # Sort also by language name (x[0]) if by_language_name is True
        if by_language_name:
            return sorted(subtitles_list, key=lambda x: (x[0], -x[5], site_id_order.index(x[9]) if x[9] in site_id_order else len(site_id_order)))
        # Sort by percent (-x[5]) and site_id (x[9]) only
        return sorted(subtitles_list, key=lambda x: (-x[5], site_id_order.index(x[9]) if x[9] in site_id_order else len(site_id_order)))

    # Sort languages
    hebrew_subtitles = custom_sort(hebrew_subtitles, site_id_order)
    hebrew_gemini_translated_subtitles = custom_sort(hebrew_gemini_translated_subtitles, site_id_order)
    hebrew_tele_translated_subtitles = custom_sort(hebrew_tele_translated_subtitles, site_id_order)
    english_subtitles = custom_sort(english_subtitles, site_id_order)
    other_languages_subtitles = custom_sort(other_languages_subtitles, site_id_order, by_language_name=True)

    # Combine all sorted subtitles list
    sorted_subtitles = []
    sorted_subtitles = hebrew_subtitles + hebrew_gemini_translated_subtitles + hebrew_tele_translated_subtitles + english_subtitles + other_languages_subtitles
    ###############################################################################################

    if show_sort_overlay:
        general.show_msg = 'END'
    elif fast_mode and playing:
        try:
            from resources import main
            if not getattr(main, 'from_autosub', False):
                general.show_msg = 'END'
        except Exception:
            general.show_msg = 'END'
    return sorted_subtitles

# Prettify website source name for subs search dialog
def format_website_source_name(source):
    if source == "ktuvit":
        return "Ktuvit"
    if source == "wizdom":
        return "Wizdom"
    if source == "telesubs":
        return "TeleSubs"
    if source == "opensubtitles":
        return "OpenSubtitles"
    if source == "subtitlecat":
        return "SubtitleCat"
    if source == "yify":
        return "YIFY"
    if source == "bsplayer":
        return "BSPlayer"
    if source == "communitypool":
        return "Pool"
    if source in ("HebrewSubEmbedded", "EnglishSubEmbedded"):
        return "תרגום מובנה"
    return source
        
def _is_autosub_run():
    try:
        from resources import main
        return getattr(main, 'from_autosub', False)
    except Exception:
        return False


# subtitlecat is the only source whose own search query (not just result
# ranking) depends on the release/filename -- it builds its search from the
# release name (falling back to imdb) and rejects all candidates when it's
# empty (confirmed by grepping every source module for Tagline/picked_release/
# file_original_path use: ktuvit/wizdom/telesubs/opensubtitles never touch it,
# communitypool only uses it afterward for a match-percentage label).
#
# Rather than always re-running subtitlecat live (it can't be cached against
# the real filename, since mando's scrape-time prefetch doesn't know the
# filename yet), give it a synthetic "release" string built only from
# identity data -- "{title} s{season}e{episode}" for TV, "{title} {year}"
# for movies. Verified with a standalone live test against subtitlecat.com:
# this natural-language query finds the same real matches a genuine release
# filename would (often cleaner ones -- a real filename's release-group
# suffix, e.g. "-SPARKS", can token-match unrelated titles sharing that same
# group and sneak past the relevance threshold; the synthetic query has no
# such tokens to false-match on). Final subtitle selection still re-ranks
# every candidate against the true video_data in sort_subtitles() afterward,
# so this only affects which candidates subtitlecat itself contributes, not
# final placement accuracy.
_RELEASE_INDEPENDENT_IDENTITY_KEYS = (
    'media_type', 'title', 'OriginalTitle', 'TVShowTitle', 'tmdb',
    'IMDBNumber', 'imdb', 'imdb_UniqueID', 'season', 'episode', 'year',
)


def _synthetic_release_tag(video_data):
    title = (video_data.get('TVShowTitle') or video_data.get('OriginalTitle')
             or video_data.get('title') or '')
    if video_data.get('media_type') == 'tv':
        season = video_data.get('season') or '0'
        episode = video_data.get('episode') or '0'
        try:
            return '{0} s{1:02d}e{2:02d}'.format(title, int(season), int(episode))
        except (TypeError, ValueError):
            return '{0} s{1}e{2}'.format(title, season, episode)
    year = video_data.get('year') or ''
    return '{0} {1}'.format(title, year).strip()


def _release_independent_identity(video_data):
    data = {k: video_data.get(k, '') for k in _RELEASE_INDEPENDENT_IDENTITY_KEYS}
    synthetic = _synthetic_release_tag(video_data)
    data['Tagline'] = synthetic
    data['picked_release'] = synthetic
    data['file_original_path'] = synthetic
    return data


def _run_source_candidates(candidates, video_data, Addon, for_autosub):
    """Run (name, get_subs) candidates concurrently and collect results, with
    the same live progress/timeout/cancel behavior c_get_subtitles always had.
    Split out to be the single cache.get() target in _fetch_release_independent_sources.
    """
    from resources.modules import general
    if not candidates:
        return []

    executor = futures.ThreadPoolExecutor(max_workers=max(1, len(candidates)))
    all_sources = []
    for name, fn in candidates:
        xbmc.sleep(100)
        all_sources.append((name, executor.submit(fn, video_data)))

    start_time = time.time()
    ExcludeTime = int(Addon.getSetting('max_search_time'))
    f_result = []
    SEARCHING_MSG = 'מחפש כתוביות\n'
    PLEASE_WAIT_MSG = ' אנא המתן '

    try:
        from resources.modules import ipc_store
        ipc_store.clear('search_progress_detail')
        ipc_store.clear('search_cancel_requested')
    except Exception:
        pass

    while True:
        elapsed_time = time.time() - start_time
        still_alive = False
        string_dp = ''
        f_result = []

        for name, fut in all_sources:
              if fut.done():
                  color = "lightgreen"
                  try:
                      result = fut.result() or []
                  except Exception as e:
                      log.warning('DEBUG | c_get_subtitles | {0} raised: {1}'.format(name, e))
                      result = []
              else:
                  color = "red"
                  still_alive = True
                  result = []
              f_result = f_result + result
              string_dp = string_dp + (' %s:[COLOR %s]%s[/COLOR] ' % (format_website_source_name(name), color, len(result)))
        done_count = sum(1 for _, fut in all_sources if fut.done())
        general.progress_msg = int((done_count * 100.0) / len(all_sources)) if all_sources else 100
        try:
            from resources.modules import ipc_store
            ipc_store.write('search_progress_detail', string_dp)
            ipc_store.write('search_progress_percent', str(general.progress_msg))
        except Exception:
            pass
        short_summary = 'נמצאו {0} כתוביות | {1}/{2} מקורות'.format(
            len(f_result), done_count, len(all_sources))
        if Addon.getSetting("enable_autosub_notifications") == 'true':
            general.show_msg = SEARCHING_MSG + time.strftime("%H:%M:%S", time.gmtime(elapsed_time)) + '\n' + short_summary
        elif not for_autosub and (not xbmc.Player().isPlaying()):
            general.show_msg = PLEASE_WAIT_MSG + time.strftime("%H:%M:%S", time.gmtime(elapsed_time)) + '\n' + short_summary

        if not still_alive:
            break

        try:
            canceled = ipc_store.read('search_cancel_requested', '') == '1'
        except Exception:
            canceled = False
        if canceled:
            log.warning('DEBUG | c_get_subtitles | search canceled by user, using {0} results found so far'.format(len(f_result)))
            break

        if elapsed_time > ExcludeTime:
            log.warning('DEBUG | c_get_subtitles | timed out after {0}s, abandoning still-running sources'.format(ExcludeTime))
            try:
                from resources.sources.opensubtitles import global_var as ops_partial
                ops_still_running = any(
                    not fut.done() for name, fut in all_sources if 'opensubtitles' in name.lower())
                if ops_partial and ops_still_running:
                    log.warning('DEBUG | c_get_subtitles | rescued {0} partial OpenSubtitles results'.format(len(ops_partial)))
                    f_result = f_result + ops_partial
            except Exception:
                pass
            break
        xbmc.sleep(10)

    return f_result


_RELEASE_INDEPENDENT_SOURCE_FUNCS = {
    'ktuvit': ktuvit.get_subs,
    'wizdom': wizdom.get_subs,
    'telesubs': telesubs.get_subs,
    'opensubtitles': opensubtitles.get_subs,
    'communitypool': communitypool.get_subs,
    'yify': yify.get_subs,
    'bsplayer': bsplayer.get_subs,
    'subtitlecat': subtitlecat.get_subs,
}


def _fetch_release_independent_sources(identity_data, names_key):
    """cache.get() target for the full source list -- args are hashed for the
    cache key (identity_data + names_key), so this must not take the actual
    video_data/real Tagline, only the identity subset (subtitlecat gets the
    synthetic release tag baked into identity_data by
    _release_independent_identity, not the real filename). The (name ->
    function) mapping is a fixed module-level registry, not an argument,
    since function objects aren't stable cache-key material.
    """
    # Only reached on an actual cache miss (cache.get calls this function
    # itself when there's nothing usable cached) -- a cache HIT never logs
    # this line at all, so its presence/absence is the way to tell from the
    # log whether a given trigger paid for a live network search or reused
    # an earlier one.
    log.warning('DEBUG | _fetch_release_independent_sources | LIVE search (cache miss): {0}'.format(identity_data))
    Addon = xbmcaddon.Addon(MyScriptID)
    candidates = [(n, _RELEASE_INDEPENDENT_SOURCE_FUNCS[n]) for n in names_key.split(',') if n]
    return _run_source_candidates(candidates, identity_data, Addon, _is_autosub_run())

def c_get_subtitles(video_data):
    # For settings changes to take effect.
    Addon=xbmcaddon.Addon(MyScriptID)
    from resources.modules import general
    for_autosub = _is_autosub_run()

    log.warning("DEBUG | c_get_subtitles | Searching for:")
    log.warning(f"DEBUG | c_get_subtitles | video_data={video_data}")

    # Determine wether to search hebrew language
    search_language_hebrew_bool = (Addon.getSetting('language_hebrew') == 'true' or Addon.getSetting("all_lang") == 'true')
    
    # Israeli subtitles sources
    
    candidates = []

    if Addon.getSetting('ktuvit')=='true' and search_language_hebrew_bool:
        candidates.append(('ktuvit', ktuvit.get_subs))

    if Addon.getSetting('wizdom')=='true' and search_language_hebrew_bool:
        candidates.append(('wizdom', wizdom.get_subs))

    if Addon.getSetting('telesubs')=='true' and search_language_hebrew_bool:
        candidates.append(('telesubs', telesubs.get_subs))

    try:
        from resources.modules.ai_translate import pool as _pool
        _pool_enabled = _pool.use_enabled()
    except Exception:
        _pool_enabled = Addon.getSetting('pool_use') == 'true'
    if _pool_enabled and search_language_hebrew_bool:
        candidates.append(('communitypool', communitypool.get_subs))

    # Global subtitles sources
    if Addon.getSetting('opensubtitles')=='true':
        candidates.append(('opensubtitles', opensubtitles.get_subs))

    if Addon.getSetting('subtitlecat2')=='true' and search_language_hebrew_bool:
        candidates.append(('subtitlecat', subtitlecat.get_subs))

    if Addon.getSetting('yify2')=='true' and not for_autosub:
        candidates.append(('yify', yify.get_subs))

    if Addon.getSetting('bsplayer2')=='true' and search_language_hebrew_bool:
        candidates.append(('bsplayer', bsplayer.get_subs))


    # Cached keyed on title/season/episode (+ a synthetic release tag derived
    # from the same identity data, see _synthetic_release_tag) alone, so it's
    # reused regardless of which exact release/filename ends up chosen --
    # mando's scrape-time prefetch (no filename known yet) and its play-time
    # prefetch (filename known) hit the same cache entry instead of each
    # paying for the full multi-source network search.
    names_key = ','.join(sorted(n for n, _ in candidates))
    identity_data = _release_independent_identity(video_data)

    f_result = cache.get(
        _fetch_release_independent_sources, 24,
        identity_data, names_key, table='subs') or []

    playing = False
    try:
        playing = xbmc.Player().isPlaying()
    except Exception:
        pass
    if not for_autosub and not playing and (Addon.getSetting("enable_autosub_notifications")=='true' or not xbmc.Player().isPlaying()):
        # If searching subtitles from context menu - will show the message.
        general.show_msg="מסדר כתוביות"

    return f_result
    
def get_subtitles(video_data):
    # For settings changes to take effect.
    Addon=xbmcaddon.Addon(MyScriptID)
    from resources.modules import general
    for_autosub = _is_autosub_run()

    if not for_autosub and (Addon.getSetting("enable_autosub_notifications")=='true' or not xbmc.Player().isPlaying()):
        general.show_msg='מחפש כתוביות'
    
    f_result=c_get_subtitles(video_data)
    xbmc.sleep(100)
    return f_result

#################### PUNCTUATION FIX ###########################################################
def fix_sub_punctuation_text(original_subtitle_lines):

    # Remove <i> </i> tags
    original_subtitle_lines = original_subtitle_lines.replace('<i>', '').replace('</i>', '')

    import re
    punctuation_regex = re.compile(r'[.,?!:…]+$') # "…" is not three regular dots, but single Ellipsis character. https://en.wikipedia.org/wiki/Ellipsis
    hyphen_mark = '-'
    modified_lines = []
        
    # Helper function to check if a line contains Hebrew characters
    def is_hebrew(line):
        hebrew_unicode_range = (0x0590, 0x05FF)
        for char in line:
            if hebrew_unicode_range[0] <= ord(char) <= hebrew_unicode_range[1]:
                return True
        return False
    ###############################################################
    
    # Helper function to fix punctuation in a text line
    def fix_punctuation_in_text(text):

        # Check for hyphen at the start of the line
        starts_with_hyphen = text.startswith(hyphen_mark)
        
        # Temporary remove hyphen
        if starts_with_hyphen: text = text.lstrip(hyphen_mark)
    
        match = punctuation_regex.search(text)
        # From: "קרובים יותר ממה שהיינו אי פעם."
        # To: ".קרובים יותר ממה שהיינו אי פעם"
        if match:
            # Move punctuation to the beginning
            text =  match.group(0) + text[:match.start()]
        
        # From: "-קח את זה"
        # To: "קח את זה-"
        # Bring back hyphen to end of text
        if starts_with_hyphen: text += hyphen_mark
            
        return text
    ###############################################################
        
    for line in original_subtitle_lines.splitlines():
        if is_hebrew(line):
            # Fix punctuation for the entire line
            line = fix_punctuation_in_text(line.rstrip())
        modified_lines.append(line)
                
    return '\n'.join(modified_lines)

def fix_sub_punctuation_and_write(sub_file):

    try:
        # Open the file as binary data
        import chardet
        with open(sub_file, 'rb') as f:
            # Join binary lines for specified number of lines
            text = f.read()

        encoding=chardet.detect(text)['encoding']
        log.warning(f"PUNCT | encoding={encoding}")
        with open(sub_file, 'r', encoding=encoding) as f:
            # Join binary lines for specified number of lines
            text = f.read()
        
        text = fix_sub_punctuation_text(text)
        
        with open(sub_file, mode="w", encoding="utf8") as f:
                 f.write(text)

        return sub_file
    except Exception as e:
        log.warning(f"Exception in fix_sub_punctuation_and_write | Exception: {str(e)}")
        return None

#################### HEARING IMPAIRED TAGS REMOVE ###########################################################
def remove_hi_tags_and_write(sub_file):
    
    def remove_hi_subs(subtitle_content):

        import re

        # Remove unwanted characters and patterns from a line.
        def clean_line(line):
            # Remove music notation symbols (♪)
            line = re.sub(r'[♪]+\s?', '', line)
            # Remove text within square brackets (e.g., [door slams], [music playing])
            line = re.sub(r'\[[^\]]*\]\s?', '', line)
            # Remove text within parentheses (e.g., (whispering), (background noise))
            line = re.sub(r'\([^\)]*\)\s?', '', line)
            return line
        
        # Initialize a list to hold processed lines
        final_lines = []
        
        for original_line in subtitle_content.splitlines():
            cleaned_line = clean_line(original_line)
            
            # Check if the line was modified
            if original_line != cleaned_line:
                
                # Strip leading and trailing whitespace
                cleaned_line = cleaned_line.strip()
                
                # Skip empty lines or lines that are just isolated "-" or ":"
                if cleaned_line and not re.match(r'^\s*[-:]\s*$', cleaned_line):
                    final_lines.append(cleaned_line)

            else:
                final_lines.append(original_line)

        # Join lines back with newlines
        return "\n".join(final_lines)

    try:
        # Open the file as binary data
        import chardet
        with open(sub_file, 'rb') as f:
            # Join binary lines for specified number of lines
            text = f.read()

        encoding=chardet.detect(text)['encoding']
        log.warning(f"PUNCT | encoding={encoding}")
        with open(sub_file, 'r', encoding=encoding) as f:
            # Join binary lines for specified number of lines
            text = f.read()
        
        text = remove_hi_subs(text)
        
        with open(sub_file, mode="w", encoding="utf8") as f:
                 f.write(text)

        return sub_file
    except Exception as e:
        log.warning(f"Exception in remove_hi_tags_and_write | Exception: {str(e)}")
        return None

#################### MACHINE TRANSLATE WEBSITES #######################################

#################### GOOGLE ###########################################################
# activate_embedded_sub now lives in embedded_streams.py (everything it
# does is embedded-stream-state, which that module owns) -- re-exported so
# `from resources.modules.engine import activate_embedded_sub` still works.
from resources.modules.embedded_streams import activate_embedded_sub


def download_sub(source,download_data,MySubFolder,language,filename):
    log.warning('Download sub')
    log.warning('filename: ')
    log.warning(filename)
    from resources.modules import general
    from resources.modules.ai_translate import kodi_bridge
    if source in ('HebrewSubEmbedded', 'EnglishSubEmbedded'):
        lang = 'heb' if source == 'HebrewSubEmbedded' else 'eng'
        if activate_embedded_sub(lang, max_wait_sec=5, clear_external=True) is not None:
            return 'EmbeddedSubSelected'
        return 'FaultSubException'
    
    ext=[".idx",".sup",".srt",".sub",".str",".ass"]
    Addon=xbmcaddon.Addon(MyScriptID)
    try:
        shutil.rmtree(MySubFolder)
    except: pass
    xbmcvfs.mkdirs(MySubFolder)
    
    
    if not os.path.exists(MySubFolder):
        os.makedirs(MySubFolder)
        

    
    source_dir = os.path.join(addonPath, 'resources', 'sources')
    sys.path.append(source_dir)
    try:
        impmodule = __import__(source)
    except ImportError:
        # A stale cached/session search result (or an old settings.xml from
        # a previous addon version) can still reference a source module
        # that's since been removed entirely (e.g. wizdom/subdl/subsource/
        # subscene). Fail this one download cleanly instead of crashing --
        # the source is gone, not a bug to retry.
        log.warning(f"Download source module '{source}' no longer exists in this version -- skipping")
        general.break_all=True
        return 'FaultSubException'
    from resources.modules.general import ensure_cache_dirs
    ensure_cache_dirs()
    max_sub_cache=int(Addon.getSetting("subtitle_trans_cache"))
    f_count=0
    for filename_o in os.listdir(CachedSubFolder):
        
        f_count+=1

    if (f_count>max_sub_cache):
            for filename_o in os.listdir(CachedSubFolder):
                f = os.path.join(CachedSubFolder, filename_o)
                os.remove(f) 
    c_sub_file=os.path.join(CachedSubFolder, f"{source}_{language}_{filename}")
    found_in_cache=False
    for items in ext:
        log.warning(c_sub_file+items)
        if os.path.exists(c_sub_file+items):
            sub_file=c_sub_file+items
            found_in_cache=True
            log.warning('Found cache')
            break
    if not found_in_cache:
        try:
            sub_file=impmodule.download(download_data,MySubFolder)
        except Exception as e:
            log.warning(f"Exception downloading sub, configuring general.break_all=True... | Exception: {str(e)}, soure={source}, download_data={download_data}")
            general.break_all=True
            return 'FaultSubException'
        if not sub_file or not os.path.isfile(str(sub_file)):
            log.warning(f"Download returned no file | source={source} | sub_file={sub_file}")
            general.break_all=True
            return 'FaultSubException'
        
    # Auto punctuation fix for external Hebrew subtitles.
    if (subtitle_needs_machine_translate(language, source) is False
            and 'Hebrew' in (language or '')
            and ".idx" not in sub_file and ".sup" not in sub_file):
        if Addon.getSetting("auto_fix_sub_punctuation")=='true':
            try:
                fix_sub_punctuation_and_write(sub_file)
            except Exception as e:
                log.warning(f"Exception in fix_sub_punctuation_and_write | Exception: {str(e)}")
                pass
            
        ###### Upload to Telegram ########
        # Upload only subtitles (not from Telesubs), and are not in "Cached_subs" directory. In that case, those subtitles should already have been uploaded.
        if Addon.getSetting('telesubs')=='true' and source != "telesubs" and not found_in_cache: 
            log.warning(f"[TeleSubs] | upload_subtitle_to_telegram | source={source} | sub_file={sub_file}")
            caption = ''
            from threading import Thread
            t = Thread(target=telesubs.upload_subtitle_to_telegram, args=(sub_file,filename,caption,format_website_source_name(source),))
            t.start()
        ##################################
    
    elif (subtitle_needs_machine_translate(language, source)
            and kodi_bridge.get_bool('auto_translate', True)):
        f_count=0
        for filename_o in os.listdir(TransFolder):
            
            f_count+=1
        if (f_count>max_sub_cache):
            for filename_o in os.listdir(TransFolder):
                f = os.path.join(TransFolder, filename_o)
                os.remove(f)
        trans_basename = _resolve_trans_basename(filename, download_data, source)
        trans_file=os.path.join(TransFolder, trans_basename)
        already_translated = _trans_file_is_hebrew(trans_file)
        if os.path.isfile(trans_file) and not already_translated:
            try:
                os.remove(trans_file)
                stale = trans_file + '.ai_done'
                if os.path.isfile(stale):
                    os.remove(stale)
            except OSError:
                pass
        if not already_translated:
            translated = machine_translate_subs(sub_file, trans_file)
            if not translated and not _trans_file_is_hebrew(trans_file):
                log.warning('Translation failed (Gemini selected, no Google fallback)')
                general.break_all = True
                return 'FaultSubException'
            if _trans_file_is_hebrew(trans_file):
                _mark_trans_done(trans_file)
        sub_file = trans_file
        
        ###### Upload to Telegram ########
        # Upload only subtitles (not from Telesubs), and are not in "trans_subs" directory. In that case, those subtitles should already have been uploaded.
        if Addon.getSetting('telesubs')=='true' and source != "telesubs" and not already_translated:
            log.warning(f"[TeleSubs] | upload_subtitle_to_telegram | source={source} | sub_file={sub_file}")
            try:
                from resources.modules.ai_translate import settings_guard
                is_gemini_translation = settings_guard.effective_translate_p() == '2'
            except Exception as e:
                log.warning(f"settings_guard failed, assuming non-Gemini translation: {e}")
                is_gemini_translation = False
            trans_label = "תרגום ג'מני" if is_gemini_translation else 'תרגום מכונה'
            caption = f'\n({language} - {trans_label})'
            from threading import Thread
            t = Thread(target=telesubs.upload_subtitle_to_telegram, args=(sub_file,filename,caption,format_website_source_name(source),))
            t.start()
        ##################################
            
    # Remove HI (Hearing Impaired) subtitle tags for non-Hebrew subs.
    hearing_imp = download_data.get('hearing_imp', 'false')
    if hearing_imp=='true' and Addon.getSetting("auto_remove_hi_tags")=='true':
        if Addon.getSetting("enable_autosub_notifications")=='true':
            from resources.modules.general import notify
            notify("כתובית לכבדי שמיעה נבחרה, מנקה...")
        try:
            remove_hi_tags_and_write(sub_file)
        except Exception as e:
            log.warning(f"Exception in remove_hi_tags_and_write | Exception: {str(e)}")
            pass
            
    log.warning(f"general.break_all: {general.break_all}")
    return sub_file
