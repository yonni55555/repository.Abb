
# -*- coding: utf-8 -*-
"""Machine-translation engines (Google/Yandex/Bing + Gemini dispatch) and
the trans_subs filename/state bookkeeping that goes with them.

Split out of engine.py, which had become a grab-bag of the actual
search/rank/place engine PLUS a third of its size in unrelated translation
infrastructure. engine.py re-exports the few names other modules import
(machine_translate_subs, subtitle_needs_machine_translate,
_trans_file_is_hebrew) so no external call site needed to change.
"""
import random
import os
import sys
import time
import chardet
import xbmc
import xbmcvfs
import xbmcaddon
from concurrent import futures
from urllib.parse import unquote_plus, quote_plus
from resources.modules import log
from resources.modules import cache
from resources.modules.general import (
    Thread, TransFolder, user_dataDir, DEFAULT_REQUEST_TIMEOUT,
)

xbmc_tranlate_path = xbmcvfs.translatePath
que = quote_plus
unque = unquote_plus

MyScriptID = 'service.subtitles.All_Subs'
try:
    Addon = xbmcaddon.Addon(MyScriptID)
except Exception:
    Addon = xbmcaddon.Addon()
    MyScriptID = Addon.getAddonInfo('id')
addonPath = xbmc_tranlate_path(Addon.getAddonInfo("path"))

trans_result = []
global_sub_size = 0
global_progress = 0
global_failed_chunks = []  # one entry per Google chunk that came back untranslated


class Bing(object):
    def __init__(self):
        self.url = "http://api.microsofttranslator.com/v2/ajax.svc/TranslateArray2?"

    def translate(self, from_lan, to_lan,content,):
        import urllib.parse
        import urllib.request
        data = {}
        #data['from'] = '"' + from_lan + '"'
        data['to'] = '"' + to_lan + '"'
        data['texts'] = '["'
        data['texts'] += content
        data['texts'] += '"]'
        data['options'] = "{}"
        data['oncomplete'] = 'onComplete_3'
        data['onerror'] = 'onError_3'
        data['_'] = '1430745999189'
        data = urllib.parse.urlencode(data).encode('utf-8')
        strUrl = self.url + data.decode() + "&appId=%22ABB1C5A823DC3B7B1D5F4BDB886ED308B50D1919%22"
        response = urllib.request.urlopen(strUrl)
        str_data = response.read().decode('utf-8')
        try:
            tmp, str_data = str_data.split('"TranslatedText":')
        except:
            print (str_data)
            return str_data
        translate_data = str_data[1:str_data.find('"', 1)]
        return translate_data


def split_on_cues(text, limit):
    """Split SRT text into chunks of at most ~`limit` characters without cutting a cue.

    Args:
        text: subtitle text; cues are separated by blank lines (CRLF is normalised to LF).
        limit: soft size cap per chunk. A chunk closes when adding the next cue would
            pass it; a single cue longer than `limit` becomes its own chunk.

    Returns:
        list of chunk strings. Join them with "\n\n" to get the cues back in order.
    """
    import re
    cues = [c for c in re.split(r'\n[ \t]*\n', text.replace('\r\n', '\n')) if c.strip()]
    chunks = []
    current = ''
    for cue in cues:
        if current and len(current) + 2 + len(cue) > limit:
            chunks.append(current)
            current = cue
        else:
            current = current + '\n\n' + cue if current else cue
    if current:
        chunks.append(current)
    return chunks


def google_send_translate(items):
    from resources.modules import general
    global global_sub_size,global_progress
    from resources.modules.auto_translate.googletrans import Translator


    translator = Translator()
    result = translator.translate(items, dest='he')
    translation = result.text
    if result._response is None:  # client gave up after its retries; chunk is still the original text
        global_failed_chunks.append(1)

    global_progress+=1
    general.show_msg=f"Google Translate מתרגם | {str(int(((global_progress* 100.0)/(global_sub_size)) ))}%"
    general.progress_msg=int(((global_progress* 100.0)/(global_sub_size)) )
    return translation

def google_machine_translate(text, encoding):
    from resources.modules import general
    global global_sub_size,global_progress
    ax2=split_on_cues(text,3000)
    global_sub_size=len(ax2)
    global_progress=0
    del global_failed_chunks[:]
    log.warning('Start Google')

    general.show_msg=f"Google Translate מתרגם {encoding}"
    with futures.ThreadPoolExecutor(max_workers=5) as executor:  # more parallel requests trigger Google 429
        res = [executor.submit(google_send_translate, txt) for txt in ax2]
        futures.wait(res)

    general.progress_msg=0

    if global_failed_chunks:
        general.notify('Google Translate: {0} of {1} parts stayed untranslated'.format(
            len(global_failed_chunks), global_sub_size), times=6000)

    f_sub_pre = '\n\n'.join((r.result() for r in res))

    ########################################################################################################
    # SRT Format FIX
    # Fix timestamp format: Ensure proper format for 'HH:MM:SS,SSS --> HH:MM:SS,SSS'
    import re
    f_sub_pre = re.sub(r'(\d{2}):\s?(\d{2}):\s?(\d{2}),\s?(\d{3})\s?-{1,2}>\s?(\d{2}):\s?(\d{2}):\s?(\d{2}),\s?(\d{3})',
                       r'\1:\2:\3,\4 --> \5:\6:\7,\8', f_sub_pre)

    # MAYBE USEFUL IN THE FUTURE:
    # Add \r\n for empty lines, retain non-empty lines as they are
    # f_sub_pre = '\n'.join(line if len(line) > 1 else line + "\r\n" for line in f_sub_pre.splitlines())
    ########################################################################################################

    return f_sub_pre


#################### YANDEX ###########################################################
def yandex_get_random_number():
    import random
    result=22
    while (result == 20) or (result == 21) or (result == 22):
        result=int(random.random()*22+1)
    return result

def yandex_get_translated(base_url,items,counter,headers):
    import requests
    global trans_result
    translation='Error code'
    count_error=0
    while ('Error code' in translation or 'Resource Limit Is Reached' in translation or 'Access denied' in translation or 'onError_3' in translation):
        try:
            translation=requests.get(base_url+(items),headers=headers).text
        except:
            num=yandex_get_random_number()
            base_url='https://t%s.freetranslations.org/freetranslationsorg.php?p1=auto&p2=he&p3='%str(num)
            try:
                translation=requests.get(base_url+(items),headers=headers,timeout=2).text
            except:
                translation='Error code'
        if ('Error code' in translation or 'Resource Limit Is Reached' in translation or 'Access denied' in translation or 'onError_3' in translation):

            bing=Bing()
            log.warning('Error Found')

            x=bing.translate('en', 'he',que(items))
            translation=unque(x)

            if ('onError_3' in translation):
                time.sleep(1)
                count_error+=1
                if (count_error>5):
                    log.warning('Error 5')
                    break

    if ('Error code' in translation or 'Resource Limit Is Reached' in translation or 'Access denied' in translation):
        translation='Error now:'+str(count_error)
    trans_result.append((translation,counter))

def yandex_machine_translate(text, encoding):
    global trans_result
    from resources.modules import general

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20100101 Firefox/99.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Alt-Used': 't19.freetranslations.org',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-User': '?1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    num=yandex_get_random_number()
    base_url='https://t%s.freetranslations.org/freetranslationsorg.php?p1=auto&p2=he&p3='%str(num)


    split_string = lambda x, n: [x[i:i+n] for i in range(0, len(x), n)]
    f_sub_pre=''
    xx=0

    general.progress_msg=0
    ax2=split_string(text,500)
    thread=[]
    counter=0
    for items in ax2:
         thread.append(Thread(yandex_get_translated,base_url,items.replace('ה',''),counter,headers))
         counter+=1
         if general.break_all:
             break
         xx+=1
    for td in thread:
        td.start()
    while 1:

        still_alive=0
        for threads in thread:

              if general.break_all:

                 break

              num_live=0
              string_dp=''

              still_alive=0
              for yy in range(0,len(thread)):
                if not thread[yy].is_alive():
                  num_live=num_live+1

                else:
                  still_alive=1
        general.show_msg=f"Yandex מתרגם {encoding} | {str(int(((num_live* 100.0)/(len(thread))) ))}%"
        general.progress_msg=int(((num_live* 100.0)/(len(thread))) )


        if still_alive==0:
                break
    translation=sorted(trans_result, key=lambda x: x[1], reverse=False)
    for sub_title,index in translation:
        f_sub_pre=f_sub_pre+sub_title

    return f_sub_pre


#################### BING #############################################################
def bing_c_get_keys():
    import requests
    x=requests.get('https://kodi7rd.github.io/repository/other/DarkSubs_Bing/darksubs_bing_api.json', timeout=DEFAULT_REQUEST_TIMEOUT).json()
    return x

def bing_get_last_key():
    try:
        last_key_file=os.path.join(user_dataDir,'last_bing_key.txt')
        file = open(last_key_file, 'r')
        file_data= file.read()
        file.close()

        file_data=int(file_data)
    except:
        x=bing_c_get_keys()
        file_data = random.randint(0, len(x) - 1) # Generate random number from 0 to keys count
    return file_data

def bing_set_last_key(count_key):
    try:
        last_key_file=os.path.join(user_dataDir,'last_bing_key.txt')
        file = open(last_key_file, 'w')
        file.write(str(count_key))
        file.close()
    except:
        pass

def bing_select_key(count_key):
    x=cache.get(bing_c_get_keys, 24,table='subs')


    return x[count_key]['bing_translator_name'],x[count_key]['bing_api_key'],x[count_key]['bing_region'],len(x)

def bing_machine_translate(text, encoding):
    from resources.modules import general
    general.show_msg='Bing מתרגם'
    import requests, uuid, json


    count_key=bing_get_last_key()
    # Add your key and endpoint
    nm,key,location,amount = bing_select_key(count_key)
    endpoint = "https://api.cognitive.microsofttranslator.com"

    # location, also known as region.
    # required if you're using a multi-service or regional (not global) resource. It can be found in the Azure portal on the Keys and Endpoint page.


    path = '/translate'
    constructed_url = endpoint + path

    params = {
        'api-version': '3.0',
        #'from': 'en',
        'to': ['he']
    }

    headers = {
        'Ocp-Apim-Subscription-Key': key,
        # location required if you're using a multi-service or regional (not global) resource.
        'Ocp-Apim-Subscription-Region': location,
        'Content-type': 'application/json',
        'X-ClientTraceId': str(uuid.uuid4())
    }

    split_string = lambda x, n: [x[i:i+n] for i in range(0, len(x), n)]

    ax2=split_string(text,50000)
    f_sub_pre=''
    xx=0

    general.progress_msg=0
    for items in ax2:

        general.progress_msg=int(((xx* 100.0)/(len(ax2))) )
        if general.break_all:
             break
        body = [{
            'text': items
        }]
        count_test=0
        while count_test<amount:
            general.show_msg=f"Bing מתרגם {encoding} | {nm} {str(count_key)}/{str(amount)} | {str(int(((xx* 100.0)/(len(ax2))) ))}%"
            request = requests.post(constructed_url, params=params, headers=headers, json=body)
            response = request.json()
            try:
                f_sub_pre=f_sub_pre+response[0]['translations'][0]['text']

                bing_set_last_key(count_key)
                break
            except:
                general.show_msg=str(response)

                count_key = random.randint(0, amount - 1) # Generate random number from 0 to keys count
                nm,key,location,amount = bing_select_key(count_key)
                log.warning(f"DarkSubs Bing API: bing_translator_name={nm} | bing_api_key={key} | total_keys_amount={amount}")
                headers = {
                    'Ocp-Apim-Subscription-Key': key,
                    # location required if you're using a multi-service or regional (not global) resource.
                    'Ocp-Apim-Subscription-Region': location,
                    'Content-type': 'application/json',
                    'X-ClientTraceId': str(uuid.uuid4())
                }
                count_test+=1
        xx+=1

    return f_sub_pre


#################### MACHINE TRANSLATE ################################################
def machine_translate_subs(input_file,output_file):
    global trans_result
    trans_result=[]

    from resources.modules import general

    if not input_file or not os.path.isfile(str(input_file)):
        log.warning('machine_translate_subs: input file missing: {0}'.format(input_file))
        return ''

    try:
        from resources.modules.ai_translate import language_detect
        with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
            sample = f.read(12000)
        if language_detect.detect(sample) == 'he':
            log.warning('machine_translate_subs: skip — subtitle already Hebrew')
            import shutil
            shutil.copy2(input_file, output_file)
            with open(output_file, encoding='utf8') as f:
                return f.read()
    except Exception as e:
        log.warning('machine_translate_subs: Hebrew pre-check failed: {0}'.format(e))

    g_show_msg=general.show_msg
    progress_msg=general.progress_msg

    from resources.modules.ai_translate import kodi_bridge
    translate_p = '0'
    try:
        from resources.modules.ai_translate import settings_guard
        settings_guard.sanitize_user_settings()
        translate_p = settings_guard.effective_translate_p()
    except Exception as e:
        log.warning('settings_guard failed, using kodi_bridge: {0}'.format(e))
        translate_p = (kodi_bridge.get_setting('translate_p') or '0').strip()
    auto_translate = kodi_bridge.get_bool('auto_translate', True)
    if translate_p == '2' and auto_translate:
        # Progress UI is owned by main.py ("מתבצע תרגום AI" + seconds).
        general.show_msg = 'END'
    else:
        general.show_msg='אנא המתן'+'\n'+'מתרגם'
        log.warning('אנא המתן'+'\n'+'מתרגם')

    # Open the file as binary data
    with open(input_file, 'rb') as f:
        # Join binary lines for specified number of lines
        text = f.read()

    import chardet
    encoding=chardet.detect(text)['encoding']
    log.warning('encoding:'+encoding)

    if encoding=='ISO-8859-7':
      text=text.decode('cp1253','ignore')
    elif encoding=='MacCyrillic':
      text=text.decode('cp1256','ignore')
    else:
      text=text.decode(encoding,'ignore')

    path=xbmc_tranlate_path('special://home/addons/%s/resources/modules/auto_translate'%MyScriptID)
    sys.path.append(path)

    # For settings changes to take effect.
    log.warning(f"selected translation engine: {translate_p}")
    f_sub_pre = None

    if translate_p == '2':
        api_key = (kodi_bridge.get_setting('gemini_api_key') or '').strip()
        if api_key:
            try:
                from resources.modules.ai_translate import translate_engine
                log.warning('Gemini translation starting...')
                from resources.modules.ai_translate import kodi_bridge
                fast_first = kodi_bridge.get_bool('fast_first_chunk', True)
                if translate_engine.translate_file(
                        input_file, output_file,
                        fast_first=fast_first,
                        info=kodi_bridge.current_video_info()):
                    if os.path.isfile(output_file):
                        with open(output_file, encoding='utf8') as f:
                            f_sub_pre = f.read()
                        log.warning('Gemini translation finished OK')
                    else:
                        log.warning(
                            'Gemini returned OK but output missing: {0}'.format(
                                output_file))
                else:
                    log.warning('Gemini translation returned False')
            except Exception as e:
                log.warning('Gemini translation failed: {0}'.format(e))
        else:
            log.warning('Gemini selected but gemini_api_key is empty')

    if f_sub_pre is None:
        if translate_p == '2':
            log.warning('Gemini AI selected — not falling back to Google Translate')
            if not (kodi_bridge.get_setting('gemini_api_key') or '').strip():
                log.warning('Gemini selected but gemini_api_key is empty — enter key in DarkSubs settings')
            return ''
        elif translate_p == '1':
            f_sub_pre = yandex_machine_translate(text, encoding)
        else:
            f_sub_pre = google_machine_translate(text, encoding)

    f_all=f_sub_pre.replace('\r\r','\n')

    source_dir = os.path.join(addonPath, 'resources', 'modules')
    sys.path.append(source_dir)
    if not general.break_all:
        with open(output_file, mode="w", encoding="utf8") as f:
                 f.write(f_all)

    from resources.modules import pysrt
    try:
        subs = pysrt.open(output_file)

        first_sub = subs[0]
        log.warning('Subs Ok')

    except Exception as e:
        log.warning('Error in sub:'+str(e))
        f_all=f_sub_pre.replace('\r\r','\n').replace('\n\n','\n')

    # Gemini path already runs MoranSubs postprocess (stacked lines + RTL punct).
    if (kodi_bridge.get_bool('auto_fix_sub_punctuation', True)
            and translate_p != '2'):
        # Lazy import: fix_sub_punctuation_text still lives in engine.py
        # (search/rank/place + subtitle-text cleanup), which itself
        # re-exports names from this module -- a top-level import here
        # would be circular. By the time this runs, engine.py has always
        # already finished loading.
        from resources.modules.engine import fix_sub_punctuation_text
        f_all = fix_sub_punctuation_text(f_all)


    if not general.break_all:
        with open(output_file, mode="w", encoding="utf8") as f:
                 f.write(f_all)
        if _trans_file_is_hebrew(output_file):
            _mark_trans_done(output_file)

    return f_all


def _sanitize_sub_basename(name):
    raw = (name or '').split('|')[0].split('?')[0]
    chars_to_remove = '\\/:*?"<>|\'&=%'
    return ''.join(c for c in raw if c not in chars_to_remove).strip()


def _is_unusable_media_name(name):
    """Reject stream URLs / m3u8 paths — invalid and unsafe as trans_subs basenames."""
    low = (name or '').lower()
    if not low:
        return True
    if low.startswith('http') or low.startswith('plugin://'):
        return True
    if '.m3u8' in low or 'referer=' in low or 'user-agent=' in low:
        return True
    if low in ('stream', 'http', 'https'):
        return True
    return False


def subtitle_needs_machine_translate(language, source=None):
    """Only foreign-language external subs get machine/Gemini translation."""
    src = (source or '').strip()
    if src in ('HebrewSubEmbedded', 'EnglishSubEmbedded'):
        return False
    lang = (language or '').strip()
    if not lang:
        return True
    low = lang.lower()
    if low in ('he', 'heb', 'hebrew') or lang.startswith('Hebrew'):
        return False
    return True


def _pick_basename(filename, download_data=None):
    """Pick the fullest release name for trans_subs (Show.SxxExx…), not a short OS tag."""
    import re
    fn = _sanitize_sub_basename(filename)
    dd = download_data or {}
    dd_name = _sanitize_sub_basename(dd.get('filename') or '')
    if dd_name and not _is_unusable_media_name(dd_name):
        if not fn or len(dd_name) > len(fn):
            fn = dd_name
    if fn and re.search(r'[Ss]\d{1,2}[Ee]\d{1,2}', fn) and len(fn) >= 15:
        return fn
    try:
        from resources.modules.ai_translate import kodi_bridge
        info = kodi_bridge.current_video_info()
        for key in ('picked_release', 'tagline', 'label', 'filepath'):
            raw = (info.get(key) or '').replace('\\', '/')
            raw = raw.split('|')[0].split('?')[0]
            c = _sanitize_sub_basename(os.path.basename(raw))
            if _is_unusable_media_name(c):
                continue
            if re.search(r'[Ss]\d{1,2}[Ee]\d{1,2}', c) and len(c) > len(fn):
                fn = c
            elif len(c) > len(fn) and len(c) >= 25:
                fn = c
    except Exception:
        pass
    if fn and not _is_unusable_media_name(fn):
        return fn
    if dd_name and not _is_unusable_media_name(dd_name):
        return dd_name
    return _sanitize_sub_basename(filename) or 'translated_sub'


def _resolve_trans_basename(filename, download_data=None, source=None):
    """trans_subs cache key for this specific subtitle pick.

    _pick_basename() derives a human-readable name from the release/episode
    (Show.SxxExx...), which is the same for every subtitle a user picks for
    that episode -- including two different English subtitles from two
    different uploaders/sites. Without something to tell those picks apart,
    translating the second one would find the first one's already-translated
    file sitting at the same path and silently reuse it instead of
    translating the new pick (confirmed: user picked subtitle #1, it
    translated; picked subtitle #2 for the same episode, it instantly
    "translated" by reusing #1's Hebrew output). download_data carries a
    per-subtitle id/url that's unique per actual file, so fold it (plus the
    source site, since ids aren't unique across sites) into the basename.
    """
    import hashlib
    import json
    base = _pick_basename(filename, download_data)
    dd = download_data or {}
    key = json.dumps({'source': source, 'dd': dd}, sort_keys=True, default=str)
    digest = hashlib.md5(key.encode('utf-8')).hexdigest()[:10]
    root, ext = os.path.splitext(base)
    if ext and len(ext) <= 5:
        return f'{root}.{digest}{ext}'
    return f'{base}.{digest}'


def _trans_file_is_hebrew(trans_file):
    """True when trans_subs file content is actually Hebrew."""
    if not trans_file or not os.path.isfile(trans_file):
        return False
    try:
        from resources.modules.ai_translate import language_detect
        with open(trans_file, 'r', encoding='utf-8', errors='ignore') as f:
            sample = f.read(12000)
        if language_detect.detect(sample) == 'he':
            return True
        done_marker = trans_file + '.ai_done'
        if os.path.isfile(done_marker):
            try:
                os.remove(done_marker)
            except OSError:
                pass
        return False
    except Exception:
        return False


def _mark_trans_done(trans_file):
    try:
        with open(trans_file + '.ai_done', 'w', encoding='utf-8') as f:
            f.write('1')
    except OSError:
        pass
