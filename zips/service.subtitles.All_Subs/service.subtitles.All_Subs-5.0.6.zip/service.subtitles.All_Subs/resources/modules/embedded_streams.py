# -*- coding: utf-8 -*-
"""Track MKV embedded subtitle streams vs external setSubtitles() false positives."""
import xbmc
from resources.modules import log

_ISO_HEB = frozenset(('heb', 'he', 'iw'))
_ISO_ENG = frozenset(('eng', 'en'))
_EXTERNAL_LABEL_MARKERS = (
    '(חיצוני)', '(external)', '(ext)', 'חיצוני', 'external',
)


def _clean_stream_list(streams):
    return [s for s in (streams or []) if s is not None and str(s).strip()]


def stream_matches_lang(stream, lang):
    """Loose label match — use is_confident_embedded_track before treating as MKV embedded."""
    if stream is None or not str(stream).strip():
        return False
    raw = str(stream).strip()
    low = raw.lower()
    if lang == 'heb':
        if low in _ISO_HEB:
            return True
        if low == 'hebrew' or raw == 'עברית':
            return True
        if '(עברית)' in raw or raw.endswith('(עברית)'):
            return True
        if 'hebrew' in low and len(raw) > 12:
            return True
        return False
    if lang == 'eng':
        if low in _ISO_ENG:
            return True
        if low == 'english' or raw == 'אנגלית':
            return True
        if '(english)' in low or '(אנגלית)' in raw:
            return True
        return False
    return low == lang


def _stream_is_external_label(stream):
    raw = str(stream or '').strip().lower()
    if not raw:
        return False
    for marker in _EXTERNAL_LABEL_MARKERS:
        if marker.lower() in raw or marker in str(stream or ''):
            return True
    return False


def _looks_like_external_file_tracks(subs):
    """
    After setSubtitles(), Kodi often reports [(חיצוני), heb] — not MKV embedded.
    """
    cleaned = _clean_stream_list(subs)
    if not cleaned:
        return False
    has_ext_label = any(_stream_is_external_label(s) for s in cleaned)
    has_iso_heb = any(str(s).strip().lower() in _ISO_HEB for s in cleaned)
    if not (has_ext_label and has_iso_heb):
        return False
    if len(cleaned) > 3:
        return False
    has_eng = any(
        str(s).strip().lower() in _ISO_ENG or stream_matches_lang(s, 'eng')
        for s in cleaned)
    if has_eng:
        return False
    log.warning(
        'embedded_streams | external-file track pattern (not MKV): {0}'.format(cleaned))
    return True


def is_confident_embedded_track(subs, index_sub, lang):
    """
    MKV embedded vs debrid/player ghost tracks.
    Single non-ISO label like (עברית) alone is NOT embedded (RDmovies false positive).
    (חיצוני)+heb after setSubtitles is NOT embedded (Michael false positive).
    """
    if index_sub is None or index_sub >= len(subs or []):
        return False
    cleaned = _clean_stream_list(subs)
    if _looks_like_external_file_tracks(cleaned):
        return False
    stream_val = subs[index_sub]
    if not stream_matches_lang(stream_val, lang):
        return False
    low = str(stream_val).strip().lower()
    if lang == 'heb' and low in _ISO_HEB:
        return True
    if lang == 'eng' and low in _ISO_ENG:
        return True
    if len(cleaned) >= 2:
        return True
    log.warning(
        'embedded_streams | reject single label-only {0} track (not MKV embedded): {1!r}'.format(
            lang, stream_val))
    return False


def _find_stream_index(subs, lang):
    for j, s in enumerate(subs or []):
        if stream_matches_lang(s, lang):
            return j
    return None


class EmbeddedStreamTracker:
    """Groups the embedded-vs-external subtitle-stream detection state and
    the operations that read/mutate it. One instance per Kodi player
    session (see the module-level singleton below) -- everything here is
    about answering one question: is a given subtitle language a genuine
    MKV-embedded track, or a false positive from an external file load /
    debrid player quirk.
    """

    def __init__(self):
        self._initial_subtitle_streams = []
        self._external_sub_loaded = False
        self._snapshot_before_external = []
        self._confirmed_no_tracks = False

    def reset(self):
        self._initial_subtitle_streams = []
        self._external_sub_loaded = False
        self._snapshot_before_external = []
        self._confirmed_no_tracks = False

    def get_initial_snapshot(self):
        return list(self._initial_subtitle_streams)

    def external_sub_loaded(self):
        return self._external_sub_loaded

    def mark_external_loaded(self):
        self._snapshot_before_external = list(self._initial_subtitle_streams)
        self._external_sub_loaded = True
        log.warning(
            'embedded_streams | external sub loaded — heb added to player streams is not MKV embedded | pre-snapshot={0}'.format(
                self._snapshot_before_external))

    def player_subtitle_streams(self):
        try:
            return xbmc.Player().getAvailableSubtitleStreams() or []
        except Exception:
            return []

    def snapshot_has_lang(self, lang):
        subs = _clean_stream_list(self._initial_subtitle_streams)
        idx = _find_stream_index(subs, lang)
        return idx is not None and is_confident_embedded_track(subs, idx, lang)

    def _update_snapshot(self, streams):
        cleaned = _clean_stream_list(streams)
        if cleaned:
            self._initial_subtitle_streams = list(cleaned)

    def capture_initial(self, max_wait_sec=5):
        """Snapshot player subtitle streams before any external setSubtitles(path)."""
        if self._external_sub_loaded:
            log.warning(
                'embedded_streams | capture_initial skipped — external sub already loaded | snapshot={0}'.format(
                    self._initial_subtitle_streams))
            return self._initial_subtitle_streams
        if not xbmc.Player().isPlaying():
            self._initial_subtitle_streams = []
            return self._initial_subtitle_streams
        streams = []
        for _ in range(max(1, int(max_wait_sec * 10))):
            try:
                streams = _clean_stream_list(xbmc.Player().getAvailableSubtitleStreams())
                if streams:
                    break
            except Exception:
                pass
            if not xbmc.Player().isPlaying():
                break
            xbmc.sleep(100)
        self._initial_subtitle_streams = list(streams)
        log.warning(
            'embedded_streams | initial snapshot={0}'.format(self._initial_subtitle_streams))
        return self._initial_subtitle_streams

    def capture_at_play_start(self, initial_sec=1, poll_if_empty_sec=3):
        """Snapshot at play start; brief poll while list empty."""
        self.capture_initial(initial_sec)
        if self.snapshot_has_genuine_tracks():
            return self._initial_subtitle_streams
        loops = max(0, int(poll_if_empty_sec * 10))
        for _ in range(loops):
            if not xbmc.Player().isPlaying():
                break
            try:
                streams = _clean_stream_list(xbmc.Player().getAvailableSubtitleStreams())
            except Exception:
                streams = []
            if streams:
                self._initial_subtitle_streams = list(streams)
                log.warning(
                    'embedded_streams | snapshot after poll={0}'.format(
                        self._initial_subtitle_streams))
                if self.snapshot_has_genuine_tracks():
                    break
            xbmc.sleep(100)
        if not self.snapshot_has_genuine_tracks():
            # Definitive for this playback: every later refresh_snapshot_if_needed
            # / genuine_embedded_index call would otherwise re-poll for its own
            # max_wait_sec looking for something this already spent up to
            # initial_sec+poll_if_empty_sec confirming isn't there -- letting
            # a cached-and-ready external subtitle sit unplaced the whole time.
            self._confirmed_no_tracks = True
            log.warning('embedded_streams | confirmed no embedded tracks this playback')
        return self._initial_subtitle_streams

    def refresh_snapshot_if_needed(self, max_wait_sec=1):
        """Re-read player streams into snapshot when list was empty or incomplete."""
        if self._external_sub_loaded:
            return self._initial_subtitle_streams
        if self._confirmed_no_tracks:
            return self._initial_subtitle_streams
        loops = max(1, int(max_wait_sec * 10))
        for i in range(loops):
            if not xbmc.Player().isPlaying():
                break
            subs = _clean_stream_list(self.player_subtitle_streams())
            if subs:
                if subs != self._initial_subtitle_streams:
                    self._initial_subtitle_streams = list(subs)
                    log.warning(
                        'embedded_streams | snapshot refreshed at {0:.1f}s={1}'.format(
                            i / 10.0, self._initial_subtitle_streams))
                if self.snapshot_has_genuine_tracks():
                    return self._initial_subtitle_streams
            xbmc.sleep(100)
        return self._initial_subtitle_streams

    def snapshot_has_genuine_tracks(self):
        subs = _clean_stream_list(self._initial_subtitle_streams)
        if not subs:
            return False
        for lang in ('heb', 'eng'):
            idx = _find_stream_index(subs, lang)
            if idx is not None and is_confident_embedded_track(subs, idx, lang):
                return True
        return len(subs) >= 2

    def _is_genuine_at_index(self, subs, lang, index_sub):
        if _looks_like_external_file_tracks(subs):
            return False
        if not is_confident_embedded_track(subs, index_sub, lang):
            return False
        if self._external_sub_loaded:
            pre = _clean_stream_list(self._snapshot_before_external)
            idx_pre = _find_stream_index(pre, lang)
            if idx_pre is None:
                return False
            return is_confident_embedded_track(pre, idx_pre, lang)
        if self.snapshot_has_lang(lang):
            return True
        if not self._initial_subtitle_streams:
            return is_confident_embedded_track(subs, index_sub, lang)
        return is_confident_embedded_track(subs, index_sub, lang)

    def genuine_embedded_index(self, lang, max_wait_sec=5):
        """
        Return stream index for an embedded MKV track, or None.
        Ignores lang entries that appeared only after setSubtitles(external path).
        """
        if self._external_sub_loaded and not self.snapshot_has_lang(lang):
            return None
        if self._confirmed_no_tracks:
            return None

        loops = max(1, int(max_wait_sec * 10)) if max_wait_sec > 0 else 1
        for i in range(loops):
            if self._external_sub_loaded and not self.snapshot_has_lang(lang):
                return None
            subs = self.player_subtitle_streams()
            if _looks_like_external_file_tracks(subs):
                index_sub = None
            else:
                index_sub = _find_stream_index(subs, lang)
            if index_sub is not None and self._is_genuine_at_index(subs, lang, index_sub):
                if not self.snapshot_has_lang(lang) and not self._external_sub_loaded:
                    if is_confident_embedded_track(subs, index_sub, lang):
                        self._update_snapshot(subs)
                log.warning(
                    'embedded_streams | genuine {0} index={1} at {2:.1f}s | player streams={3} | snapshot={4}'.format(
                        lang, index_sub, i / 10.0, subs, self._initial_subtitle_streams))
                return index_sub
            if max_wait_sec <= 0:
                break
            if not xbmc.Player().isPlaying():
                return None
            xbmc.sleep(100)

        subs = self.player_subtitle_streams()
        log.warning(
            'embedded_streams | no genuine {0} after {1}s | player streams={2} | snapshot={3} | external={4}'.format(
                lang, max_wait_sec, subs, self._initial_subtitle_streams, self._external_sub_loaded))
        return None

    def has_genuine_embedded_hebrew(self, max_wait_sec=5):
        return self.genuine_embedded_index('heb', max_wait_sec=max_wait_sec) is not None

    def set_external_subtitles(self, path):
        """Load external subtitle file and mark so new stream langs are not treated as embedded."""
        xbmc.Player().setSubtitles(path)
        self.mark_external_loaded()

    def has_external_subtitle_active(self):
        """Whether an externally-loaded subtitle is present in the player's
        CURRENT stream list right now -- not whether setSubtitles() was
        called and returned without error at some earlier point.

        A setSubtitles() call made before the real video has actually
        started playing (e.g. mando's prefetch finishing early) can succeed
        against a player session that gets torn down once the real one
        starts, silently losing the subtitle. VideoPlayer.HasSubtitles is no
        substitute for this check -- it's true for ANY video with its own
        embedded tracks, whether or not our external one survived.
        """
        subs = _clean_stream_list(self.player_subtitle_streams())
        return any(_stream_is_external_label(s) for s in subs)


# Module-level singleton -- there is exactly one "current playback" embedded-
# stream state at a time in this addon's process, matching how every caller
# already uses this module (as a bare `embedded_streams.foo()` namespace).
_tracker = EmbeddedStreamTracker()


def reset():
    return _tracker.reset()


def get_initial_snapshot():
    return _tracker.get_initial_snapshot()


def external_sub_loaded():
    return _tracker.external_sub_loaded()


def mark_external_loaded():
    return _tracker.mark_external_loaded()


def player_subtitle_streams():
    return _tracker.player_subtitle_streams()


def snapshot_has_lang(lang):
    return _tracker.snapshot_has_lang(lang)


def capture_initial(max_wait_sec=5):
    return _tracker.capture_initial(max_wait_sec)


def capture_at_play_start(initial_sec=1, poll_if_empty_sec=3):
    return _tracker.capture_at_play_start(initial_sec, poll_if_empty_sec)


def refresh_snapshot_if_needed(max_wait_sec=1):
    return _tracker.refresh_snapshot_if_needed(max_wait_sec)


def snapshot_has_genuine_tracks():
    return _tracker.snapshot_has_genuine_tracks()


def genuine_embedded_index(lang, max_wait_sec=5):
    return _tracker.genuine_embedded_index(lang, max_wait_sec)


def has_genuine_embedded_hebrew(max_wait_sec=5):
    return _tracker.has_genuine_embedded_hebrew(max_wait_sec)


def set_external_subtitles(path):
    return _tracker.set_external_subtitles(path)


def has_external_subtitle_active():
    return _tracker.has_external_subtitle_active()


def activate_embedded_sub(language_code='heb', max_wait_sec=3, clear_external=True):
    """Tell Kodi player to show an embedded MKV subtitle track (not a file download).

    Moved from engine.py: everything this does is already about embedded
    stream state, which this module owns.
    """
    player = xbmc.Player()
    if not player.isPlaying():
        return None
    if clear_external:
        try:
            player.setSubtitles('')
        except Exception:
            pass
        xbmc.sleep(200)
    index_sub = genuine_embedded_index(language_code, max_wait_sec=max_wait_sec)
    if index_sub is not None:
        log.warning(
            'activate_embedded_sub | {0} index={1} | player streams={2}'.format(
                language_code, index_sub, player_subtitle_streams()))
        player.setSubtitleStream(index_sub)
        xbmc.sleep(150)
        try:
            player.showSubtitles(True)
        except Exception:
            pass
        return index_sub
    log.warning(
        'activate_embedded_sub | genuine {0} not found after {1}s'.format(
            language_code, max_wait_sec))
    return None
