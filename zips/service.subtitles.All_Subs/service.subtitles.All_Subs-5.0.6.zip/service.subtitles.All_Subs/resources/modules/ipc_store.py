# -*- coding: utf-8 -*-
"""File-based IPC for DarkSubs — keeps transient data out of settings.xml."""
import os
import re
import threading
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    KODI_AVAILABLE = True
except ImportError:
    KODI_AVAILABLE = False
    xbmc = xbmcaddon = xbmcvfs = None

_lock = threading.Lock()
_addon_id = 'service.subtitles.All_Subs'

EPHEMERAL_EXACT = frozenset((
    'main_search_return',
    'main_search_subs',
    'fast_subs',
    'quick_subs',
    'fast_search_return',
    'gemini_translate_progress',
    'gemini_translate_done',
    'gemini_translate_total',
    'gemini_usage_count',
    'gemini_usage_date_utc',
))

_MSR_PREFIX = 'msr_'
_SAFE_NAME = re.compile(r'[^A-Za-z0-9._-]+')


def _addon():
    if not KODI_AVAILABLE:
        return None
    return xbmcaddon.Addon(_addon_id)


def profile_dir():
    if not KODI_AVAILABLE:
        return ''
    return xbmcvfs.translatePath(_addon().getAddonInfo('profile'))


def ipc_dir():
    path = os.path.join(profile_dir(), 'ipc')
    if not path:
        return ''
    try:
        xbmcvfs.mkdirs(path)
    except Exception:
        try:
            os.makedirs(path, exist_ok=True)
        except Exception:
            pass
    return path


def _safe_filename(name):
    name = str(name or '').strip()
    if not name:
        return 'empty'
    return _SAFE_NAME.sub('_', name)


def _file_path(name):
    return os.path.join(ipc_dir(), _safe_filename(name) + '.ipc')


def write(name, value):
    """Write transient IPC payload; overwrites any previous value."""
    if not KODI_AVAILABLE:
        return
    text = '' if value is None else str(value)
    with _lock:
        base = ipc_dir()
        if not base:
            return
        path = _file_path(name)
        tmp = path + '.tmp'
        try:
            with open(tmp, 'w', encoding='utf-8') as handle:
                handle.write(text)
            try:
                if os.path.exists(path):
                    os.remove(path)
            except OSError:
                pass
            os.rename(tmp, path)
        except Exception:
            try:
                with open(path, 'w', encoding='utf-8') as handle:
                    handle.write(text)
            except Exception:
                pass
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass


def read(name, default=''):
    if not KODI_AVAILABLE:
        return default
    path = _file_path(name)
    try:
        if not os.path.isfile(path):
            return default
        with open(path, 'r', encoding='utf-8') as handle:
            return handle.read()
    except Exception:
        return default


def clear(name):
    delete(name)


def delete(name):
    if not KODI_AVAILABLE:
        return
    path = _file_path(name)
    with _lock:
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError:
            pass


def take(name, default=''):
    """Atomically read and remove an IPC payload."""
    if not KODI_AVAILABLE:
        return default
    path = _file_path(name)
    with _lock:
        try:
            if not os.path.isfile(path):
                return default
            with open(path, 'r', encoding='utf-8') as handle:
                value = handle.read()
            os.remove(path)
            return value
        except Exception:
            return default


def return_key(req_id):
    return (_MSR_PREFIX + str(req_id)) if req_id else 'main_search_return'


def cleanup_ipc_files(max_age_seconds=86400):
    """Remove stale per-search return files."""
    base = ipc_dir()
    if not base or not os.path.isdir(base):
        return 0
    removed = 0
    now = __import__('time').time()
    with _lock:
        for entry in os.listdir(base):
            if not entry.endswith('.ipc'):
                continue
            stem = entry[:-4]
            if not stem.startswith(_MSR_PREFIX):
                continue
            path = os.path.join(base, entry)
            try:
                if (now - os.path.getmtime(path)) > max_age_seconds:
                    os.remove(path)
                    removed += 1
            except OSError:
                pass
    return removed


def _is_ephemeral_setting(setting_id):
    if not setting_id:
        return False
    if setting_id in EPHEMERAL_EXACT:
        return True
    return setting_id.startswith(_MSR_PREFIX)


def cleanup_ephemeral_settings():
    """Strip transient keys from userdata settings.xml (one-time / startup)."""
    if not KODI_AVAILABLE:
        return 0
    settings_path = os.path.join(profile_dir(), 'settings.xml')
    if not os.path.isfile(settings_path):
        return 0
    try:
        tree = ET.parse(settings_path)
        root = tree.getroot()
    except Exception:
        return 0

    removed = 0
    for node in list(root.findall('setting')):
        setting_id = node.get('id') or ''
        if _is_ephemeral_setting(setting_id):
            root.remove(node)
            removed += 1

    if not removed:
        return 0

    try:
        tree.write(settings_path, encoding='utf-8', xml_declaration=True)
    except Exception:
        return 0
    return removed


def migrate_legacy_settings_to_ipc():
    """Move any leftover ephemeral values from settings.xml into IPC files."""
    if not KODI_AVAILABLE:
        return
    addon = _addon()
    for key in EPHEMERAL_EXACT:
        try:
            value = addon.getSetting(key)
        except Exception:
            value = ''
        if value:
            write(key, value)
            try:
                addon.setSetting(key, '')
            except Exception:
                pass

    settings_path = os.path.join(profile_dir(), 'settings.xml')
    if not os.path.isfile(settings_path):
        return
    try:
        tree = ET.parse(settings_path)
        root = tree.getroot()
    except Exception:
        return

    changed = False
    for node in list(root.findall('setting')):
        setting_id = node.get('id') or ''
        if not setting_id.startswith(_MSR_PREFIX):
            continue
        text = node.text or ''
        if text:
            write(setting_id, text)
        root.remove(node)
        changed = True

    if changed:
        try:
            tree.write(settings_path, encoding='utf-8', xml_declaration=True)
        except Exception:
            pass
