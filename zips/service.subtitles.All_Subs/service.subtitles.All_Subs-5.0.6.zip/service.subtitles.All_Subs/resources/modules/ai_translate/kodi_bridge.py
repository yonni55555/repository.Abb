# DarkSubs-facing helpers for embedded Gemini translation (from MoranSubs).
import os

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    import xbmcgui
    KODI_AVAILABLE = True
except ImportError:
    KODI_AVAILABLE = False
    xbmc = xbmcaddon = xbmcvfs = xbmcgui = None

_ADDON_ID = 'service.subtitles.All_Subs'
_addon = None
_ai_notify_icon = None


def addon():
    """Always bind to DarkSubs — never xbmcaddon.Addon() without id (reuse invoker)."""
    global _addon
    if not KODI_AVAILABLE:
        return None
    if _addon is None:
        _addon = xbmcaddon.Addon(_ADDON_ID)
    return _addon


def get_setting(key, default=''):
    if not KODI_AVAILABLE:
        return default
    try:
        v = addon().getSetting(key)
        return v if v is not None else default
    except Exception:
        return default


def get_bool(key, default=False):
    v = (get_setting(key, 'true' if default else 'false') or '').strip().lower()
    return v in ('1', 'true', 'yes', 'on')


def get_int(key, default=0):
    try:
        return int(get_setting(key, str(default)))
    except (TypeError, ValueError):
        return default


def get_float(key, default=0.0):
    try:
        return float(get_setting(key, str(default)))
    except (TypeError, ValueError):
        return default


def set_setting(key, value):
    if KODI_AVAILABLE:
        try:
            addon().setSetting(key, str(value))
        except Exception:
            pass


def new_request_id():
    import time
    return str(int(time.time() * 1000000))


def return_setting_key(req_id):
    from resources.modules import ipc_store
    return ipc_store.return_key(req_id)


def clear_return(req_id=''):
    from resources.modules import ipc_store
    ipc_store.clear(return_setting_key(req_id))


def set_return(req_id, value):
    from resources.modules import ipc_store
    ipc_store.write(return_setting_key(req_id), value)


def get_return(req_id=''):
    from resources.modules import ipc_store
    return ipc_store.read(return_setting_key(req_id), '')


_TRANSLATE_PROGRESS_KEY = 'gemini_translate_progress'


def set_translate_progress(percent):
    from resources.modules import ipc_store
    ipc_store.write(_TRANSLATE_PROGRESS_KEY, max(0, min(100, int(percent))))


def set_translate_chunks(done, total):
    from resources.modules import ipc_store
    ipc_store.write('gemini_translate_done', str(max(0, int(done))))
    ipc_store.write('gemini_translate_total', str(max(0, int(total))))


def get_translate_progress(default=0):
    from resources.modules import ipc_store
    try:
        return int(ipc_store.read(_TRANSLATE_PROGRESS_KEY, str(default)) or default)
    except (TypeError, ValueError):
        return default


def profile_dir():
    if not KODI_AVAILABLE:
        return ''
    return xbmcvfs.translatePath(addon().getAddonInfo('profile'))


def log(msg, level='INFO'):
    try:
        from resources.modules import log as ds_log
        if level == 'ERROR':
            ds_log.error(str(msg))
        elif level == 'WARNING':
            ds_log.warning(str(msg))
        else:
            ds_log.warning(str(msg))
    except Exception:
        pass


def ai_notify_icon():
    """Custom Ai+עברית toast icon (resources/media/ai_notify.png)."""
    global _ai_notify_icon
    if _ai_notify_icon is not None:
        return _ai_notify_icon
    _ai_notify_icon = ''
    if not KODI_AVAILABLE:
        return _ai_notify_icon
    try:
        rel = 'resources/media/ai_notify.png'
        base = addon().getAddonInfo('path')
        path = os.path.join(base, rel.replace('/', os.sep))
        if os.path.isfile(path):
            _ai_notify_icon = xbmcvfs.translatePath(path)
        else:
            _ai_notify_icon = addon().getAddonInfo('icon')
    except Exception:
        pass
    return _ai_notify_icon


def notify(msg, time_ms=6000):
    if not KODI_AVAILABLE:
        return
    try:
        title = addon().getAddonInfo('name') or 'DarkSubs'
        text = str(msg).replace('\n', ' ').strip()[:180]
        if text:
            stripped = text.lstrip('‏‪‫‬‭‮').rstrip('‬')
            text = '‫' + stripped + '‬'
        xbmcgui.Dialog().notification(
            title, text, ai_notify_icon(), int(time_ms), False)
    except Exception:
        try:
            xbmc.executebuiltin(
                'Notification(DarkSubs,{0},{1})'.format(
                    str(msg).replace(',', ' ').replace('\n', ' ')[:180],
                    int(time_ms),
                )
            )
        except Exception:
            pass


def current_video_info():
    info = {
        'imdb_id': '', 'tmdb_id': '', 'title': '', 'year': '',
        'season': '', 'episode': '', 'language': '', 'filepath': '',
        'tvshow': '', 'is_episode': False, 'tagline': '', 'label': '',
    }
    if not KODI_AVAILABLE:
        return info

    def gi(name):
        try:
            return xbmc.getInfoLabel(name) or ''
        except Exception:
            return ''

    info['imdb_id'] = gi('VideoPlayer.UniqueId(imdb)') or gi('VideoPlayer.IMDBNumber')
    info['tmdb_id'] = gi('VideoPlayer.UniqueId(tmdb)')
    try:
        from resources.modules.ai_translate.pool import normalize_id_pair
        info['imdb_id'], info['tmdb_id'] = normalize_id_pair(
            info['imdb_id'], info['tmdb_id'])
    except Exception:
        pass
    info['title'] = gi('VideoPlayer.Title') or gi('VideoPlayer.OriginalTitle')
    info['year'] = gi('VideoPlayer.Year')
    info['season'] = gi('VideoPlayer.Season')
    info['episode'] = gi('VideoPlayer.Episode')
    info['tvshow'] = gi('VideoPlayer.TVshowtitle')
    info['filepath'] = gi('Player.Filenameandpath')
    info['tagline'] = gi('VideoPlayer.Tagline') or gi('ListItem.Tagline')
    info['label'] = gi('VideoPlayer.Label') or gi('ListItem.Label')
    info['picked_release'] = gi('Window(10000).Property(subs.player_filename)')
    info['is_episode'] = bool(info['tvshow'] and info['episode'])
    return info
