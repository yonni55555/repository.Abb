    # Community Hebrew subtitle pool (shared cloud API).
# Best-effort: any failure falls back to local Gemini translation.
import hashlib
import hmac
import json
import os
import threading

from . import kodi_bridge

try:
    from . import tmdb_helper
except ImportError:
    tmdb_helper = None

try:
    import urllib.request as _urlreq
    import urllib.parse as _urlparse
except ImportError:
    _urlreq = None
    _urlparse = None

POOL_URL = 'https://povil-subs-pool.moran200333.workers.dev'
POOL_API_KEY = 'povil_x8FayxrUOAS9Qew1sFWzO6UgAnEAgJAG'
# Same secret baked into official MoranSubs builds (>= 0.2.291).
POOL_SECRET = 'povsig_MvX3wCZcE-puRIyNdOBbI5XhAfg9MUaxm0s-LA25_GTBnbYl'
_POOL_MIN_VER = '0.2.291'
_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/120.0 Safari/537.36')
_GET_TIMEOUT = 8
_POST_TIMEOUT = 25


def _anon_id():
    v = (kodi_bridge.get_setting('_telemetry_id', '') or '').strip()
    if not v:
        import uuid
        v = uuid.uuid4().hex
        kodi_bridge.set_setting('_telemetry_id', v)
    return v


def _addon_version():
    try:
        v = (kodi_bridge.addon().getAddonInfo('version') or '').strip()
        if v:
            return v
    except Exception:
        pass
    return _POOL_MIN_VER


def sign_headers(method, path):
    anon = _anon_id()
    try:
        msg = (method.upper() + '\n' + path + '\n' + anon).encode('utf-8')
        sig = hmac.new(POOL_SECRET.encode('utf-8'), msg,
                       hashlib.sha256).hexdigest()
    except Exception:
        sig = ''
    return {'x-pov-sig': sig, 'x-pov-anon': anon, 'x-pov-v': _addon_version()}


def _post_headers(path):
    h = {'content-type': 'application/json', 'user-agent': _UA}
    h.update(sign_headers('POST', path))
    return h


def normalize_id_pair(imdb_raw, tmdb_raw):
    """RDmovies and others sometimes put tt… in the TMDB field — that breaks lookup."""
    import re
    imdb = (imdb_raw or '').strip()
    tmdb = (tmdb_raw or '').strip()
    if imdb and not imdb.startswith('tt') and re.fullmatch(r'\d+', imdb):
        imdb = 'tt' + imdb
    if tmdb.startswith('tt'):
        if not imdb:
            imdb = tmdb
        tmdb = ''
    elif tmdb and not re.fullmatch(r'\d+', tmdb):
        tmdb = ''
    return imdb, tmdb


def normalize_info(info):
    if not info:
        return info
    imdb, tmdb = normalize_id_pair(
        info.get('imdb_id') or info.get('imdb') or '',
        info.get('tmdb_id') or info.get('tmdb') or '',
    )
    info['imdb_id'] = imdb
    info['imdb'] = imdb
    info['tmdb_id'] = tmdb
    info['tmdb'] = tmdb
    return info


def use_enabled():
    return kodi_bridge.get_bool('pool_use', True)


def share_enabled():
    return kodi_bridge.get_bool('pool_share', False)


def _is_token_like(s):
    import re as _re
    s = (s or '').strip()
    low = s.lower()
    if not s:
        return True
    if 'token=' in low or '://' in low or '?' in low or '&' in low:
        return True
    if _re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-'
                     r'[0-9a-f]{4}-[0-9a-f]{12}', low):
        return True
    if (len(s) >= 24 and '.' not in s and ' ' not in s
            and _re.fullmatch(r'[0-9a-f-]+', low)):
        return True
    return False


def _release_from(info):
    for key in ('release', 'filename', 'picked_release', 'tagline', 'label'):
        rel = (info.get(key) or '').strip()
        if rel and not _is_token_like(rel):
            return rel
    fp = info.get('filepath') or ''
    base = os.path.basename(fp)
    if '.' in base:
        base = base.rsplit('.', 1)[0]
    return '' if _is_token_like(base) else base


def _params(info):
    imdb, tmdb = normalize_id_pair(
        info.get('imdb_id') or info.get('imdb') or '',
        info.get('tmdb_id') or info.get('tmdb') or '',
    )
    if imdb and not tmdb and tmdb_helper is not None:
        try:
            resolved = tmdb_helper.resolve_imdb_to_tmdb(
                imdb, bool(info.get('is_episode')))
            if resolved:
                tmdb = resolved
        except Exception:
            pass
    return {
        'tmdb': tmdb,
        'imdb': imdb,
        'type': 'episode' if info.get('is_episode') else 'movie',
        'season': str(info.get('season') or '0'),
        'episode': str(info.get('episode') or '0'),
        'lang': 'he',
    }


def _has_id(p):
    return bool(p.get('tmdb') or p.get('imdb'))


def _get(path, params):
    q = _urlparse.urlencode({k: v for k, v in params.items() if v})
    hdrs = {'user-agent': _UA}
    hdrs.update(sign_headers('GET', path))
    req = _urlreq.Request(POOL_URL + path + '?' + q, headers=hdrs)
    with _urlreq.urlopen(req, timeout=_GET_TIMEOUT) as r:
        return r.read()


def lookup(info):
    if _urlreq is None:
        return []
    p = _params(info)
    if not _has_id(p):
        kodi_bridge.log(
            '[Pool] lookup skipped — no imdb/tmdb (play the video first, '
            'or search while a title with IMDB is playing)', 'WARNING')
        return []
    try:
        data = json.loads(_get('/lookup', p).decode('utf-8'))
        if not data.get('ok'):
            kodi_bridge.log('[Pool] lookup returned not-ok', 'WARNING')
            return []
        variants = data.get('variants') or []
        n_kt = len(data.get('ktuvit') or [])
        n_emb = len(data.get('embedded') or [])
        if variants:
            kodi_bridge.log(
                '[Pool] lookup found {0} shared Hebrew subs '
                '(imdb={1} tmdb={2} type={3} s{4}e{5})'.format(
                    len(variants),
                    p.get('imdb') or '-', p.get('tmdb') or '-',
                    p.get('type'), p.get('season'), p.get('episode')))
        else:
            kodi_bridge.log(
                '[Pool] lookup OK — 0 shared AI subs in community pool for '
                'this title (imdb={0} s{1}e{2}; ktuvit_hints={3} '
                'embedded_hints={4})'.format(
                    p.get('imdb') or '-', p.get('season'), p.get('episode'),
                    n_kt, n_emb))
        return variants
    except Exception as e:
        kodi_bridge.log('[Pool] lookup failed: {0}'.format(e), 'WARNING')
        return []


def fetch(info, source_hash=None):
    if _urlreq is None:
        return None
    p = _params(info)
    if not _has_id(p):
        return None
    if source_hash:
        p['hash'] = source_hash
    try:
        return _get('/sub', p).decode('utf-8')
    except Exception as e:
        kodi_bridge.log('pool fetch failed: {0}'.format(e), 'DEBUG')
        return None


def _lookup_params_from_body(body):
    imdb, tmdb = normalize_id_pair(
        body.get('imdb_id') or '', body.get('tmdb_id') or '')
    return {
        'tmdb': tmdb,
        'imdb': imdb,
        'type': body.get('type') or '',
        'season': str(body.get('season') or '0'),
        'episode': str(body.get('episode') or '0'),
        'lang': body.get('lang') or 'he',
    }


def _pool_has_hash(body, source_hash):
    if not source_hash:
        return False
    try:
        data = json.loads(
            _get('/lookup', _lookup_params_from_body(body)).decode('utf-8'))
        variants = (data.get('variants') or []) if data.get('ok') else []
        return any(v.get('hash') == source_hash for v in variants)
    except Exception:
        return False


def _build_body(info, source_hash, source_lang, srt_text,
                kind='ai', release_override=None):
    p = _params(info)
    if not _has_id(p):
        return None
    show = (info.get('tvshow') or '').strip()
    title = (show if (p['type'] == 'episode' and show)
             else (info.get('title') or '').strip())
    if release_override:
        rel = '' if _is_token_like(release_override) else release_override
    else:
        rel = _release_from(info)
    return {
        'tmdb_id': p['tmdb'], 'imdb_id': p['imdb'], 'type': p['type'],
        'season': p['season'], 'episode': p['episode'], 'lang': 'he',
        'release': rel,
        'source_hash': source_hash or '',
        'source_lang': source_lang or 'en',
        'kind': kind or 'ai',
        'title': title,
        'year': str(info.get('year') or ''),
        'srt': srt_text,
    }


def _post(body, marker_path=None):
    try:
        if _pool_has_hash(body, (body.get('source_hash') or '').strip()):
            if marker_path:
                mark_contributed(marker_path)
            return
    except Exception:
        pass
    try:
        req = _urlreq.Request(
            POOL_URL + '/contribute',
            data=json.dumps(body).encode('utf-8'),
            headers=_post_headers('/contribute'),
            method='POST')
        _urlreq.urlopen(req, timeout=_POST_TIMEOUT).read()
    except Exception as e:
        kodi_bridge.log('pool contribute failed: {0}'.format(e), 'DEBUG')
        return
    if marker_path:
        mark_contributed(marker_path)


def contribute(info, source_hash, source_lang, srt_text, marker_path=None,
               kind='ai', release_override=None):
    if _urlreq is None or not srt_text:
        return
    body = _build_body(info, source_hash, source_lang, srt_text,
                       kind=kind, release_override=release_override)
    if body is None:
        return
    try:
        threading.Thread(target=_post, args=(body, marker_path),
                         daemon=True).start()
    except Exception:
        pass


def _marker_path(translated_path):
    return (translated_path + '.shared') if translated_path else None


def was_contributed(translated_path):
    m = _marker_path(translated_path)
    return bool(m and os.path.isfile(m))


def mark_contributed(translated_path):
    m = _marker_path(translated_path)
    if not m:
        return
    try:
        with open(m, 'w', encoding='utf-8') as f:
            f.write('1')
    except OSError:
        pass


def contribute_once(info, source_hash, source_lang, srt_text, marker_path=None,
                    kind='ai', release_override=None):
    if marker_path and was_contributed(marker_path):
        return
    contribute(info, source_hash, source_lang, srt_text,
               marker_path=marker_path, kind=kind,
               release_override=release_override)


def content_hash(text):
    return hashlib.sha1(
        (text or '').encode('utf-8', errors='replace')).hexdigest()[:16]
