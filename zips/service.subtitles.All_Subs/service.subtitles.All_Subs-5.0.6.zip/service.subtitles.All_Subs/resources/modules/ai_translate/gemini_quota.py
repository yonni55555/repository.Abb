# Local daily counter for gemini-3.1-flash-lite free-tier usage.
# Stored in IPC files — NOT addon settings — so per-chunk API
# accounting does not rewrite settings.xml and reset translate_p.
import datetime

from . import kodi_bridge

try:
    from resources.modules import ipc_store
except Exception:
    ipc_store = None

MODEL_TRACKED = 'gemini-3.1-flash-lite'
DAILY_LIMIT = 500
IPC_COUNT = 'gemini_usage_count'
IPC_DATE = 'gemini_usage_date_utc'
# Legacy keys in userdata settings.xml (migrated once).
LEGACY_COUNT = 'gemini_usage_count'
LEGACY_DATE = 'gemini_usage_date_utc'


def _today_utc():
    return datetime.datetime.utcnow().strftime('%Y-%m-%d')


def is_tracked(model):
    return (model or '').lower().strip() == MODEL_TRACKED


def _read_count():
    if ipc_store is None:
        return 0
    try:
        return max(0, int(ipc_store.read(IPC_COUNT, '0') or 0))
    except (TypeError, ValueError):
        return 0


def _read_date():
    if ipc_store is None:
        return ''
    return (ipc_store.read(IPC_DATE, '') or '').strip()


def _write_count(count):
    if ipc_store is not None:
        ipc_store.write(IPC_COUNT, str(max(0, int(count))))


def _write_date(day):
    if ipc_store is not None:
        ipc_store.write(IPC_DATE, day or '')


def _migrate_legacy_once():
    """Move quota counters out of settings.xml into IPC."""
    if ipc_store is None:
        return
    if kodi_bridge.get_setting('_gemini_quota_ipc_v1', '') == '1':
        return
    try:
        legacy_count = kodi_bridge.get_int(LEGACY_COUNT, 0)
        legacy_date = (kodi_bridge.get_setting(LEGACY_DATE, '') or '').strip()
        if legacy_count or legacy_date:
            if not _read_date() and legacy_date:
                _write_date(legacy_date)
            if not _read_count() and legacy_count:
                _write_count(legacy_count)
            kodi_bridge.set_setting(LEGACY_COUNT, '')
            kodi_bridge.set_setting(LEGACY_DATE, '')
        kodi_bridge.set_setting('_gemini_quota_ipc_v1', '1')
    except Exception:
        pass


def note_request(model):
    try:
        if not is_tracked(model):
            return
        _migrate_legacy_once()
        today = _today_utc()
        last = _read_date()
        count = 1 if last != today else _read_count() + 1
        _write_count(count)
        _write_date(today)
    except Exception:
        pass


def get_today_usage():
    _migrate_legacy_once()
    today = _today_utc()
    count = _read_count() if _read_date() == today else 0
    limit = DAILY_LIMIT
    return {
        'count': count,
        'limit': limit,
        'percent': int(round(100.0 * count / limit)) if limit else 0,
        'remaining': max(0, limit - count),
        'date': today,
        'model': MODEL_TRACKED,
    }


def format_status_short():
    u = get_today_usage()
    return '{0}/{1} ביום'.format(u['count'], u['limit'])
