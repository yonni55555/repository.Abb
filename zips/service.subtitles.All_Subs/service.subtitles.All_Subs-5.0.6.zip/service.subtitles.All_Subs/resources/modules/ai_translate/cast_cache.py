# TMDB cast metadata cache (per imdb_id) for gender-aware Gemini prompts.
import hashlib
import json
import os

from . import kodi_bridge

_CACHE_SUBDIR = 'gemini_metadata'


def _metadata_dir():
    base = kodi_bridge.profile_dir()
    if not base:
        return ''
    path = os.path.join(base, _CACHE_SUBDIR)
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        pass
    return path


def metadata_path(imdb_id):
    imdb_id = (imdb_id or '').strip()
    if not imdb_id:
        return ''
    safe = hashlib.sha1(imdb_id.encode('utf-8')).hexdigest()[:16]
    root = _metadata_dir()
    if not root:
        return ''
    return os.path.join(root, '{0}_{1}.json'.format(imdb_id, safe))


def load_json(path):
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError, TypeError):
        return None


def save_json(path, data):
    if not path:
        return False
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=0)
        return True
    except (OSError, TypeError, ValueError):
        return False
