# Arabic-as-gender-reference for Gemini translation (opt-in).
# Ported from kodipovilai — uses DarkSubs OpenSubtitles for Arabic fetch.
import os
import re

from . import kodi_bridge
from . import srt


def _log(msg, level='WARNING'):
    kodi_bridge.log('[arabic_gender] {0}'.format(msg), level)


_TIME_RE = re.compile(
    r'(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*'
    r'(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})')
_NONDIALOG = re.compile(r'\[[^\]]*\]|\([^)]*\)|\{[^}]*\}|<[^>]+>')
_MUSIC = ('♪', '♫', '#')


def _to_ms(h, m, s, ms):
    ms = (ms + '000')[:3]
    return (int(h) * 3600 + int(m) * 60 + int(s)) * 1000 + int(ms)


def _parse_cues(text):
    text = (text or '').replace('\r\n', '\n').replace('\r', '\n')
    cues = []
    for block in re.split(r'\n\s*\n', text):
        lines = [ln for ln in block.split('\n') if ln.strip() != '']
        if not lines:
            continue
        ti = None
        m = None
        for i, ln in enumerate(lines[:3]):
            m = _TIME_RE.search(ln)
            if m:
                ti = i
                break
        if m is None:
            continue
        start = _to_ms(*m.group(1, 2, 3, 4))
        end = _to_ms(*m.group(5, 6, 7, 8))
        if end < start:
            end = start
        body = ' '.join(lines[ti + 1:]).strip()
        body = _NONDIALOG.sub(' ', body)
        body = re.sub(r'\s{2,}', ' ', body).strip()
        cues.append({'start': start, 'end': end, 'text': body})
    cues.sort(key=lambda c: c['start'])
    return cues


def _is_dialogue(text):
    t = text or ''
    if any(mk in t for mk in _MUSIC):
        return False
    t = _NONDIALOG.sub(' ', t)
    letters = re.sub(r'[^A-Za-z֐-׿؀-ۿ]', '', t)
    return len(letters) >= 2


_FPS = [24000 / 1001, 24.0, 25.0, 30000 / 1001, 30.0]
_SCALES = sorted({1.0} | {round(p / q, 6) for p in _FPS for q in _FPS
                          if 0.9 <= p / q <= 1.11})
_TOL = 500
_TIGHT = 250
_MAXOFF = 600000
_SAMPLE = 500


def _best_offset(en_on, ar_on, a):
    step = max(1, len(en_on) // _SAMPLE)
    import bisect
    hist = {}
    for e in en_on[::step]:
        pe = a * e
        lo = bisect.bisect_left(ar_on, pe - _MAXOFF)
        hi = bisect.bisect_right(ar_on, pe + _MAXOFF)
        for j in range(lo, hi):
            b = int(round((ar_on[j] - pe) / _TOL))
            hist[b] = hist.get(b, 0) + 1
    if not hist:
        return 0.0, 0
    peak = max(hist, key=lambda k: hist[k] + hist.get(k - 1, 0)
               + hist.get(k + 1, 0))
    votes = hist.get(peak - 1, 0) + hist.get(peak, 0) + hist.get(peak + 1, 0)
    return float(peak * _TOL), votes


def _estimate_map(en, ar):
    en_on = [c['start'] for c in en]
    ar_on = [c['start'] for c in ar]
    if not en_on or not ar_on:
        return 1.0, 0.0, 0.0
    sampled = len(en_on[::max(1, len(en_on) // _SAMPLE)])
    best = (1.0, 0.0, -1)
    for a in _SCALES:
        b, v = _best_offset(en_on, ar_on, a)
        if v > best[2]:
            best = (a, b, v)
    a, b, v = best
    return a, b, (v / sampled if sampled else 0.0)


def _overlap_rate(en, ar, a, b):
    import bisect
    ar_starts = [c['start'] for c in ar]
    ar_ends = [c['end'] for c in ar]
    ok = 0
    for c in en:
        es, ee = a * c['start'] + b, a * c['end'] + b
        lo = bisect.bisect_left(ar_ends, es)
        k = lo
        hit = False
        while k < len(ar) and ar_starts[k] < ee:
            if min(ee, ar_ends[k]) - max(es, ar_starts[k]) > 0:
                hit = True
                break
            k += 1
        if hit:
            ok += 1
    return ok / len(en) if en else 0.0


def _arabic_for_blocks(src_blocks, ar_cues, a, b):
    import bisect
    ar_centers = [(c['start'] + c['end']) / 2.0 for c in ar_cues]
    ar_starts = [c['start'] for c in ar_cues]
    ar_ends = [c['end'] for c in ar_cues]
    out = {}
    for blk in src_blocks:
        lines = [ln for ln in blk.split('\n') if ln.strip() != '']
        if len(lines) < 2 or not lines[0].strip().isdigit():
            continue
        num = int(lines[0].strip())
        m = _TIME_RE.search(blk)
        if not m:
            continue
        s = _to_ms(*m.group(1, 2, 3, 4))
        e = _to_ms(*m.group(5, 6, 7, 8))
        body = ' '.join(lines[2:]).strip()
        if not _is_dialogue(body):
            continue
        es, ee = a * s + b, a * e + b
        lo = bisect.bisect_left(ar_ends, es)
        cand = []
        k = lo
        while k < len(ar_cues) and ar_starts[k] < ee:
            ov = min(ee, ar_ends[k]) - max(es, ar_starts[k])
            if ov > 0:
                cand.append((ov, k))
            k += 1
        if cand:
            out[num] = ar_cues[max(cand)[1]]['text']
            continue
        pred = a * ((s + e) / 2.0) + b
        j = bisect.bisect_left(ar_centers, pred)
        bd, bk = 1e9, None
        for kk in (j - 1, j, j + 1):
            if 0 <= kk < len(ar_cues) and abs(ar_centers[kk] - pred) < bd:
                bd, bk = abs(ar_centers[kk] - pred), kk
        if bk is not None and bd <= _TIGHT:
            out[num] = ar_cues[bk]['text']
    return out


def align_one(src_text, src_blocks, ar_text):
    en = [c for c in _parse_cues(src_text) if _is_dialogue(c['text'])]
    ar = [c for c in _parse_cues(ar_text) if _is_dialogue(c['text'])]
    if len(en) < 8 or len(ar) < 8:
        return None, 'too few dialogue cues (en=%d ar=%d)' % (len(en), len(ar))
    a, b, vote = _estimate_map(en, ar)
    ov = _overlap_rate(en, ar, a, b)
    diag = 'scale=%.4f offset=%+dms vote=%.0f%% overlap=%.0f%%' % (
        a, int(b), vote * 100, ov * 100)
    if not (0.90 <= a <= 1.11) or vote < 0.65 or ov < 0.80:
        return None, 'gate FAILED (' + diag + ')'
    return _arabic_for_blocks(src_blocks, ar, a, b), 'gate OK (' + diag + ')'


def _info_to_video_data(info):
    return {
        'imdb': info.get('imdb_id') or info.get('imdb') or '',
        'year': info.get('year') or '',
        'title': info.get('title') or '',
        'OriginalTitle': info.get('title') or info.get('OriginalTitle') or '',
        'season': str(info.get('season') or '0'),
        'episode': str(info.get('episode') or '0'),
        'media_type': 'tv' if info.get('is_episode') else 'movie',
    }


def _arabic_candidates(info, limit=5):
    try:
        from resources.sources import opensubtitles as osrc
    except Exception:
        return []
    vd = _info_to_video_data(info)
    try:
        results = osrc.api_search_arabic_subtitles(vd) or []
    except Exception as e:
        _log('OpenSubtitles Arabic search failed: {0}'.format(e))
        return []
    out = []
    for item in results[:limit]:
        attrs = item.get('attributes') or {}
        files = attrs.get('files') or []
        if not files:
            continue
        fn = (files[0].get('file_name') or attrs.get('release') or '').strip()
        fid = files[0].get('file_id')
        if not fn or fid is None:
            continue
        out.append({
            'filename': fn,
            'id': str(fid),
            'format': 'srt',
            'hearing_imp': 'false',
        })
    if not out:
        _log('no Arabic subtitles found on OpenSubtitles')
    return out


def _download_arabic(download_data):
    try:
        from resources.sources import opensubtitles as osrc
        from resources.modules.general import MySubFolder
        path = osrc.download(download_data, MySubFolder)
        if path and os.path.isfile(path):
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                return f.read()
    except Exception as e:
        _log('Arabic download failed: {0}'.format(e), 'DEBUG')
    return None


def prepare(info, src_text):
    """Return {srt_entry_number: arabic_line} or None."""
    try:
        src_blocks = srt.parse_blocks(src_text)
    except Exception:
        return None
    if not src_blocks:
        return None
    cands = _arabic_candidates(info)
    if not cands:
        return None
    for idx, dl in enumerate(cands, 1):
        ar_text = _download_arabic(dl)
        if not ar_text:
            continue
        try:
            mapping, diag = align_one(src_text, src_blocks, ar_text)
        except Exception as e:
            _log('align candidate {0} crashed: {1}'.format(idx, e))
            continue
        if mapping is not None:
            _log('using Arabic gender reference ({0}, {1} entries)'.format(
                diag, len(mapping)))
            return mapping
        _log('candidate {0} rejected: {1}'.format(idx, diag))
    _log('all Arabic candidates failed alignment — normal translation')
    return None
