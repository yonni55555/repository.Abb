# Gemini-based subtitle translation for DarkSubs machine_translate_subs.
import os
import threading
import time

from . import kodi_bridge
from . import gemini
from . import prompt
from . import srt
from . import language_detect
from . import tmdb_helper

try:
    from . import pool
except Exception:
    pool = None

try:
    import xbmc
except ImportError:
    xbmc = None


class _AbortTranslation(Exception):
    def __init__(self, reason, user_msg):
        self.reason = reason
        self.user_msg = user_msg


def _read_text(path):
    with open(path, 'rb') as f:
        raw = f.read()
    try:
        import chardet
        enc = chardet.detect(raw).get('encoding') or 'utf-8'
    except Exception:
        enc = 'utf-8'
    if enc == 'ISO-8859-7':
        return raw.decode('cp1253', 'ignore')
    if enc == 'MacCyrillic':
        return raw.decode('cp1256', 'ignore')
    return raw.decode(enc, 'ignore')


def _prepare_source(raw_src):
    cleaned = srt.strip_hi_annotations(raw_src)
    if cleaned and srt.count_entries(cleaned) >= max(
            1, int(srt.count_entries(raw_src) * 0.3)):
        return cleaned
    return raw_src


def _pool_quality_ok(src_text, final_text):
    if not srt.looks_hebrew(final_text):
        return False
    if srt.untranslated_line_ratio(final_text) > 0.35:
        return False
    if src_text and final_text.strip() == src_text.strip():
        return False
    return True


def _try_pool_fetch(src_text, info):
    if pool is None:
        return None, ''
    cid = pool.content_hash(src_text)
    if not pool.use_enabled():
        return None, cid
    try:
        return pool.fetch(info, cid), cid
    except Exception as e:
        kodi_bridge.log('pool pre-translate fetch failed: {0}'.format(e), 'WARNING')
        return None, cid


def _share_to_pool(info, source_hash, source_lang, final_text, marker_path):
    if pool is None or not pool.share_enabled():
        return
    if not _pool_quality_ok('', final_text):
        return
    try:
        pool.contribute_once(
            info, source_hash, source_lang, final_text,
            marker_path=marker_path, kind='ai',
            release_override=info.get('picked_release') or info.get('tagline') or None,
        )
    except Exception as e:
        kodi_bridge.log('pool share failed: {0}'.format(e), 'DEBUG')


def _gemini_model_settings():
    api_key = (kodi_bridge.get_setting('gemini_api_key', '') or '').strip()
    model = (kodi_bridge.get_setting('gemini_model', 'gemini-3.1-flash-lite')
             or 'gemini-3.1-flash-lite')
    temperature = kodi_bridge.get_float('gemini_temperature', 1.0)
    top_p = None if model.lower().startswith('gemini-3') else 0.95
    thinking_level = 'medium'
    max_output_tokens = 16384
    chunk_lines = max(50, min(250, kodi_bridge.get_int('gemini_chunk_lines', 150)))
    first_chunk_lines = max(10, min(50, kodi_bridge.get_int('gemini_first_chunk_lines', 15)))
    parallel = max(1, min(8, kodi_bridge.get_int('gemini_parallel_chunks', 3)))
    return {
        'api_key': api_key,
        'model': model,
        'temperature': temperature,
        'top_p': top_p,
        'thinking_level': thinking_level,
        'max_output_tokens': max_output_tokens,
        'chunk_lines': chunk_lines,
        'first_chunk_lines': first_chunk_lines,
        'parallel': parallel,
    }


_MIN_CAST_FOR_CACHE = 20


def _fetch_cast(info):
    from . import cast_cache
    from . import pool as _pool

    info = dict(info or {})
    _pool.normalize_info(info)
    imdb_id = (info.get('imdb_id') or info.get('imdb') or '').strip()
    tmdb_id = (info.get('tmdb_id') or info.get('tmdb') or '').strip()
    season = info.get('season') or ''
    episode = info.get('episode') or ''
    title = info.get('title') or ''
    year = info.get('year') or ''
    cast = None
    meta_path = cast_cache.metadata_path(imdb_id) if imdb_id else ''
    if meta_path:
        cached_meta = cast_cache.load_json(meta_path)
        if cached_meta:
            cached_cast = cached_meta.get('cast') or []
            if len(cached_cast) >= _MIN_CAST_FOR_CACHE:
                cast = cached_cast
                title = cached_meta.get('title') or title
                year = cached_meta.get('year') or year
                kodi_bridge.log(
                    'TMDB cast cache hit ({0} actors)'.format(len(cast)))
            else:
                kodi_bridge.log(
                    'TMDB cast cache stale ({0} actors) — refetching'.format(
                        len(cached_cast)), 'WARNING')
    if cast is None:
        try:
            cast = tmdb_helper.fetch_cast(
                imdb_id=imdb_id,
                tmdb_id=tmdb_id,
                media_type=('tv' if info.get('is_episode') else 'movie'),
                season=season,
                episode=episode,
            ) or []
            t2, y2 = tmdb_helper.title_and_year(
                imdb_id=imdb_id, tmdb_id=tmdb_id,
                media_type=('tv' if info.get('is_episode') else 'movie'))
            title = title or t2
            year = year or y2
            if meta_path and cast:
                cast_cache.save_json(meta_path, {
                    'cast': cast, 'title': title, 'year': year,
                })
                kodi_bridge.log(
                    'TMDB cast cached ({0} actors)'.format(len(cast)))
        except Exception as e:
            kodi_bridge.log('TMDB cast lookup failed: {0}'.format(e), 'WARNING')
            cast = []
    return cast, title, year


def _translated_chunk_is_hebrew(blocks):
    """Check only the translated chunk — not a progressive merge with English tail."""
    if not blocks:
        return False
    chunk_text = srt.postprocess_hebrew_srt(srt.stitch_blocks(blocks))
    if srt.looks_hebrew(chunk_text, min_alpha=25, min_ratio=0.35):
        return True
    hebrew_cues = 0
    for block in blocks:
        line = srt.block_text_only(block)
        if line and any(0x0590 <= ord(c) <= 0x05FF for c in line):
            hebrew_cues += 1
    return hebrew_cues >= max(3, min(5, len(blocks) // 3))


def translate_text(src_text, info=None, source_lang=None, progressive_cb=None,
                   output_path=None, fast_first_wait=False):
    """Return Hebrew SRT text, or None on failure.

    progressive_cb(phase, payload) phases:
      chunk_ready  — completed, total, merged_text, source_id
      done         — success, source_id, final_text (on success)

    fast_first_wait: translate chunk 1 synchronously, return partial Hebrew,
    then finish remaining chunks in a background thread.
    """
    if not src_text or not src_text.strip():
        return None

    src_text = _prepare_source(src_text)
    content_id = pool.content_hash(src_text) if pool else ''

    if language_detect.detect(src_text[:8000]) == 'he':
        kodi_bridge.log('translate_text: source already Hebrew, skipping')
        if progressive_cb:
            try:
                progressive_cb('done', {
                    'success': True, 'source_id': content_id,
                    'final_text': src_text,
                })
            except Exception:
                pass
        return src_text

    info = info or kodi_bridge.current_video_info()
    if not source_lang:
        source_lang = language_detect.detect(src_text[:8000]) or 'en'

    pooled, cid = _try_pool_fetch(src_text, info)
    content_id = cid or content_id
    if pooled:
        kodi_bridge.log('pool: reusing community translation (hash={0})'.format(
            content_id))
        pooled = srt.postprocess_hebrew_srt(pooled)
        if output_path:
            try:
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(pooled)
            except OSError:
                pass
        if progressive_cb:
            try:
                progressive_cb('done', {
                    'success': True, 'source_id': content_id,
                    'final_text': pooled, 'from_pool': True,
                })
            except Exception:
                pass
        return pooled

    cfg = _gemini_model_settings()
    if not cfg['api_key']:
        kodi_bridge.notify('Gemini: חסר API Key בהגדרות DarkSubs')
        if progressive_cb:
            try:
                progressive_cb('done', {'success': False, 'source_id': content_id})
            except Exception:
                pass
        return None

    kodi_bridge.log(
        'Gemini translate start | model={0} | source_lang={1} | chars={2}'.format(
            cfg['model'], source_lang, len(src_text)),
    )
    _notify_ai_start(fast_first=fast_first_wait)
    season = info.get('season') or ''
    episode = info.get('episode') or ''

    def _make_prompt(cast_list, title_val='', year_val=''):
        return prompt.build(
            source_lang=source_lang,
            title=title_val or info.get('title') or '',
            year=year_val or info.get('year') or '',
            cast=cast_list,
            is_episode=info.get('is_episode', False),
            tvshow=info.get('tvshow', ''),
            season=season,
            episode=episode,
        )

    # Always load TMDB cast before chunk 1 (gender-aware prompt from the start).
    cast, title, year = _fetch_cast(info)
    prompt_holder = [_make_prompt(cast, title, year)]

    ar_map = None
    if kodi_bridge.get_bool('gender_ref_arabic', True):
        try:
            from . import arabic_gender
            ar_map = arabic_gender.prepare(info, src_text)
        except Exception as e:
            kodi_bridge.log('arabic-gender prepare failed: {0}'.format(e),
                            'WARNING')

    blocks = srt.parse_blocks(src_text)
    if not blocks:
        if progressive_cb:
            try:
                progressive_cb('done', {'success': False, 'source_id': content_id})
            except Exception:
                pass
        return None

    if fast_first_wait:
        chunks = srt.chunk_blocks_fast_first(
            blocks,
            first_chunk=cfg['first_chunk_lines'],
            per_chunk=cfg['chunk_lines'],
        )
    else:
        chunks = list(srt.chunk_blocks(blocks, per_chunk=cfg['chunk_lines']))
    total = len(chunks)
    kodi_bridge.log(
        'Gemini chunks: {0} total | first={1} rest={2} | parallel={3}'.format(
            total,
            len(chunks[0]) if chunks else 0,
            cfg['chunk_lines'],
            cfg['parallel'],
        ),
    )
    kodi_bridge.set_translate_chunks(0, total)
    kodi_bridge.set_translate_progress(3)

    OVERLOAD_BACKOFF = [5, 15, 30, 60, 120]
    GENERIC_BACKOFF = [2, 5]
    prev_context_lines = 5
    prev_context_by_idx = {}
    for i in range(1, len(chunks)):
        prev_block_texts = []
        for block in chunks[i - 1][-prev_context_lines:]:
            t = srt.block_text_only(block)
            if t:
                prev_block_texts.append(t)
        prev_context_by_idx[i] = prev_block_texts

    def _call_gemini(idx, ch):
        body = '\n\n'.join(ch)
        prev_ctx_block = prompt.build_prev_context_block(
            prev_context_by_idx.get(idx) or [])
        ar_block = ''
        if ar_map:
            ent = []
            for block in ch:
                first = block.lstrip().split('\n', 1)[0].strip()
                if first.isdigit():
                    num = int(first)
                    ar_line = ar_map.get(num)
                    if ar_line:
                        ent.append((num, ar_line))
            if ent:
                try:
                    ar_block = prompt.build_arabic_gender_block(ent)
                except Exception:
                    ar_block = ''
        full_prompt = (prompt_holder[0]
                       .replace('{prev_context_block}', prev_ctx_block + ar_block)
                       .replace('{entry_count}', str(len(ch)))
                       .replace('{chunk}', body))
        overload_attempts = 0
        generic_attempts = 0
        use_minimal = fast_first_wait and idx == 1
        chunk_max_tokens = 4096 if use_minimal else cfg['max_output_tokens']
        chunk_thinking = 'minimal' if use_minimal else cfg['thinking_level']
        while True:
            try:
                return gemini.generate(
                    api_key=cfg['api_key'],
                    model=cfg['model'],
                    prompt=full_prompt,
                    temperature=cfg['temperature'],
                    max_output_tokens=chunk_max_tokens,
                    top_p=cfg['top_p'],
                    thinking_level=chunk_thinking,
                )
            except gemini.QuotaExceeded:
                raise _AbortTranslation('quota', 'Gemini: מכסה יומית אזלה')
            except gemini.InvalidKey as e:
                raise _AbortTranslation('invalid_key',
                                        'Gemini: מפתח API נדחה ({0})'.format(e))
            except gemini.TruncatedResponse:
                raise
            except gemini.OverloadError:
                if overload_attempts < len(OVERLOAD_BACKOFF):
                    wait = OVERLOAD_BACKOFF[overload_attempts]
                    overload_attempts += 1
                    time.sleep(wait)
                    continue
                raise _AbortTranslation('overload', 'Gemini עמוס מדי')
            except gemini.GeminiError as e:
                if generic_attempts < len(GENERIC_BACKOFF):
                    generic_attempts += 1
                    time.sleep(GENERIC_BACKOFF[generic_attempts - 1])
                    continue
                raise _AbortTranslation('error', 'Gemini: {0}'.format(str(e)[:80]))

    def _translate_one(idx, ch):
        kodi_bridge.set_translate_chunks(idx - 1, total)
        kodi_bridge.set_translate_progress(
            max(3, int((idx - 1) * 100 / total)))
        if len(ch) > 1:
            try:
                response = _call_gemini(idx, ch)
            except gemini.TruncatedResponse:
                mid = len(ch) // 2
                left = _translate_one(idx, ch[:mid])
                right = _translate_one(idx, ch[mid:])
                return left + '\n\n' + right

            got = len(srt.parse_blocks(response))
            expected = len(ch)
            if got < max(1, int(expected * 0.85)):
                mid = expected // 2
                left = _translate_one(idx, ch[:mid])
                right = _translate_one(idx, ch[mid:])
                return left + '\n\n' + right
            return response
        try:
            return _call_gemini(idx, ch)
        except gemini.TruncatedResponse as e:
            return e.partial_text or ''

    def _progressive_merge(out_blocks_by_index):
        merged_blocks = []
        for i, ch in enumerate(chunks):
            key = i + 1
            if key in out_blocks_by_index:
                merged_blocks.extend(out_blocks_by_index[key])
            else:
                merged_blocks.extend(ch)
        return srt.postprocess_hebrew_srt(srt.stitch_blocks(merged_blocks))

    def _emit_chunk_ready(out_blocks_by_index, completed):
        if progressive_cb is None:
            return
        try:
            progressive_cb('chunk_ready', {
                'completed': completed,
                'total': total,
                'merged_text': _progressive_merge(out_blocks_by_index),
                'source_id': content_id,
            })
        except Exception as e:
            kodi_bridge.log('progressive_cb chunk_ready: {0}'.format(e), 'WARNING')

    def _finalize(out_blocks_by_index):
        if len(out_blocks_by_index) != total:
            kodi_bridge.log('Gemini translate incomplete: {0}/{1} chunks'.format(
                len(out_blocks_by_index), total), 'ERROR')
            kodi_bridge.notify('AI: תרגום חלקי — נכשל', time_ms=10000)
            if progressive_cb:
                try:
                    progressive_cb('done', {'success': False, 'source_id': content_id})
                except Exception:
                    pass
            return None

        merged = []
        for i in range(total):
            merged.extend(out_blocks_by_index.get(i + 1, []))
        if len(merged) != len(blocks):
            kodi_bridge.log(
                'Gemini entry count mismatch ({0} vs {1}) — aligning to source timing'
                .format(len(merged), len(blocks)), 'WARNING')
        merged = srt.apply_source_timing(blocks, merged)
        final = srt.postprocess_hebrew_srt(srt.stitch_blocks(merged))

        if not srt.looks_hebrew(final):
            kodi_bridge.log('Gemini output not Hebrew — rejecting', 'WARNING')
            kodi_bridge.notify('AI: התרגום לא הוחזר בעברית. נסה שוב.', time_ms=10000)
            if progressive_cb:
                try:
                    progressive_cb('done', {'success': False, 'source_id': content_id})
                except Exception:
                    pass
            return None

        kodi_bridge.set_translate_progress(100)
        kodi_bridge.log('Gemini translate done | entries={0}'.format(
            srt.count_entries(final)))

        if output_path:
            try:
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(final)
            except OSError:
                pass
            _mark_ai_done(output_path)

        _share_to_pool(info, content_id, source_lang, final, output_path)

        if progressive_cb:
            try:
                progressive_cb('done', {
                    'success': True,
                    'source_id': content_id,
                    'final_text': final,
                    'chunk_count': total,
                })
            except Exception as e:
                kodi_bridge.log('progressive_cb done: {0}'.format(e), 'WARNING')
        else:
            _notify_ai_complete(chunk_count=total)

        return final

    def _run_parallel(start_idx, out_blocks_by_index, completed_start):
        abort_msg = None
        completed = completed_start
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            with ThreadPoolExecutor(max_workers=cfg['parallel']) as executor:
                future_to_idx = {
                    executor.submit(_translate_one, i + 1, ch): i + 1
                    for i, ch in enumerate(chunks[start_idx:], start=start_idx)
                }
                for future in as_completed(future_to_idx):
                    idx = future_to_idx[future]
                    try:
                        response = future.result()
                    except _AbortTranslation as e:
                        abort_msg = e.user_msg
                        for f in future_to_idx:
                            f.cancel()
                        break
                    except Exception as e:
                        abort_msg = 'AI: שגיאה: {0}'.format(str(e)[:80])
                        for f in future_to_idx:
                            f.cancel()
                        break
                    out_blocks_by_index[idx] = srt.parse_blocks(response)
                    completed += 1
                    done = len(out_blocks_by_index)
                    kodi_bridge.set_translate_chunks(done, total)
                    kodi_bridge.set_translate_progress(int(done * 100 / total))
                    _emit_chunk_ready(out_blocks_by_index, completed)
        except ImportError:
            kodi_bridge.notify('AI: Python ללא concurrent.futures', time_ms=8000)
            if progressive_cb:
                try:
                    progressive_cb('done', {'success': False, 'source_id': content_id})
                except Exception:
                    pass
            return None

        if abort_msg:
            kodi_bridge.log('Gemini translate aborted: {0}'.format(abort_msg), 'ERROR')
            kodi_bridge.notify(abort_msg, time_ms=12000)
            if progressive_cb:
                try:
                    progressive_cb('done', {'success': False, 'source_id': content_id})
                except Exception:
                    pass
            return None

        return _finalize(out_blocks_by_index)

    if fast_first_wait:
        out_blocks_by_index = {}
        try:
            response = _translate_one(1, chunks[0])
            out_blocks_by_index[1] = srt.parse_blocks(response)
        except _AbortTranslation as e:
            kodi_bridge.log('Gemini first chunk aborted: {0}'.format(e.user_msg), 'ERROR')
            kodi_bridge.notify(e.user_msg, time_ms=12000)
            if progressive_cb:
                try:
                    progressive_cb('done', {'success': False, 'source_id': content_id})
                except Exception:
                    pass
            return None
        except Exception as e:
            kodi_bridge.log('Gemini first chunk failed: {0}'.format(e), 'ERROR')
            kodi_bridge.notify('AI: שגיאה בתרגום מקטע ראשון', time_ms=10000)
            if progressive_cb:
                try:
                    progressive_cb('done', {'success': False, 'source_id': content_id})
                except Exception:
                    pass
            return None

        partial = _progressive_merge(out_blocks_by_index)
        if not _translated_chunk_is_hebrew(out_blocks_by_index.get(1)):
            kodi_bridge.log('Gemini first chunk not Hebrew — rejecting', 'WARNING')
            kodi_bridge.notify('AI: המקטע הראשון לא הוחזר בעברית', time_ms=10000)
            if progressive_cb:
                try:
                    progressive_cb('done', {'success': False, 'source_id': content_id})
                except Exception:
                    pass
            return None

        kodi_bridge.set_translate_chunks(1, total)
        kodi_bridge.set_translate_progress(max(15, int(100 / total)))
        if output_path:
            try:
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(partial)
            except OSError as e:
                kodi_bridge.log(
                    'fast_first partial write failed: {0}'.format(e), 'WARNING')
        _emit_chunk_ready(out_blocks_by_index, 1)

        if total == 1:
            return _finalize(out_blocks_by_index)

        def _bg_rest():
            _run_parallel(1, out_blocks_by_index, 1)

        threading.Thread(target=_bg_rest, daemon=True).start()
        return partial

    return _run_parallel(0, {}, 0)


def _mark_ai_done(output_path):
    if output_path:
        try:
            with open(output_path + '.ai_done', 'w', encoding='utf-8') as f:
                f.write('1')
        except OSError:
            pass


def _apply_subtitles(path):
    if not xbmc or not path or not os.path.isfile(path):
        return
    try:
        xbmc.Player().setSubtitles(path)
    except Exception:
        pass


def _notify_ai_start(fast_first=False):
    if not kodi_bridge.get_bool('enable_autosub_notifications', True):
        return
    if fast_first:
        kodi_bridge.notify('תרגום AI מתחיל — מקטע ראשון בעברית בקרוב', time_ms=7000)
    else:
        kodi_bridge.notify('תרגום AI מתחיל', time_ms=6000)


def _notify_ai_complete(from_pool=False, chunk_count=0):
    if from_pool:
        return
    if not kodi_bridge.get_bool('enable_autosub_notifications', True):
        return
    msg = 'כתובית AI תורגמה במלואה!'
    try:
        from . import gemini_quota
        usage = gemini_quota.format_status_short()
        if chunk_count:
            msg = 'AI: תרגום הסתיים ({0} chunks · {1})'.format(
                chunk_count, usage)
        else:
            msg = 'AI: תרגום הסתיים ({0})'.format(usage)
    except Exception:
        pass
    kodi_bridge.notify(msg, time_ms=8000)


def translate_file(input_path, output_path, fast_first=False, info=None):
    try:
        text = _read_text(input_path)
        info = info or kodi_bridge.current_video_info()

        if fast_first and kodi_bridge.get_bool('fast_first_chunk', True):
            prepared = _prepare_source(text)
            if language_detect.detect(prepared[:8000]) == 'he':
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(prepared)
                return True

            pooled, _ = _try_pool_fetch(prepared, info)
            if pooled:
                pooled = srt.postprocess_hebrew_srt(pooled)
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(pooled)
                kodi_bridge.set_translate_progress(100)
                return True

            out_path = output_path

            def on_phase(phase, payload):
                if phase == 'chunk_ready':
                    merged = payload.get('merged_text')
                    if merged:
                        try:
                            with open(out_path, 'w', encoding='utf-8') as f:
                                f.write(merged)
                            _apply_subtitles(out_path)
                        except OSError:
                            pass
                elif phase == 'done' and payload.get('success'):
                    final = payload.get('final_text')
                    if final and not payload.get('from_pool'):
                        try:
                            with open(out_path, 'w', encoding='utf-8') as f:
                                f.write(final)
                            _apply_subtitles(out_path)
                        except OSError:
                            pass
                        _notify_ai_complete(
                            from_pool=payload.get('from_pool'),
                            chunk_count=payload.get('chunk_count', 0),
                        )
                        if not payload.get('from_pool'):
                            _mark_ai_done(out_path)

            partial = translate_text(
                text, info=info, progressive_cb=on_phase,
                output_path=out_path, fast_first_wait=True,
            )
            return bool(partial)

        result = translate_text(text, info=info, output_path=output_path)
        if not result:
            return False
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(result)
        _mark_ai_done(output_path)
        return True
    except Exception as e:
        kodi_bridge.log('translate_file failed: {0}'.format(e), 'ERROR')
        return False
