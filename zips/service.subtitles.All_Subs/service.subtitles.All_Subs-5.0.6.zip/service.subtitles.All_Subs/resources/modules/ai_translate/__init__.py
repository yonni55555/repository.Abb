# Embedded MoranSubs AI translation (subtitle-only subset).
