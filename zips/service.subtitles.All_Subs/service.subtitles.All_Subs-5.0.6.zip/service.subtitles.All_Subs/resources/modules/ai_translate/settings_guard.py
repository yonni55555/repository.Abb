# User translate_p (Google / Yandex / Gemini) is read as stored — no silent override.
import re

from . import kodi_bridge

_VALID_SETTING_ID = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
_GEMINI_ENGINE = '2'


def ensure_gemini_translate_engine():
    """No-op: honour translate_p from addon settings UI."""
    return False


def effective_translate_p():
    """Runtime engine id from user settings (0=Google, 1=Yandex, 2=Gemini)."""
    value = (kodi_bridge.get_setting('translate_p') or '0').strip()
    if value not in ('0', '1', '2'):
        value = '0'
    return value


def is_gemini_translate_enabled():
    api_key = (kodi_bridge.get_setting('gemini_api_key') or '').strip()
    if not api_key:
        return False
    if kodi_bridge.get_setting('auto_translate', 'true').strip().lower() != 'true':
        return False
    return effective_translate_p() == _GEMINI_ENGINE


def sanitize_user_settings():
    """Drop corrupt <setting> nodes from userdata settings.xml."""
    if not kodi_bridge.KODI_AVAILABLE:
        return 0
    import os
    import xml.etree.ElementTree as ET

    settings_path = os.path.join(kodi_bridge.profile_dir(), 'settings.xml')
    if not settings_path or not os.path.isfile(settings_path):
        return 0
    try:
        tree = ET.parse(settings_path)
        root = tree.getroot()
    except Exception:
        return 0

    removed = 0
    for node in list(root.findall('setting')):
        setting_id = (node.get('id') or '').strip()
        if not setting_id or not _VALID_SETTING_ID.match(setting_id):
            root.remove(node)
            removed += 1

    if not removed:
        return 0
    try:
        tree.write(settings_path, encoding='utf-8', xml_declaration=True)
        kodi_bridge.log(
            'Removed {0} corrupt setting(s) from settings.xml'.format(removed),
            'WARNING')
    except Exception:
        return 0
    return removed
