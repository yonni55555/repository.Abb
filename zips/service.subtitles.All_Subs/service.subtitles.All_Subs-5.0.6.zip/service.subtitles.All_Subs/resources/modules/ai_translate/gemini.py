# Google Generative Language API client. Just the bits we need:
# generateContent for translation, ListModels for the connection
# test. Bring your own API key.

import json
import urllib.parse

try:
    import requests
except ImportError:
    requests = None

API_BASE = 'https://generativelanguage.googleapis.com/v1beta'

REQUEST_TIMEOUT = 90


class GeminiError(Exception):
    """Raised on any non-recoverable API failure."""


class QuotaExceeded(GeminiError):
    """Daily request limit hit (HTTP 429). Caller may want to
    suggest waiting until UTC midnight."""


class OverloadError(GeminiError):
    """Service-side overload (HTTP 503 / 500). Retryable with
    longer backoff -- Google explicitly tells callers to wait at
    least a few seconds before retrying these."""


class InvalidKey(GeminiError):
    """Key is missing / revoked / malformed."""


class TruncatedResponse(GeminiError):
    """Model hit its output-token cap mid-response. The text we
    received is real but cut off (incomplete subtitle entries at
    the end). Caller should re-issue with smaller input."""
    def __init__(self, message, partial_text=''):
        super().__init__(message)
        self.partial_text = partial_text


def test_key(api_key, model='gemini-3.1-flash-lite'):
    """Cheap sanity check: list the user's available models and
    confirm the chosen one is in the set. Returns the model id we
    matched (so the caller can show "Connected: <model>")."""
    if not requests:
        raise GeminiError('python-requests is not installed')
    if not api_key:
        raise InvalidKey('No API key provided')

    url = '{0}/models?key={1}'.format(API_BASE, urllib.parse.quote(api_key, safe=''))
    try:
        r = requests.get(url, timeout=REQUEST_TIMEOUT)
    except requests.RequestException as e:
        raise GeminiError('Network error: {0}'.format(e))

    if r.status_code == 400 or r.status_code == 403:
        # Surface Google's actual error reason -- the API returns JSON
        # like {"error":{"code":400,"message":"API key not valid. ..."}}
        # and the user otherwise sees only "rejected (400)" with no
        # clue WHY (typo'd key vs revoked vs quota vs project not
        # enabled all show the same way). Trim to a sensible length.
        reason = ''
        try:
            err = (r.json() or {}).get('error') or {}
            reason = err.get('message') or err.get('status') or ''
        except Exception:
            pass
        if not reason:
            reason = (r.text or '').strip()[:140]
        raise InvalidKey('Gemini rejected the key ({0}): {1}'.format(
            r.status_code, reason or '(no reason returned)'))
    if r.status_code != 200:
        raise GeminiError('HTTP {0}: {1}'.format(r.status_code, r.text[:200]))

    try:
        data = r.json()
    except ValueError:
        raise GeminiError('Unparseable response from API')

    available = [m.get('name', '').replace('models/', '')
                 for m in data.get('models', [])]
    if model in available:
        return model
    # If the user's chosen model isn't listed, fall back to any
    # flash-lite variant so the dialog still shows a happy result.
    for cand in available:
        if 'flash-lite' in cand:
            return cand
    return available[0] if available else 'unknown'


def generate(api_key, model, prompt, temperature=0.2,
             max_output_tokens=16384, top_p=None,
             thinking_budget=None, thinking_level=None,
             timeout=REQUEST_TIMEOUT):
    """One-shot text generation. Returns the model's text response.

    Raises QuotaExceeded on 429, InvalidKey on 400/403, GeminiError
    on anything else."""
    if not requests:
        raise GeminiError('python-requests is not installed')
    if not api_key:
        raise InvalidKey('No API key provided')
    if not model:
        raise GeminiError('No model selected')

    url = '{0}/models/{1}:generateContent?key={2}'.format(
        API_BASE, urllib.parse.quote(model, safe=''),
        urllib.parse.quote(api_key, safe=''))

    generation_config = {
        'temperature': temperature,
        'maxOutputTokens': max_output_tokens,
    }
    if top_p is not None:
        generation_config['topP'] = top_p
    if thinking_level:
        generation_config['thinkingConfig'] = {
            'thinkingLevel': thinking_level,
        }
    elif thinking_budget:
        generation_config['thinkingConfig'] = {
            'thinkingBudget': thinking_budget,
        }

    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': generation_config,
    }

    try:
        r = requests.post(url,
                          data=json.dumps(payload),
                          headers={'Content-Type': 'application/json'},
                          timeout=timeout)
    except requests.RequestException as e:
        raise GeminiError('Network error: {0}'.format(e))

    if r.status_code == 429:
        raise QuotaExceeded('Daily quota exceeded')
    if r.status_code in (500, 502, 503, 504):
        raise OverloadError(
            'Gemini overloaded (HTTP {0})'.format(r.status_code))
    if r.status_code in (400, 403):
        # Distinguish key-related vs content-related rejection by
        # looking at the body when we can.
        snippet = r.text[:300] if r.text else ''
        if 'API key' in snippet or 'API_KEY' in snippet:
            raise InvalidKey('Key rejected: {0}'.format(snippet))
        raise GeminiError('Request rejected: {0}'.format(snippet))
    if r.status_code != 200:
        raise GeminiError('HTTP {0}: {1}'.format(r.status_code, r.text[:200]))

    try:
        data = r.json()
    except ValueError:
        raise GeminiError('Unparseable response from API')

    cands = data.get('candidates') or []
    if not cands:
        # Often means the prompt triggered a safety filter.
        raise GeminiError('No candidates in response (possibly filtered)')

    parts = (cands[0].get('content') or {}).get('parts') or []
    chunks = [p.get('text', '') for p in parts if isinstance(p, dict)]
    text = ''.join(chunks).strip()
    if not text:
        raise GeminiError('Empty text in response')

    # If the model hit its output cap, the last entry in the
    # returned SRT is almost always cut off and the chunk has a
    # silent gap. Surface this so the caller can bisect and retry
    # with a smaller request, rather than silently saving an
    # incomplete translation. Flash Lite caps at 8192 output
    # tokens, which Hebrew SRT can blow through around the
    # 150-200 entry mark.
    finish_reason = (cands[0].get('finishReason') or '').upper()
    if finish_reason in ('MAX_TOKENS', 'LENGTH'):
        raise TruncatedResponse(
            'Gemini hit output-token cap (finishReason={0})'.format(
                finish_reason),
            partial_text=text,
        )

    # Bump the daily-quota counter. Lazy import + try/except so a
    # bug here can never break translation. We only count successful
    # responses (i.e. after all the error branches above), and the
    # tracker itself decides which models to actually record.
    try:
        from . import gemini_quota
        gemini_quota.note_request(model)
    except Exception:
        pass

    return text
