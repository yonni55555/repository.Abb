# SRT parsing + chunking. Kept minimal -- we only need to split a
# file into translatable chunks of N entries and merge the model's
# response back into one document.
#
# An SRT entry block looks like:
#   1
#   00:01:22,082 --> 00:01:22,584
#   Hey, turtle.
#   <blank line>
#
# The model returns the same block shape with the text translated;
# we re-stitch the blocks back into a single SRT body.

import re

BLOCK_SEPARATOR = re.compile(r'\r?\n\r?\n')

# Hearing-impaired annotations. Two flavours:
#  - whole-line annotations like "[breathing heavily]" or "(music
#    swells)" -- we want to drop the whole text line
#  - inline annotations like "Hello! [chuckles] How are you?" --
#    we want to drop just the bracketed part
# Brackets we recognise: [] {} () and unicode equivalents that
# show up in some sources.
_BRACKET_RE = re.compile(
    r'[\[\(\{][^\[\]\(\){}]*?[\]\)\}]'
)
# Also strip ALL-CAPS speaker prefixes like "MABEL: ..." that are
# common in HI subs but redundant for translation.
_SPEAKER_RE = re.compile(
    r'^[A-Z][A-Z0-9 \'\.\-]{1,30}:\s*'
)
_INDEX_RE = re.compile(r'^\d+$')
_TIMECODE_RE = re.compile(
    r'^\d{1,2}:\d{2}:\d{2}[,\.]\d{1,3}\s*-->\s*'
    r'\d{1,2}:\d{2}:\d{2}[,\.]\d{1,3}'
)


# Hebrew letter range for RTL post-processing.
_HEB_LETTER = r'֐-׿'
# Punctuation that goes at the end of a Hebrew sentence but the AI
# sometimes outputs at the start.
_TRAILING_PUNCT_CHARS = '.,;:!?'

# Match a Hebrew text line that has a misplaced punctuation prefix.
# Supports several common wrappers / decorations we need to ignore:
#   - leading dialogue dash: "- " (single dash + space)
#   - leading HTML tags (italic, bold, color, etc.): "<i>", "<b>"
#   - trailing HTML close tags: "</i>"
# The captured groups let us rebuild the line with the punct moved
# to its correct position while preserving the wrappers around it.
_LEADING_PUNCT_RE = re.compile(
    r'^(?P<dash>-\s+)?'                                 # optional "- " dialogue marker
    r'(?P<open_tags_a>(?:<[a-zA-Z!][^>]*>)*)'           # opening tags BEFORE the punct
    r'(?P<leading>[' + _TRAILING_PUNCT_CHARS + r']+)\s*'  # the misplaced punct
    r'(?P<open_tags_b>(?:<[a-zA-Z!][^>]*>)*)'           # opening tags AFTER the punct
                                                         # (covers ".<i>text</i>")
    r'(?P<rest>[' + _HEB_LETTER + r'][^\n]*?)'          # Hebrew body (non-greedy)
    r'(?P<close_tags>(?:</[a-zA-Z][^>]*>)*)\s*$'        # zero or more closing tags
)
# Detect a pure ellipsis (".." or "..." or more) -- legitimate
# continuation marker, don't move it.
_ELLIPSIS_RE = re.compile(r'^\.{2,}$')


# Invisible BiDi / direction-control / BOM characters that Gemini
# (and other LLMs) sometimes insert at the START of a Hebrew line.
# When they're there, my leading-punct regex misses the punct that
# follows them, so the line never gets corrected. We strip these
# before checking, then drop them entirely from the output (they're
# noise for SRT rendering -- Kodi handles RTL via the text content
# alone).
_INVISIBLE_BIDI = (
    '‎'  # LRM
    '‏'  # RLM
    '‪'  # LRE
    '‫'  # RLE
    '‬'  # PDF
    '‭'  # LRO
    '‮'  # RLO
    '⁦'  # LRI
    '⁧'  # RLI
    '⁨'  # FSI
    '⁩'  # PDI
    '﻿'  # BOM / ZWNBSP
)


def _fix_one_text_line(line):
    """Apply the RTL punctuation correction to a single text line
    (not an index or timecode line). Returns the corrected line."""
    stripped = line.strip()
    # Strip any leading invisible BiDi / BOM characters that would
    # otherwise hide the punct from our regex.
    while stripped and stripped[0] in _INVISIBLE_BIDI:
        stripped = stripped[1:]
    # Also strip from the end -- Gemini occasionally appends them too.
    while stripped and stripped[-1] in _INVISIBLE_BIDI:
        stripped = stripped[:-1]
    if not stripped:
        return line
    m = _LEADING_PUNCT_RE.match(stripped)
    if not m:
        # No leading punct -- but if we stripped invisible chars,
        # the rewritten stripped line is itself cleaner. Return it
        # so the invisible noise doesn't survive.
        if stripped != line.strip():
            return stripped
        return line
    dash       = m.group('dash')        or ''
    # Tags from EITHER side of the punct -- merge so the punct
    # ends up inside the tag wrap regardless of where Gemini put
    # the tag relative to the punct.
    open_tags  = (m.group('open_tags_a') or '') + \
                 (m.group('open_tags_b') or '')
    leading    = m.group('leading')
    rest       = m.group('rest')        or ''
    close_tags = m.group('close_tags')  or ''
    # Leave legitimate ellipsis alone.
    if _ELLIPSIS_RE.match(leading):
        return stripped if stripped != line.strip() else line
    if not rest:
        return stripped if stripped != line.strip() else line
    # If the rest already ends with punctuation, the leading one is
    # redundant -- drop it instead of moving (which would double up).
    if rest[-1] in _TRAILING_PUNCT_CHARS:
        return dash + open_tags + rest + close_tags
    # Otherwise move leading punct to the end, INSIDE any closing
    # tag (so "<i>.לעזאזל</i>" becomes "<i>לעזאזל.</i>", not
    # "<i>לעזאזל</i>.").
    return dash + open_tags + rest + leading + close_tags


def fix_rtl_punctuation(text, mode=None):
    """Normalize RTL punctuation placement in a Hebrew SRT body.

    `mode` controls the direction of the correction. Pulled from
    the addon's `rtl_punct_mode` setting if not explicitly passed:
      'reverse' (default) -- move END-of-sentence punct from line
                             END to line START. Necessary because
                             Kodi's subtitle renderer (across the
                             observed setups -- Windows, Android,
                             FENtastic skin) does NOT BiDi-reorder
                             Hebrew lines, so a logical-START
                             punct visually lands at the end of
                             the Hebrew reader's reading flow.
      'legacy'            -- the inverse: move leading punct to
                             the logical end. Was the default in
                             v0.2.0-v0.2.6 under the (wrong)
                             assumption that Kodi reorders. Kept
                             around in case any setup actually
                             does reorder correctly.
      'off'               -- no processing.

    Idempotent. Skips index + timecode lines. Preserves trailing
    newline so a benign re-run doesn't flag the file as changed."""
    if not text:
        return text
    if mode is None:
        try:
            from . import kodi_bridge
            mode = (kodi_bridge.get_setting('rtl_punct_mode', 'reverse')
                    or 'reverse').lower()
        except Exception:
            mode = 'reverse'
    # 'auto' was the v0.2.7 name for what is now 'legacy'. Map for
    # backwards compatibility with users who manually selected it.
    if mode == 'auto':
        mode = 'legacy'
    if mode == 'off':
        return text
    trailing_nl = '\n' if text.endswith(('\n', '\r')) else ''
    out_lines = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or _INDEX_RE.match(stripped) or \
                _TIMECODE_RE.match(stripped):
            out_lines.append(line)
            continue
        if mode == 'legacy':
            out_lines.append(_fix_one_text_line(line))
        else:
            # 'reverse' (default) or anything unrecognised
            out_lines.append(_reverse_fix_one_text_line(line))
    return '\n'.join(out_lines) + trailing_nl


# Match a Hebrew text line that has punctuation at the END (the
# "normal" Hebrew sentence shape). Used by the reverse-mode fix to
# move that punct to the START of the line.
_TRAILING_PUNCT_RE = re.compile(
    r'^(?P<dash>-\s+)?'
    r'(?P<open_tags>(?:<[a-zA-Z!][^>]*>)*)'
    r'(?P<rest>(?=[^\n]*[' + _HEB_LETTER + r'])[^\n]*?[^'
    + _TRAILING_PUNCT_CHARS + r'\s])'
    r'(?P<trailing>[' + _TRAILING_PUNCT_CHARS + r']+)'
    r'(?P<close_tags>(?:</[a-zA-Z][^>]*>)*)\s*$'
)
_REVERSE_DASHED_LEADING_PUNCT_RE = re.compile(
    r'^(?P<dash>-\s+)'
    r'(?P<open_tags>(?:<[a-zA-Z!][^>]*>)*)'
    r'(?P<leading>[' + _TRAILING_PUNCT_CHARS + r']+)'
    r'(?P<rest>(?=[^\n]*[' + _HEB_LETTER + r'])[^\n]*?[^'
    + _TRAILING_PUNCT_CHARS + r'\s])'
    r'(?P<close_tags>(?:</[a-zA-Z][^>]*>)*)\s*$'
)


def _reverse_dash_suffix(dash):
    return ' -' if dash else ''


def _reverse_fix_one_text_line(line):
    """Move END-of-line punctuation to the START. Used by the
    'reverse' rtl_punct_mode for Kodi setups whose subtitle
    renderer doesn't BiDi-reorder Hebrew lines and shows source
    text in physical L-to-R order."""
    stripped = line.strip()
    while stripped and stripped[0] in _INVISIBLE_BIDI:
        stripped = stripped[1:]
    while stripped and stripped[-1] in _INVISIBLE_BIDI:
        stripped = stripped[:-1]
    if not stripped:
        return line
    dashed_leading = _REVERSE_DASHED_LEADING_PUNCT_RE.match(stripped)
    if dashed_leading:
        open_tags = dashed_leading.group('open_tags') or ''
        leading = dashed_leading.group('leading')
        rest = dashed_leading.group('rest') or ''
        close_tags = dashed_leading.group('close_tags') or ''
        if rest:
            return open_tags + leading + rest + close_tags + ' -'
    m = _TRAILING_PUNCT_RE.match(stripped)
    if not m:
        if stripped != line.strip():
            return stripped
        return line
    dash       = m.group('dash')       or ''
    open_tags  = m.group('open_tags')  or ''
    rest       = m.group('rest')       or ''
    trailing   = m.group('trailing')
    close_tags = m.group('close_tags') or ''
    if not rest:
        return stripped if stripped != line.strip() else line
    # If a leading punct is already present too, don't double up:
    # the trailing one is redundant, drop it. Detection: rest
    # itself starts with punct (after the optional dash/tag prefix).
    if rest[0] in _TRAILING_PUNCT_CHARS:
        return open_tags + rest + close_tags + _reverse_dash_suffix(dash)
    return open_tags + trailing + rest + close_tags + \
        _reverse_dash_suffix(dash)


def parse_blocks(text):
    """Return a list of raw entry blocks (still strings). We don't
    bother with a structured parse since the model handles the
    timecodes verbatim -- if we round-trip strings unchanged for
    those, we minimise damage from accidental edits."""
    if not text:
        return []
    # Some SRTs start with a BOM. Strip it once.
    if text.startswith('﻿'):
        text = text[1:]
    text = text.strip()
    return [b for b in BLOCK_SEPARATOR.split(text) if b.strip()]


def chunk_blocks(blocks, per_chunk=250):
    """Yield groups of `per_chunk` blocks. Last group may be smaller."""
    if per_chunk < 1:
        per_chunk = 1
    for i in range(0, len(blocks), per_chunk):
        yield blocks[i:i + per_chunk]


def chunk_blocks_fast_first(blocks, first_chunk=15, per_chunk=150):
    """Small first chunk for quick Hebrew preview; remainder at per_chunk."""
    if not blocks:
        return []
    first_n = max(10, min(first_chunk, len(blocks)))
    rest_n = max(50, per_chunk)
    chunks = [blocks[:first_n]]
    pos = first_n
    while pos < len(blocks):
        chunks.append(blocks[pos:pos + rest_n])
        pos += rest_n
    return chunks


def block_text_only(block):
    """Return just the dialogue text from a single SRT entry block,
    stripping the entry number and the timecode line. Returns ''
    if the block isn't shaped like SRT.

    Used by the cross-chunk context feature in translate.py: we
    feed the last N source-text lines of the previous chunk to the
    AI as "PREVIOUS DIALOGUE CONTEXT" so the model has the same
    conversational thread it would have had if everything ran in
    one giant chunk -- which catches the cross-chunk gender drift
    that the per-chunk-cast block alone can't prevent.
    """
    if not block:
        return ''
    lines = block.strip().split('\n')
    # First line: entry number. Second line: timecode arrow.
    # Everything from line 3 onward is the dialogue text.
    # We're tolerant: if the entry number is missing (some scrapers
    # emit unnumbered SRT) we accept and start at the timecode.
    start = 0
    if lines and lines[0].strip().isdigit():
        start = 1
    if start < len(lines) and '-->' in lines[start]:
        start += 1
    return '\n'.join(lines[start:]).strip()


def block_header(block):
    """Return (index_line, timecode_line) from one SRT entry."""
    if not block:
        return '', ''
    lines = block.strip().split('\n')
    idx = ''
    tc = ''
    pos = 0
    if lines and _INDEX_RE.match(lines[0].strip()):
        idx = lines[0].strip()
        pos = 1
    if pos < len(lines):
        candidate = lines[pos].strip()
        if _TIMECODE_RE.match(candidate):
            tc = candidate
    return idx, tc


def make_block(index_line, timecode_line, text):
    """Build one SRT entry from header lines + dialogue text."""
    parts = []
    if index_line:
        parts.append(index_line)
    if timecode_line:
        parts.append(timecode_line)
    if text and text.strip():
        parts.append(text.strip())
    return '\n'.join(parts)


def _line_starts_with_punct(line):
    s = (line or '').strip().lstrip('-').strip()
    return bool(s) and s[0] in _TRAILING_PUNCT_CHARS


def fix_stacked_line_order(text):
    """Gemini often stacks two-line Hebrew cues bottom-to-top (RTL habit).

    Kodi always renders SRT line 1 at the top. When the first physical
    line looks like a continuation (leading punct) and the last does not,
    reverse the text lines inside that entry. Matches MoranSubs behaviour
    (no line-order swap in fix_rtl_punctuation — fix the model slip here).
    """
    if not text:
        return text
    out_blocks = []
    for block in parse_blocks(text):
        lines = block.split('\n')
        header = []
        text_lines = []
        for ln in lines:
            s = ln.strip()
            if not s:
                continue
            if _INDEX_RE.match(s) or _TIMECODE_RE.match(s):
                header.append(ln.rstrip('\r'))
            else:
                text_lines.append(ln.rstrip('\r'))
        if len(text_lines) >= 2:
            if (_line_starts_with_punct(text_lines[0])
                    and not _line_starts_with_punct(text_lines[-1])):
                text_lines = list(reversed(text_lines))
        if header or text_lines:
            out_blocks.append('\n'.join(header + text_lines))
    return stitch_blocks(out_blocks) if out_blocks else text


def postprocess_hebrew_srt(text, mode=None):
    """MoranSubs pipeline: fix stacked line order, then RTL punctuation."""
    if not text:
        return text
    text = fix_stacked_line_order(text)
    return fix_rtl_punctuation(text, mode=mode)


def apply_source_timing(source_blocks, translated_blocks):
    """Keep source timecodes; preserve each Gemini block verbatim when timing matches."""
    out = []
    for i, src in enumerate(source_blocks):
        idx, tc = block_header(src)
        if not tc:
            out.append(src)
            continue
        if i >= len(translated_blocks):
            out.append(src)
            continue
        trans = translated_blocks[i]
        t_idx, trans_tc = block_header(trans)
        trans_text = block_text_only(trans)
        if trans_tc == tc and trans_text.strip():
            if idx and t_idx and idx != t_idx:
                out.append(make_block(idx, tc, trans_text))
            else:
                out.append(trans)
            continue
        text = trans_text.strip() or block_text_only(src)
        src_text = block_text_only(src)
        if src_text and text:
            text = _maybe_fix_stacked_line_order(src_text, text)
        out.append(make_block(idx or t_idx or str(i + 1), tc, text))
    return out


def _maybe_fix_stacked_line_order(src_text, trans_text):
    src_lines = [ln.strip() for ln in src_text.split('\n') if ln.strip()]
    trans_lines = [ln.strip() for ln in trans_text.split('\n') if ln.strip()]
    if len(src_lines) < 2 or len(trans_lines) < 2:
        return trans_text
    if len(src_lines) != len(trans_lines):
        return trans_text
    if (_line_starts_with_punct(trans_lines[0])
            and not _line_starts_with_punct(trans_lines[-1])):
        return '\n'.join(reversed(trans_lines))
    return trans_text


def stitch_blocks(blocks):
    """Join blocks back into a single SRT body using CRLF blank lines
    between entries (standard SRT delimiter). Trailing newline so
    Kodi's parser is happy."""
    return '\r\n\r\n'.join(b.strip() for b in blocks) + '\r\n'


def count_entries(text):
    return len(parse_blocks(text))


def looks_hebrew(text, min_alpha=120, min_ratio=0.5):
    """Rough sanity check that `text` is genuinely a Hebrew translation and not
    a failed / mostly-untranslated one. Among the alphabetic characters, Hebrew
    must dominate. If there's too little text to judge, returns True (never
    block on thin evidence). Used as a pool-upload quality gate."""
    heb = lat = 0
    for c in text or '':
        o = ord(c)
        if 0x0590 <= o <= 0x05FF:
            heb += 1
        elif ('a' <= c <= 'z') or ('A' <= c <= 'Z'):
            lat += 1
    alpha = heb + lat
    if alpha < min_alpha:
        return True
    return heb >= alpha * min_ratio


def untranslated_line_ratio(text, min_cues=10, min_len=8):
    """Fraction of substantial cues that look UNTRANSLATED -- i.e. they carry
    Latin letters but contain no Hebrew at all. Used as a pool-upload quality
    gate to catch a PARTIALLY-failed translation (whole chunks left in English)
    that `looks_hebrew` misses because the document is Hebrew overall.

    A cue with ANY Hebrew counts as translated (mixed Hebrew+English lines are
    fine). Only cues with real text (>= min_len letters) are weighed, so blank
    lines, '♪', numbers and short interjections don't skew it. Returns 0.0 when
    there are too few substantial cues to judge (never block on thin evidence)
    -- so a handful of legitimately-English lines (song lyrics, on-screen
    signs, 'FBI') can't trip the gate; only a large proportion does."""
    substantial = 0
    untranslated = 0
    for block in parse_blocks(text or ''):
        line = block_text_only(block)
        if not line:
            continue
        heb = lat = 0
        for c in line:
            o = ord(c)
            if 0x0590 <= o <= 0x05FF:
                heb += 1
            elif ('a' <= c <= 'z') or ('A' <= c <= 'Z'):
                lat += 1
        if (heb + lat) < min_len:
            continue  # too little text to judge this cue
        substantial += 1
        if heb == 0 and lat > 0:
            untranslated += 1
    if substantial < min_cues:
        return 0.0
    return untranslated / float(substantial)


def strip_hi_annotations(text):
    """Remove hearing-impaired noise from an SRT body.

    Drops bracketed sound cues like [breathing], (music playing),
    {chuckles}, and ALL-CAPS speaker prefixes like 'MABEL: '. If an
    entry's text was nothing but annotations, the whole entry is
    dropped (its timecode goes too -- there's literally no speech
    in that span, so an empty subtitle would be a visual gap with
    nothing useful).

    Returns the cleaned SRT body. Block order and numbering are
    preserved for surviving entries (we keep the original index
    numbers so the model sees stable references).
    """
    if not text:
        return text
    out_blocks = []
    for block in parse_blocks(text):
        lines = block.split('\n')
        kept_lines = []
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            if _INDEX_RE.match(stripped):
                kept_lines.append(line)
                continue
            if _TIMECODE_RE.match(stripped):
                kept_lines.append(line)
                continue
            # text line -- strip annotations
            cleaned = _BRACKET_RE.sub('', line)
            cleaned = _SPEAKER_RE.sub('', cleaned)
            # collapse whitespace runs that the strips may have
            # left behind
            cleaned = re.sub(r'\s{2,}', ' ', cleaned).strip()
            if cleaned:
                kept_lines.append(cleaned)
        # only keep the block if there's actual dialogue text left
        # (more than just the index + timecode)
        text_lines = [ln for ln in kept_lines
                      if ln.strip() and not _INDEX_RE.match(ln.strip())
                      and not _TIMECODE_RE.match(ln.strip())]
        if text_lines and len(kept_lines) >= 3:
            out_blocks.append('\n'.join(kept_lines))
    return '\r\n\r\n'.join(out_blocks) + '\r\n' if out_blocks else ''
