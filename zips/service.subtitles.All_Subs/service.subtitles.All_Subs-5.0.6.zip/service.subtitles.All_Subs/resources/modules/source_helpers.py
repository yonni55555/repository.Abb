# -*- coding: utf-8 -*-
"""Shared helpers for resources/sources/*.py subtitle scrapers."""
import shutil

import xbmcvfs

from resources.modules import log

_FILENAME_CHARS_TO_REMOVE = '\\/:*?"<>|\''


def sanitize_filename(name):
    """Strip characters that break writing a subtitle file to disk."""
    return ''.join(c for c in (name or '') if c not in _FILENAME_CHARS_TO_REMOVE)


def reset_tmp_dir(path):
    """Clear and recreate a source module's temp download directory."""
    try:
        shutil.rmtree(path)
    except Exception as e:
        log.warning('reset_tmp_dir failed for {0}: {1}'.format(path, e))
    xbmcvfs.mkdirs(path)
