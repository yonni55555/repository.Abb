# -*- coding: utf-8 -*-

'''
    Genesis Add-on
    Copyright (C) 2015 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.modules import log
import xbmc,re,hashlib,time,os,logging
import ast  # SECURITY FIX: Replace eval() with ast.literal_eval()

try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

try:
    import xbmcaddon
except:
    pass

KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    xbmc_tranlate_path=xbmc.translatePath
else:
    import xbmcvfs
    xbmc_tranlate_path=xbmcvfs.translatePath
def set_PRAGMAS(dbcon):
    """Optimize SQLite pragmas for cache performance."""
    dbcur = dbcon.cursor()
    dbcur.execute('''PRAGMA synchronous = OFF''')
    dbcur.execute('''PRAGMA journal_mode = OFF''')
    return dbcur


import threading

_inflight_lock = threading.Lock()
_inflight_events = {}
_INFLIGHT_WAIT_SECONDS = 90


def get(function, timeout, *args, **table):
    """
    Cache function results in SQLite database with timeout.

    If an identical call (same function+args+table) is already running on
    another thread, wait for it instead of launching a redundant duplicate
    -- e.g. auto-sub's background search and a manual "search subtitles"
    click for the same video used to both run the full multi-source search
    independently, doubling network load and making the manual search sit
    through the whole thing a second time even though the first one was
    already almost done.
    """
    try:
        f_key = repr(function)
        f_key = re.sub('.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', f_key)
        a_key = hashlib.md5()
        for i in args:
            a_key.update(str(i).encode('utf-8'))
        a_key = a_key.hexdigest()
        t_key = table.get('table', 'rel_list')
        key = (f_key, a_key, t_key)
    except Exception:
        key = None

    if key is None:
        return _get_impl(function, timeout, *args, **table)

    with _inflight_lock:
        event = _inflight_events.get(key)
        is_leader = event is None
        if is_leader:
            event = threading.Event()
            _inflight_events[key] = event

    if not is_leader:
        event.wait(_INFLIGHT_WAIT_SECONDS)
        return _get_impl(function, timeout, *args, **table)

    try:
        return _get_impl(function, timeout, *args, **table)
    finally:
        with _inflight_lock:
            _inflight_events.pop(key, None)
        event.set()


def _get_impl(function, timeout, *args, **table):
    """
    Cache function results in SQLite database with timeout.
    SECURITY: Uses ast.literal_eval() instead of eval() to prevent code injection.
    """
    import linecache, sys
    try:
        response = None

        f = repr(function)
        f = re.sub('.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', f)

        a = hashlib.md5()
        for i in args: a.update(str(i).encode('utf-8'))
        a = str(a.hexdigest())
    except Exception as e:
      
      exc_type, exc_obj, tb = sys.exc_info()
      fail = tb.tb_frame
      lineno = tb.tb_lineno
      filename = fail.f_code.co_filename
      linecache.checkcache(filename)
      line = linecache.getline(filename, lineno, fail.f_globals)
      
      log.error('CACHE err:'+str(lineno))
      log.error('inline:'+line)
      log.error(e)
      
     
    
      
      pass
    
  
    try:
        table = table['table']
    except:
        table = 'rel_list'

    try:
        try:
            import xbmc
            addonInfo = xbmcaddon.Addon().getAddonInfo
            dataPath = xbmc_tranlate_path(addonInfo('profile'))
        except:
           
            dataPath = os.path.dirname(os.path.realpath(__file__))
       
        
        mypath=os.path.join(dataPath,'cache_f')
     
        if not os.path.exists(mypath):
          os.mkdir(mypath)
    
           
        dbcon = database.connect(os.path.join(mypath,'sources.db'))
        dbcur = set_PRAGMAS(dbcon)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='%s';"%table)
        match = dbcur.fetchone()

        if match[0]!=0:

            dbcur.execute("SELECT * FROM %s WHERE func = '%s' AND args = '%s'" % (table, f, a))
            match = dbcur.fetchone()
            if match!=None:
                # SECURITY FIX: Use ast.literal_eval() instead of eval()
                try:
                    response = ast.literal_eval(match[2])
                except (ValueError, SyntaxError):
                    # Fallback for complex objects - log and skip
                    log.warning(f'Cache deserialization failed for {f}, clearing entry')
                    response = None

                if response is not None:
                    t1 = int(match[3])
                    t2 = int(time.time())
                    update = (abs(t2 - t1) / 3600) >= int(timeout)
                    if update == False:
                        return response

    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        fail = tb.tb_frame
        lineno = tb.tb_lineno
        filename = fail.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, fail.f_globals)
      
        log.error('CACHE2 err:'+str(lineno))
        log.error('inline:'+line)
        log.error(e)
        
        pass
    
    try:
        r = function(*args)
        if (r == None or r == []) and not response == None:

            return response
        elif (r == None or r == []):

            return r
    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        fail = tb.tb_frame
        lineno = tb.tb_lineno
        filename = fail.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, fail.f_globals)
      
        log.error('CACHE3 err:'+str(lineno))
        log.error('inline:'+line)
        log.error(e)
        return

    try:
        r = repr(r)
        t = int(time.time())
      
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s (""func TEXT, ""args TEXT, ""response TEXT, ""added TEXT, ""UNIQUE(func, args)"");" % table)
        dbcur.execute("DELETE FROM %s WHERE func = '%s' AND args = '%s'" % (table, f, a))
        dbcur.execute("INSERT INTO %s Values (?, ?, ?, ?)" % table, (f, a, r, t))
        dbcon.commit()
    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        fail = tb.tb_frame
        lineno = tb.tb_lineno
        filename = fail.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, fail.f_globals)
      
        log.error('CACHE4 err:'+str(lineno))
        log.error('inline:'+line)
        log.error(e)
        pass

    try:
        # SECURITY FIX: Use ast.literal_eval() instead of eval()
        return ast.literal_eval(r)
    except (ValueError, SyntaxError, Exception) as e:
        exc_type, exc_obj, tb = sys.exc_info()
        fail = tb.tb_frame
        lineno = tb.tb_lineno
        filename = fail.f_code.co_filename
        line = linecache.getline(filename, lineno, fail.f_globals)
      
        log.error(f'CACHE5 err:{lineno}')
        log.error(f'inline:{line}')
        log.error(str(e))
        pass


def clear(table=None):
    """Clear cache tables. Pass list of table names or None for default."""
    try:
        

        if table == None: table = ['rel_list']
        elif not type(table) == list: table = [table]
        try:
            import xbmc
            addonInfo = xbmcaddon.Addon().getAddonInfo
            dataPath = xbmc_tranlate_path(addonInfo('profile'))
        except:
            dataPath = os.path.dirname(os.path.realpath(__file__))
       
        mypath=os.path.join(dataPath,'cache_f')
        if not os.path.exists(mypath):
          os.mkdir(mypath)
        dbcon = database.connect(os.path.join(mypath,'sources.db'))
        dbcur = dbcon.cursor()

        for t in table:
            try:
                dbcur.execute("DROP TABLE IF EXISTS %s" % t)
                dbcur.execute("VACUUM")
                dbcon.commit()
            except:
                pass
    except Exception as e:
        log.error('Error cleaning: '+str(e))
        
        pass

