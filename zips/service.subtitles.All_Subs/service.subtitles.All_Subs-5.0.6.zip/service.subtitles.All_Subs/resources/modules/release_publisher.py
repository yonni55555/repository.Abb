# DarkSubs: publish subs.player_filename on every playback (no external addon).
from urllib.parse import unquote

import xbmc
import xbmcgui

from resources.modules import general
from resources.modules import log

_WIN_ID = 10000
_PROP_NAME = 'subs.player_filename'
_PROP_URL = 'subs.player_file_url'


def _window():
    return xbmcgui.Window(_WIN_ID)


def _playing_url():
    try:
        return unquote(xbmc.Player().getPlayingFile() or '')
    except Exception:
        return ''


def _urls_match(stored, current):
    if not stored or not current:
        return True
    return stored in current or current in stored


def _is_weak_release_name(name):
    if not name:
        return True
    lower = name.strip().lower()
    if lower in (
            'stream', 'play', 'video', 'file', 'index',
            'original.mp4', 'original.mkv', 'video.mp4', 'play.mp4'):
        return True
    return not general._filename_looks_like_release(name)


def publish_picked_release(force=False):
    """Write Window(10000) release name for subtitle match % / dialog header."""
    try:
        win = _window()
        current_url = _playing_url()
        existing = (win.getProperty(_PROP_NAME) or '').strip()
        stored_url = (win.getProperty(_PROP_URL) or '').strip()

        if stored_url and current_url and not _urls_match(stored_url, current_url):
            if general._existing_release_ok_for_subs(existing):
                if current_url:
                    win.setProperty(_PROP_URL, current_url)
                return existing
            win.setProperty(_PROP_NAME, '')
            win.setProperty(_PROP_URL, '')
            existing = ''

        if not force and general._existing_release_ok_for_subs(existing):
            if current_url:
                win.setProperty(_PROP_URL, current_url)
            return existing

        resolved = general.resolve_release_name_from_url(current_url)
        if _is_weak_release_name(resolved):
            return existing or ''
        if not resolved:
            return existing or ''

        win.setProperty(_PROP_NAME, resolved)
        if current_url:
            win.setProperty(_PROP_URL, current_url)
        log.warning('ReleasePublisher: {0}'.format(resolved))
        return resolved
    except Exception as e:
        log.warning('ReleasePublisher failed: {0}'.format(e))
        return ''


class ReleaseFilenamePlayer(xbmc.Player):
    """Runs inside DarkSubs service — fires on every video playback."""

    def onAVStarted(self):  # pylint: disable=invalid-name
        try:
            publish_picked_release()
        except Exception:
            pass

    def onPlayBackStarted(self):  # pylint: disable=invalid-name
        try:
            publish_picked_release()
        except Exception:
            pass
