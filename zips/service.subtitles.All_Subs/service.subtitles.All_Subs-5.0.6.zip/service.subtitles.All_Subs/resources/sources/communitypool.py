# Community pool Hebrew subtitles (instant fetch from shared channel).
import json
import os
import re
import difflib
import xbmcaddon
import xbmcvfs

global global_var, site_id, sub_color
global_var = []

from resources.modules import log

Addon = xbmcaddon.Addon()
MyScriptID = Addon.getAddonInfo('id')
que = __import__('urllib.parse').parse.quote_plus

site_id = '[Pool]'
sub_color = 'mediumorchid'


def _video_data_to_info(video_data):
    imdb = (video_data.get('imdb') or video_data.get('IMDBNumber')
            or video_data.get('imdb_UniqueID') or '')
    info = {
        'tmdb_id': video_data.get('tmdb') or '',
        'imdb_id': imdb,
        'title': video_data.get('title') or video_data.get('OriginalTitle') or '',
        'year': video_data.get('year') or '',
        'season': video_data.get('season') or '0',
        'episode': video_data.get('episode') or '0',
        'tvshow': video_data.get('TVShowTitle') or '',
        'is_episode': video_data.get('media_type') == 'tv',
        'filepath': video_data.get('file_original_path') or '',
        'tagline': video_data.get('Tagline') or '',
        'label': video_data.get('title') or '',
        'picked_release': (video_data.get('Tagline')
                           or video_data.get('file_original_path') or ''),
    }
    from resources.modules.ai_translate import pool
    return pool.normalize_info(info)


def _match_pct(video_ref, release):
    def toks(s):
        s = re.sub(r'\.[a-z0-9]{2,4}$', '', s or '', flags=re.I)
        for ch in '_ +/-':
            s = s.replace(ch, '.')
        return [x.lower() for x in s.split('.') if x]

    a, b = toks(video_ref), toks(release)
    if not a or not b:
        return 0
    try:
        return int(round(difflib.SequenceMatcher(None, a, b).ratio() * 100))
    except Exception:
        return 0


def _looks_like_token(s):
    s = (s or '').strip()
    low = s.lower()
    if not s:
        return True
    if 'token=' in low or '://' in low:
        return True
    if re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-'
                    r'[0-9a-f]{4}-[0-9a-f]{12}', low):
        return True
    return False


def get_subs(video_data):
    global global_var
    global_var = []
    try:
        from resources.modules.ai_translate import pool
        log.warning('[Pool] Searching community pool')
        info = _video_data_to_info(video_data)
        variants = pool.lookup(info)
        if not variants:
            log.warning('[Pool] No community-pool downloads for this title '
                        '(see lookup line above — pool search itself ran OK)')
            return global_var
        video_ref = (info.get('picked_release') or info.get('tagline')
                     or os.path.basename(info.get('filepath') or '')
                     or info.get('title') or '')
        for v in variants:
            kind = (v.get('kind') or 'ai')
            release = (v.get('release') or '').strip()
            if release and _looks_like_token(release):
                release = ''
            pct = _match_pct(video_ref, release) if release else 0
            if kind == 'ktuvit':
                if release and pct > 0:
                    label2 = site_id + ' כתובית · מאגר · {0}%  —  {1}'.format(
                        pct, release)
                elif release:
                    label2 = site_id + ' כתובית · מאגר  —  {0}'.format(release)
                else:
                    label2 = site_id + ' כתובית · מאגר'
            else:
                if release and pct > 0:
                    label2 = site_id + ' תרגום AI · מאגר · {0}%  —  {1}'.format(
                        pct, release)
                elif release:
                    label2 = site_id + ' תרגום AI · מאגר  —  {0}'.format(release)
                else:
                    label2 = site_id + ' תרגום AI · מאגר'
            sub_name = release or ('pool_{0}'.format(v.get('hash', '')[:8]))
            download_data = {
                'hash': v.get('hash'),
                'pool_info': info,
                'kind': kind,
            }
            url = ('plugin://%s/?action=download&filename=%s&download_data=%s'
                   '&source=communitypool&language=Hebrew' % (
                       MyScriptID, que(sub_name), que(json.dumps(download_data))))
            global_var.append({
                'url': url,
                'label': 'Hebrew',
                'label2': label2,
                'iconImage': '0',
                'thumbnailImage': 'he',
                'hearing_imp': 'false',
                'site_id': site_id,
                'sub_color': sub_color,
                'filename': sub_name,
                'sync': 'false',
            })
        log.warning('[Pool] Found {0} community subtitles'.format(len(global_var)))
        return global_var
    except Exception as e:
        log.warning('[Pool] get_subs failed: {0}'.format(e))
        return global_var


def download(download_data, MySubFolder):
    from resources.modules.ai_translate import pool
    info = download_data.get('pool_info') or {}
    h = download_data.get('hash')
    text = pool.fetch(info, h)
    if not text:
        log.warning('[Pool] fetch returned empty for hash={0}'.format(h))
        return None
    xbmcvfs.mkdirs(MySubFolder)
    out = os.path.join(MySubFolder, 'community_pool.srt')
    with open(out, 'w', encoding='utf-8') as f:
        f.write(text)
    log.warning('[Pool] Downloaded community subtitle ({0} bytes)'.format(len(text)))
    return out
