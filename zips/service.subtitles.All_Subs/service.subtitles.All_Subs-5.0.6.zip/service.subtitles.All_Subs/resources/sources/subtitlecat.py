# SubtitleCat — Hebrew subtitles with ready Download only (no on-site Translate).
import json
import os
import re
import shutil

import requests
import urllib.parse
import xbmc
import xbmcaddon
import xbmcvfs

from resources.modules import log
from resources.modules.extract_sub import extract
from resources.modules.general import DEFAULT_REQUEST_TIMEOUT
from resources.modules.source_helpers import sanitize_filename, reset_tmp_dir

global global_var, site_id, sub_color
global_var = []

que = urllib.parse.quote_plus
Addon = xbmcaddon.Addon()
MyScriptID = Addon.getAddonInfo('id')
MyAddonName = Addon.getAddonInfo('name')
MyAddonVersion = Addon.getAddonInfo('version')
USER_AGENT = '%s v%s' % (MyAddonName, MyAddonVersion)
xbmc_tranlate_path = xbmcvfs.translatePath
__profile__ = xbmc_tranlate_path(Addon.getAddonInfo('profile'))
MyTmp = xbmc_tranlate_path(os.path.join(__profile__, 'temp_subtitlecat'))

BASE_URL = 'https://www.subtitlecat.com'
SEARCH_URL = BASE_URL + '/index.php'
site_id = '[SubtitleCat]'
sub_color = 'mediumorchid'

_HEADERS = {
    'User-Agent': USER_AGENT,
    'Accept': 'text/html,application/xhtml+xml',
}


def _normalize_rel_url(url):
    url = (url or '').strip()
    if not url:
        return ''
    if url.startswith('http'):
        return url
    if url.startswith('/'):
        return BASE_URL + url
    return BASE_URL + '/' + url


def _hebrew_download_url(html):
    """Return a direct Hebrew SRT URL only when Download exists."""
    patterns = [
        r'id="download_iw"[^>]*href="([^"]+)"',
        r'href="(subs/[^"]+-iw\.srt)"',
        r'href="(/subs/[^"]+-iw\.srt)"',
        r'href="(subs/[^"]+-he\.srt)"',
        r'href="(/subs/[^"]+-he\.srt)"',
    ]
    for pat in patterns:
        m = re.search(pat, html, re.I)
        if not m:
            continue
        href = m.group(1)
        # Skip translate-only rows (no real download link).
        if 'translate_from_server_folder' in href:
            continue
        return _normalize_rel_url(href)
    return None


def _search_page_links(html):
    return list(dict.fromkeys(re.findall(r'href="(subs/\d+/[^"]+\.html)"', html)))


def _build_queries(video_data):
    """Search keys: picked release filename first, then IMDb."""
    queries = []

    for key in ('picked_release', 'file_original_path', 'Tagline'):
        val = video_data.get(key) or ''
        val = val.split('\n')[0].strip()
        base = os.path.basename(val)
        base = os.path.splitext(base)[0]
        if base and len(base) > 3:
            queries.append(base)

    imdb = (video_data.get('imdb') or '').strip()
    if imdb.startswith('tt'):
        queries.append(imdb)

    seen = set()
    out = []
    for q in queries:
        q = q.strip()
        key = q.lower()
        if q and key not in seen:
            seen.add(key)
            out.append(q)
    return out


def _normalize_name(text):
    text = urllib.parse.unquote(text or '')
    return re.sub(r'[^a-z0-9]+', '.', text.lower()).strip('.')


def _release_basename(video_data):
    for key in ('picked_release', 'file_original_path', 'Tagline'):
        val = (video_data.get(key) or '').strip()
        if not val:
            continue
        val = val.split('\n')[0].strip()
        return _normalize_name(os.path.splitext(os.path.basename(val))[0])
    return ''


def _title_core_tokens(name_norm):
    """Tokens before year/quality — where the movie title usually lives."""
    stop = {
        '1080p', '720p', '2160p', '4k', 'webrip', 'web', 'bluray', 'remux',
        'h264', 'h265', 'x264', 'x265', 'hevc', 'aac', 'ddp', 'atmos', 'nf',
        'amzn', 'webdl', 'dvdrip', 'cam', 'ts', 'proper', 'repack',
    }
    core = []
    for tok in name_norm.split('.'):
        if re.match(r'^\d{4}$', tok) or tok in stop:
            break
        core.append(tok)
    return core


def _tv_episode_tag(video_data):
    """SxxExx from season/episode metadata, or parsed from picked release."""
    season = video_data.get('season') or ''
    episode = video_data.get('episode') or ''
    if season and episode:
        try:
            return 's{0:02d}e{1:02d}'.format(int(season), int(episode))
        except (TypeError, ValueError):
            pass
    release_base = _release_basename(video_data)
    m = re.search(r's(\d{1,2})e(\d{1,3})', release_base, re.I)
    if m:
        return 's{0:02d}e{1:02d}'.format(int(m.group(1)), int(m.group(2)))
    return ''


def _matches_picked_release(video_data, name):
    """True when subtitle filename matches picked_release / file path."""
    release_base = _release_basename(video_data)
    if not release_base or not name:
        return False
    if release_base == name or release_base in name or name in release_base:
        return True
    rel_core = set(_title_core_tokens(release_base))
    name_core = set(_title_core_tokens(name))
    if rel_core and name_core and len(rel_core & name_core) >= 2:
        return True
    rel_tokens = set(release_base.split('.'))
    name_tokens = set(name.split('.'))
    overlap = len(rel_tokens & name_tokens)
    return overlap >= max(3, min(len(rel_core), 4))


def _is_relevant_subtitle(video_data, filename_or_link):
    """
    Accept only results that match picked_release (same rule as autosub sort).
    Reject SubtitleCat false positives (APEX release-group suffix, wrong episode).
    """
    name = _normalize_name(
        os.path.basename((filename_or_link or '').replace('.html', '')))
    if not name:
        return False

    release_base = _release_basename(video_data)
    if not release_base:
        log.warning(
            'DEBUG | [SubtitleCat] | reject — no picked_release: {0}'.format(
                filename_or_link))
        return False

    imdb = (video_data.get('imdb') or '').lower()
    if imdb.startswith('tt') and imdb in name:
        return True

    ep_tag = _tv_episode_tag(video_data)
    if ep_tag and ep_tag in release_base and ep_tag not in name:
        log.warning(
            'DEBUG | [SubtitleCat] | reject wrong episode (need {0}): {1}'.format(
                ep_tag, filename_or_link))
        return False

    if not _matches_picked_release(video_data, name):
        log.warning(
            'DEBUG | [SubtitleCat] | reject no release match ({0}): {1}'.format(
                release_base, filename_or_link))
        return False

    tokens = name.split('.')
    release_core = _title_core_tokens(release_base)
    if release_core:
        primary = release_core[0]
        if len(primary) <= 6 and primary in tokens:
            idx = tokens.index(primary)
            if idx == len(tokens) - 1 and idx >= 2:
                log.warning(
                    'DEBUG | [SubtitleCat] | reject release-group suffix: {0}'.format(
                        filename_or_link))
                return False
            if idx >= 3:
                log.warning(
                    'DEBUG | [SubtitleCat] | reject non-title token: {0}'.format(
                        filename_or_link))
                return False

    return True


def _score_link(link, video_data):
    if not _is_relevant_subtitle(video_data, link):
        return -999
    name = _normalize_name(link.split('/')[-1].replace('.html', ''))
    score = 0
    for key in ('picked_release', 'file_original_path', 'Tagline'):
        val = video_data.get(key) or ''
        val = val.split('\n')[0].strip()
        base = _normalize_name(os.path.splitext(os.path.basename(val))[0])
        if not base:
            continue
        if base == name:
            score += 120
        elif base in name or name in base:
            score += 80
        overlap = len(set(base.split('.')) & set(name.split('.')))
        score += min(40, overlap * 4)
    imdb = (video_data.get('imdb') or '').lower()
    if imdb and imdb in name:
        score += 30
    ep_tag = _tv_episode_tag(video_data)
    if ep_tag and ep_tag in name:
        score += 25
    return score


_MIN_SUBTITLE_SCORE = 12


def _candidate_from_link(link, html):
    dl = _hebrew_download_url(html)
    if not dl:
        return None
    filename = urllib.parse.unquote(link.split('/')[-1].replace('.html', ''))
    filename = sanitize_filename(filename)
    return {
        'filename': filename,
        'url': dl,
        'page': BASE_URL + '/' + link,
        'score': 0,
    }


def _fetch_page(link):
    page_url = BASE_URL + '/' + link
    try:
        p = requests.get(
            page_url,
            headers=_HEADERS,
            timeout=min(8, max(3, DEFAULT_REQUEST_TIMEOUT)),
        )
        p.raise_for_status()
        return link, p.text
    except Exception as e:
        log.warning('DEBUG | [SubtitleCat] | page failed {0}: {1}'.format(page_url, e))
        return link, None


def _collect_candidates(video_data, max_results=25, max_links_to_scan=100):
    """Collect Hebrew Download-ready subs. Pages are fetched in parallel because
    SubtitleCat often lists translate-only releases first — a sequential scan
    cannot reach ready Hebrew downloads before DarkSubs' search timeout."""
    seen_pages = set()
    ranked_links = []

    for query in _build_queries(video_data):
        try:
            r = requests.get(
                SEARCH_URL,
                params={'search': query},
                headers=_HEADERS,
                timeout=min(8, max(3, DEFAULT_REQUEST_TIMEOUT)),
            )
            r.raise_for_status()
        except Exception as e:
            log.warning('DEBUG | [SubtitleCat] | search failed for {0}: {1}'.format(query, e))
            continue

        for link in _search_page_links(r.text):
            if link in seen_pages:
                continue
            seen_pages.add(link)
            sc = _score_link(link, video_data)
            if sc < 0:
                continue
            ranked_links.append((-sc, link))

    if not ranked_links:
        return []

    ranked_links.sort()
    links = [link for _, link in ranked_links[:max_links_to_scan]]
    candidates = []

    try:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        workers = min(12, max(4, len(links)))
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(_fetch_page, link): link for link in links}
            for future in as_completed(futures):
                link = futures[future]
                try:
                    _, html = future.result()
                except Exception:
                    continue
                if not html:
                    continue
                item = _candidate_from_link(link, html)
                if not item:
                    continue
                if not _is_relevant_subtitle(video_data, item['filename']):
                    continue
                item['score'] = _score_link(link, video_data)
                if item['score'] < _MIN_SUBTITLE_SCORE:
                    continue
                candidates.append(item)
                if len(candidates) >= max_results:
                    for pending in futures:
                        pending.cancel()
                    break
    except ImportError:
        for link in links:
            _, html = _fetch_page(link)
            if not html:
                continue
            item = _candidate_from_link(link, html)
            if item and _is_relevant_subtitle(video_data, item['filename']):
                item['score'] = _score_link(link, video_data)
                if item['score'] >= _MIN_SUBTITLE_SCORE:
                    candidates.append(item)
            if len(candidates) >= max_results:
                break

    candidates.sort(key=lambda x: -x.get('score', 0))
    return candidates


def get_subs(video_data):
    global global_var
    Addon = xbmcaddon.Addon()
    log.warning('DEBUG | [SubtitleCat] | Searching SubtitleCat (Hebrew download only)')

    if Addon.getSetting('language_hebrew') != 'true' and Addon.getSetting('all_lang') != 'true':
        global_var = []
        return []

    subtitle_list = []
    for item in _collect_candidates(video_data):
        SubFileName = item['filename']
        download_data = {
            'filename': SubFileName,
            'url': item['url'],
            'format': 'srt',
            'hearing_imp': 'false',
        }
        url = (
            'plugin://%s/?action=download&filename=%s&language=%s&download_data=%s&source=subtitlecat'
            % (MyScriptID, que(SubFileName), 'Hebrew', que(json.dumps(download_data)))
        )
        json_data = {
            'url': url,
            'label': 'Hebrew',
            'label2': site_id + ' ' + SubFileName,
            'iconImage': '5',
            'thumbnailImage': 'he',
            'hearing_imp': 'false',
            'site_id': site_id,
            'sub_color': sub_color,
            'filename': SubFileName,
            'sync': 'false',
        }
        subtitle_list.append(json_data)

    global_var = subtitle_list
    log.warning('DEBUG | [SubtitleCat] | Found {0} Hebrew downloads'.format(len(subtitle_list)))
    return subtitle_list


def download(download_data, MySubFolder):
    reset_tmp_dir(MyTmp)

    filename = download_data['filename']
    fmt = download_data.get('format', 'srt')
    sub_url = download_data['url']
    sub_file = os.path.join(MyTmp, '%s.%s' % (filename, fmt))
    log.warning('DEBUG | [SubtitleCat] | Download {0}'.format(sub_url))

    r = requests.get(sub_url, headers=_HEADERS, timeout=DEFAULT_REQUEST_TIMEOUT)
    r.raise_for_status()
    with open(sub_file, 'wb') as f:
        f.write(r.content)

    if sub_file.lower().endswith('.zip'):
        return extract(sub_file, MySubFolder)
    return sub_file
