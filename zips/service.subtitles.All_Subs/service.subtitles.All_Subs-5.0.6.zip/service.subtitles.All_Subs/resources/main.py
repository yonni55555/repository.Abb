# -*- coding: utf-8 -*-
import os
import sys
import json
from urllib.parse import parse_qsl

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

from resources.modules import log
from resources.modules.general import show_results, Thread

_EMBEDDED_SUB_SELECTED = 'EmbeddedSubSelected'

_CMD_RESPONSES = frozenset((
    'clean', 'open_settings', 'clean_all_cache', 'disable_subs',
    'browse_local_sub', 'sub_window', 'sub_window_unpause', 'clean_folders',
))

_LOCAL_ACTIONS = frozenset((
    'open_settings', 'clean_all_cache', 'disable_subs', 'clean',
    'browse_local_sub',
))


def _is_embedded_sub_response(resp):
    if isinstance(resp, str):
        return resp.strip().strip('"').strip("'") == _EMBEDDED_SUB_SELECTED
    return False


def _is_command_response(resp):
    if isinstance(resp, str):
        return resp.strip().strip('"').strip("'") in _CMD_RESPONSES
    return False


def _raw_response_ready(raw, is_download_action):
    if not raw:
        return False
    if not is_download_action:
        return True
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return False
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return True


def _resolve_subtitle_path(response):
    path = response
    for _ in range(3):
        if not isinstance(path, str):
            break
        path = path.strip().strip('"').replace('\\\\', '\\')
        if path.startswith('"'):
            try:
                path = json.loads(path)
                continue
            except (json.JSONDecodeError, TypeError, ValueError):
                break
        break
    return path if isinstance(path, str) else None


def _kodi_subtitle_path(file_path):
    """Kodi subtitle download expects a local .srt path in addDirectoryItem."""
    if not file_path:
        return file_path
    if file_path.lower().endswith('.srt'):
        return file_path
    if os.path.isfile(file_path):
        srt_path = file_path + '.srt'
        if not os.path.isfile(srt_path):
            import shutil
            shutil.copy2(file_path, srt_path)
        if os.path.isfile(srt_path):
            return srt_path
    return file_path


def _subtitle_file_exists(file_path):
    if not file_path:
        return False
    if os.path.isfile(file_path):
        return True
    try:
        return xbmcvfs.exists(file_path)
    except Exception:
        return False


def _parse_plugin_query():
    if len(sys.argv) < 3:
        return {}
    try:
        return dict(parse_qsl(sys.argv[2].lstrip('?')))
    except Exception:
        return {}


def _plugin_action():
    return (_parse_plugin_query().get('action') or '').strip()


def _browse_local_sub_start_folder():
    try:
        play_path = xbmc.Player().getPlayingFile()
        low = (play_path or '').lower()
        if play_path and not low.startswith(('http://', 'https://', 'plugin://')):
            folder = os.path.dirname(play_path.replace('/', os.sep))
            if xbmcvfs.exists(folder):
                return folder
    except Exception:
        pass
    return xbmcvfs.translatePath('special://home/')


def _handle_browse_local_sub(handle):
    addon = xbmcaddon.Addon('service.subtitles.All_Subs')
    sub_path = xbmcgui.Dialog().browse(
        1,
        'טען כתובית מקומית',
        'files',
        '.srt',
        False,
        False,
        _browse_local_sub_start_folder())
    if not sub_path:
        try:
            xbmcplugin.endOfDirectory(handle, succeeded=True)
        except Exception:
            pass
        return True

    sub_path = _kodi_subtitle_path(_resolve_subtitle_path(sub_path))
    if not _subtitle_file_exists(sub_path):
        xbmcgui.Dialog().notification(
            addon.getAddonInfo('name'),
            'קובץ כתובית לא נמצא',
            addon.getAddonInfo('icon'),
            3000)
        try:
            xbmcplugin.endOfDirectory(handle, succeeded=True)
        except Exception:
            pass
        return True

    try:
        from resources.modules import embedded_streams
        embedded_streams.set_external_subtitles(sub_path)
        player = xbmc.Player()
        try:
            player.showSubtitles(True)
        except Exception:
            pass
        log.warning('Local subtitle loaded: {0}'.format(sub_path))
    except Exception as e:
        log.warning('browse_local_sub failed: {0}'.format(e))
        xbmcgui.Dialog().notification(
            addon.getAddonInfo('name'),
            'שגיאה בטעינת כתובית',
            addon.getAddonInfo('icon'),
            3000)
        try:
            xbmcplugin.endOfDirectory(handle, succeeded=True)
        except Exception:
            pass
        return True

    try:
        xbmc.executebuiltin('Dialog.Close(all,true)')
    except Exception:
        try:
            xbmc.executebuiltin('Action(back)')
        except Exception:
            pass
    try:
        xbmcplugin.endOfDirectory(handle, succeeded=True)
    except Exception:
        pass
    return True


def _handle_local_plugin_action(action, handle):
    """Menu commands — never run subtitle search."""
    addon = xbmcaddon.Addon('service.subtitles.All_Subs')
    if action == 'browse_local_sub':
        return _handle_browse_local_sub(handle)
    if action == 'open_settings':
        addon.openSettings()
    elif action == 'clean_all_cache':
        xbmc.executebuiltin(
            'RunScript(special://home/addons/service.subtitles.All_Subs/'
            'resources/modules/clean_cache_functions.py, clean_all_cache)')
    elif action == 'disable_subs':
        xbmc.Player().setSubtitles('')
    elif action == 'clean':
        from resources.modules import cache
        cache.clear(['subs'])
    else:
        return False
    try:
        xbmc.executebuiltin('Action(back)')
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(handle, succeeded=True)
    except Exception:
        pass
    return True


def _append_subtitle_list_items(response, all_d):
    for items in response:
        listitem = xbmcgui.ListItem(
            label=items['label'],
            label2=items['label2'],
        )
        listitem.setArt({
            'thumb': items['thumbnailImage'],
            'icon': items['iconImage'],
        })
        listitem.setProperty('sync', items['sync'])
        listitem.setProperty('hearing_imp', items['hearing_imp'])
        is_folder = bool(items.get('menu_item'))
        all_d.append((items['url'], listitem, is_folder))


class _ResponseState:
    """Groups the three things a single start() invocation's IPC response
    can resolve into (a command name / a ready download path / an embedded-
    sub-selected flag) with the one method that classifies a response into
    them. A fresh instance per start() call -- these were already reset at
    the top of every invocation, so this also removes any chance of stale
    state leaking across invocations under reuselanguageinvoker.
    """

    def __init__(self):
        self.resolved_download_path = None
        self.parsed_response = None
        self.embedded_sub_selected = False

    def interpret(self, response, is_download_action, all_d):
        """Classify the parsed IPC response and update this state."""
        if _is_command_response(response):
            self.parsed_response = response
            return

        if isinstance(response, list) and len(response) > 0:
            first_item = response[0]
            if (isinstance(first_item, dict)
                    and 'hearing_imp' in first_item
                    and 'thumbnailImage' in first_item):
                _append_subtitle_list_items(response, all_d)
            return

        if isinstance(response, str):
            if _is_embedded_sub_response(response):
                self.embedded_sub_selected = True
                return
            file_path = _resolve_subtitle_path(response)
            if is_download_action and file_path and _subtitle_file_exists(file_path):
                self.resolved_download_path = file_path
                log.warning('Download action: subtitle file ready for Kodi')


def _finish_embedded_subtitle_download(handle):
    """Kodi download UI needs a file path; embedded uses setSubtitleStream."""
    try:
        player = xbmc.Player()
        try:
            player.showSubtitles(True)
        except Exception:
            pass
        sub_path = player.getSubtitles()
        if sub_path:
            sub_path = _kodi_subtitle_path(_resolve_subtitle_path(sub_path))
            if _subtitle_file_exists(sub_path):
                listitem = xbmcgui.ListItem(label=os.path.basename(sub_path))
                xbmcplugin.addDirectoryItem(handle, sub_path, listitem, False)
                xbmcplugin.endOfDirectory(handle, succeeded=True)
                log.warning('Embedded subtitle returned to Kodi: {0}'.format(sub_path))
                return True
    except Exception as e:
        log.warning('Embedded subtitle return failed: {0}'.format(e))
    try:
        xbmcplugin.endOfDirectory(handle, succeeded=True)
    except Exception:
        pass
    return False


def start():
    state = _ResponseState()
    log.warning('Starting Allsubs')

    try:
        addon = xbmcaddon.Addon('service.subtitles.All_Subs')
    except Exception as e:
        log.warning('ERROR | main.py | Failed to create addon instance: {0}'.format(e))
        return

    try:
        handle = int(sys.argv[1])
    except (ValueError, IndexError):
        log.warning('Exiting Allsubs - invalid handle')
        return

    plugin_action = _plugin_action()
    log.warning('DEBUG | main.py | plugin_action={0}'.format(plugin_action or '(none)'))

    if plugin_action in _LOCAL_ACTIONS:
        log.warning('Local plugin action (no search): {0}'.format(plugin_action))
        _handle_local_plugin_action(plugin_action, handle)
        return

    all_d = []
    progress = None
    is_download_action = False
    is_search_action = False

    if len(sys.argv) >= 2:
        is_download_action = plugin_action == 'download'
        is_search_action = (
            plugin_action == 'search'
            or (not is_download_action and 'languages=' in sys.argv[2])
        )
        plugin_params = _parse_plugin_query()
        download_language = (plugin_params.get('language') or '').strip()
        download_source = (plugin_params.get('source') or '').strip()
        try:
            from resources.modules.engine import subtitle_needs_machine_translate
            needs_translate = subtitle_needs_machine_translate(
                download_language, download_source)
        except Exception:
            needs_translate = 'Hebrew' not in download_language
        try:
            from resources.modules.ai_translate import settings_guard
            uses_gemini_translate = (
                settings_guard.is_gemini_translate_enabled()
                and needs_translate)
        except Exception:
            uses_gemini_translate = (
                addon.getSetting('auto_translate') == 'true'
                and addon.getSetting('translate_p') == '2'
                and needs_translate
            )
        if is_download_action and not needs_translate:
            log.warning(
                'Download: skip Gemini UI (language={0} source={1})'.format(
                    download_language or '?', download_source or '?'))

        if is_search_action:
            from resources.modules import general
            progress = general.SearchProgressDialog()
            progress.create('DarkSubs', 'מחפש כתוביות...')
            # Clear here (reader side) rather than relying only on the
            # service clearing it -- the service's own clear happens
            # asynchronously after this dialog is already polling, so a
            # leftover value from the previous search could otherwise
            # flash briefly before the new search's first real update.
            try:
                from resources.modules import ipc_store as _ipc_store_early
                _ipc_store_early.clear('search_progress_detail')
                _ipc_store_early.clear('search_progress_percent')
                _ipc_store_early.clear('search_cancel_requested')
            except Exception:
                pass
        elif is_download_action and uses_gemini_translate:
            from resources.modules import ipc_store
            ipc_store.write('gemini_translate_progress', '0')
            ipc_store.write('gemini_translate_done', '0')
            ipc_store.write('gemini_translate_total', '0')
            progress = xbmcgui.DialogProgress()
            progress.create('DarkSubs', 'מתבצע תרגום AI\n0% (0 שניות)')

        try:
            from resources.modules.ai_translate import kodi_bridge
            from resources.modules import ipc_store
            req_id = kodi_bridge.new_request_id()
            kodi_bridge.clear_return(req_id)

            try:
                sub_data = sys.argv[2] + '$$$$$$$$' + sys.argv[1] + '$$$$$$$$' + req_id
            except Exception:
                sub_data = 'None$$$$$$$$' + sys.argv[1] + '$$$$$$$$' + req_id

            ipc_store.write('main_search_subs', sub_data)

            response = ''
            timeout = 0
            if is_download_action and uses_gemini_translate:
                max_timeout = 1800
            elif is_download_action:
                max_timeout = 600
            else:
                try:
                    search_secs = max(1, int(addon.getSetting('max_search_time') or 10))
                except (TypeError, ValueError):
                    search_secs = 10
                max_timeout = (search_secs + 4) * 10

            while response == '' and (not progress or not progress.iscanceled()):
                raw = kodi_bridge.get_return(req_id)
                if _raw_response_ready(raw, is_download_action):
                    response = raw

                if progress:
                    if is_download_action and uses_gemini_translate:
                        try:
                            pct = int(ipc_store.read('gemini_translate_progress', '0') or 0)
                        except (TypeError, ValueError):
                            pct = 0
                        done = ipc_store.read('gemini_translate_done', '0') or '0'
                        total = ipc_store.read('gemini_translate_total', '?') or '?'
                        progress.update(
                            pct,
                            'מתבצע תרגום AI\n{0}% ({1} שניות) · חלק {2}/{3}'.format(
                                pct, timeout // 10, done, total),
                        )
                    elif is_search_action and timeout % 10 == 0:
                        real_percent = ipc_store.read('search_progress_percent', '')
                        if real_percent:
                            try:
                                percent = max(0, min(99, int(real_percent)))
                            except (TypeError, ValueError):
                                percent = min(int((timeout / max_timeout) * 100), 99)
                        else:
                            # Real per-source progress not published yet
                            # (service hasn't picked up the request) --
                            # fall back to a time-based estimate only
                            # until it is.
                            percent = min(int((timeout / max_timeout) * 100), 99)
                        detail = ipc_store.read('search_progress_detail', '')
                        text = 'מחפש כתוביות... {0}s'.format(timeout // 10)
                        if detail:
                            text += '\n' + detail
                        progress.update(percent, text)

                xbmc.sleep(100)
                timeout += 1
                if timeout > max_timeout:
                    log.warning('Timeout after {0}s (download={1})'.format(
                        max_timeout // 10, is_download_action))
                    break

            if progress:
                progress.close()

            kodi_bridge.clear_return(req_id)

            if progress and progress.iscanceled():
                if is_download_action and uses_gemini_translate:
                    from resources.modules import general
                    general.break_all = True
                    return
                if is_search_action:
                    # Tell the service to stop searching and use whatever
                    # it already has -- c_get_subtitles runs that partial
                    # list through the exact same sort_subtitles/ranking
                    # pipeline as a normal completion (it doesn't care why
                    # its loop ended), so just wait briefly for the real
                    # response instead of reconstructing an unranked one
                    # here.
                    try:
                        ipc_store.write('search_cancel_requested', '1')
                    except Exception:
                        pass
                    grace_ticks = 0
                    while response == '' and grace_ticks < 80:  # up to ~8s
                        raw = kodi_bridge.get_return(req_id)
                        if _raw_response_ready(raw, is_download_action):
                            response = raw
                            break
                        xbmc.sleep(100)
                        grace_ticks += 1
                else:
                    return

            if response:
                try:
                    response = json.loads(response)
                    state.interpret(response, is_download_action, all_d)
                except (json.JSONDecodeError, ValueError) as e:
                    log.warning('JSON parse error: {0}'.format(e))
            else:
                log.warning('Empty response from service')

        except Exception as e:
            log.warning('Error in search process: {0}'.format(e))
            if progress:
                progress.close()

    if state.parsed_response and _is_command_response(state.parsed_response):
        try:
            xbmcplugin.endOfDirectory(handle, succeeded=True)
        except Exception:
            pass
        return

    if state.resolved_download_path:
        try:
            sub_path = _kodi_subtitle_path(state.resolved_download_path)
            if _subtitle_file_exists(sub_path):
                listitem = xbmcgui.ListItem(label=os.path.basename(sub_path))
                xbmcplugin.addDirectoryItem(handle, sub_path, listitem, False)
                xbmcplugin.endOfDirectory(handle, succeeded=True)
                log.warning('Download returned to Kodi: {0}'.format(sub_path))
                return
        except Exception as e:
            log.warning('Download return failed: {0}'.format(e))

    if state.embedded_sub_selected and is_download_action:
        try:
            xbmc.Player().showSubtitles(True)
        except Exception:
            pass
        try:
            xbmc.executebuiltin('Dialog.Close(all,true)')
        except Exception:
            pass
        try:
            xbmcplugin.addDirectoryItems(handle, [], 0)
            xbmc.sleep(100)
            xbmcplugin.endOfDirectory(handle, updateListing=True, cacheToDisc=True)
        except Exception:
            pass
        log.warning('Embedded subtitle download completed')
        return

    try:
        log.warning('About to display | all_d count: {0}'.format(len(all_d)))
        if all_d:
            xbmcplugin.addDirectoryItems(handle, all_d, len(all_d))
            xbmc.sleep(100)
            xbmcplugin.endOfDirectory(handle, updateListing=True, cacheToDisc=True)
        elif is_download_action:
            if _finish_embedded_subtitle_download(handle):
                return
            xbmcplugin.endOfDirectory(handle, succeeded=True)
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
    except Exception as e:
        log.warning('Error adding directory items: {0}'.format(e))
