# MD_SUB_PRECENT — אחוז התאמת כתוביות

## מטרה

**חלון מקורות Novix** ו**חלון כתוביות DarkSubs** חייבים לחשב את אותו אחוז התאמה:

```
שם קובץ הניגון שנבחר במקורות (למשל):
  Deadpool.And.Wolverine.2024.1080p.BluRay.REMUX.MULTi[Ben The Men].mkv

מול שם הכתובית (למשל):
  Deadpool.And.Wolverine.2024.1080p.BluRay.REMUX.MULTi[Ben The Men].srt

→ אחוז = דמיון בין שני השמות (0–100)
```

---

## אלגוריתם אחיד (שני התוספים)

קובץ: `resources/modules/release_match.py` (DarkSubs)  
מקביל: `plugin.video.novix/.../he_sub_match.py` → `match_percent()`

1. הסרת סיומת קובץ (`.mkv`, `.srt`, …)
2. נרמול: `_`, רווח, `-`, `+`, `/` → נקודה
3. פיצול לטוקנים לפי `.`
4. `difflib.SequenceMatcher` על רשימות הטוקנים → `ratio() * 100`

---

## מאיפה מגיע שם הניגון?

| שלב | מקור |
|-----|------|
| בחירת מקור ב-Novix | `NovixPlayer._publish_subtitle_release()` → `Window(10000).Property(subs.player_filename)` |
| DarkSubs בזמן ניגון | `get_video_data_playing()` → `picked_release` / `Tagline` / `file_original_path` |
| מיון כתוביות | `pick_release_name(video_data)` — עדיפות ל-`picked_release` |

---

## בעיות שהיו (לפני התיקון)

### 1. DarkSubs — אלגוריתם שונה
- `sort_subtitles` השתמש ב-`clean_string_and_create_array` (הסרת כותרת הסרט, season/episode, וכו')
- במצב `fast_mode` — `quick_sync_percent` (ספירת טוקנים) במקום SequenceMatcher
- **תוצאה:** אחוזים שונים מ-Novix

### 2. `ReleaseFilenamePlayer` דרס שם טוב
- כשה-URL היה `original.mp4` / hash, `publish_picked_release()` החליף את `subs.player_filename`
- **תוצאה:** התאמה על `original.mp4` במקום שם הריליז האמיתי

### 3. Novix חלון מקורות
- כבר השתמש ב-`_score()` / `best_score()` — נכון בעקרון
- חייב להישאר זהה ל-`release_match_percent`

---

## קבצים רלוונטיים

| קובץ | תפקיד |
|------|--------|
| `Novix: modules/player.py` | שמירת `subs.player_filename` בבחירת מקור |
| `Novix: subsmodules/he_sub_match.py` | HEB % בחלון מקורות |
| `DarkSubs: resources/modules/release_match.py` | אלגוריתם משותף |
| `DarkSubs: resources/modules/engine.py` | `sort_subtitles` — אחוז לכל כתובית |
| `DarkSubs: resources/modules/general.py` | `get_video_data_playing`, `get_playing_filename` |
| `DarkSubs: resources/modules/release_publisher.py` | לא לדרוס שם ריליז תקין |

---

## אימות בלוג

חפש ב-`kodi.log`:

```
get_playing_filename | property=Deadpool.And.Wolverine...
P checking release: Deadpool.And.Wolverine...
picked_release': 'Deadpool...
```

**לא** אמור להופיע `original.mp4` / `stream` כשבחרת ריליז אמיתי במקורות.

---

## בדיקה ידנית

1. Novix → מקורות → בחר ריליז עם שם מלא (1080p REMUX וכו')
2. DarkSubs אוטו / חיפוש ידני → אחוז ליד כתובית דומה ל-HEB % במקורות
3. כתובית עם אותו שם ריליז → אחוז גבוה (66%+)
4. כתובית עם שם שונה → אחוז נמוך

---

## היסטוריה

| תאריך | שינוי |
|-------|--------|
| 2026-06-26 | אלגוריתם אחיד `release_match_percent`; תיקון `release_publisher` |
