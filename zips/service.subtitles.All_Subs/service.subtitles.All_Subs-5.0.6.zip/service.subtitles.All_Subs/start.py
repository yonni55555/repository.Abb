# -*- coding: utf-8 -*-
# Library for the xbmc.subtitle.module extension. Kodi resolves a bare-ID
# RunScript(service.subtitles.All_Subs, ...) call to this file (not to
# default.py), so OSD-button actions ('previous'/'next'/'sub_window_unpause'
# from skin.phenomenal_18's VideoOSD) are dispatched here directly via
# file-based IPC to the running autosub.py service, instead of falling
# through to resources/main.py:start(), which expects sys.argv[1] to be a
# numeric plugin handle and logs "invalid handle" otherwise.
import os
import sys

import xbmc
import xbmcaddon
import xbmcvfs

_OSD_ACTIONS = frozenset(('previous', 'next', 'sub_window_unpause'))

action = sys.argv[1] if len(sys.argv) > 1 else ''

if action in _OSD_ACTIONS:
	xbmc.log('/*DarkSubs*/ start.py-> OSD action, action={0}'.format(action), xbmc.LOGWARNING)

	addon = xbmcaddon.Addon('service.subtitles.All_Subs')
	profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
	ipc_dir = os.path.join(profile, 'ipc')
	try:
		xbmcvfs.mkdirs(ipc_dir)
	except Exception:
		os.makedirs(ipc_dir, exist_ok=True)

	path = os.path.join(ipc_dir, 'main_search_subs.ipc')
	with open(path, 'w', encoding='utf-8') as f:
		f.write('None$$$$$$$$' + action)

	xbmc.log('/*DarkSubs*/ start.py-> wrote ipc file: {0}'.format(path), xbmc.LOGWARNING)
else:
	from resources.main import start
	start()
