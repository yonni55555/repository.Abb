# -*- coding: utf-8 -*-
"""Tests for translate_engines.split_on_cues (cue-boundary chunking for Google translate).

Needs the `kodisim` Kodi simulator on sys.path (it is not part of this addon); skipped without it.
Run from the addon root:  python -m unittest discover -s tests
"""
import os
import re
import sys
import types
import unittest

ADDON_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KODISIM_DIR = os.environ.get("KODISIM_DIR", r"D:\Kodi21\portable_data\addons\_kodi-sim")


def _cue(n, text):
    return "%d\n00:00:%02d,000 --> 00:00:%02d,500\n%s" % (n, n % 60, n % 60, text)


class SplitOnCuesTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not os.path.isdir(KODISIM_DIR):
            raise unittest.SkipTest("kodisim not found (set KODISIM_DIR)")
        sys.path.insert(0, KODISIM_DIR)
        import kodisim
        sys.modules.setdefault("chardet", types.ModuleType("chardet"))  # imported, unused by the splitter
        cls.world = kodisim.install(platform="windows")
        cls.world.install_addon_from(ADDON_ROOT)
        cls.world.default_addon_id = "service.subtitles.All_Subs"
        sys.path.insert(0, ADDON_ROOT)
        sys.path.insert(0, os.path.join(ADDON_ROOT, "resources", "modules"))
        from resources.modules import translate_engines
        cls.split = staticmethod(translate_engines.split_on_cues)
        cls.kodisim = kodisim

    @classmethod
    def tearDownClass(cls):
        cls.kodisim.uninstall()

    def test_empty_and_blank_input(self):
        self.assertEqual(self.split("", 100), [])
        self.assertEqual(self.split("\n\n\n", 100), [])

    def test_never_cuts_a_cue_and_rejoins_exactly(self):
        cues = [_cue(i, "line one of %d\nline two" % i) for i in range(1, 200)]
        chunks = self.split("\n\n".join(cues) + "\n\n", 500)
        self.assertGreater(len(chunks), 1)
        self.assertEqual("\n\n".join(chunks), "\n\n".join(cues))
        for chunk in chunks:
            self.assertLessEqual(len(chunk), 500)
            # every chunk starts at a cue number and each timestamp line is whole
            self.assertRegex(chunk, r"^\d+\n\d\d:\d\d:\d\d,\d\d\d --> ")
            self.assertEqual(len(re.findall(r"^\d+$", chunk, re.M)), len(re.findall(r"-->", chunk)))

    def test_crlf_is_normalised(self):
        text = "1\r\n00:00:01,000 --> 00:00:02,000\r\nhi\r\n\r\n2\r\n00:00:03,000 --> 00:00:04,000\r\nyo\r\n"
        chunks = self.split(text, 10 ** 6)
        self.assertEqual(len(chunks), 1)
        self.assertNotIn("\r", chunks[0])
        self.assertEqual(chunks[0].count("-->"), 2)

    def test_oversized_cue_gets_its_own_chunk(self):
        chunks = self.split("A" * 50 + "\n\n" + "B" * 5 + "\n\n" + "C" * 5, 20)
        self.assertEqual([len(c) for c in chunks], [50, 12])

    def test_blank_line_with_trailing_spaces_still_separates(self):
        chunks = self.split(_cue(1, "a") + "\n \t\n" + _cue(2, "b"), 10)
        self.assertEqual(len(chunks), 2)


if __name__ == "__main__":
    unittest.main()
