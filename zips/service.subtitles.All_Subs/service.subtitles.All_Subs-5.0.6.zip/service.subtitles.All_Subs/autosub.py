import time,re,xbmcaddon
import xbmc,xbmcgui,xbmcplugin,xbmcvfs
import os,json,shutil
from resources.modules import cache
from resources.modules import log
from resources.modules.engine import download_sub,get_subtitles,sort_subtitles
from urllib.parse import  unquote_plus, unquote,  quote
from resources.modules.general import TransFolder,clean_title,CachedSubFolder,get_video_data,get_db_data,MySubFolder,notify,Thread,show_results,save_file_name
from urllib.parse import parse_qsl
from resources.modules.sub_window import MySubs
import urllib.parse
from resources.modules import general
from resources.modules import ipc_store
Addon=xbmcaddon.Addon('service.subtitles.All_Subs')
MyScriptName = Addon.getAddonInfo('name')
MyScriptID = Addon.getAddonInfo('id')
unque=urllib.parse.unquote_plus
monit = xbmc.Monitor()
ab_req=monit.abortRequested()
log.warning('Starting %s Service!!!'%MyScriptName)

global video_id,pre_video_id,trigger,dont_place_sub
global playing_addon,break_wait,quick_sub_value,already_placed_sub
already_placed_sub=False
quick_sub_value=""
# Which video quick_sub_value was set for (_video_identity_key) -- lets
# play_auto_sub tell a genuinely stale value (previous title) apart from one
# a concurrent mando prefetch just set for the SAME video it's about to
# place a subtitle for, instead of racily clearing it (see play_auto_sub).
quick_sub_value_sig=""
# Set by sub_from_mando_quick while it's actively searching/placing a
# subtitle for a video (identity key, see _video_identity_key), cleared when
# it's done. play_auto_sub waits briefly on this before doing its own
# embedded-stream snapshot/placement, since the two run on separate threads
# and otherwise race: play_auto_sub's snapshot can catch the external file
# the prefetch just loaded and mistake it for a genuine MKV embedded track,
# and play_auto_sub's own "clear stale sub from previous title" step can
# wipe the subtitle the prefetch just correctly placed for this same video.
_mando_prefetch_busy_key=""
# Set (to the same identity key) when sub_from_mando_quick successfully
# placed a subtitle, so play_auto_sub can skip redoing the same
# search+download instead of racing to completion then repeating it from
# scratch. Consumed (cleared) the first time play_auto_sub checks it, so a
# later, unrelated playback of the same episode can't read it as stale.
_mando_prefetch_done_key=""
# "Subtitle ready" toast text place_sub() would have shown immediately, but
# didn't because it ran from mando's prefetch (video isn't playing yet, so
# the toast would appear before the user sees anything on screen). Consumed
# by play_auto_sub once it re-applies the prefetch's subtitle for the now-live
# player, so the toast lands at the moment the user can actually see it land.
_mando_prefetch_ready_msg=""
dont_place_sub=False
break_wait=False
playing_addon=""
video_id=""
pre_video_id=""
trigger=False
is_embedded_hebrew_sub_exists=False
_autosub_running_sig = None
que=urllib.parse.quote_plus
cache.clear(['subs'])
####################################################################################
    
def translate_sub_language_to_hebrew(language):
    if "Hebrew" in language:
        return "עברית"
    elif language == "English":
        return "אנגלית"
    elif language == "Russian":
        return "רוסית"
    elif language == "Arabic":
        return "ערבית"
    else:
        return language


_SUBTITLE_READY_NOTIFY_MS = 2000


def _show_manual_subtitle_ready(language, source, sub_file, filename, uses_gemini=False, sync_percent=''):
    """Toast + overlay after a subtitle is loaded (manual pick or auto place)."""
    if Addon.getSetting('enable_autosub_notifications') != 'true':
        return
    try:
        from resources.modules.engine import format_website_source_name
        site = format_website_source_name(source)
        lang = translate_sub_language_to_hebrew(language)
        if (language != 'Hebrew'
                and Addon.getSetting('auto_translate') == 'true'
                and uses_gemini):
            lang = f"{lang} (תרגום AI)"
        elif (language != 'Hebrew'
              and Addon.getSetting('auto_translate') == 'true'
              and sub_file and sub_file not in ('EmbeddedSubSelected', '')):
            try:
                from resources.modules.engine import _trans_file_is_hebrew
                if _trans_file_is_hebrew(sub_file):
                    lang = f"{lang} (תרגום מכונה)"
            except Exception:
                pass
        sync = str(sync_percent).strip() if sync_percent not in (None, '') else ''
        if not sync or sync == '0':
            sync = '101'
        msg = '{0} | {1}% | {2}'.format(lang, sync, site)
        log.warning('_show_manual_subtitle_ready: {0}'.format(msg))
        try:
            xbmcgui.Dialog().notification(
                '',
                msg,
                Addon.getAddonInfo('icon'),
                _SUBTITLE_READY_NOTIFY_MS,
                False)
        except Exception as e:
            log.warning('_show_manual_subtitle_ready notification failed: {0}'.format(e))
        general.show_msg = (
            '[COLOR lightblue]כתובית מוכנה[/COLOR]\n'
            + msg)
        overlay = Thread(show_results)
        overlay.start()
        xbmc.sleep(_SUBTITLE_READY_NOTIFY_MS)
        general.show_msg = 'END'
    except Exception as e:
        log.warning('_show_manual_subtitle_ready failed: {0}'.format(e))
####################################################################################

_SUBTITLE_SEARCH_KEYS = (
    'media_type', 'title', 'OriginalTitle', 'TVShowTitle', 'tmdb',
    'IMDBNumber', 'imdb', 'imdb_UniqueID', 'season', 'episode', 'year',
    'picked_release', 'Tagline', 'file_original_path',
)


_SUBTITLE_SEARCH_RELEASE_KEYS = ('picked_release', 'Tagline', 'file_original_path')


def _subtitle_search_cache_data(video_data):
    """Canonical copy of video_data used as the cache.get() argument for
    get_subtitles, so the same video hashes to the same cache entry
    regardless of which caller searched for it first. This is also the
    literal dict get_subtitles() runs with (cache.get() calls
    function(*args) using these same args), so it has to carry every key
    any source ever reads for searching, or that source silently never
    receives the value.

    Deliberately an ALLOWLIST of the exact keys any source/engine.py ever
    reads for searching (verified by grepping every video_data.get(...)/
    video_data[...] access across engine.py and resources/sources/*.py),
    not a blocklist of known-volatile keys. A blocklist only protects
    against volatility it already knows about -- mando's two different
    prefetch triggers (sub_from_mando vs sub_from_mando_quick) build
    video_data by hand with slightly different key sets (one includes
    'mpaa', the other omits it entirely), which isn't even used for
    searching but still changed str(dict) and therefore the cache hash,
    so the second trigger's prefetch missed the first one's cache entry
    and redundantly re-ran the full live search (confirmed in a real
    kodi.log: 'FoundMando_search33' CACHE MISS seconds after 'Mando_search'
    had already CACHE WRITE-ed the identical search). Every key here is
    read with .get(key, '') so a key being entirely absent from one
    caller's video_data can never change the hash -- only a genuinely
    different value can.

    picked_release/Tagline/file_original_path (subtitlecat.py,
    communitypool.py) are release/filename strings, not IDs -- mando's
    prefetch (raw, URL-escaped release name, e.g. 'Movie%3A.Name') and
    the live player readback (xbmc InfoLabels, already unescaped, e.g.
    'Movie:.Name') describe the identical release in different spellings
    (see _video_identity_key's docstring for the same %3A-vs-':' gap).
    Run through clean_title() -- already used for title/OriginalTitle --
    so that formatting difference doesn't split one release into two
    cache entries.

    The 3 release keys are also collapsed to a single resolved value shared
    across all 3, rather than hashed independently -- callers don't agree on
    which of the 3 they populate. sub_from_mando_quick's hand-built video_data
    only ever sets 'Tagline'; get_video_data_playing() always derives and sets
    all 3 to the same value. Hashing them independently split what's the same
    release into two different cache entries (confirmed in a real kodi.log:
    the manual "search subtitles" button re-ran the full search seconds after
    mando's prefetch had already cached the identical release, because its
    video_data had 'picked_release'/'file_original_path' populated too where
    the prefetch's had left them empty).
    """
    data = {k: video_data.get(k, '') for k in _SUBTITLE_SEARCH_KEYS}
    for k in ('title', 'OriginalTitle', 'TVShowTitle'):
        if data[k]:
            data[k] = clean_title(data[k])
    release = ''
    for k in _SUBTITLE_SEARCH_RELEASE_KEYS:
        if data[k]:
            release = clean_title(data[k])
            break
    for k in _SUBTITLE_SEARCH_RELEASE_KEYS:
        data[k] = release
    return data


def wait_for_video():

    log.warning('Waiting for video')
    counter=0
    vidtime_pre=0
    once=True
    
    while counter<70:
        try:
            vidtime = xbmc.Player().getTime()
            if vidtime>0:
                  if once:
                      vidtime_pre=vidtime
                      once=False
                  if vidtime_pre!=vidtime:
                      break
                  vidtime_pre=vidtime
                  if (vidtime>1):
                    break
            counter+=1
            xbmc.sleep(100)
        except:
          break
          
    log.warning(f"DEBUG | Time waited for video to start (wait_for_video): {counter/10} seconds.")

######################### EMBEDDED SUBS #####################################

from resources.modules import embedded_streams
    
def determine_placeHebrewEmbeddedSub(last_sub_in_cache_is_external, last_sub_in_cache_is_heb_embedded, first_external_sub_language):

    # For settings changes to take effect.
    Addon=xbmcaddon.Addon()

    if Addon.getSetting("auto_place_hebrew_embedded_subs") != 'true':
        return False

    global is_embedded_hebrew_sub_exists
    embedded_streams.refresh_snapshot_if_needed(1)
    if embedded_streams.genuine_embedded_index('heb', max_wait_sec=1) is None:
        return False
    is_embedded_hebrew_sub_exists = True

    if _player_has_active_subtitles():
        return True

    if not last_sub_in_cache_is_external:
        return True

    if last_sub_in_cache_is_heb_embedded:
        return True

    return False
    

def wait_for_video_and_return_subs_list():

    log.warning('Waiting for video')
    counter=0
    vidtime=0
    once=True
    
    while counter<70:
        try:
          vidtime = xbmc.Player().getTime()
          if vidtime>0.1:
                if once:
                    vidtime_pre=vidtime
                    once=False
                if vidtime_pre!=vidtime:
                    break
                vidtime_pre=vidtime
                if (vidtime>1):
                    break
        except:
          pass
        counter+=1
        xbmc.sleep(100)
    subs=xbmc.Player().getAvailableSubtitleStreams()
    log.warning(f'Em subs:{subs}')
    if len(subs)>0:
        log.warning(f"DEBUG | Time waited for video to start (wait_for_video_and_return_subs_list): {counter/10} seconds.")
    return subs
    

def check_if_embedded_sub_exists(embedded_language):
    global is_embedded_hebrew_sub_exists
    if embedded_language == 'heb' and is_embedded_hebrew_sub_exists:
        return True
    found = embedded_streams.genuine_embedded_index(
        embedded_language, max_wait_sec=0) is not None
    if found and embedded_language == 'heb':
        is_embedded_hebrew_sub_exists = True
    return found


def _player_has_active_subtitles():
    try:
        return xbmc.getCondVisibility("VideoPlayer.HasSubtitles")
    except Exception:
        return False


def _capture_embedded_at_play_start(full_poll=True):
    """Snapshot MKV subtitle tracks at play start.

    full_poll=False skips embedded_streams.capture_at_play_start's extra
    "poll a few more seconds if the first second came up empty" step and
    takes only the initial 1s snapshot (via capture_initial) instead. That
    extra step also permanently sets _confirmed_no_tracks, which makes every
    later genuine_embedded_index() call -- including _try_swap_to_late_embedded's
    own poll -- return None immediately regardless of its own max_wait_sec.
    Used when a mando-prefetched subtitle is about to be re-applied right
    after this call: the 1s snapshot is still taken (it's the "before
    external load" baseline genuine-track detection needs), but blocking the
    user on a multi-second poll for tracks we're not even waiting to decide
    on is wasted -- _try_swap_to_late_embedded does its own real poll right
    after the subtitle is already showing instead.
    """
    global is_embedded_hebrew_sub_exists
    if full_poll:
        embedded_streams.capture_at_play_start(1, 3)
    else:
        embedded_streams.capture_initial(1)
    if embedded_streams.snapshot_has_lang('heb') or 'heb' in embedded_streams.get_initial_snapshot():
        is_embedded_hebrew_sub_exists = True
    elif check_if_embedded_sub_exists('heb'):
        is_embedded_hebrew_sub_exists = True
    log.warning(
        'play_auto_sub | snapshot={0} | is_embedded_hebrew_sub_exists={1} | full_poll={2}'.format(
            embedded_streams.get_initial_snapshot(), is_embedded_hebrew_sub_exists, full_poll))


def _try_skip_external_search(video_data, search_language_hebrew_bool):
    """Skip site search only when confident MKV Hebrew embedded exists."""
    global is_embedded_hebrew_sub_exists, dont_place_sub, already_placed_sub
    global _mando_prefetch_done_key
    Addon = xbmcaddon.Addon()

    # sub_from_mando_quick already ran the full search+place for this exact
    # video moments ago (mando prefetches while resolving playback sources) --
    # redoing it here would just repeat the same "search"/"downloading"
    # show_msg sequence for no benefit. Consume the flag either way so a
    # later, unrelated playback of the same episode can't read it as stale.
    if _mando_prefetch_done_key == _video_identity_key(video_data):
        _mando_prefetch_done_key = ""
        # Trust it only if the externally-loaded subtitle is actually present
        # in the player's live stream list right now. The prefetch can finish
        # (and call setSubtitles successfully) BEFORE the real video starts
        # playing -- Kodi discards a subtitle selection made before the
        # actual playback session begins, so "prefetch reported success"
        # doesn't always mean it survived into the now-live player.
        # VideoPlayer.HasSubtitles (_player_has_active_subtitles) isn't
        # enough here -- it's true for any video with its OWN embedded
        # tracks (e.g. an MKV with Italian/English subs), regardless of
        # whether our external Hebrew one made it. If it didn't survive,
        # fall through and place it for real.
        if embedded_streams.has_external_subtitle_active():
            log.warning('play_auto_sub | skip external search — mando prefetch already placed it')
            already_placed_sub = True
            return True
        log.warning(
            'play_auto_sub | mando prefetch placed a sub but none is active now '
            '(placed before playback truly started) — placing it for real')

    embedded_streams.refresh_snapshot_if_needed(1)
    has_heb = (
        is_embedded_hebrew_sub_exists
        or check_if_embedded_sub_exists('heb')
        or embedded_streams.has_genuine_embedded_hebrew(max_wait_sec=1))
    if has_heb:
        is_embedded_hebrew_sub_exists = True
        if search_language_hebrew_bool:
            last_sub_name_in_cache, last_sub_language_in_cache, all_subs = get_db_data(
                video_data)
            last_sub_in_cache_is_empty = not last_sub_name_in_cache
            last_sub_in_cache_is_heb_embedded = (
                'HebrewSubEmbedded' in (last_sub_name_in_cache or ''))
            last_sub_in_cache_is_external = (
                not last_sub_in_cache_is_empty and not last_sub_in_cache_is_heb_embedded)
            place_heb = determine_placeHebrewEmbeddedSub(
                last_sub_in_cache_is_external,
                last_sub_in_cache_is_heb_embedded,
                '')
            log.warning(
                'play_auto_sub | embedded heb detected | placeHebrewEmbeddedSub={0}'.format(
                    place_heb))
            if place_heb and Addon.getSetting('auto_place_hebrew_embedded_subs') == 'true':
                log.warning('play_auto_sub | skip external search — placing embedded heb')
                if set_embedded_hebrew_sub(video_data, max_wait_sec=3):
                    already_placed_sub = True
                    dont_place_sub = True
                return True
            log.warning(
                'play_auto_sub | skip external search — embedded heb present')
            return True

    if Addon.getSetting('force') == 'false':
        if _player_has_active_subtitles() or embedded_streams.snapshot_has_genuine_tracks():
            log.warning(
                'play_auto_sub | skip external search — force=false and subs already present')
            return True

    return False


def _refresh_embedded_hebrew_after_search():
    """Re-check embedded heb after site search (stream labels may appear late)."""
    global is_embedded_hebrew_sub_exists
    embedded_streams.refresh_snapshot_if_needed(1)
    if embedded_streams.has_genuine_embedded_hebrew(max_wait_sec=1):
        is_embedded_hebrew_sub_exists = True
        return True
    if check_if_embedded_sub_exists('heb'):
        is_embedded_hebrew_sub_exists = True
        return True
    return False


def get_embedded_sub_index(subs, embedded_language):
    return next((index for index, sub in enumerate(subs) if sub == embedded_language), None)

    
def set_embedded_hebrew_sub(video_data, notify=True, max_wait_sec=5):
    global quick_sub_value, quick_sub_value_sig, is_embedded_hebrew_sub_exists
    from resources.modules.engine import activate_embedded_sub
    index_sub = activate_embedded_sub('heb', max_wait_sec=max_wait_sec, clear_external=True)
    if index_sub is not None:
        is_embedded_hebrew_sub_exists = True
        quick_sub_value = index_sub
        quick_sub_value_sig = _video_identity_key(video_data)
        tag = (
            video_data.get('Tagline')
            or video_data.get('picked_release')
            or video_data.get('file_original_path')
            or '')
        save_data=(
            'HebrewSubEmbedded'
            + str(video_data.get('imdb', ''))
            + str(video_data.get('season', ''))
            + str(video_data.get('episode', ''))
            + str(video_data.get('OriginalTitle', ''))
            + str(tag))
        save_video = dict(video_data)
        save_video['Tagline'] = tag
        save_video['file_original_path'] = video_data.get('file_original_path') or tag
        save_file_name(que(save_data), "Hebrew", save_video)
        Addon = xbmcaddon.Addon()
        if notify and Addon.getSetting('enable_autosub_notifications') == 'true':
            _show_manual_subtitle_ready(
                'Hebrew', 'HebrewSubEmbedded', '', '',
                sync_percent='101')
        xbmc.sleep(300)
        return True
    return False


def _video_identity_key(video_data):
    """imdb+season+episode only -- no release string.

    Used to tell whether a mando prefetch (sub_from_mando_quick) running on
    its own thread is working on the SAME video play_auto_sub was just
    triggered for. _autosub_play_signature's release-string component can
    differ in formatting between mando's own video_data and what
    get_video_data() reads back from the live player for the same file
    (e.g. '%3A' vs ':' escaping), so it's too strict for this comparison.
    """
    return '{0}|{1}|{2}'.format(
        video_data.get('imdb', ''),
        video_data.get('season', ''),
        video_data.get('episode', ''))


def _autosub_play_signature(video_data):
    try:
        release = (
            video_data.get('picked_release')
            or video_data.get('file_original_path')
            or xbmcgui.Window(10000).getProperty('subs.player_filename')
            or '')
    except Exception:
        release = ''
    return '{0}|{1}|{2}|{3}'.format(
        video_data.get('imdb', ''),
        video_data.get('season', ''),
        video_data.get('episode', ''),
        str(release).strip()[:240])


_SESSION_SUBS_RAW_KEY = 'autosub_session_subs_raw'
_SESSION_SUBS_SORTED_KEY = 'autosub_session_subs_sorted'


def _session_video_sig(video_data):
    return _autosub_play_signature(video_data)


def clear_session_sub_results():
    ipc_store.clear(_SESSION_SUBS_RAW_KEY)
    ipc_store.clear(_SESSION_SUBS_SORTED_KEY)


def save_session_sub_results(video_data, f_result, sorted_results=None):
    try:
        sig = _session_video_sig(video_data)
        ipc_store.write(_SESSION_SUBS_RAW_KEY, json.dumps({
            'sig': sig,
            'results': f_result or [],
        }))
        log.warning('save_session_sub_results | raw {0} subs | sig={1}'.format(
            len(f_result or []), sig))
        if sorted_results is not None:
            ipc_store.write(_SESSION_SUBS_SORTED_KEY, json.dumps({
                'sig': sig,
                'results': sorted_results or [],
            }))
            log.warning('save_session_sub_results | sorted {0} subs'.format(
                len(sorted_results or [])))
    except Exception as e:
        log.warning('save_session_sub_results failed: {0}'.format(e))


def load_session_sub_results(video_data, sorted_list=False):
    key = _SESSION_SUBS_SORTED_KEY if sorted_list else _SESSION_SUBS_RAW_KEY
    try:
        raw = ipc_store.read(key, '')
        if not raw:
            return None
        data = json.loads(raw)
        sig = _session_video_sig(video_data)
        if data.get('sig') != sig:
            return None
        results = data.get('results')
        if results is not None:
            log.warning('load_session_sub_results | hit {0} | {1} subs'.format(
                'sorted' if sorted_list else 'raw', len(results)))
        return results
    except Exception as e:
        log.warning('load_session_sub_results failed: {0}'.format(e))
        return None


def _bg_sort_session_subs(video_data_snapshot, f_result_snapshot):
    try:
        sorted_full = sort_subtitles(
            list(f_result_snapshot), dict(video_data_snapshot),
            for_autosub=False, fast_mode=True)
        save_session_sub_results(video_data_snapshot, f_result_snapshot, sorted_full)
    except Exception as e:
        log.warning('_bg_sort_session_subs failed: {0}'.format(e))


def _autosub_is_stale(run_sig):
    if not run_sig:
        return False
    if not xbmc.Player().isPlaying():
        return True
    try:
        return _autosub_play_signature(get_video_data()) != run_sig
    except Exception:
        return True


def add_embbded_sub_if_exists(video_data, f_result, embedded_language):

    # Avoid checking when using subtitles search from context menu (display_subtitle)
    if not xbmc.Player().isPlaying():
        log.warning(f'DEBUG | add_embbded_sub_if_exists STOP | embedded_language={embedded_language} | xbmc.Player().isPlaying(): {xbmc.Player().isPlaying()}')
        return f_result

    if embedded_language=='heb':
        embedded_sub_name_prefix = 'HebrewSubEmbedded'
        FullLanguageName = 'Hebrew'
        thumbnailImageLanguageName = 'he'
        EmbeddedSubLabel = 'תרגום מובנה בעברית'
    elif embedded_language=='eng':
        embedded_sub_name_prefix = 'EnglishSubEmbedded'
        FullLanguageName = 'English'
        thumbnailImageLanguageName = 'en'
        EmbeddedSubLabel = 'תרגום מובנה באנגלית'
    else:
        return f_result
        
    # Exit if embedded sub is already present in f_result. Else, continue. Safe checking again.
    for items in f_result:
        if embedded_sub_name_prefix in items[8]:
            return f_result

    subs = embedded_streams.player_subtitle_streams()
    index_sub = embedded_streams.genuine_embedded_index(embedded_language, max_wait_sec=0)
    if index_sub is None and embedded_language == 'heb':
        embedded_streams.refresh_snapshot_if_needed(0)
        index_sub = embedded_streams.genuine_embedded_index(
            embedded_language, max_wait_sec=0)
    if index_sub is not None and embedded_language == 'heb':
        global is_embedded_hebrew_sub_exists
        is_embedded_hebrew_sub_exists = True
    elif embedded_language == 'heb':
        log.warning(
            'DEBUG | add_embbded_sub_if_exists STOP | embedded_language={0} | player streams={1} | snapshot={2}'.format(
                embedded_language, subs, embedded_streams.get_initial_snapshot()))
        return f_result
    log.warning(
        'add_embbded_sub_if_exists | embedded_language={0} | Player subtitle streams: {1} | index_sub={2}'.format(
            embedded_language, subs, index_sub))

    if index_sub is not None:
        download_data={}
        download_data['url']=str(index_sub)
        download_data['file_name']=str(index_sub)
        save_data=embedded_sub_name_prefix+str(video_data.get('imdb',''))+str(video_data.get('season',''))+str(video_data.get('episode',''))+str(video_data.get('OriginalTitle',''))+str(video_data.get('Tagline') or video_data.get('picked_release') or '')
  
        url = "plugin://%s/?action=download&download_data=%s&filename=%s&language=%s&source=%s" % (MyScriptID,
                                                            que(json.dumps(download_data)),
                                                            que(que(que(save_data))),
                                                            FullLanguageName,
                                                            embedded_sub_name_prefix)
        json_value={'url':url,
                             'label':FullLanguageName,
                             'label2':'[LOC] '+ EmbeddedSubLabel,
                             'iconImage':"0",
                             'thumbnailImage':thumbnailImageLanguageName,
                             'hearing_imp':'false',
                             'site_id':'[LOC]',
                             'sub_color':'cyan',
                             'filename':que(save_data),
                             'sync': 'true'}
                             
   
        index = 0
        if embedded_language=='eng':
            # Find the index where English subtitles should be inserted
            for i, sub in enumerate(f_result):
                if sub[0] == 'Hebrew':
                    index = i + 1  # Insert after the last Hebrew subtitle
                             
            
        f_result.insert(index, (json_value['label'],'[COLOR %s]'%json_value['sub_color']+json_value['label2']+'[/COLOR]',json_value['iconImage'],json_value['thumbnailImage'],json_value['url'],101,json_value['sync'],json_value['hearing_imp'],json_value['filename'],json_value['site_id']))

    return f_result
    
    
def add_embbded_subs_to_subs_list(video_data, f_result):

    # For settings changes to take effect.
    Addon=xbmcaddon.Addon()
    global is_embedded_hebrew_sub_exists
        
    # Add Hebrew Embbeded Subtitles if exists
    search_language_hebrew_bool = (Addon.getSetting('language_hebrew') == 'true' or Addon.getSetting("all_lang") == 'true')
    if search_language_hebrew_bool:
        if not is_embedded_hebrew_sub_exists:
            is_embedded_hebrew_sub_exists = check_if_embedded_sub_exists('heb')
        f_result=add_embbded_sub_if_exists(video_data, f_result, 'heb')
        
    # Add English Embbeded Subtitles if exists
    search_language_english_bool = (Addon.getSetting('language_english') == 'true' or Addon.getSetting("all_lang") == 'true')
    if search_language_english_bool:
        f_result=add_embbded_sub_if_exists(video_data, f_result, 'eng')

    return f_result


def _fetch_ranked_subs(video_data):
    """Search (or reuse cache), rank, add embedded subs, and read last-placed state.

    Mutates video_data in place: VideoPlayer.Tagline/Tagline_From_Fen are
    popped for the duration of the cache lookups (they're not part of the
    cache key -- see _SUBTITLE_SEARCH_KEYS) and restored before returning.
    Tagline/file_original_path stay in place, since _subtitle_search_cache_data
    is also the actual argument get_subtitles() runs with, and sources like
    subtitlecat/communitypool need them to match a release.
    """
    tag_original2 = video_data.get('VideoPlayer.Tagline')
    video_data.pop('VideoPlayer.Tagline', None)
    tag_original3 = video_data.get('Tagline_From_Fen')
    video_data.pop('Tagline_From_Fen', None)
    if video_data.get('year') == '':
        video_data['year'] = '0'

    f_result = cache.get(get_subtitles, 24, _subtitle_search_cache_data(video_data), table='subs')

    video_data['VideoPlayer.Tagline'] = tag_original2
    video_data['Tagline_From_Fen'] = tag_original3

    f_result = cache.get(sort_subtitles, 24, f_result, video_data, table='subs')
    f_result = [] if not f_result else f_result
    f_result = add_embbded_subs_to_subs_list(video_data, f_result)

    last_sub_name_in_cache, last_sub_language_in_cache, all_subs = get_db_data(video_data)
    return f_result, last_sub_name_in_cache, last_sub_language_in_cache, all_subs

####################################################################################
    
def isPlayingAddonExcluded(movieFullPath,playing_addon):
    excluded_addons=['idanplus','sdarot.tv','youtube','kids_new']

    playing_addon=playing_addon+movieFullPath
 
    if (playing_addon.find("pvr://") > -1) :
        log.warning("isPlayingAddonExcluded(): Video is playing via Live TV, which is currently set as excluded location.")
        return True
    if (xbmc.getInfoLabel("VideoPlayer.mpaa")=='heb'):
          log.warning("isPlayingAddonExcluded(): mpaa!!." )
          return True
    for x in excluded_addons:
        
        if x in playing_addon.lower():
            
            log.warning("isPlayingAddonExcluded(): Video is playing from '%s', which is currently set as !!excluded_addons!!."%x )
            
            return True
    if ',' in  Addon.getSetting('ExcludedAddons'):
        ExcludedAddons = Addon.getSetting('ExcludedAddons').split(',')  
    else:
        ExcludedAddons = [Addon.getSetting('ExcludedAddons')]
    for items in ExcludedAddons:
        if items.lower() in playing_addon.lower() and (len(items)>0):
            log.warning("isPlayingAddonExcluded(): Video is playing from '%s', which is currently set as !!excluded_addons!!."%items )
            return True
    return False
    
def _last_sub_cache_state(last_sub_name_in_cache):
    """Classify the last-placed-subtitle cache record for embedded-vs-external decisions."""
    is_empty = last_sub_name_in_cache == ''
    is_heb_embedded = 'HebrewSubEmbedded' in last_sub_name_in_cache
    is_external = not is_empty and not is_heb_embedded
    return is_empty, is_heb_embedded, is_external


def _prioritize_hebrew_candidates(try_list, Addon):
    """Never fall back to English/other languages once a Hebrew subtitle is available."""
    hebrew_embedded = [s for s in try_list if 'HebrewSubEmbedded' in str(s[8])]
    if hebrew_embedded:
        try_list = hebrew_embedded + [s for s in try_list if s not in hebrew_embedded]
        log.warning('place_sub | Hebrew-embedded-first: {0}'.format(len(hebrew_embedded)))

    has_hebrew_external = any(s[0] == 'Hebrew' for s in try_list)
    if has_hebrew_external:
        dropped = [s for s in try_list if 'EnglishSubEmbedded' in str(s[8])]
        if dropped:
            try_list = [s for s in try_list if s not in dropped]
            log.warning('place_sub | skip English embedded ({0}) — Hebrew externals exist'.format(
                len(dropped)))

    if try_list and any(s[0] == 'Hebrew' for s in try_list):
        hebrew_only = [s for s in try_list if s[0] == 'Hebrew']
        if hebrew_only:
            try_list = hebrew_only
            log.warning('place_sub | Hebrew-first: trying {0} Hebrew subs only'.format(
                len(try_list)))

    search_hebrew = (
        Addon.getSetting('language_hebrew') == 'true'
        or Addon.getSetting('all_lang') == 'true')
    if search_hebrew and Addon.getSetting('auto_translate') == 'true':
        eng_embedded = [s for s in try_list if 'EnglishSubEmbedded' in str(s[8])]
        if eng_embedded:
            try_list = [s for s in try_list if s not in eng_embedded]
            log.warning(
                'place_sub | skip English embedded ({0}) — auto_translate + Hebrew search '
                '(use external + translate)'.format(len(eng_embedded)))

    return try_list


def place_sub(video_data,f_result,last_sub_name_in_cache,last_sub_language_in_cache,all_subs,last_sub_in_cache_is_empty,notify_now=True):
    global quick_sub_value,quick_sub_value_sig,dont_place_sub,_mando_prefetch_ready_msg
    # For settings changes to take effect.
    Addon=xbmcaddon.Addon()
    from resources.modules.general import ensure_cache_dirs
    ensure_cache_dirs()

    if Addon.getSetting("enable_autosub_notifications")=='true':
        try:
            from resources import main
            if not getattr(main, 'from_autosub', False):
                general.show_msg="מוריד כתובית נבחרת"
        except Exception:
            pass
    # Default placing sub to the first subtitle in subtitles list results.
    selected_sub=f_result[0]
    cached_choice = None
    log.warning(f"place_sub | selected_sub BEFORE checking last sub in cache: {selected_sub}")
    # Changing subtitle to place to subtitles from database.db cache db (if exists)
    if not last_sub_in_cache_is_empty:
        from resources.modules.general import _subtitle_matches_current_video
        if _subtitle_matches_current_video(last_sub_name_in_cache, video_data):
            for f_sub in f_result:
                if (last_sub_name_in_cache==f_sub[8]) and (last_sub_language_in_cache==f_sub[0]):
                    selected_sub=f_sub
                    cached_choice=f_sub
                    break
        else:
            log.warning(
                'place_sub | ignoring stale cache entry: {0}'.format(last_sub_name_in_cache))
    log.warning(f"place_sub | selected_sub AFTER checking last sub in cache: {selected_sub}")

    try_list = _prioritize_hebrew_candidates(list(f_result), Addon)

    if cached_choice is not None and cached_choice in try_list:
        # The user explicitly chose this one before (manual pick from the
        # search list, or next/previous) -- re-try it first instead of
        # silently re-running the auto best-match ranking and placing
        # something different. Falls back to the normal ranked order below
        # if it's no longer present in this search's results.
        try_list = [cached_choice] + [s for s in try_list if s != cached_choice]
        log.warning('place_sub | trying last user-chosen sub first: {0}'.format(last_sub_name_in_cache))

    if not try_list:
        log.warning('place_sub | no subs to place after filters')
        return None, None

    c_sub_file = None
    filename = None
    place_sub_count = 0
    for f_sub in try_list:
        place_sub_count += 1
        selected_sub = f_sub

        params=get_params(f_sub[4],"")
        download_data=unque(params["download_data"])
        download_data=json.loads(download_data)
        source=(params["source"])
        language=(params["language"])
        filename=unque(params["filename"])
        try:
                
            is_embedded = source in ('HebrewSubEmbedded', 'EnglishSubEmbedded')
            if is_embedded:
                from resources.modules.engine import activate_embedded_sub
                lang = 'heb' if source == 'HebrewSubEmbedded' else 'eng'
                if activate_embedded_sub(lang, max_wait_sec=5) is None:
                    raise Exception('embedded activate failed')
                sub_file = 'EmbeddedSubSelected'
            else:
                sub_file = download_sub(source, download_data, MySubFolder, language, filename)
            log.warning('Auto Sub result:'+str(sub_file))
            if sub_file == 'FaultSubException':
                raise Exception('download_sub failed: %s' % sub_file)

            if is_embedded:
                quick_sub_value = download_data.get('url', '')
                quick_sub_value_sig = _video_identity_key(video_data)
                sync_pct = str(selected_sub[5]) if len(selected_sub) > 5 else '101'
                if not sync_pct or sync_pct == '0':
                    sync_pct = '101'
                if Addon.getSetting("enable_autosub_notifications") == 'true':
                    emb_src = 'HebrewSubEmbedded' if 'HebrewSubEmbedded' in str(
                        params.get('filename', '')) or source == 'HebrewSubEmbedded' else source
                    _show_manual_subtitle_ready(
                        language, emb_src, '', filename,
                        sync_percent=sync_pct)
                save_file_name(params["filename"], language, video_data)
                log.warning(
                    'DEBUG | place_sub | embedded sub placed | sync={0}'.format(sync_pct))
                break

            xbmc.sleep(200)
            wait_for_video()
            quick_sub_value=sub_file
            quick_sub_value_sig = _video_identity_key(video_data)
            if not dont_place_sub:
                log.warning(f'setSubtitles:317 {sub_file}')
                embedded_streams.set_external_subtitles(sub_file)
                try:
                    from resources.modules.ai_translate import settings_guard
                    uses_gemini_ai = settings_guard.is_gemini_translate_enabled()
                except Exception:
                    uses_gemini_ai = (
                        Addon.getSetting('auto_translate') == 'true'
                        and Addon.getSetting('translate_p') == '2'
                    )
                try:
                    from resources import main
                    autosub_run = getattr(main, 'from_autosub', False)
                except Exception:
                    autosub_run = False
                if Addon.getSetting("enable_autosub_notifications") == 'true' and not autosub_run:
                    _show_manual_subtitle_ready(
                        language, source, sub_file, filename,
                        uses_gemini=(
                            language != 'Hebrew'
                            and Addon.getSetting('auto_translate') == 'true'
                            and uses_gemini_ai),
                        sync_percent=(
                            str(selected_sub[5]) if len(selected_sub) > 5 else '101'))
                elif autosub_run and Addon.getSetting("enable_autosub_notifications") == 'true':
                    try:
                        from resources.modules.engine import format_website_source_name
                        site = format_website_source_name(source)
                        sync = str(selected_sub[5]) if len(selected_sub) > 5 else '101'
                        if not sync or sync == '0':
                            sync = '101'
                        lang = translate_sub_language_to_hebrew(language)
                        msg = '{0} | {1}% | {2}'.format(lang, sync, site)
                        if notify_now:
                            notify(msg, times=_SUBTITLE_READY_NOTIFY_MS)
                            general.show_msg = (
                                '[COLOR lightblue]כתובית מוכנה[/COLOR]\n' + msg)
                        else:
                            # mando prefetch: nothing is on screen yet -- defer
                            # the toast until play_auto_sub re-applies this sub
                            # for the live player (see _mando_prefetch_ready_msg).
                            _mando_prefetch_ready_msg = msg
                            log.warning(
                                'place_sub | deferred mando prefetch ready toast: {0}'.format(msg))
                    except Exception as e:
                        log.warning('autosub subtitle ready notify failed: {0}'.format(e))
                
                save_file_name(params["filename"],language,video_data)
                
                f_count=0
                max_sub_cache=int(Addon.getSetting("subtitle_trans_cache"))
                for filename_o in os.listdir(CachedSubFolder):
                    f_count+=1
                
                if (f_count>max_sub_cache):
                        for filename_o in os.listdir(CachedSubFolder):
                            f = os.path.join(CachedSubFolder, filename_o)
                            os.remove(f)
                try:
                    file_type=(os.path.splitext(sub_file)[1])
                except:
                    file_type=""
                c_sub_file=os.path.join(CachedSubFolder, f"{source}_{language}_{filename}{file_type}")
                if not os.path.exists(c_sub_file):
                        if file_type=='.idx'  or file_type=='.sup':
                            shutil.copy(sub_file,c_sub_file.replace('idx','sub').replace('sup','sub'))
                        try:
                            shutil.copy(sub_file,c_sub_file)
                        except Exception as e:
                            log.warning(f"shutil.copy(sub_file,c_sub_file) | Exception: {str(e)}")
                            pass
                

                
                # Break the loop since setting external subtitle was successful.
                log.warning(f"DEBUG | place_sub | Number of try: {place_sub_count} | Successfuly set external sub: {sub_file}")
                break
            else:
                break
        except Exception as e:
            # Try the next Hebrew subtitle (never downgrade to English when Hebrew exists).
            log.warning(f"DEBUG | place_sub | Number of try: {place_sub_count} | Exception in Sub: {str(e)}")
            log.warning(f"DEBUG | place_sub | Number of try: {place_sub_count} | failed sub: {f_sub[0]} | {f_sub[8]}")
            continue
            
    return c_sub_file,filename
def display_subtitle(f_result,video_data,last_sub_name_in_cache,last_sub_language_in_cache,all_subs,argv1):
    
    all_d=[]
    sub_final_data=[]
    for items in f_result:
            try:
                val = all_subs.get(items[8])
            except Exception:
                val=None

            if (last_sub_name_in_cache==items[8]) and (last_sub_language_in_cache==items[0]):
                added_string='[COLOR FFFF00FE][B][I] >>> '
            elif 'SubEmbedded' in str(items[8]):
                added_string='[COLOR cyan][B][I]'
            elif val and items[0] in val:
                added_string='[COLOR deepskyblue][B][I]'
            else:
                added_string='[COLOR gold]'
            if xbmc.Player().isPlaying():
                sub_name=added_string+str(items[5])+ "% "+'[/COLOR]'+items[1]
                if ('[B][I]' in added_string):
                    sub_name=sub_name+'[/I][/B]'
                if video_data['file_original_path'].replace("."," ").lower() in items[1].replace("."," ").lower() and len(video_data['file_original_path'].replace("."," "))>5 or items[5]>80:
                         #json_value['label2']='[COLOR gold] GOLD [B]'+json_value['label2']+'[/B][/COLOR]'
                         sub_name='[COLOR gold] GOLD '+sub_name+'[/COLOR]'
            else:
                sub_name=items[1]
            
            item_url = items[4]
            if 'sync_pct=' not in item_url and len(items) > 5:
                item_url = '{0}{1}sync_pct={2}'.format(
                    item_url, '&' if '?' in item_url else '?', int(items[5]))

            sub_final_data.append({'label':items[0],
                                  'label2':sub_name, 
                                  'iconImage':items[2],
                                  'thumbnailImage':items[3],
                                  'url':item_url,
                                  
                                  "sync": items[6],
                                  "hearing_imp":items[7]})
                                       
                
    sub_final_data.append({'label':"מקומית",
                          'label2':'[B][COLOR lightgreen][I]'+ "DarkSubs - טען כתובית מקומית"+'[/I][/COLOR][/B]',
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url':"plugin://%s/?action=browse_local_sub" % (MyScriptID),
                          "sync": "",
                          "hearing_imp":"",
                          "menu_item": True})

    sub_final_data.append({'label':"הגדרות",
                          'label2':'[B][COLOR plum][I]'+ "DarkSubs - הגדרות"+'[/I][/COLOR][/B]', 
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url':"plugin://%s/?action=open_settings" % (MyScriptID),
                          "sync": "",
                          "hearing_imp":"",
                          "menu_item": True})
                          
    sub_final_data.append({'label':"קאש",
                          'label2':'[B][COLOR khaki][I]'+"DarkSubs - ניקוי קאש"+'[/I][/COLOR][/B]',  
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url':"plugin://%s/?action=clean_all_cache" % (MyScriptID),
                          "sync": "",
                          "hearing_imp":"",
                          "menu_item": True})
                          
    sub_final_data.append({'label':"חלון",
                          'label2':'[B][COLOR lightblue][I]'+ "DarkSubs - חלון כתוביות"+'[/I][/COLOR][/B]', 
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url': "plugin://%s/?action=sub_window"% (MyScriptID),
                          "sync": "",
                          "hearing_imp":"",
                          "menu_item": True})
                          
    sub_final_data.append({'label':"ביטול",
                          'label2':'[B][COLOR seagreen][I]'+ "DarkSubs - בטל כתוביות"+'[/I][/COLOR][/B]', 
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url':"plugin://%s/?action=disable_subs"% (MyScriptID),
                          "sync": "",
                          "hearing_imp":"",
                          "menu_item": True})
    log.warning(f'DEBUG | display_subtitle | Returning {len(sub_final_data)} items')
    return sub_final_data
def get_params(argv2,argv1):
    if argv2!="None":
        param = dict(parse_qsl(argv2.replace('?','')))
    else:
        
        param={}
        param['action']=argv1
    return param


def _parse_main_arg(arg):
    parts = arg.split('$$$$$$$$')
    argv2 = parts[0]
    argv1 = parts[1] if len(parts) > 1 else ''
    req_id = parts[2] if len(parts) > 2 else ''
    return argv2, argv1, req_id


def _publish_main_return(Addon, req_id, return_result):
    from resources.modules.ai_translate import kodi_bridge
    json_str = json.dumps(return_result)
    kodi_bridge.set_return(req_id, json_str)
    log.warning('DEBUG | sub_from_main | published return key={0} len={1}'.format(
        kodi_bridge.return_setting_key(req_id), len(json_str)))


def sub_from_main(arg):
    global is_embedded_hebrew_sub_exists
    ipc_store.clear('main_search_subs')
    # For settings changes to take effect.
    Addon=xbmcaddon.Addon()
    argv2, argv1, req_id = _parse_main_arg(arg)
    params = get_params(argv2,argv1)

    video_data=get_video_data()
    action=None
    
    
    try:        
        action=(params["action"])
    except:
            pass
    log.warning(f"DEBUG | sub_from_main | action={action} | params={params}")
    try:
        download_data=unque(params["download_data"])
        download_data=json.loads(download_data)
    except:
        pass
    try:
        source=(params["source"])
    except:
        source = ''
    try:
        filename=unque(params["filename"])
    except:
        pass
    try:
        language=(params["language"])
    except:
        language = ''
    from resources.modules import general
    try:
        from resources.modules.ai_translate import settings_guard
        from resources.modules.engine import subtitle_needs_machine_translate
        _gemini_on = settings_guard.is_gemini_translate_enabled()
    except Exception:
        subtitle_needs_machine_translate = None
        _gemini_on = (
            Addon.getSetting('auto_translate') == 'true'
            and Addon.getSetting('translate_p') == '2'
        )
    try:
        _needs_translate = subtitle_needs_machine_translate(language, source)
    except Exception:
        _needs_translate = language != 'Hebrew' and source not in (
            'HebrewSubEmbedded', 'EnglishSubEmbedded')

    uses_gemini_download = (
        action == 'download'
        and _gemini_on
        and _needs_translate
        and Addon.getSetting('fast_first_chunk') != 'true'
    )
    uses_fast_gemini = (
        action == 'download'
        and _gemini_on
        and _needs_translate
        and Addon.getSetting('fast_first_chunk') == 'true'
    )

    if (action != "sub_window_unpause" and action != "sub_window" and action != "search"
            and Addon.getSetting("enable_autosub_notifications") == 'true'
            and not uses_gemini_download):
        try:
            from resources import main
            if not getattr(main, 'from_autosub', False):
                general.show_msg = "מוריד כתוביות"
        except Exception:
            general.show_msg = "מוריד כתוביות"
    elif uses_gemini_download or uses_fast_gemini:
        general.show_msg = 'END'
        ipc_store.write('gemini_translate_progress', '0')
        ipc_store.write('gemini_translate_done', '0')
        ipc_store.write('gemini_translate_total', '0')

    thread = []
    # action=='search' already shows its own DialogProgress in main.py --
    # starting this overlay too just duplicates the progress indicator.
    if not uses_gemini_download and not uses_fast_gemini and action != 'search':
        thread.append(Thread(show_results))
        thread[0].start()
    video_data.pop('state', None)
    video_data.pop('media_type_videoInfoTag', None)
    video_data.pop('is_local_media_playing', None)
    log.warning(video_data)
    if action=='search':
        
     
        
        from resources import main
        main.from_autosub = False
        tag_original2=""
        tag_original3=""
        tag_original=""
        file_org=""
        search_language_hebrew_bool = (Addon.getSetting('language_hebrew') == 'true' or Addon.getSetting("all_lang") == 'true')
        if xbmc.Player().isPlaying() and not embedded_streams.external_sub_loaded():
            if not embedded_streams.snapshot_has_genuine_tracks():
                embedded_streams.capture_initial(1)
        is_embedded_hebrew_sub_exists = False
        tag_original2=video_data.get('VideoPlayer.Tagline','')
        video_data.pop('VideoPlayer.Tagline',None) 
        if 'year' in video_data:
                if video_data['year'] == '':
                    video_data['year'] = '0'
        tag_original3=video_data.get('Tagline_From_Fen')
        video_data.pop('Tagline_From_Fen',None) 
        
        tag_original=video_data.get('Tagline')
        file_org=video_data.get('file_original_path')
        log.warning('Normal Search:')
        log.warning(video_data)

        sig_video = dict(video_data)
        sig_video['Tagline'] = tag_original
        sig_video['file_original_path'] = file_org
        sig_video['picked_release'] = tag_original

        if search_language_hebrew_bool and load_session_sub_results(sig_video, sorted_list=True) is None:
            is_embedded_hebrew_sub_exists = check_if_embedded_sub_exists(embedded_language='heb')

        f_result = load_session_sub_results(sig_video, sorted_list=True)
        if f_result is not None:
            log.warning('sub_from_main | reusing autosub sorted session')
            general.show_msg = 'END'
        else:
            session_raw = load_session_sub_results(sig_video, sorted_list=False)
            if session_raw is not None:
                log.warning('sub_from_main | reusing autosub raw session — fast sort only')
                general.show_msg = 'END'
                f_result = sort_subtitles(session_raw, sig_video, fast_mode=True)
            else:
                f_result = cache.get(get_subtitles, 24, _subtitle_search_cache_data(video_data), table='subs')
                video_data['file_original_path'] = file_org
                video_data['Tagline'] = tag_original
                video_data['VideoPlayer.Tagline'] = tag_original2
                video_data['Tagline_From_Fen'] = tag_original3
                f_result = sort_subtitles(f_result, video_data, fast_mode=True)
                general.show_msg = 'END'

        video_data['file_original_path'] = file_org
        video_data['Tagline'] = tag_original
        video_data['VideoPlayer.Tagline'] = tag_original2
        video_data['Tagline_From_Fen'] = tag_original3
        f_result = [] if not f_result else f_result
        f_result = add_embbded_subs_to_subs_list(video_data, f_result)
        last_sub_name_in_cache, last_sub_language_in_cache, all_subs = get_db_data(video_data)
        return_result = display_subtitle(
            f_result, video_data, last_sub_name_in_cache,
            last_sub_language_in_cache, all_subs, argv1)
        log.warning(f'DEBUG | sub_from_main | action=search | f_result count: {len(f_result)}')
        log.warning(f'DEBUG | sub_from_main | action=search | return_result type: {type(return_result).__name__}')
        log.warning(f'DEBUG | sub_from_main | action=search | return_result length: {len(return_result) if isinstance(return_result, (list, dict)) else "N/A"}')
        
    
    elif action=='download':
        if source in ('HebrewSubEmbedded', 'EnglishSubEmbedded'):
            from resources.modules.engine import activate_embedded_sub
            lang = 'heb' if source == 'HebrewSubEmbedded' else 'eng'
            if activate_embedded_sub(lang, max_wait_sec=5, clear_external=True) is not None:
                save_video = dict(video_data)
                save_video['Tagline'] = (
                    video_data.get('Tagline')
                    or video_data.get('picked_release')
                    or video_data.get('file_original_path')
                    or '')
                save_file_name(filename, language, save_video)
                _publish_main_return(Addon, req_id, 'EmbeddedSubSelected')
                general.show_msg = 'END'
                notify('התרגום המובנה יופיע בעוד 10 שניות')
                _show_manual_subtitle_ready(
                    language, source, '', '',
                    sync_percent='101')
                return
            notify('לא נמצאה כתובית מובנת בנגן')
            _publish_main_return(Addon, req_id, '')
            general.show_msg = 'END'
            return

        all_download_data=((source,download_data,MySubFolder,language,filename))
        log.warning(all_download_data)
        log.warning(params["filename"])
        sub_file=download_sub(source,download_data,MySubFolder,language,filename)
        fault=False
        if sub_file=='EmbeddedSubSelected':
            return
        elif sub_file=='FaultSubException':
            notify( 'תקלה בהורדה נסה שנית' )
            return_result = ''
        else: # External subtitle
        
            log.warning('Auto Sub result:'+str(sub_file))
            xbmc.sleep(100)
            log.warning('setSubtitles:572')
            embedded_streams.set_external_subtitles(sub_file)
            save_file_name(filename,language,video_data)
            _show_manual_subtitle_ready(
                language, source, sub_file, filename,
                uses_gemini=uses_gemini_download or uses_fast_gemini,
                sync_percent=params.get('sync_pct', ''))
            f_count=0
            max_sub_cache=int(Addon.getSetting("subtitle_trans_cache"))
            for filename_o in os.listdir(CachedSubFolder):
                
                f_count+=1
            
            if (f_count>max_sub_cache):
                    for filename_o in os.listdir(CachedSubFolder):
                        f = os.path.join(CachedSubFolder, filename_o)
                        os.remove(f) 
      

            try:
                file_type=(os.path.splitext(sub_file)[1])
            except:
                file_type=""
            c_sub_file=os.path.join(CachedSubFolder, f"{source}_{language}_{filename}{file_type}")
            
            if not os.path.exists(c_sub_file):
                    if file_type=='.idx' or file_type=='.sup':
                        shutil.copy(sub_file,c_sub_file.replace('idx','sub').replace('sup','sub'))
                    
                    try:
                        shutil.copy(sub_file,c_sub_file)
                    except Exception as e:
                        log.warning(f"shutil.copy(sub_file,c_sub_file) | Exception: {str(e)}")
                        pass
            return_result = sub_file
        
    elif action in ('open_settings', 'browse_local_sub'):
        # Handled locally in main.py — service path is fallback only
        return_result = action
        _publish_main_return(Addon, req_id, return_result)
        general.show_msg = 'END'
        return
    elif action=='clean':
        cache.clear(['subs'])
        notify( "קאש כתוביות נוקה" )
        return_result = action
    elif action=='clean_all_cache':
        xbmc.executebuiltin("RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)")
        return_result = action
    elif action=='disable_subs':
        xbmc.Player().setSubtitles("")
        return_result = action
        notify("כתוביות בוטלו")
    elif action=='sub_window':
        thread=[]
                    
        thread.append(Thread(run_my_window))

        thread[0].start()

        f_result, last_sub_name_in_cache, last_sub_language_in_cache, all_subs = _fetch_ranked_subs(video_data)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.Player().pause()
        window = MySubs('DarkSubs - חלון כתוביות' ,f_result,f_result,video_data,all_subs,last_sub_name_in_cache,last_sub_language_in_cache)
        return_result=json.dumps(action)
    elif action=='sub_window_unpause':
        f_result, last_sub_name_in_cache, last_sub_language_in_cache, all_subs = _fetch_ranked_subs(video_data)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        window = MySubs('DarkSubs - חלון כתוביות' ,f_result,f_result,video_data,all_subs,last_sub_name_in_cache,last_sub_language_in_cache)
        return_result=json.dumps(action)
    elif action=='next':
        from resources.modules import general
        general.show_msg="כתובית הבאה"
        log.warning(general.show_msg)
        thread=[]
                    
        thread.append(Thread(show_results))

        thread[0].start()

        f_result, last_sub_name_in_cache, last_sub_language_in_cache, all_subs = _fetch_ranked_subs(video_data)
        next_one=False
        selected_sub=None
        for items in f_result:
            if (next_one):
                if (last_sub_name_in_cache!=items[8]) and (last_sub_language_in_cache!=items[0]):
                    selected_sub=items
                    
                    break
                else:
                    next_one=False
            if (last_sub_name_in_cache==items[8]) and (last_sub_language_in_cache==items[0]):
                next_one=True
            
        if selected_sub:
            params=get_params(selected_sub[4],"")
            download_data=unque(params["download_data"])
            download_data=json.loads(download_data)
            source=(params["source"])
            language=(params["language"])
            filename=params["filename"]
            general.show_msg="מוריד"
            sub_file=download_sub(source,download_data,MySubFolder,language,filename)
            log.warning('Next Sub result:'+str(sub_file))
            general.show_msg="מוכן"
            if (sub_file!='EmbeddedSubSelected') and (sub_file!='FaultSubException'):
                log.warning('setSubtitles:755')
                embedded_streams.set_external_subtitles(sub_file)
            save_file_name(filename,language,video_data)
            
        else:
            general.show_msg="סוף הכתוביות"
            
        xbmc.sleep(800)
        general.show_msg="END"
        return_result=json.dumps(action)
    elif action=='previous':
        from resources.modules import general
        general.show_msg="כתובית קודמת"
        
        thread=[]
                    
        thread.append(Thread(show_results))

        thread[0].start()
        f_result, last_sub_name_in_cache, last_sub_language_in_cache, all_subs = _fetch_ranked_subs(video_data)
        pre_one=None
        found=None
        for items in f_result:
            if (found):
                if ((pre_one) and (last_sub_name_in_cache!=pre_one[8]) and (last_sub_language_in_cache!=pre_one[0])):
                    selected_sub=pre_one
                    
                    break
                else:
                    found=None
            if (last_sub_name_in_cache==items[8]) and (last_sub_language_in_cache==items[0]):
                found=True
            else:
                pre_one=items
        log.warning('found_P:'+str(found))
        if found:
            params=get_params(selected_sub[4],"")
            download_data=unque(params["download_data"])
            download_data=json.loads(download_data)
            source=(params["source"])
            language=(params["language"])
            filename=params["filename"]
            sub_file=download_sub(source,download_data,MySubFolder,language,filename)
            
            log.warning('previous Sub result:'+str(sub_file))
            general.show_msg=sub_file
            xbmc.sleep(100)
            if (sub_file!='EmbeddedSubSelected') and (sub_file!='FaultSubException'):
                log.warning('setSubtitles:832')
                embedded_streams.set_external_subtitles(sub_file)
                save_file_name(filename,language,video_data)
            else:
                save_file_name(unque(filename),language,video_data)
                
        else:
            general.show_msg="זאת הכתובית הראשונה"
            xbmc.sleep(800)
        general.show_msg="END"
        return_result=json.dumps(action)
    elif action=='clean_folders':
        general.show_msg="מוחק קבצים"
        try:
            shutil.rmtree(CachedSubFolder)
        except: pass
        xbmcvfs.mkdirs(CachedSubFolder)
        try:
            shutil.rmtree(TransFolder)
        except: pass
        xbmcvfs.mkdirs(TransFolder)
        return_result=json.dumps(action)
        general.show_msg="END"
        xbmc.sleep(300)

        if not os.path.exists(CachedSubFolder):
             os.makedirs(CachedSubFolder)


        if not os.path.exists(TransFolder):
             os.makedirs(TransFolder)
             
        notify( "קאש תרגום מכונה נוקה" )

    log.warning(f'DEBUG | sub_from_main | Setting main_search_return | return_result defined: {"return_result" in locals()}')
    if 'return_result' in locals():
        log.warning(f'DEBUG | sub_from_main | return_result type: {type(return_result).__name__} | length: {len(return_result) if isinstance(return_result, (list, dict)) else len(str(return_result))}')
        _publish_main_return(Addon, req_id, return_result)
        log.warning('DEBUG | sub_from_main | setSetting completed successfully')
    else:
        log.warning('ERROR | sub_from_main | return_result NOT DEFINED - this is the bug!')
        _publish_main_return(Addon, req_id, [])
    general.show_msg="END"


def is_hebrew(term):
    """
    Check if a character or string contains Hebrew characters.
    BUGFIX: Handle both str and unicode properly for Python 2/3 compatibility.
    """
    try:
        if not term:
            return False
        
        # Ensure we're working with a string
        if not isinstance(term, str):
            try:
                term = str(term)
            except:
                return False
        
        import unicodedata
        hebrew = False
        
        for i in term:
            try:
                # Skip empty characters
                if not i or not i.strip():
                    continue
                    
                if 'HEBREW' in unicodedata.name(i.strip()):
                    hebrew = True
                    break
            except (ValueError, TypeError):
                # Character doesn't have a unicode name, skip it
                continue
        
        return hebrew
        
    except Exception as e:
        log.warning(f'Error in is_hebrew:{e}')
        return False


def _try_swap_to_late_embedded(video_data, tag_original, file_org, Addon, poll_sec=3):
    """Embedded MKV subtitle streams can take a few seconds after playback
    starts before Kodi finishes enumerating them (see
    embedded_streams.capture_at_play_start's own 1-4s wait). If an external
    subtitle was already placed because the embedded track wasn't visible yet
    at decision time, briefly poll once more and switch to the embedded
    track if it has since appeared and settings prefer it.
    """
    if Addon.getSetting('auto_place_hebrew_embedded_subs') != 'true':
        return False
    search_hebrew = (
        Addon.getSetting('language_hebrew') == 'true'
        or Addon.getSetting('all_lang') == 'true')
    if not search_hebrew:
        return False

    index_sub = embedded_streams.genuine_embedded_index('heb', max_wait_sec=poll_sec)
    if index_sub is None:
        return False

    place_video = dict(video_data)
    place_video['Tagline'] = tag_original
    place_video['picked_release'] = tag_original
    place_video['file_original_path'] = file_org or tag_original
    log.warning('DEBUG | late-embedded swap: embedded heb became available after external was placed')
    return set_embedded_hebrew_sub(place_video, max_wait_sec=2)


def _decide_and_place_subtitle(video_data, f_result, last_sub_name_in_cache, last_sub_language_in_cache,
                                all_subs, tag_original, file_org, search_language_hebrew_bool,
                                first_external_sub_language, Addon, allow_embedded_check=True):
    """Shared embedded-vs-external placement decision.

    allow_embedded_check=False is for triggers that run before the player has
    started (mando's prefetch): there's no live subtitle-stream state to check
    yet, so this goes straight to ranking/placing an external subtitle.

    When an external result list is already available (cached/ready), it gets
    placed immediately instead of first blocking on embedded-track detection
    (determine_placeHebrewEmbeddedSub alone can cost ~2s of polling, on top of
    whatever capture_at_play_start already spent) -- the only exception is the
    zero-cost check for "Kodi already has an embedded track active on screen",
    which needs no polling. Once the external sub is showing,
    _try_swap_to_late_embedded upgrades to embedded Hebrew if it turns out to
    be present and preferred, so the user isn't left staring at nothing while
    the addon decides. Blocking on embedded detection is only still done when
    there's no external result at all -- then it's the only thing worth
    waiting for.
    """
    global already_placed_sub, dont_place_sub

    last_sub_in_cache_is_empty, last_sub_in_cache_is_heb_embedded, last_sub_in_cache_is_external = \
        _last_sub_cache_state(last_sub_name_in_cache)

    def _place_video():
        pv = dict(video_data)
        pv['Tagline'] = tag_original
        pv['picked_release'] = tag_original
        pv['file_original_path'] = file_org or tag_original
        return pv

    embedded_placed = False
    sub_name = None
    sub_filename = None

    if (allow_embedded_check and f_result
            and _player_has_active_subtitles()
            and is_embedded_hebrew_sub_exists
            and embedded_streams.genuine_embedded_index('heb', max_wait_sec=0) is not None
            and Addon.getSetting('auto_place_hebrew_embedded_subs') == 'true'):
        log.warning(
            'play_auto_sub | active embedded heb on screen — skip external place_sub')
        if set_embedded_hebrew_sub(_place_video(), max_wait_sec=3):
            embedded_placed = True
            already_placed_sub = True
            dont_place_sub = True
            general.show_msg = 'END'

    if not embedded_placed and f_result:
        if allow_embedded_check:
            if Addon.getSetting("enable_autosub_notifications") == 'true':
                general.show_msg = "מוריד כתובית"
            wait_for_video()
        sub_name, sub_filename = place_sub(
            _place_video(), f_result, last_sub_name_in_cache, last_sub_language_in_cache,
            all_subs, last_sub_in_cache_is_empty, notify_now=allow_embedded_check)
        if sub_name:
            already_placed_sub = True
            if allow_embedded_check and Addon.getSetting("enable_autosub_notifications") == 'true':
                xbmc.sleep(_SUBTITLE_READY_NOTIFY_MS)
            general.show_msg = 'END'

            # Don't override a sub the user explicitly chose external over an
            # available embedded track last time they played this exact video.
            if (allow_embedded_check and not last_sub_in_cache_is_external
                    and _try_swap_to_late_embedded(video_data, tag_original, file_org, Addon)):
                embedded_placed = True

    elif not embedded_placed and not f_result and allow_embedded_check:
        # No external result to show at all -- embedded detection is the only
        # option left, so it's worth blocking on here.
        placeHebrewEmbeddedSub = False
        if search_language_hebrew_bool and Addon.getSetting('auto_place_hebrew_embedded_subs') == 'true':
            placeHebrewEmbeddedSub = determine_placeHebrewEmbeddedSub(
                last_sub_in_cache_is_external, last_sub_in_cache_is_heb_embedded, first_external_sub_language)

        if placeHebrewEmbeddedSub:
            log.warning('DEBUG | Placing embedded Hebrew sub.')
            if set_embedded_hebrew_sub(_place_video(), max_wait_sec=5):
                embedded_placed = True
                already_placed_sub = True
                dont_place_sub = True
                general.show_msg = 'END'

    return embedded_placed, sub_name, sub_filename


def play_auto_sub():
        global video_id,pre_video_id,trigger,dont_place_sub
        global playing_addon,break_wait,quick_sub_value,quick_sub_value_sig,already_placed_sub
        global _autosub_running_sig,_mando_prefetch_ready_msg,_mando_prefetch_done_key
        mando_prefetch_reapplied = False
        progress_overlay_started = False
        run_sig = None
        acquired = False
        try:

            Addon=xbmcaddon.Addon()
            from resources.modules import general
            last_sub_name_in_cache=""
            is_playing_addon_excluded=False
            manual_search=""
            while  manual_search!='':
                manual_search=ipc_store.read('fast_subs')
                xbmc.sleep(100)

            video_data=get_video_data()
            video_key = _video_identity_key(video_data)
            # sub_from_mando_quick runs on its own thread and can still be
            # actively searching/placing a subtitle for this exact video
            # (mando prefetches while resolving playback sources, so this can
            # still be in flight right as Player.OnPlay fires) -- wait briefly
            # for it to finish instead of racing its embedded-stream snapshot
            # and setSubtitles call, which otherwise causes both false
            # "embedded track found" detections and this function's own
            # stale-sub cleanup below wiping the subtitle it just placed.
            if (_mando_prefetch_busy_key == video_key
                    and Addon.getSetting("enable_autosub_notifications") == 'true'):
                # The video is already playing (Player.OnPlay just fired) --
                # mando doesn't block playback on the subtitle search, it only
                # triggers it, so there's no reason for the user to see
                # nothing while this function waits below for that in-flight
                # search to finish. Closed once the wait ends, either by the
                # reapply path below (general.show_msg = 'END') or by the
                # normal search/place flow taking over.
                general.show_msg = "מחפש כתוביות"
                Thread(show_results).start()
                progress_overlay_started = True
            for _ in range(25):
                if _mando_prefetch_busy_key != video_key:
                    break
                xbmc.sleep(200)
            run_sig = _autosub_play_signature(video_data)
            if _autosub_running_sig == run_sig:
                log.warning('play_auto_sub | skip duplicate run')
                return
            _autosub_running_sig = run_sig
            acquired = True
            pre_video_id=video_id
      
            video_id=video_data['OriginalTitle']+video_data['imdb']+str(video_data['season'])+str(video_data['episode'])
            
            if (video_id!=pre_video_id):
                
                
                trigger=True
                clear_session_sub_results()
            # Always trigger autosub, even when replaying the same content    
            
            # pre_video_id=video_id
            

            sub_name=None
            global is_embedded_hebrew_sub_exists
            is_embedded_hebrew_sub_exists=False
            embedded_streams.reset()
            wait_for_video()
            # Peek (without consuming) whether mando's prefetch already has a
            # ready external file for this exact video -- if so, the trigger
            # block below re-applies it immediately, so there's no point
            # blocking that on the embedded-track poll's full budget first.
            fast_path_available = (
                quick_sub_value_sig == video_key
                and isinstance(quick_sub_value, str)
                and os.path.isfile(quick_sub_value))
            _capture_embedded_at_play_start(full_poll=not fast_path_available)
        
            if  trigger:
                trigger=False
                f_result=None
                if 'OriginalTitle' in video_data:
                    test_name=video_data['OriginalTitle']
                else:
                    test_name=video_data['title']
                check_auto=is_hebrew(test_name)
                log.warning('check_auto::'+str(check_auto))
                log.warning(test_name)

                # Drop path/index from a genuinely previous playback; never
                # re-apply here. Checked against video_key (not just
                # truthiness) so this doesn't wipe a subtitle sub_from_mando_quick
                # just placed for THIS same video on its own thread (quick_sub_value_sig
                # would match video_key in that case, not "previous title").
                stale_quick_sub = quick_sub_value
                is_same_video = quick_sub_value_sig == video_key
                # Tied to the same quick_sub_value lifecycle (both set together
                # by place_sub() during the SAME prefetch call) -- consumed here
                # unconditionally so a message meant for this video can't leak
                # into a later, unrelated one if is_same_video ever comes out
                # False for it.
                stale_ready_msg = _mando_prefetch_ready_msg
                _mando_prefetch_ready_msg = ""
                quick_sub_value = ""
                quick_sub_value_sig = ""
                if stale_quick_sub and not is_same_video:
                    try:
                        xbmc.Player().setSubtitles('')
                        log.warning(
                            'play_auto_sub | cleared external sub from previous title')
                    except Exception:
                        pass
                elif (stale_quick_sub and is_same_video
                        and isinstance(stale_quick_sub, str)
                        and os.path.isfile(stale_quick_sub)):
                    # mando's prefetch (sub_from_mando_quick) already found and
                    # downloaded this exact subtitle for this exact video --
                    # its own setSubtitles() call can land before the real
                    # playback session begins and get silently dropped by Kodi
                    # (see _try_skip_external_search). wait_for_video() above
                    # already confirmed the player is live now, so re-apply the
                    # already-downloaded file directly instead of waiting for
                    # _try_skip_external_search's check to fail and falling all
                    # the way back to a brand new search -- this is a local
                    # file, so it's effectively instant.
                    embedded_streams.set_external_subtitles(stale_quick_sub)
                    already_placed_sub = True
                    # Don't rely on _try_skip_external_search's own
                    # has_external_subtitle_active() re-check below to confirm
                    # this -- it queries Kodi's live getAvailableSubtitleStreams()
                    # immediately after setSubtitles(), which doesn't always
                    # reflect the new stream that fast yet (confirmed in a real
                    # kodi.log: the exact same "none active" fallback this
                    # elif exists to avoid, now firing moments after this
                    # elif's own setSubtitles() call, sending the whole thing
                    # into a redundant full re-search anyway). We already know
                    # this succeeded -- we just set an existing, valid file.
                    mando_prefetch_reapplied = True
                    _mando_prefetch_done_key = ""
                    log.warning(
                        'play_auto_sub | re-applied mando prefetch subtitle for live player: {0}'.format(
                            stale_quick_sub))
                    # Overlay's job here is just "searching..." progress -- close
                    # it now that something's placed; the toast below (like
                    # every other placement path) is what announces "ready".
                    general.show_msg = 'END'
                    if stale_ready_msg and Addon.getSetting("enable_autosub_notifications") == 'true':
                        notify(stale_ready_msg, times=_SUBTITLE_READY_NOTIFY_MS)
                        log.warning(
                            'play_auto_sub | fired deferred mando prefetch ready toast: {0}'.format(
                                stale_ready_msg))
                    else:
                        log.warning(
                            'play_auto_sub | no deferred toast to fire | stale_ready_msg={0!r} | '
                            'enable_autosub_notifications={1}'.format(
                                stale_ready_msg, Addon.getSetting("enable_autosub_notifications")))
                    # mando's prefetch never checks embedded tracks (there's no
                    # live player yet when it runs -- see _decide_and_place_subtitle's
                    # allow_embedded_check=False docstring), so it always picks
                    # external. Now that the player is genuinely live, give
                    # embedded Hebrew the same chance to override it that the
                    # normal Auto Search path already gives its own external
                    # placements, instead of permanently locking in mando's
                    # external-only choice.
                    _try_swap_to_late_embedded(
                        video_data, video_data.get('Tagline'),
                        video_data.get('file_original_path'), Addon)

                force_download=True
                if  Addon.getSetting("force")=='true':
                  force_download=True
                if  Addon.getSetting("force")=='false' and _player_has_active_subtitles():
                  force_download=False
                if Addon.getSetting("force")=='false' and embedded_streams.snapshot_has_genuine_tracks():
                  force_download=False
                
                
                log.warning('playing_addon::'+str(playing_addon))

                search_language_hebrew_bool = (
                    Addon.getSetting('language_hebrew') == 'true'
                    or Addon.getSetting('all_lang') == 'true')

                if Addon.getSetting("autosub")=='true':
                  try:
                      movieFullPath = xbmc.Player().getPlayingFile()

                      is_playing_addon_excluded=isPlayingAddonExcluded(movieFullPath,playing_addon)
                  except: pass
                  if is_playing_addon_excluded:
                    trigger=False

                  if not is_playing_addon_excluded and (mando_prefetch_reapplied or _try_skip_external_search(
                          video_data, search_language_hebrew_bool)):
                      force_download = False
                      general.show_msg = 'END'
                  
                  if is_playing_addon_excluded and not check_auto:
                        if _autosub_is_stale(run_sig):
                            general.show_msg = 'END'
                            return
                        search_language_hebrew_bool = (Addon.getSetting('language_hebrew') == 'true' or Addon.getSetting("all_lang") == 'true')
                        is_embedded_hebrew_sub_exists = False
                        if search_language_hebrew_bool:
                            is_embedded_hebrew_sub_exists = check_if_embedded_sub_exists(embedded_language='heb')
                            log.warning(f'is_embedded_hebrew_sub_exists:{is_embedded_hebrew_sub_exists}')
                        placeHebrewEmbeddedSub = False
                        if search_language_hebrew_bool and is_embedded_hebrew_sub_exists:
                            first_external_sub_language = ''
                            last_sub_in_cache_is_empty, last_sub_in_cache_is_heb_embedded, last_sub_in_cache_is_external = _last_sub_cache_state(last_sub_name_in_cache)
                            placeHebrewEmbeddedSub = determine_placeHebrewEmbeddedSub(last_sub_in_cache_is_external, last_sub_in_cache_is_heb_embedded, first_external_sub_language)
                                    
                        log.warning(f"DEBUG | placeHebrewEmbeddedSub: {placeHebrewEmbeddedSub}")   
                  
                        if placeHebrewEmbeddedSub:
                            xbmc.executebuiltin('Dialog.Close(all,true)')
                            wait_for_video()
                            log.warning('DEBUG | Placing embedded Hebrew sub.')
                            result=set_embedded_hebrew_sub(video_data)
                            if result:
                                dont_place_sub=True
                                already_placed_sub = True
                  if force_download==True and not is_playing_addon_excluded:

                    if  Addon.getSetting("pause")=='true':
                        xbmc.Player().pause()
                    
                    if already_placed_sub == False:
                        general.show_msg = "מחפש כתוביות"
                    thread=[]
                    from resources import main
                    main.from_autosub=True
                    if Addon.getSetting("enable_autosub_notifications")=='true' and not progress_overlay_started:
                        thread.append(Thread(show_results))
                        thread[0].start()
                    
                    video_data.pop('state', None)
                    video_data.pop('is_local_media_playing', None)
                    try:
                        tag_original2=video_data.get('VideoPlayer.Tagline','')
                        video_data.pop('VideoPlayer.Tagline',None)

                        tag_original3=video_data.get('Tagline_From_Fen')
                        video_data.pop('Tagline_From_Fen',None)

                        tag_original=video_data.get('Tagline')
                        file_org=video_data.get('file_original_path')
                        if 'year' in video_data:
                            if video_data['year'] == '':
                                video_data['year'] = '0'

                        if _autosub_is_stale(run_sig):
                            general.show_msg = 'END'
                            return

                        search_language_hebrew_bool = (
                            Addon.getSetting('language_hebrew') == 'true'
                            or Addon.getSetting('all_lang') == 'true')

                        log.warning('Auto Search:')
                        log.warning(video_data)
                        f_result=cache.get(get_subtitles,24,_subtitle_search_cache_data(video_data),table='subs')
                        video_data['VideoPlayer.Tagline']=tag_original2
                        video_data['Tagline_From_Fen']=tag_original3
                        video_data['picked_release'] = tag_original
                        f_result = [] if not f_result else f_result
                        if f_result:
                            save_session_sub_results(video_data, f_result)

                        if _autosub_is_stale(run_sig):
                            general.show_msg = 'END'
                            return

                        f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
                        f_result = [] if not f_result else f_result

                        if _autosub_is_stale(run_sig):
                            general.show_msg = 'END'
                            return

                        _refresh_embedded_hebrew_after_search()
                        f_result = add_embbded_subs_to_subs_list(video_data, f_result)
                        
                        video_data.pop('Tagline', None)
                        video_data.pop('file_original_path', None)

                        video_data['Tagline'] = tag_original
                        video_data['file_original_path'] = file_org
                        last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)
                        video_data.pop('Tagline', None)
                        video_data.pop('file_original_path', None)
                        
                        if len(f_result) > 0:
                            first_external_sub_params = get_params(f_result[0][4], "")
                            first_external_sub_language = first_external_sub_params.get("language")
                        else:
                            first_external_sub_language = ''
                        
                        last_sub_in_cache_is_empty, last_sub_in_cache_is_heb_embedded, last_sub_in_cache_is_external = _last_sub_cache_state(last_sub_name_in_cache)

                        embedded_placed, sub_name, sub_filename = _decide_and_place_subtitle(
                            video_data, f_result, last_sub_name_in_cache, last_sub_language_in_cache,
                            all_subs, tag_original, file_org, search_language_hebrew_bool,
                            first_external_sub_language, Addon, allow_embedded_check=True)

                        if not embedded_placed:
                            if Addon.getSetting("enable_autosub_notifications")=='true':
                                if not sub_name:
                                    general.show_msg="[COLOR red]אין כתוביות[/COLOR]"
                                    xbmc.sleep(2000)
                                    general.show_msg = 'END'
                                
                                if search_language_hebrew_bool and is_embedded_hebrew_sub_exists and not embedded_placed:
                                    notify( "קיים גם תרגום מובנה בעברית" )
      
                    except Exception as e:
                        import linecache
              
                        exc_type, exc_obj, tb = sys.exc_info()
                        f = tb.tb_frame
                        lineno = tb.tb_lineno
                        filename = f.f_code.co_filename
                        linecache.checkcache(filename)
                        log.warning('Error in subs:'+str(e)+','+'line:'+str(lineno))
                        general.show_msg = 'END'
                        
                        
                  else:
                    log.warning('Not Downloading:')
                    log.warning(f"force_download={force_download}")
                    log.warning(f"is_playing_addon_excluded={is_playing_addon_excluded}")
        finally:
            if acquired and run_sig and _autosub_running_sig == run_sig:
                _autosub_running_sig = None
            general.show_msg="END"
                    
ipc_store.clear('main_search_subs')
ipc_store.clear('fast_subs')
ipc_store.clear('quick_subs')
def sub_from_mando(Mando_search):
    from resources import main
    ipc_store.clear('fast_subs')
            
    video_data=unque(Mando_search)
    
    video_data=json.loads(video_data)
    
    if 'imdb' not in video_data:
        video_data=get_video_data()
    if 'TVShowTitle' not in video_data:
        video_data['TVShowTitle']=""
    if 'mpaa' not in video_data:
        video_data['mpaa']=""
    if 'year' in video_data:
        if video_data['year'] == '':
            video_data['year'] = '0'
    video_data['title']=clean_title(video_data['title'])
    video_data['OriginalTitle']=clean_title(video_data['OriginalTitle'])
    video_data['TVShowTitle']=clean_title(video_data['TVShowTitle'])
    from resources import main
    main.from_autosub=True
    log.warning('Mando_search:')
    log.warning(video_data)



    f_result=cache.get(get_subtitles,24,_subtitle_search_cache_data(video_data),table='subs')

    ipc_store.write('fast_search_return', json.dumps(f_result))
def sub_from_mando_quick(Mando_quick_subs):
            global already_placed_sub, _mando_prefetch_busy_key, _mando_prefetch_done_key
            ipc_store.clear('quick_subs')
            video_data=unque(Mando_quick_subs)

            video_data=json.loads(video_data)



            log.warning(video_data)
            if 'imdb' not in video_data:
                video_data=get_video_data()
            if 'TVShowTitle' not in video_data:
                video_data['TVShowTitle']=""

            if 'year' in video_data:
                if video_data['year'] == '':
                    video_data['year'] = '0'
            video_data['title']=clean_title(video_data['title'])
            video_data['OriginalTitle']=clean_title(video_data['OriginalTitle'])
            video_data['TVShowTitle']=clean_title(video_data['TVShowTitle'])
            from resources import main
            main.from_autosub=True
            tag_original=video_data['Tagline']
            # play_auto_sub (Player.OnPlay, its own thread) waits briefly on
            # this so it doesn't race this function's embedded-stream
            # snapshot / setSubtitles / quick_sub_value writes for the same
            # video -- without it, play_auto_sub can catch the external file
            # this function just loaded and mistake it for a genuine MKV
            # embedded track, or clear the subtitle this function just placed
            # thinking it's stale from the previous title.
            _mando_prefetch_busy_key = _video_identity_key(video_data)
            try:
                log.warning('FoundMando_search33:')
                log.warning(video_data)
                f_result=cache.get(get_subtitles,24,_subtitle_search_cache_data(video_data),table='subs')

                #video_data=get_video_data()

                video_data['Tagline']=tag_original
                video_data['Tagline']=tag_original
                video_data['VideoPlayer.Tagline']=tag_original
                video_data['Tagline_From_Fen']=tag_original
                video_data['file_original_path']=tag_original
                log.warning("Mando_quick_subs_sort::")
                log.warning(video_data)

                f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
                f_result = [] if not f_result else f_result
                # Gets last chosen subtitle from subtitles cache DB (if exists) for playing video tagline.
                last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)

                # Get sub language of first subtitle in external subs list found.
                if len(f_result) > 0:
                    first_external_sub_params = get_params(f_result[0][4], "")
                    first_external_sub_language = first_external_sub_params.get("language")
                else:
                    first_external_sub_language = ''

                last_sub_in_cache_is_empty, last_sub_in_cache_is_heb_embedded, last_sub_in_cache_is_external = _last_sub_cache_state(last_sub_name_in_cache)

                embedded_placed, sub_name, sub_filename = _decide_and_place_subtitle(
                    video_data, f_result, last_sub_name_in_cache, last_sub_language_in_cache,
                    all_subs, tag_original, tag_original, False, first_external_sub_language,
                    Addon, allow_embedded_check=False)
                if sub_name:
                    _mando_prefetch_done_key = _video_identity_key(video_data)
                if Addon.getSetting("enable_autosub_notifications")=='true':
                    if sub_name:
                        general.show_msg=f"[COLOR lightblue]כתובית מוכנה\n{sub_filename}[/COLOR]" if last_sub_in_cache_is_empty else f"[COLOR lightblue]כתובית מוכנה\n{sub_filename}\n(הכתובית נבחרה מהקאש)[/COLOR]"
                    else:
                        general.show_msg="[COLOR red]אין כתוביות[/COLOR]"

                    # Show the message for 5 seconds before general.show_msg="END"
                    #xbmc.sleep(5000)
            finally:
                if _mando_prefetch_busy_key == _video_identity_key(video_data):
                    _mando_prefetch_busy_key = ""
class KodiMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        _dispatch_ipc_triggers()

    def onNotification(self, sender, method, data):
        global video_id,pre_video_id,trigger,dont_place_sub
        global playing_addon,break_wait,quick_sub_value
        # For settings changes to take effect.
        
        if method=='Player.OnStop':
            global _autosub_running_sig
            _autosub_running_sig = None
            trigger=False
            dont_place_sub=False
            video_id=""
            xbmcgui.Window(10000).setProperty("subs.player_filename","")
            xbmcgui.Window(10000).setProperty("subs.player_file_url","")
            break_wait=True
            
        if method=='Player.OnPlay':
            log.warning('Player ONONON::')
            global already_placed_sub
            already_placed_sub = False
            thread=[]
            
            thread.append(Thread(play_auto_sub))
            
            thread[0].start()
    
            
            general.show_msg="END"


def _dispatch_ipc_triggers():
    manual_search = ipc_store.take('main_search_subs')
    if manual_search:
        thread = []
        thread.append(Thread(sub_from_main, manual_search))
        thread[0].start()
        general.show_msg = "END"

    Mando_search = ipc_store.take('fast_subs')
    if Mando_search:
        thread = []
        thread.append(Thread(sub_from_mando, Mando_search))
        thread[0].start()

    Mando_quick_subs = ipc_store.take('quick_subs')
    if Mando_quick_subs:
        thread = []
        thread.append(Thread(sub_from_mando_quick, Mando_quick_subs))
        thread[0].start()


monitor=KodiMonitor()

try:
    from resources.modules.release_publisher import ReleaseFilenamePlayer
    _release_filename_player = ReleaseFilenamePlayer()
    log.warning('DarkSubs ReleaseFilenamePlayer started')
except Exception as e:
    log.warning('ReleaseFilenamePlayer failed to start: {0}'.format(e))

###################################################################################################################################################
# Auto clean DarkSubs cache + machine translate folders on Kodi startup.
if  Addon.getSetting("clean_cache_on_startup") == 'true':
    try:
        log.warning("Clean cache on startup Starting...")
        xbmc.executebuiltin("RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)")
        log.warning("Clean cache on startup Finished.")
    except Exception as e:
        log.warning(f"Clean cache on startup FAILED. ERROR: {str(e)}")
        pass
###################################################################################################################################################

try:
    from resources.modules.ai_translate import settings_guard
    settings_guard.sanitize_user_settings()
    ipc_store.migrate_legacy_settings_to_ipc()
    removed = ipc_store.cleanup_ephemeral_settings()
    if removed:
        log.warning('DarkSubs: removed {0} ephemeral keys from settings.xml'.format(removed))
    ipc_store.cleanup_ipc_files()
except Exception as e:
    log.warning('DarkSubs IPC cleanup failed: {0}'.format(e))

while not ab_req:
    playing_addon = general.get_playing_addon(playing_addon)
    _dispatch_ipc_triggers()
    if monitor.waitForAbort(1):
       break
del monitor