import sys
import urllib.parse
import urllib.request
import re
import os
import subprocess
import json
import xbmcgui
import xbmcplugin
import xbmc

# 1. הגדרות שרת וכתובות האתר
SITE_SCHEME = "https"
SITE_DOMAIN = "seret"
SITE_TLD = "top"
BASE_URL = SITE_SCHEME + "://" + SITE_DOMAIN + "." + SITE_TLD

API_SCHEME = "https"
API_HOST = "effecttv.vercel.app"
API_PATH = "/api"
API_URL = API_SCHEME + "://" + API_HOST + API_PATH

# 2. חילוץ נתיבי קבצי המקור המקומיים בתוך תיקיית ההרחבה
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LOCAL_ICON = os.path.join(ADDON_DIR, "icon.png")
LOCAL_FANART = os.path.join(ADDON_DIR, "fanart.jpg")
M3U8_FILE_PATH = os.path.join(ADDON_DIR, "movies_sorted.M3U8") # נתיב לקובץ ה-M3U8 החדש
M3U8_FILE_PATH3 = os.path.join(ADDON_DIR, "movies_sorted3.M3U8") # נתיב לקובץ ה-M3U8 השלישי

# הגדרת ידית קודי (HANDLE) בצורה בטוחה
HANDLE = -1
if len(sys.argv) > 1:
    try:
        HANDLE = int(sys.argv[1])
    except (ValueError, TypeError):
        pass

def load_movies_database():
    json_path = os.path.join(ADDON_DIR, 'movies_db.json')
    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data["movies"] if isinstance(data, dict) and "movies" in data else data
        except Exception:
            return []
    return []

def load_series_database():
    json_path = os.path.join(ADDON_DIR, 'series_db.json')
    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data["series"] if isinstance(data, dict) and "series" in data else data
        except Exception:
            return []
    return []

MOVIES_DATABASE = load_movies_database()
SERIES_DATABASE = load_series_database()

# קטגוריות סרטים נקיות (ללא הרשתות והז'אנרים)
GENRES = [
    {"name": "כל הסרטים (רשימה מלאה)", "slug": "all"},
    {"name": "סרטים מדובבים וילדים", "slug": "kids"},
    {"name": "רק סרטים מדובבים", "slug": "dubbed"},
    {"name": "סרטי אימה ומתח", "slug": "horror"},
    {"name": "פשע ופעולה", "slug": "crime"},
    {"name": "קולנוע ישראלי", "slug": "israeli"},
]

# קטגוריות סדרות (תכלת)
SERIES_CATEGORIES = [
    {"name": "חיפוש סדרה במאגר", "slug": "search_series"},
    {"name": "טלנבלות ישראליות", "slug": "טלנבלות ישראליות"},
    {"name": "סדרות טורקיות", "slug": "סדרות טורקיות"},
    {"name": "סדרות חול", "slug": "סדרות חול"},
    {"name": "סדרות ישראליות", "slug": "סדרות ישראליות"},
    {"name": "סדרות לילדים ונוער", "slug": "סדרות לילדים ונוער"},
    {"name": "סדרות מדובבות", "slug": "סדרות מדובבות"},
]

def get_current_player():
    mode = xbmcgui.Window(10000).getProperty("seret_top_player_mode")
    return mode if mode else "kodi"

def set_current_player(mode):
    xbmcgui.Window(10000).setProperty("seret_top_player_mode", mode)

def get_page_size():
    size = xbmcgui.Window(10000).getProperty("seret_top_page_size")
    return int(size) if size else 250

def cycle_page_size():
    """מעבר בלחיצה בין האופציות 250 -> 5000 -> 11000 -> 250"""
    current = get_page_size()
    mapping = {250: 5000, 5000: 11000, 11000: 250}
    new_size = mapping.get(current, 250)
    xbmcgui.Window(10000).setProperty("seret_top_page_size", str(new_size))

def create_directory_item(name, url, is_folder=True, thumb=None, fanart=None):
    if HANDLE != -1:
        list_item = xbmcgui.ListItem(label=name)
        art = {}
        if thumb:
            art.update({'thumb': thumb, 'icon': thumb, 'poster': thumb})
        if fanart:
            art.update({'fanart': fanart})
        if art:
            list_item.setArt(art)
        if not is_folder:
            list_item.setProperty('IsPlayable', 'true')
            list_item.setInfo('video', {'title': name, 'mediatype': 'movie'})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)

def build_main_menu():
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""
    
    # 1. חיפוש סרטים (צהוב)
    search_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'main_search'})
    create_directory_item("[COLOR yellow]חפש סרט במאגר[/COLOR]", search_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
    
    # הוספת קטגוריית "סרטים 2" (M3U8) מיד אחרי החיפוש הראשי בתפריט הראשי
    m3u8_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_m3u8_movies'})
    create_directory_item("[COLOR gold] סרטים 2 (פלייליסט)[/COLOR]", m3u8_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)

    # הוספת קטגוריית "סרטים 3" (M3U8) המכוונת לאקשן נפרד
    m3u8_url3 = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_m3u8_movies3'})
    create_directory_item("[COLOR gold] סרטים 3 (פלייליסט)[/COLOR]", m3u8_url3, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)

    # 2. סרטים וז'אנרים מסוננים (תכלת)
    for genre in GENRES:
        create_directory_item(f"[COLOR teal]{genre['name']}[/COLOR]", base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_movies', 'slug': genre["slug"], 'filter_type': 'genre', 'page_num': '1'}), is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
        
    # 3. קטגוריית סדרות אב (תכלת)
    series_main_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_series_menu'})
    create_directory_item("[COLOR teal]סדרות[/COLOR]", series_main_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
        
    # 4. הגדרות נגן וכמויות (דינמי)
    current_player = get_current_player()
    player_label = "[COLOR green]נגן פעיל: קודי (לחץ למעבר ל-VLC)[/COLOR]" if current_player == "kodi" else "[COLOR orange]נגן פעיל: VLC חיצוני (לחץ למעבר לקודי)[/COLOR]"
    create_directory_item(player_label, base_plugin_path + "?" + urllib.parse.urlencode({'action': 'toggle_player'}), is_folder=False, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
    
    create_directory_item(f"מספר סרטים בעמוד: [COLOR green]{get_page_size()}[/COLOR]", base_plugin_path + "?" + urllib.parse.urlencode({'action': 'toggle_page_size'}), is_folder=False, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
        
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)

def list_m3u8_movies3(search_query=None):
    """פונקציה ייעודית לקריאה וטעינה של קובץ ה-M3U8 השלישי למסך קודי עם אפשרות סינון"""
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'movies')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""

    if not os.path.exists(M3U8_FILE_PATH3):
        xbmcgui.Dialog().ok("שגיאה", "קובץ movies_sorted3.M3U8 לא נמצא בתיקיית ההרחבה!")
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, False)
        return

    try:
        with open(M3U8_FILE_PATH3, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except Exception as e:
        xbmcgui.Dialog().ok("שגיאה", f"נכשל קריאת קובץ ה-M3U8 השלישי:\n{str(e)}")
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, False)
        return

    # הוספת כפתור חיפוש ייעודי בראש הרשימה
    if not search_query:
        search_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'm3u8_search', 'playlist_num': '3'})
        create_directory_item("[COLOR yellow] חפש סרט ברשימה זו...[/COLOR]", search_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
        create_directory_item("-------------------------------------------", "#", is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)

    current_title = ""
    current_icon = ""

    for line in lines:
        line = line.strip()
        if not line or line.startswith("#EXTM3U"):
            continue

        if line.startswith("#EXTINF"):
            title_match = line.split(",")[-1].strip()
            current_title = title_match if title_match else "סרט ללא שם"
            
            logo_match = re.search(r'tvg-logo="([^"]+)"', line)
            current_icon = logo_match.group(1) if logo_match else LOCAL_ICON
        elif line.startswith("http"):
            # אם יש שאילתת חיפוש, נציג רק סרטים שמתאימים לה
            if search_query and search_query.lower() not in current_title.lower():
                current_title = ""
                current_icon = ""
                continue
                
            url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'play_m3u8_link', 'title': current_title, 'target_url': line})
            create_directory_item(current_title, url, is_folder=False, thumb=current_icon, fanart=LOCAL_FANART)
            current_title = ""
            current_icon = ""

    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)

def list_m3u8_movies(search_query=None):
    """פונקציה ייעודית לקריאה וטעינה של קובץ ה-M3U8 השני למסך קודי עם אפשרות סינון"""
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'movies')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""

    if not os.path.exists(M3U8_FILE_PATH):
        xbmcgui.Dialog().ok("שגיאה", "קובץ movies_sorted.M3U8 לא נמצא בתיקיית ההרחבה!")
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, False)
        return

    try:
        with open(M3U8_FILE_PATH, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except Exception as e:
        xbmcgui.Dialog().ok("שגיאה", f"נכשל קריאת קובץ ה-M3U8:\n{str(e)}")
        if HANDLE != -1:
            xbmcplugin.endOfDirectory(HANDLE, False)
        return

    # הוספת כפתור חיפוש ייעודי בראש הרשימה
    if not search_query:
        search_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'm3u8_search', 'playlist_num': '2'})
        create_directory_item("[COLOR yellow] חפש סרט ברשימה זו...[/COLOR]", search_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
        create_directory_item("-------------------------------------------", "#", is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)

    current_title = ""
    current_icon = ""

    for line in lines:
        line = line.strip()
        if not line or line.startswith("#EXTM3U"):
            continue

        if line.startswith("#EXTINF"):
            title_match = line.split(",")[-1].strip()
            current_title = title_match if title_match else "סרט ללא שם"
            
            logo_match = re.search(r'tvg-logo="([^"]+)"', line)
            current_icon = logo_match.group(1) if logo_match else LOCAL_ICON
        elif line.startswith("http"):
            # אם יש שאילתת חיפוש, נציג רק סרטים שמתאימים לה
            if search_query and search_query.lower() not in current_title.lower():
                current_title = ""
                current_icon = ""
                continue
                
            url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'play_m3u8_link', 'title': current_title, 'target_url': line})
            create_directory_item(current_title, url, is_folder=False, thumb=current_icon, fanart=LOCAL_FANART)
            current_title = ""
            current_icon = ""

    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)

def list_movies(slug, filter_type, page_num=1):
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'movies')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""
    page_num = int(page_num)
    page_size = get_page_size()
    
    filtered_items = []
    for item in MOVIES_DATABASE:
        # סינון שנים משופר: בודק רק אם קיימת שנה תקינה, ולא פוסל סרטים ללא שנה במאגר הנוכחי
        movie_year = item.get("year", "")
        if movie_year and str(movie_year).isdigit():
            if int(movie_year) < 2000:
                continue

        match = False
        if filter_type == 'genre':
            if slug == 'all' or slug in item.get("genres", []):
                match = True
        if match:
            filtered_items.append(item)
            
    start_idx = (page_num - 1) * page_size
    end_idx = start_idx + page_size
    page_items = filtered_items[start_idx:end_idx]
    
    # ניווט עליון
    if page_num > 1:
        prev_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_movies', 'slug': slug, 'filter_type': filter_type, 'page_num': str(page_num - 1)})
        create_directory_item(f"[COLOR cyan]▲ עמוד קודם ({page_num - 1}) ▲[/COLOR]", prev_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
    if end_idx < len(filtered_items):
        next_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_movies', 'slug': slug, 'filter_type': filter_type, 'page_num': str(page_num + 1)})
        create_directory_item(f"[COLOR orange]▼ עמוד הבא ({page_num + 1}) ▼[/COLOR]", next_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
        
    if page_num > 1 or end_idx < len(filtered_items):
        create_directory_item("-------------------------------------------", "#", is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)

    for item in page_items:
        year_str = f" ({item['year']})" if item.get("year") else ""
        display_name = f"{item['title']}{year_str}"
        full_site_url = BASE_URL + "/main/watch/movie/" + item['id']
        url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'play_live_video', 'title': display_name, 'target_url': full_site_url})
        create_directory_item(display_name, url, is_folder=False, thumb=item.get("thumb"), fanart=LOCAL_FANART)
        
    if page_num > 1 or end_idx < len(filtered_items):
        create_directory_item("-------------------------------------------", "#", is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
    if page_num > 1:
        prev_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_movies', 'slug': slug, 'filter_type': filter_type, 'page_num': str(page_num - 1)})
        create_directory_item(f"[COLOR cyan]▲ עמוד קודם ({page_num - 1}) ▲[/COLOR]", prev_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
    if end_idx < len(filtered_items):
        next_url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_movies', 'slug': slug, 'filter_type': filter_type, 'page_num': str(page_num + 1)})
        create_directory_item(f"[COLOR orange]▼ עמוד הבא ({page_num + 1}) ▼[/COLOR]", next_url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
        
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)

def list_series_menu():
    """הצגת תפריט קטגוריות הסדרות הראשי"""
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'tvshows')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""
    
    for cat in SERIES_CATEGORIES:
        if cat["slug"] == "search_series":
            url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'series_search'})
            create_directory_item(f"[COLOR teal]{cat['name']}[/COLOR]", url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
        else:
            url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_series_by_category', 'category': cat["slug"]})
            create_directory_item(f"[COLOR teal]{cat['name']}[/COLOR]", url, is_folder=True, thumb=LOCAL_ICON, fanart=LOCAL_FANART)
            
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)

def list_series_by_category(category_name):
    """הצגת כל הסדרות השייכות לקטגוריה מסוימת"""
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'tvshows')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""
    
    for item in SERIES_DATABASE:
        if item.get("category") == category_name:
            url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_seasons', 'series_title': item["title"]})
            display_name = f"[COLOR teal]{item['title']}[/COLOR]"
            create_directory_item(display_name, url, is_folder=True, thumb=item.get("thumb") or LOCAL_ICON, fanart=LOCAL_FANART)
            
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)

def list_seasons(series_title):
    """הצגת העונות של סדרה שנבחרה"""
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'seasons')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""
    
    for item in SERIES_DATABASE:
        if item["title"] == series_title:
            seasons = item.get("seasons", {})
            for s_key in sorted(seasons.keys()):
                s_num = seasons[s_key]["season_number"]
                url = base_plugin_path + "?" + urllib.parse.urlencode({
                    'action': 'list_episodes', 
                    'series_title': series_title,
                    'season_key': s_key
                })
                display_name = f"[COLOR teal]עונה {s_num}[/COLOR]"
                create_directory_item(display_name, url, is_folder=True, thumb=item.get("thumb") or LOCAL_ICON, fanart=LOCAL_FANART)
            break
            
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(series_title, season_key):
    """הצגת הפרקים של עונה מסוימת בסדרה תוך בניית הלינק מה-ID הקצר באופן מדויק"""
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'episodes')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""
    
    for item in SERIES_DATABASE:
        if item["title"] == series_title:
            episodes = item.get("seasons", {}).get(season_key, {}).get("episodes", [])
            for ep in episodes:
                short_id = ep.get("id", "") # למשל: "8027/S01E02"
                
                if "/" in short_id:
                    series_id, ep_code = short_id.split("/")
                    s_match = re.search(r'[sS](\d+)', ep_code)
                    s_num = int(s_match.group(1)) if s_match else 1
                    
                    # תיקון: בניית הכתובת המלאה דרך הדומיין הנכון והנתיב המצופה של האתר
                    full_site_url = f"{BASE_URL}/main/watch/series/{series_id}/season/season{s_num}/episode/{ep_code}"
                else:
                    full_site_url = ep.get("url", "")

                # תיקון: החלפת ה-& ב-| עבור ה-Referer במידה ומדובר בלינק המשובש
                url = base_plugin_path + "?" + urllib.parse.urlencode({
                    'action': 'play_live_video', 
                    'title': f"{series_title} - פרק {ep['episode_number']}", 
                    'target_url': full_site_url
                })
                display_name = f"[COLOR teal]פרק {ep['episode_number']}[/COLOR]"
                create_directory_item(display_name, url, is_folder=False, thumb=item.get("thumb") or LOCAL_ICON, fanart=LOCAL_FANART)
            break
            
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)


def do_series_search():
    """ביצוע חיפוש סדרות במאגר המקומי"""
    dialog = xbmcgui.Dialog()
    search_term = dialog.input('חפש סדרה במאגר:', type=xbmcgui.INPUT_ALPHANUM)
    if not search_term:
        return
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'tvshows')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""
    
    for item in SERIES_DATABASE:
        if search_term.lower() in item["title"].lower():
            url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'list_seasons', 'series_title': item["title"]})
            display_name = f"[COLOR teal]{item['title']}[/COLOR]"
            create_directory_item(display_name, url, is_folder=True, thumb=item.get("thumb") or LOCAL_ICON, fanart=LOCAL_FANART)
            
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)


def play_m3u8_link(title, target_url):
    """מנגן את הקישור הישיר השלוף מקובץ ה-M3U8 בקודי או בנגן VLC חיצוני"""
    import subprocess
    import os
    import time

    headers_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    current_player = get_current_player()
    
    if current_player == "kodi":
        kodi_headers = f"|User-Agent={headers_agent}&Referer=https://seret.top"
        final_playable_url = str(target_url) + kodi_headers

        list_item = xbmcgui.ListItem(path=final_playable_url)
        list_item.setContentLookup(False)
        list_item.setInfo('video', {'title': title})
        
        if xbmc.getCondVisibility("system.platform.windows"):
            # במחשב נמשיך להשתמש ב-ffmpegdirect למניעת תקיעות
            list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
            list_item.setProperty('inputstream.ffmpegdirect.is_live', 'false') 
            list_item.setProperty('inputstream.ffmpegdirect.stream_protocol', 'ffmpeg')
            list_item.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_timeout', '20') 
            list_item.setProperty('inputstream.ffmpegdirect.http_reconnect', 'true')
        else:
            # באנדרואיד/סטרימר ננקה לחלוטין כמו בגרסה 1.0.6 כדי לעקוף את הבאג
            list_item.setProperty('inputstream', '')
        
        if HANDLE != -1:
            xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        return

    # הרצת VLC חיצוני
    if xbmc.getCondVisibility("system.platform.windows"):
        vlc_path = r"C:\Program Files\VideoLAN\VLC\vlc.exe"
        if os.path.exists(vlc_path):
            subprocess.Popen([vlc_path, str(target_url), "--http-user-agent=" + headers_agent, "--http-referrer=https://seret.top", "--fullscreen", "--play-and-exit"])


def play_live_video(title, target_url):
    import subprocess
    import os
    import time

    if "effecttv.vercel.app" in str(target_url):
        playable_link = str(target_url)
    else:
        playable_link = API_URL + "?url=" + str(target_url)
        
    headers_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    current_player = get_current_player()
    
    if current_player == "kodi":
        kodi_headers = f"|User-Agent={headers_agent}&Referer=https://seret.top"
        final_playable_url = playable_link + kodi_headers

        list_item = xbmcgui.ListItem(path=final_playable_url)
        list_item.setContentLookup(False)
        list_item.setInfo('video', {'title': title})
        
        if xbmc.getCondVisibility("system.platform.windows"):
            # במחשב נשמור על ה-ffmpegdirect היציב
            list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
            list_item.setProperty('inputstream.ffmpegdirect.is_live', 'false') 
            list_item.setProperty('inputstream.ffmpegdirect.stream_protocol', 'ffmpeg')
            list_item.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_timeout', '20') 
            list_item.setProperty('inputstream.ffmpegdirect.http_reconnect', 'true')
        else:
            # באנדרואיד ננקה לחלוטין כדי לעקוף את הבאג של ה-32bit
            list_item.setProperty('inputstream', '')
            
        retry_count = 3
        for attempt in range(retry_count):
            try:
                xbmc.log(f"Seret.top Addon: Playback Attempt {attempt + 1} out of {retry_count}", xbmc.LOGINFO)
                
                # שליחת פקודת הניגון לקודי
                xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
                
                # מתן חלון זמן סבלני של 12 שניות לקודי לבצע את ה-Buffering הראשוני של הוידאו
                for check in range(12):
                    time.sleep(1)
                    if xbmc.Player().isPlayingVideo():
                        xbmc.log("Seret.top Addon: Playback started successfully and stabilized!", xbmc.LOGINFO)
                        return # הצלחנו בניגון, יוצאים מהפונקציה בבטחה
                        
            except Exception as e:
                xbmc.log(f"Seret.top Addon: Playback attempt exception: {str(e)}", xbmc.LOGWARNING)
            
            # אם עברו 8 שניות והסרט עדיין לא מנגן, נפעיל את הניסיון הבא
            if attempt < retry_count - 1:
                xbmcgui.Dialog().notification("מנסה להתחבר שוב", f"שרת איטי. מריץ ניסיון חיבור ({attempt + 2}/{retry_count})...", xbmcgui.NOTIFICATION_INFO, 2500)
                time.sleep(2)
        
        # אם כל 3 הניסיונות נכשלו והאינטרנט באמת התייאש
        xbmcgui.Dialog().ok("שגיאת טעינה", "נכשל חיבור רשת לזרם המדיה.\nאנא ודא ששרת ה-Vercel זמין ונסה שוב.")
        return

    # הרצת VLC
    if xbmc.getCondVisibility("system.platform.windows"):
        vlc_path = r"C:\Program Files\VideoLAN\VLC\vlc.exe"
        if os.path.exists(vlc_path):
            subprocess.Popen([vlc_path, playable_link, "--http-user-agent=" + headers_agent, "--http-referrer=https://seret.top", "--fullscreen", "--play-and-exit"])


def do_search():
    dialog = xbmcgui.Dialog()
    search_term = dialog.input('חפש סרט במאגר סרט טופ:', type=xbmcgui.INPUT_ALPHANUM)
    if not search_term:
        return
    if HANDLE != -1:
        xbmcplugin.setContent(HANDLE, 'movies')
    base_plugin_path = sys.argv[0] if len(sys.argv) > 0 else ""
    
    for item in MOVIES_DATABASE:
        if search_term.lower() in item["title"].lower():
            # סינון שנים בחיפוש: מעל שנת 2000
            movie_year = item.get("year", "")
            if movie_year and movie_year.isdigit() and int(movie_year) < 2000:
                continue
            
            year_str = f" ({item['year']})" if item.get("year") else ""
            display_name = f"{item['title']}{year_str}"
            full_site_url = BASE_URL + "/main/watch/movie/" + item['id']
            url = base_plugin_path + "?" + urllib.parse.urlencode({'action': 'play_live_video', 'title': display_name, 'target_url': full_site_url})
            create_directory_item(display_name, url, is_folder=False, thumb=item.get("thumb"), fanart=LOCAL_FANART)
            
    if HANDLE != -1:
        xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    clean_param_str = ""
    if isinstance(paramstring, list):
        if len(paramstring) > 2:
            clean_param_str = str(paramstring[2])
        elif len(paramstring) > 1:
            clean_param_str = str(paramstring[1])
    else:
        clean_param_str = str(paramstring)

    clean_params = clean_param_str.lstrip('?')
    params = dict(urllib.parse.parse_qsl(clean_params))
    action = params.get('action')
    
    if action == 'list_movies':
        list_movies(params.get('slug'), params.get('filter_type'), params.get('page_num', '1'))
    elif action == 'list_m3u8_movies':
        list_m3u8_movies(params.get('query'))
    elif action == 'list_m3u8_movies3':
        list_m3u8_movies3(params.get('query'))
    elif action == 'list_series_menu':
        list_series_menu()
    elif action == 'list_series_by_category':
        list_series_by_category(params.get('category'))
    elif action == 'list_seasons':
        list_seasons(params.get('series_title'))
    elif action == 'list_episodes':
        list_episodes(params.get('series_title'), params.get('season_key'))
    elif action == 'series_search':
        do_series_search()
    elif action == 'play_m3u8_link':
        current_player = get_current_player()
        if current_player == "vlc":
            if HANDLE != -1:
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            play_m3u8_link(params.get('title'), params.get('target_url'))
            xbmc.executebuiltin("Dialog.Close(all, true)")
        else:
            play_m3u8_link(params.get('title'), params.get('target_url'))
    elif action == 'play_live_video':
        current_player = get_current_player()
        if current_player == "vlc":
            if HANDLE != -1:
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            play_live_video(params.get('title'), params.get('target_url'))
            xbmc.executebuiltin("Dialog.Close(all, true)")
        else:
            play_live_video(params.get('title'), params.get('target_url'))
    elif action == 'toggle_player':
        old_player = get_current_player()
        new_player = "vlc" if old_player == "kodi" else "kodi"
        set_current_player(new_player)
        xbmc.executebuiltin("Container.Refresh")
    elif action == 'toggle_page_size':
        cycle_page_size()
        xbmc.executebuiltin("Container.Refresh")
    elif action == 'main_search':
        do_search()
    elif action == 'm3u8_search':
        dialog = xbmcgui.Dialog()
        search_term = dialog.input('חפש סרט ברשימה זו:', type=xbmcgui.INPUT_ALPHANUM)
        if search_term:
            playlist_num = params.get('playlist_num', '2')
            if playlist_num == '2':
                list_m3u8_movies(search_term)
            else:
                list_m3u8_movies3(search_term)
    else:
        build_main_menu()

if __name__ == '__main__':
    router(sys.argv)
