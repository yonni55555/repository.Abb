# -*- coding: utf-8 -*-
import re, os, sys, time, json, requests, hashlib, gzip, collections, random, zipfile
import xbmc, xbmcvfs, xbmcgui, xbmcplugin, xbmcaddon
from urllib.parse import urlencode, parse_qsl
from datetime import datetime, timedelta

# הגדרות בסיס
addon = xbmcaddon.Addon()
try: addon_handle = int(sys.argv[1])
except: addon_handle = 0

args_str = sys.argv[2] if len(sys.argv) > 2 else ""
if args_str.startswith('?'):
    args_str = args_str[1:]
params = dict(parse_qsl(args_str))

ICON = addon.getAddonInfo('icon')
PROFILE = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
CACHE_DIR = os.path.join(PROFILE, 'cache')
FAV_FILE = os.path.join(PROFILE, 'favorites.json')
STATS_FILE = os.path.join(PROFILE, 'stats.json')
LISTS_FILE = os.path.join(PROFILE, 'all_lists.json')
VIEW_MODES_FILE = os.path.join(PROFILE, 'view_modes.json')
LOCK_FILE = os.path.join(PROFILE, 'locks.json')
PIN_HASH_FILE = os.path.join(PROFILE, 'pin.hash')
SEARCH_EXCLUDE_FILE = os.path.join(PROFILE, 'search_excludes.json')
DIRECT_HIST_FILE = os.path.join(PROFILE, 'direct_history.json')
LAST_CHAN_FILE = os.path.join(PROFILE, 'last_channel.json')

MEDIA_EXT = ('.mp4', '.mkv', '.avi', '.mov', '.mp3', '.flac', '.wav', '.m4a')

for d in [PROFILE, CACHE_DIR]:
    if not xbmcvfs.exists(d): xbmcvfs.mkdir(d)

def get_resolved_url(url):
    """חילוץ הקישור האמיתי באנגלית עם עקיפת שגיאות אימות SSL"""
    try:
        if not url.startswith('http'):
            return url
            
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        
        # כיבוי התראות SSL מעצבנות בלוג של קודי
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # verify=False פותר את שגיאת ה-SSLCertVerificationError שראינו בלוג
        r = requests.head(url, headers=headers, allow_redirects=True, verify=False, timeout=5)
        
        if r.status_code == 200:
            return r.url
            
        # גיבוי במקרה ששרת ה-HEAD חסום
        r = requests.get(url, headers=headers, allow_redirects=True, verify=False, stream=True, timeout=5)
        real_link = r.url
        r.close()
        return real_link
        
    except Exception as e:
        xbmc.log(f"Error in get_resolved_url: {str(e)}", 3)
        return url




def build_url(query): 
    return sys.argv[0] + '?' + urlencode(query)

def get_json(path, default=list):
    try:
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path); c = f.read(); f.close()
            if isinstance(c, bytes): c = c.decode('utf-8', 'ignore')
            data = json.loads(c)
            if path == FAV_FILE and isinstance(data, list):
                return {"כללי": data}
            return data if data else default()
    except: pass
    return default()

def save_json(path, data):
    try:
        f = xbmcvfs.File(path, 'w'); f.write(json.dumps(data, ensure_ascii=False)); f.close()
    except: pass

def show_help():
    title = "[B][COLOR aqua] ●▬▬▬▬▬TV-EPG-▬▬▬▬▬●מדריך בסיסי לשימוש בהרחבה[/COLOR][/B]"
    text = (
        "[B][COLOR gold]הוספת רשימות:[/COLOR][/B] כנס ל'תחזוקה והגדרות' > 'הוסף רשימה'.\n"
        "[B][COLOR gold]חיפוש חכם:[/COLOR][/B] סורק גם שמות ערוצים וגם את לוח השידורים הנוכחי.\n"
        "[B][COLOR gold]מועדפים:[/COLOR][/B] לחיצה ארוכה על ערוץ תפתח תפריט להוספה למועדפים.\n"
        "[B][COLOR gold]מועדפים:[/COLOR][/B] צור מספר קטגוריות: ערוצים,ילדים,ספורט וכו.. לשימוש נכון.\n" 
        "[B][COLOR gold]נעילת רשימה:[/COLOR][/B] ניתן לנעול רשימות עם קוד PIN דרך תפריט הקליק הימני.\n"
        "[B][COLOR gold]לוח שידורים:[/COLOR][/B] אם הגדרת קובץ EPG, המידע יופיע לצד שם הערוץ."
    )
    xbmcgui.Dialog().textviewer(title, text)

def check_pin():
    stored_hash = ""
    if xbmcvfs.exists(PIN_HASH_FILE):
        f = xbmcvfs.File(PIN_HASH_FILE); stored_hash = f.read(); f.close()
    if not stored_hash:
        new_pin = xbmcgui.Dialog().numeric(0, 'קבע PIN חדש (חובה לזכור!):')
        if not new_pin: return False
        stored_hash = hashlib.sha256(new_pin.encode()).hexdigest()
        f = xbmcvfs.File(PIN_HASH_FILE, 'w'); f.write(stored_hash); f.close()
        return True
    input_pin = xbmcgui.Dialog().numeric(0, 'הכנס PIN לביצוע הפעולה:')
    if not input_pin: return False
    return hashlib.sha256(input_pin.encode()).hexdigest() == stored_hash

def get_source(path):
    if not path: return ""
    path = xbmcvfs.translatePath(path)
    if not path.startswith('http'):
        try:
            f = xbmcvfs.File(path); content = f.read(); f.close()
            return content.decode('utf-8', 'ignore') if isinstance(content, bytes) else content
        except: return ""
    try:
        r = requests.get(path, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
        if r.status_code == 200:
            if path.endswith('.gz') or r.content[:2] == b'\x1f\x8b':
                return gzip.decompress(r.content).decode('utf-8', 'ignore')
            return r.text
    except: pass
    return ""

def resolve_url(url):
    if 'youtube.com' in url or 'youtu.be' in url:
        v_id = re.search(r'(?:v=|\/|embed\/|watch\?v=)([0-9A-Za-z_-]{11})', url)
        if v_id: return "plugin://plugin.video.youtube/play/?video_id=" + v_id.group(1)
    return url

def load_epg_now(path):
    if not path: return {}
    offset = int(addon.getSetting('epg_offset') or 0)
    cache_key = os.path.join(CACHE_DIR, hashlib.md5(path.encode()).hexdigest())
    try:
        if xbmcvfs.exists(cache_key) and (time.time() - os.path.getmtime(cache_key)) < 3600:
            return get_json(cache_key, dict)
    except: pass
    xml_data = get_source(path)
    if not xml_data: return {}
    epg_dict = {}
    try:
        now = datetime.now()
        pattern = r'<programme start="(\d{14}).*?stop="(\d{14}).*?channel="(.*?)">.*?<title.*?>(.*?)</title>(?:.*?<desc.*?>(.*?)</desc>)?'
        for m in re.finditer(pattern, xml_data, re.S):
            s_raw, e_raw, tid, title, desc = m.groups()
            s_dt = datetime(int(s_raw[:4]), int(s_raw[4:6]), int(s_raw[6:8]), int(s_raw[8:10]), int(s_raw[10:12])) + timedelta(hours=offset)
            e_dt = datetime(int(e_raw[:4]), int(e_raw[4:6]), int(e_raw[6:8]), int(e_raw[8:10]), int(e_raw[10:12])) + timedelta(hours=offset)
            if s_dt <= now <= e_dt: 
                epg_dict[tid.strip()] = {'t': title.strip(), 's': s_dt.strftime('%H:%M'), 'e': e_dt.strftime('%H:%M'), 'd': desc.strip() if desc else ""}
        if epg_dict: save_json(cache_key, epg_dict)
    except: pass
    return epg_dict

def add_dir(title, url, folder=True, icon=None, epg_data=None, ctx=None, is_sep=False, color=None):
    clean_n = re.sub(r'[^\w\s\u0590-\u05FF\.,!\?\-\(\)\[\]/]', '', str(title)).strip()
    display = "[B][COLOR " + color + "]" + clean_n + "[/COLOR][/B]" if color else "[B]" + clean_n + "[/B]"
    if is_sep: display = "[COLOR cyan]●▬▬▬▬▬ [COLOR springgreen]" + clean_n + "[/COLOR] ▬▬▬▬▬●[/COLOR]"
    elif epg_data: display += " [COLOR gray][" + epg_data['s'] + "-" + epg_data['e'] + "] [/COLOR][COLOR orange]" + epg_data['t'] + "[/COLOR]"
    li = xbmcgui.ListItem(display)
    img = icon if (icon and (icon.startswith('http') or icon.startswith('special://') or xbmcvfs.exists(icon))) else ICON
    li.setArt({'thumb': img, 'icon': img, 'poster': img, 'fanart': img})
    try:
        li.getVideoInfoTag().setPlot(epg_data['d']) if epg_data else None
    except: pass
    if not folder and not is_sep:
        li.setProperty("IsPlayable", "true")
        if not ctx: ctx = []
        f_data = json.dumps({'title': clean_n, 'url': url, 'icon': img}, ensure_ascii=False)
        ctx.append(('[COLOR deepskyblue]הוסף למועדפים[/COLOR]', 'RunPlugin(' + build_url({"mode":"add_fav", "data": f_data}) + ')'))
    if ctx: li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(addon_handle, url, li, folder if not is_sep else False)
def parse_m3u(url, group=None, epg_url=None, query=None, list_name=None, return_list=False, unlocked=False):
    locks = get_json(LOCK_FILE, list)
    if url in locks and params.get('unlocked') != 'true' and not unlocked:
        if not check_pin(): return [] if return_list else None
    try:
        content = get_source(url)
        if not content: return [] if return_list else None
        
        # טעינת EPG עבור החיפוש - חשוב מאוד!
        epg_map = load_epg_now(epg_url) if epg_url else {}
        
        lines = content.splitlines(); channels = []; current = {}
        # בדיקה אם "חיפוש עמוק" מופעל בהגדרות (או כברירת מחדל בחיפוש)
        deep_s = addon.getSetting('deep_search') != 'false' 
        
        for line in lines:
            line = line.strip()
            if line.startswith('#EXTINF'):
                tid = re.search(r'tvg-id="([^"]*)"', line); t_id = tid.group(1) if tid else ""
                logo = re.search(r'tvg-logo="([^"]*)"', line); img = logo.group(1) if logo else ICON
                grp = re.search(r'group-title="([^"]*)"', line); g_name = grp.group(1) if grp else "ללא קטגוריה"
                current = {'name': line.split(',')[-1].strip(), 't_id': t_id, 'img': img, 'group': g_name}
            elif line and not line.startswith('#'):
                if 'name' in current:
                    current['url'] = line
                    if query:
                        q = query.lower()
                        # 1. בדיקה בשם הערוץ
                        name_match = all(word in current['name'].lower() for word in q.split())
                        
                        # 2. בדיקה בלוח המשדרים (EPG)
                        epg_match = False
                        if deep_s and current['t_id'] in epg_map:
                            prog_title = epg_map[current['t_id']]['t'].lower()
                            epg_match = all(word in prog_title for word in q.split())
                        
                        # אם נמצאה התאמה באחד מהם - הוסף לתוצאות
                        if name_match or epg_match:
                            prefix = "[COLOR yellow][" + (list_name or "חיפוש") + "][/COLOR] "
                            current['display_name'] = prefix + current['name']
                            channels.append(current.copy())
                    else: channels.append(current.copy())
                    current = {}
                    
        if return_list: return channels
        
        # שאר הפונקציה (Folders/Flat) נשארת ללא שינוי...
        v_mode = get_json(VIEW_MODES_FILE, dict).get(url, 'folders')
        if v_mode == 'folders' and not group and not query:
            grps = sorted(list(set([c['group'] for c in channels])))
            for g in grps:
                add_dir("📁 " + g, build_url({'mode': 'parse', 'url': url, 'group': g, 'epg_url': epg_url or "", 'unlocked': 'true'}), True)
            xbmcplugin.endOfDirectory(addon_handle); return
        if group: channels = [c for c in channels if c['group'] == group]
        
        is_vod = any(any(c['url'].lower().split('?')[0].endswith(ext) for ext in MEDIA_EXT) for c in channels)
        if not query and is_vod and len(channels) > 1:
            m_data = json.dumps(channels, ensure_ascii=False)
            add_dir("ניגון אקראי", build_url({'mode': 'play_batch', 'type': 'random', 'data': m_data}), False, color='gold')
            add_dir("ניגון מכאן", build_url({'mode': 'play_batch', 'type': 'seq', 'data': m_data}), False, color='springgreen')
            
        last_grp = None
        for c in channels:
            if v_mode == 'flat' and not query and c['group'] != last_grp:
                add_dir(c['group'], "", False, is_sep=True); last_grp = c['group']
            add_dir(c.get('display_name', c['name']), build_url({'mode':'play','url':c['url'],'name':c['name'],'icon':c['img']}), False, c['img'], epg_map.get(c['t_id']))
        xbmcplugin.endOfDirectory(addon_handle)
    except: return [] if return_list else None


def list_wizard(edit_idx=None):
    lists = get_json(LISTS_FILE, list)
    cur = lists[int(edit_idx)] if edit_idx is not None else {"name": "", "url": "", "epg": "", "icon": ICON}
    n = xbmcgui.Dialog().input("שם הרשימה:", defaultt=cur['name'])
    if not n: return
    s = xbmcgui.Dialog().select("מקור M3U:", ["קישור אינטרנט", "קובץ מקומי"])
    u = xbmcgui.Dialog().input("כתובת:", defaultt=cur['url']) if s == 0 else xbmcgui.Dialog().browse(1, "בחר קובץ", "files", ".m3u|.m3u8", defaultt=cur['url'])
    if not u: return
    auto_epg = ""
    try:
        content = get_source(u)
        if content:
            match = re.search(r'url-tvg="([^"]+)"', content, re.I) or re.search(r'x-tvg-url="([^"]+)"', content, re.I)
            if match: auto_epg = match.group(1).strip()
    except: pass
    if auto_epg:
        xbmcgui.Dialog().ok("TV-EPG", "נמצאה כתובת EPG מובנית ברשימה:\n" + auto_epg)
        epg = auto_epg
    else:
        es = xbmcgui.Dialog().select("לוח שידורים (EPG):", ["קישור אינטרנט", "קובץ מקומי", "ללא"])
        epg = cur['epg'] if es != 2 else ""
        if es == 0: epg = xbmcgui.Dialog().input("כתובת EPG:", defaultt=epg)
        elif es == 1: epg = xbmcgui.Dialog().browse(1, "בחר XML", "files", ".xml|.gz", defaultt=epg)
    ls = xbmcgui.Dialog().select("אייקון/לוגו:", ["קישור אינטרנט", "קובץ מקומי", "ללא"])
    icon = cur['icon'] if ls != 2 else ICON
    if ls == 0: icon = xbmcgui.Dialog().input("כתובת לוגו:", defaultt=icon)
    elif ls == 1: icon = xbmcgui.Dialog().browse(1, "בחר תמונה", "files", ".png|.jpg", defaultt=icon)
    data = {"name": n, "url": u, "epg": epg, "icon": icon}
    if edit_idx is not None: lists[int(edit_idx)] = data
    else: lists.append(data)
    save_json(LISTS_FILE, lists); xbmc.executebuiltin("Container.Refresh")

def backup_addon_data():
    target = xbmcgui.Dialog().browse(3, "בחר תיקייה לשמירת הגיבוי", "files")
    if not target: return
    filename = "TV_EPG_Backup_%s.zip" % datetime.now().strftime("%Y%m%d_%H%M")
    zip_path = os.path.join(xbmcvfs.translatePath(target), filename)
    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
            files = [FAV_FILE, STATS_FILE, LISTS_FILE, VIEW_MODES_FILE, LOCK_FILE, PIN_HASH_FILE, SEARCH_EXCLUDE_FILE, DIRECT_HIST_FILE, LAST_CHAN_FILE]
            for f in files:
                if xbmcvfs.exists(f): z.write(f, os.path.basename(f))
        xbmcgui.Dialog().ok("גיבוי", "הגיבוי הסתיים בהצלחה:\n" + filename)
    except Exception as e: xbmcgui.Dialog().notification("שגיאה", str(e))

def restore_addon_data():
    source = xbmcgui.Dialog().browse(1, "בחר קובץ גיבוי (ZIP)", "files", ".zip")
    if not source: return
    try:
        with zipfile.ZipFile(xbmcvfs.translatePath(source), 'r') as z:
            z.extractall(PROFILE)
        xbmcgui.Dialog().ok("שחזור", "השחזור הושלם! ההרחבה תתעדכן כעת.")
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e: xbmcgui.Dialog().notification("שגיאה", str(e))
def Main_Menu():
    # הגדרת משתנה כריק מראש כדי למנוע קריסה אם התנאי לא מתקיים
    lc = None 
    
    if addon.getSetting('first_run') != 'false':
        show_help(); addon.setSetting('first_run', 'false')
        
    if addon.getSetting('show_last_channel') != 'false':
        lc = get_json(LAST_CHAN_FILE, dict)
        
    add_dir('הרשימות שלי', build_url({'mode': 'show_my_lists'}), color='springgreen')
    
    # הצגת "ערוץ אחרון" מחוץ לחיפוש ורק אם הוא באמת קיים ומצא נתונים
    if lc and addon.getSetting('show_last_channel') != 'false': 
        add_dir('ערוץ אחרון : ' + lc['name'], build_url({'mode': 'play', 'url': lc['url'], 'name': lc['name'], 'icon': lc.get('icon', ICON)}), False, lc.get('icon', ICON), color='hotpink')
        
    if addon.getSetting('show_search') != 'false':
        add_dir('🔍 חיפוש ערוץ', build_url({'mode': 'do_search'}), color='gold')
        
    if addon.getSetting('show_surprise') != 'false':
        add_dir('🎲 צפייה בהפתעה', build_url({'mode': 'surprise_me'}), color='orange')
        
    if addon.getSetting('show_favs') != 'false':
        add_dir('⭐ מועדפים', build_url({'mode': 'show_favs'}), color='hotpink')
        
    if addon.getSetting('show_top10') != 'false':
        add_dir('🏆 עשרת המובילים', build_url({'mode': 'show_top10'}), color='skyblue')
        
    add_dir('🛠️ תחזוקה והגדרות', build_url({'mode': 'maintenance'}), color='lightgray')
    xbmcplugin.endOfDirectory(addon_handle)


mode = params.get('mode')
if not mode: Main_Menu()
elif mode == 'show_my_lists':
    lists = get_json(LISTS_FILE, list); locks = get_json(LOCK_FILE, list); ex = get_json(SEARCH_EXCLUDE_FILE, list); modes = get_json(VIEW_MODES_FILE, dict)
    for i, l in enumerate(lists):
        isl = l['url'] in locks; isx = l['url'] in ex
        ctx = [('[COLOR orange]ערוך[/COLOR]', 'RunPlugin('+build_url({"mode":"edit_list","idx":i})+')'),
               ('[COLOR tomato]מחק[/COLOR]', 'RunPlugin('+build_url({"mode":"del_list","idx":i})+')'),
               ('[COLOR deepskyblue]' + ("מצב תיקיות" if modes.get(l['url']) == 'flat' else "רשימה חכמה") + '[/COLOR]', 'RunPlugin(' + build_url({"mode":"toggle_view", "url": l['url'], "epg": l['epg']}) + ')'),
               ('[COLOR white]' + ("ביטול נעילה" if isl else "נעילה") + '[/COLOR]', 'RunPlugin('+build_url({"mode":"toggle_lock","url":l['url']})+')'),
               ('[COLOR gray]' + ("כלול בחיפוש" if isx else "החרג מחיפוש") + '[/COLOR]', 'RunPlugin('+build_url({"mode":"toggle_search","url":l['url']})+')')]
        name = ("🔒 " if isl else "") + l['name']
        add_dir(name, build_url({'mode':'parse','url':l['url'],'epg_url':l['epg']}), ctx=ctx, color='gray' if isx else None, icon=l['icon'])
    xbmcplugin.endOfDirectory(addon_handle)
elif mode == 'do_search':
    q = xbmcgui.Dialog().input('חפש (ערוץ או תוכנית):')
    if q:
        all_r = []; lists = get_json(LISTS_FILE, list); ex = get_json(SEARCH_EXCLUDE_FILE, list); locks = get_json(LOCK_FILE, list); excluded = set(ex + locks)
        dp = xbmcgui.DialogProgress(); dp.create("חיפוש חכם...", "סורק ערוצים ולוח שידורים")
        for i, l in enumerate(lists):
            if l['url'] in excluded: continue
            dp.update(int((i/len(lists))*100), "סורק: " + l['name'])
            res = parse_m3u(l['url'], epg_url=l['epg'], query=q, list_name=l['name'], return_list=True, unlocked=True)
            if res: all_r.extend(res)
        dp.close()
        if all_r:
            for c in all_r: add_dir(c['display_name'], build_url({'mode':'play','url':c['url'],'name':c['name'],'icon':c['img']}), False, c['img'])
            xbmcplugin.endOfDirectory(addon_handle)
        else: xbmcgui.Dialog().notification("TV", "לא נמצאו תוצאות")
elif mode == 'maintenance':
    add_dir("➕ הוסף רשימה", build_url({'mode': 'wizard'}), color='cyan')
    add_dir("📥 ייבוא מ-TXT", build_url({'mode': 'import_txt'}), color='springgreen')
    add_dir("🚀 ניגון ישיר", build_url({'mode': 'direct_play'}), color='gold')
    add_dir("🔍 בדיקת תקינות רשימות", build_url({'mode': 'check_lists'}), color='lightgreen')
    add_dir("⏰ תיקון שעת EPG", build_url({'mode': 'set_offset'}), color='orange')
    add_dir("🧹 ניקוי מטמון", build_url({'mode': 'clear_cache'}), color='red')
    add_dir("📤 גיבוי מלא (מקומי)", build_url({'mode': 'backup_data'}), color='white')
    add_dir("📥 שחזור מגיבוי", build_url({'mode': 'restore_data'}), color='white')
    add_dir("📖 מדריך למשתמש", build_url({'mode': 'help'}), color='lightblue')
    add_dir("⚙️ הגדרות", build_url({'mode': 'settings'}), color='white')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode == 'backup_data': backup_addon_data()
elif mode == 'restore_data': restore_addon_data()
elif mode == 'help': show_help()
elif mode == 'direct_play':
    hist = get_json(DIRECT_HIST_FILE, list); opts = ["+ חדש"] + hist; s = xbmcgui.Dialog().select("היסטוריה:", opts)
    u = xbmcgui.Dialog().input('כתובת:') if s == 0 else (opts[s] if s > 0 else None)
    if u:
        if u not in hist: hist.insert(0, u); save_json(DIRECT_HIST_FILE, hist[:10])
        xbmc.Player().play(resolve_url(u), xbmcgui.ListItem('Direct Play'))
elif mode == 'check_lists':
    lists = get_json(LISTS_FILE, list); dp = xbmcgui.DialogProgress(); dp.create("בודק...", "סורק"); res = []
    for i, l in enumerate(lists):
        if dp.iscanceled(): break
        dp.update(int((i/len(lists))*100), "בודק: " + l['name'])
        u = xbmcvfs.translatePath(l['url'])
        if not u.startswith('http'): status = "[COLOR springgreen]תקין[/COLOR]" if xbmcvfs.exists(u) else "[COLOR red]חסר[/COLOR]"
        else:
            try:
                r = requests.get(u, timeout=5, headers={'User-Agent': 'Mozilla/5.0'}, allow_redirects=True)
                status = "[COLOR springgreen]תקין[/COLOR]" if r.status_code == 200 else "[COLOR red]שגיאה %s[/COLOR]" % r.status_code
            except: status = "[COLOR red]לא זמין[/COLOR]"
        res.append(l['name'] + " : " + status)
    dp.close(); xbmcgui.Dialog().select("תוצאות:", res)
elif mode == 'play':
    save_json(LAST_CHAN_FILE, {'name': params['name'], 'url': params['url'], 'icon': params.get('icon', ICON)})
    stats = get_json(STATS_FILE, dict); key = hashlib.md5(params['url'].encode()).hexdigest()
    stats[key] = {'name': params['name'], 'url': params['url'], 'icon': params.get('icon', ICON), 'count': stats.get(key, {}).get('count', 0) + 1}
    save_json(STATS_FILE, stats)
    
    # 1. הפעלת מנגנון הבדיקה המקורי של ההרחבה (לינקים של יוטיוב וכדומה)
    checked_url = resolve_url(params['url'])
    
    # 2. הפעלת השיטה החדשה לחילוץ השם המקורי באנגלית מהשרת
    real_url = get_resolved_url(checked_url)
    
    # הדפסת הקישור הסופי ללוג של קודי (כדי שתוכל לעקוב ולראות שזה עובד)
    xbmc.log('--- Playing "{0}". Real URL: {1}'.format(params['name'], real_url), 2)
    
    # 3. מסירת הקישור החשוף לקודי ולכתוביות
    li = xbmcgui.ListItem(params['name'])
    li.setPath(real_url)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, li)

elif mode == 'surprise_me':
    all_c = []; lists = get_json(LISTS_FILE, list); ex = get_json(SEARCH_EXCLUDE_FILE, list); locks = get_json(LOCK_FILE, list); excluded = set(ex + locks)
    for l in lists:
        if l['url'] in excluded: continue
        res = parse_m3u(l['url'], return_list=True, unlocked=True)
        if res: all_c.extend(res)
    if all_c:
        c = random.choice(all_c)
        # חילוץ הקישור והשם באנגלית לפני הניגון
        checked_url = resolve_url(c['url'])
        real_url = get_resolved_url(checked_url)
        
        li = xbmcgui.ListItem(c['name'])
        xbmc.Player().play(real_url, li)

elif mode == 'play_batch':
    data = json.loads(params['data']); pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO); pl.clear()
    if params.get('type') == 'random': random.shuffle(data)
    for i in data: pl.add(url=resolve_url(i['url']), listitem=xbmcgui.ListItem(i['name']))
    xbmc.Player().play(pl)
elif mode == 'show_top10':
    top = sorted(get_json(STATS_FILE, dict).values(), key=lambda x: x['count'], reverse=True)[:10]
    for i, item in enumerate(top, 1):
        img = item.get('icon', ICON)
        add_dir("%d. %s" % (i, item['name']), build_url({'mode':'play','url':item['url'],'name':item['name'],'icon':img}), False, img)
    xbmcplugin.endOfDirectory(addon_handle)
elif mode == 'toggle_search':
    u = params['url']; d = get_json(SEARCH_EXCLUDE_FILE, list); (d.remove(u) if u in d else d.append(u)); save_json(SEARCH_EXCLUDE_FILE, d); xbmc.executebuiltin("Container.Refresh")
elif mode == 'import_txt':
    path = xbmcgui.Dialog().browse(1, "בחר TXT", "files", ".txt")
    if path:
        content = get_source(path); lists = get_json(LISTS_FILE, list)
        for line in content.splitlines():
            if '|' in line:
                p = line.split('|'); lists.append({"name": p[0], "url": p[1], "epg": p[2] if len(p)>2 else "", "icon": p[3] if len(p)>3 else ICON})
        save_json(LISTS_FILE, lists); xbmc.executebuiltin("Container.Refresh")
elif mode == 'show_favs':
    favs = get_json(FAV_FILE, dict); group = params.get('group')
    if not group:
        for cat in sorted(favs.keys()): add_dir("📁 " + cat, build_url({'mode': 'show_favs', 'group': cat}), True)
    else:
        for x in favs.get(group, []):
            ctx = [('[COLOR orange]העבר[/COLOR]', 'RunPlugin(' + build_url({"mode":"move_fav", "url": x['url'], "old_cat": group}) + ')'),
                   ('[COLOR tomato]הסר[/COLOR]', 'RunPlugin(' + build_url({"mode":"del_fav", "url": x['url'], "cat": group}) + ')')]
            add_dir(x['title'], build_url({'mode':'play','url':x['url'],'name':x['title'],'icon':x.get('icon')}), False, x.get('icon'), ctx=ctx)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode == 'add_fav':
    favs = get_json(FAV_FILE, dict); data = json.loads(params['data']); cats = sorted(favs.keys()); opts = ["+ חדשה"] + cats
    s = xbmcgui.Dialog().select("בחר קטגוריה:", opts)
    cat = xbmcgui.Dialog().input("שם קטגוריה:") if s == 0 else (opts[s] if s > 0 else None)
    if cat:
        if cat not in favs: favs[cat] = []
        favs[cat].append(data); save_json(FAV_FILE, favs); xbmcgui.Dialog().notification("TV", "נוסף")
elif mode == 'move_fav':
    favs = get_json(FAV_FILE, dict); url = params['url']; old_cat = params['old_cat']
    cats = sorted(favs.keys()); s = xbmcgui.Dialog().select("העבר לקטגוריה:", cats)
    if s != -1:
        target = cats[s]; item = next((x for x in favs[old_cat] if x['url'] == url), None)
        if item:
            favs[old_cat] = [x for x in favs[old_cat] if x['url'] != url]
            if not favs[old_cat]: del favs[old_cat]
            if target not in favs: favs[target] = []
            favs[target].append(item); save_json(FAV_FILE, favs); xbmc.executebuiltin("Container.Refresh")
elif mode == 'del_fav':
    favs = get_json(FAV_FILE, dict); cat = params['cat']; url = params['url']; favs[cat] = [x for x in favs[cat] if x['url'] != url]
    if not favs[cat]: del favs[cat]
    save_json(FAV_FILE, favs); xbmc.executebuiltin("Container.Refresh")
elif mode == 'clear_cache':
    dirs, files = xbmcvfs.listdir(CACHE_DIR)
    for f in files: xbmcvfs.delete(os.path.join(CACHE_DIR, f))
    xbmcgui.Dialog().notification("TV", "נוקה")
elif mode == 'set_offset':
    opts = [str(x) for x in range(-12, 13)]; s = xbmcgui.Dialog().select("Offset:", opts)
    if s != -1: addon.setSetting('epg_offset', opts[s]); xbmc.executebuiltin("Container.Refresh")
elif mode == 'settings': addon.openSettings()
elif mode in ['wizard', 'edit_list']: list_wizard(params.get('idx'))
elif mode == 'toggle_lock':
    u = params['url']; d = get_json(LOCK_FILE, list)
    if check_pin():
        if u in d: d.remove(u)
        else: d.append(u)
        save_json(LOCK_FILE, d); xbmc.executebuiltin("Container.Refresh")
elif mode == 'toggle_view':
    m = get_json(VIEW_MODES_FILE, dict); m[params['url']] = 'flat' if m.get(params['url']) != 'flat' else 'folders'; save_json(VIEW_MODES_FILE, m)
    xbmc.executebuiltin('Container.Update(' + build_url({'mode': 'parse', 'url': params['url'], 'epg_url': params.get('epg', "")}) + ')')
elif mode == 'parse': parse_m3u(params['url'], params.get('group'), epg_url=params.get('epg_url'))
elif mode == 'del_list':
    l = get_json(LISTS_FILE, list); l.pop(int(params['idx'])); save_json(LISTS_FILE, l); xbmc.executebuiltin("Container.Refresh")