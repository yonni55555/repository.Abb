# -*- coding: utf-8 -*-
import re, os, sys, json, hashlib, requests, time
import xbmc, xbmcvfs, xbmcgui, xbmcplugin, xbmcaddon
from urllib.parse import urlencode, parse_qsl, quote

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- הגדרות בסיסיות ---
addon = xbmcaddon.Addon()
ADDON_NAME = "TV-MAC"
try: addon_handle = int(sys.argv[1])
except: addon_handle = 0
args_str = sys.argv[2] if len(sys.argv) > 2 else ""
params = dict(parse_qsl(args_str.lstrip('?')))

def get_setting(id, default):
    val = addon.getSetting(id)
    return val if val else default

TIMEOUT = int(get_setting('timeout', '7'))
MAG_UA = get_setting('user_agent', 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 hbbtv v.1.1.0.5 Safari/533.3')
SHOW_LOGOS = addon.getSettingBool('show_logos')
PAGE_STEPS =[2, 4, 8, 10][int(get_setting('items_per_page', '1'))]

ICON = addon.getAddonInfo('icon')
PROFILE = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
LISTS_FILE = os.path.join(PROFILE, 'all_lists.json')
FAVS_FILE = os.path.join(PROFILE, 'favorites.json')

if 'stb_session' not in globals(): globals()['stb_session'] = {}
if not xbmcvfs.exists(PROFILE): xbmcvfs.mkdir(PROFILE)

# --- פונקציית ההסבר המעוצבת ---
def show_help_dialog(first_time=False):
    title = f"[COLOR yellow]ברוכים הבאים ל-{ADDON_NAME}[/COLOR]" if first_time else f"[COLOR yellow]מדריך למשתמש - {ADDON_NAME}[/COLOR]"
    
    # עיצוב הטקסט: כותרת בצהוב, פירוט בתכלת (lightblue)
    text = (
        "[COLOR yellow][B]• שידור חי בלבד:[/B][/COLOR] "
        "[COLOR lightblue]ההרחבה מיועדת לערוצי טלוויזיה בלבד. אין תמיכה בסרטים או סדרות.[/COLOR]\n"
        "[COLOR yellow][B]• הוספת פורטל:[/B][/COLOR] "
        "[COLOR lightblue]יש להזין שם, כתובת שרת וכתובת MAC מאושרת ותקינה.[/COLOR]\n"
        "[COLOR yellow][B]• מהירות סריקה:[/B][/COLOR] "
        "[COLOR lightblue]בהגדרות ניתן לבחור כמות עמודים. 28 ערוצים יטענו הכי מהר.[/COLOR]\n"
        "[COLOR yellow][B]• ניהול מועדפים:[/B][/COLOR] "
        "[COLOR lightblue]ניתן להוסיף ערוץ/קטגוריה ע\"י לחיצה ארוכה ובחירה ב'הוסף למועדפים'.[/COLOR]\n"
        "[COLOR yellow][B]• זמן המתנה:[/B][/COLOR] "
        "[COLOR lightblue]אם הפורטל איטי או לא מגיב, ניתן להעלות את ה-Timeout בהגדרות.[/COLOR]\n"
        "[COLOR yellow][B]• תקלות ניגון:[/B][/COLOR] "
        "[COLOR lightblue]וודאו שמותקן אצלכם Inputstream Adaptive/FFmpegDirect לעבודה חלקה.[/COLOR]"
    )
    xbmcgui.Dialog().textviewer(title, text)

# --- פונקציות עזר ---
def fix_enc(text):
    if not text: return ""
    text = re.sub(r'[^\x00-\x7F\u0590-\u05FF\s!@#$%^&*()\-=_+\[\]{};:\'",.<>/?\\|]', '', text)
    try: return text.encode('iso-8859-1').decode('cp1255')
    except: return text

def build_url(query): 
    return sys.argv[0] + '?' + urlencode(query)

def get_api_session(url, mac):
    s_id = hashlib.md5((url+mac).encode()).hexdigest()
    if s_id in globals()['stb_session']: return globals()['stb_session'][s_id]
    host = url.split('/portal.php')[0].split('/c/')[0].rstrip('/')
    api_url = f"{host}/portal.php"
    domain = host.split('//')[-1].split(':')[0]
    sn = hashlib.md5(mac.encode()).hexdigest()[:12].upper()
    s = requests.Session()
    s.headers.update({'User-Agent': MAG_UA, 'X-User-Agent': 'Model: MAG250; SW: 2.18-r14-pub-250', 'Referer': f'{host}/c/'})
    s.cookies.set('mac', quote(mac), domain=domain, path='/')
    try:
        hs_url = f"{api_url}?type=stb&action=handshake&sn={sn}&JsHttpRequest=1-xml"
        r = s.get(hs_url, timeout=TIMEOUT, verify=False).text
        js = json.loads(re.sub(r'/\*.*?\*/', '', r, flags=re.DOTALL)).get('js', {})
        token = js.get('token')
        if token:
            s.headers.update({'Authorization': f'Bearer {token}'})
            globals()['stb_session'][s_id] = (s, api_url, sn, host, token)
            return s, api_url, sn, host, token
    except: pass
    return None, None, None, None, None

def add_item(title, url, folder=True, icon=None, color=None, info=None, is_video=False, host="", fav_data=None, list_idx=None):
    display = f"[B][COLOR {color}]{title}[/COLOR][/B]" if color else f"[B]{title}[/B]"
    li = xbmcgui.ListItem(display)
    img = icon if (icon and icon.startswith('http') and SHOW_LOGOS) else (host + icon if icon and host and SHOW_LOGOS else ICON)
    li.setArt({'thumb': img, 'icon': img, 'poster': img})
    
    commands = []
    if fav_data:
        f_url = build_url({'mode': 'add_fav', 'fav_json': json.dumps(fav_data)})
        commands.append((f'[COLOR yellow]הוסף למועדפים[/COLOR]', f'RunPlugin({f_url})'))
    if params.get('mode') == 'show_favs':
        r_url = build_url({'mode': 'rem_fav', 'fav_title': title})
        commands.append((f'[COLOR red]הסר מהמועדפים[/COLOR]', f'RunPlugin({r_url})'))
    if list_idx is not None:
        e_url = build_url({'mode': 'wizard', 'idx': str(list_idx)})
        d_url = build_url({'mode': 'del_list', 'idx': str(list_idx)})
        commands.append((f'[COLOR cyan]ערוך פורטל[/COLOR]', f'RunPlugin({e_url})'))
        commands.append((f'[COLOR red]מחק פורטל[/COLOR]', f'RunPlugin({d_url})'))
    
    if commands: li.addContextMenuItems(commands)
    if is_video: 
        li.setProperty("IsPlayable", "true")
        li.setInfo('video', {'title': title})
    xbmcplugin.addDirectoryItem(addon_handle, url, li, folder)

# --- ניהול מצבים ---
mode = params.get('mode')

if not mode:
    if addon.getSetting("first_run") != "false":
        show_help_dialog(first_time=True)
        addon.setSetting("first_run", "false")

    add_item('המועדפים שלי', build_url({'mode': 'show_favs'}), color='gold', icon=ICON)
    add_item('הרשימות שלי', build_url({'mode': 'show_lists'}), color='springgreen', icon=ICON)
    add_item('הוסף פורטל חדש', build_url({'mode': 'wizard'}), color='cyan', icon=ICON)
    add_item('מדריך והסבר על ההרחבה', build_url({'mode': 'help'}), color='orange', icon=ICON)
    add_item('הגדרות ההרחבה', build_url({'mode': 'open_settings'}), color='white', icon=ICON)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode == 'help':
    show_help_dialog()

elif mode == 'wizard':
    idx = params.get('idx'); lists = []
    if xbmcvfs.exists(LISTS_FILE):
        f = xbmcvfs.File(LISTS_FILE); lists = json.loads(f.read() or "[]"); f.close()
    cur = lists[int(idx)] if idx else {"name": "", "url": "", "mac": ""}
    name = xbmcgui.Dialog().input("שם הפורטל:", cur['name'])
    url = xbmcgui.Dialog().input("כתובת (URL):", cur['url'])
    mac = xbmcgui.Dialog().input("כתובת MAC:", cur['mac'])
    if name and url and mac:
        new_item = {"name": name, "url": url, "mac": mac}
        if idx: lists[int(idx)] = new_item
        else: lists.append(new_item)
        f = xbmcvfs.File(LISTS_FILE, 'w'); f.write(json.dumps(lists)); f.close()
        xbmc.executebuiltin("Container.Refresh")

elif mode == 'show_lists':
    if xbmcvfs.exists(LISTS_FILE):
        f = xbmcvfs.File(LISTS_FILE); lists = json.loads(f.read() or "[]"); f.close()
        for i, l in enumerate(lists):
            url = build_url({'mode': 'cat', 'url': l['url'], 'mac': l['mac']})
            add_item(l['name'], url, color='springgreen', list_idx=i)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode == 'cat':
    res = get_api_session(params['url'], params['mac'])
    if res:
        s, api, sn, host, token = res
        try:
            r = s.get(f"{api}?type=itv&action=get_genres&sn={sn}&JsHttpRequest=1-xml", timeout=TIMEOUT).text
            genres = json.loads(re.sub(r'/\*.*?\*/', '', r, flags=re.DOTALL)).get('js', [])
            q = params.get('q', "").lower()
            if params.get('do_search') == '1':
                kb = xbmcgui.Dialog().input("חיפוש קטגוריה:"); q = kb.lower() if kb else ""
            add_item("[ חיפוש קטגוריה ]", build_url({'mode': 'cat', 'url': params['url'], 'mac': params['mac'], 'do_search': '1'}), color='lightblue')
            add_item("כל הערוצים", build_url({'mode': 'list', 'url': params['url'], 'mac': params['mac'], 'id': '0', 'p': '0'}), color='yellow')
            for g in genres:
                title = fix_enc(g.get('title'))
                if q and q not in title.lower(): continue
                url = build_url({'mode': 'list', 'url': params['url'], 'mac': params['mac'], 'id': g.get('id'), 'p': '0'})
                add_item(title, url, color='yellow', fav_data={'title': title, 'url': url, 'folder': True, 'color': 'yellow'})
        except: pass
    xbmcplugin.endOfDirectory(addon_handle)

elif mode == 'list':
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "טוען רשימה...")
    res = get_api_session(params['url'], params['mac'])
    if res:
        s, api, sn, host, token = res
        p, cat_id = int(params.get('p', '0')), params.get('id', '0')
        if p == 0:
            add_item("[ חזרה לקטגוריות ]", build_url({'mode': 'cat', 'url': params['url'], 'mac': params['mac']}), color='white')
        for i, cp in enumerate(range(p, p + PAGE_STEPS)):
            progress.update(int((i / PAGE_STEPS) * 100))
            try:
                r = s.get(f"{api}?type=itv&action=get_ordered_list&genre={cat_id}&p={cp}&JsHttpRequest=1-xml", timeout=TIMEOUT).text
                channels = json.loads(re.sub(r'/\*.*?\*/', '', r, flags=re.DOTALL)).get('js', {}).get('data', [])
                if not channels: break
                for ch in channels:
                    name = fix_enc(ch.get('name'))
                    play_url = build_url({'mode': 'play', 'url': params['url'], 'mac': params['mac'], 'ch_id': ch.get('id')})
                    fav = {'title': name, 'url': play_url, 'folder': False, 'is_video': True, 'icon': ch.get('logo'), 'host': host}
                    add_item(name, play_url, folder=False, is_video=True, icon=ch.get('logo'), host=host, fav_data=fav)
            except: break
    progress.close()
    add_item("[ עמוד הבא ]", build_url({'mode': 'list', 'url': params['url'], 'mac': params['mac'], 'id': cat_id, 'p': str(p + PAGE_STEPS)}), color='orange')
    xbmcplugin.endOfDirectory(addon_handle)

elif mode == 'play':
    res = get_api_session(params['url'], params['mac'])
    if res:
        s, api, sn, host, token = res
        try:
            play_req = f"{api}?type=itv&action=create_link&cmd=ffrt%20http://localhost/ch/{params['ch_id']}&sn={sn}&JsHttpRequest=1-xml"
            r = s.get(play_req, timeout=TIMEOUT).text
            js = json.loads(re.sub(r'/\*.*?\*/', '', r, flags=re.DOTALL)).get('js', {})
            stream_url = js.get('cmd', '').split(' ')[-1]
            li = xbmcgui.ListItem(path=stream_url)
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            xbmcplugin.setResolvedUrl(addon_handle, True, li)
        except: pass

elif mode == 'add_fav':
    favs = []
    if xbmcvfs.exists(FAVS_FILE):
        f = xbmcvfs.File(FAVS_FILE); favs = json.loads(f.read() or "[]"); f.close()
    fav_item = json.loads(params['fav_json'])
    if not any(i['title'] == fav_item['title'] for i in favs):
        favs.append(fav_item)
        f = xbmcvfs.File(FAVS_FILE, 'w'); f.write(json.dumps(favs)); f.close()
        xbmcgui.Dialog().notification(ADDON_NAME, "נוסף למועדפים", ICON, 2000)

elif mode == 'show_favs':
    if xbmcvfs.exists(FAVS_FILE):
        f = xbmcvfs.File(FAVS_FILE); favs = json.loads(f.read() or "[]"); f.close()
        for fv in favs:
            add_item(fv['title'], fv['url'], fv.get('folder', True), fv.get('icon'), fv.get('color'), fv.get('info'), fv.get('is_video', False), fv.get('host'))
    xbmcplugin.endOfDirectory(addon_handle)

elif mode == 'rem_fav':
    if xbmcvfs.exists(FAVS_FILE):
        f = xbmcvfs.File(FAVS_FILE); favs = json.loads(f.read() or "[]"); f.close()
        favs = [f for f in favs if f['title'] != params['fav_title']]
        f = xbmcvfs.File(FAVS_FILE, 'w'); f.write(json.dumps(favs)); f.close()
        xbmc.executebuiltin("Container.Refresh")

elif mode == 'del_list':
    if xbmcvfs.exists(LISTS_FILE):
        f = xbmcvfs.File(LISTS_FILE); lists = json.loads(f.read() or "[]"); f.close()
        lists.pop(int(params['idx']))
        f = xbmcvfs.File(LISTS_FILE, 'w'); f.write(json.dumps(lists)); f.close()
        xbmc.executebuiltin("Container.Refresh")

elif mode == 'open_settings':
    addon.openSettings()

xbmcplugin.endOfDirectory(addon_handle)
