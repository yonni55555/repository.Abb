# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs, sys, os, threading, requests, time, re, json, shutil
from urllib.parse import urljoin, unquote, parse_qs

# --- הגדרות ליבה ועיצוב ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
FOLDER_IMG = os.path.join(ADDON_PATH, 'resources', 'media', 'Folder.png')
DELETE_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'DeleteRecordings.jpg')

RTL = '\u200f'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'

BASE_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
BIN_PATH = os.path.normpath(os.path.join(BASE_PATH, 'bin'))
if not xbmcvfs.exists(BIN_PATH): xbmcvfs.mkdirs(BIN_PATH)

# נירמול נתיבי קבצי המערכת לעבודה חלקה בווינדוס
FFMPEG_EXE = os.path.normpath(os.path.join(BIN_PATH, 'ffmpeg.exe'))
YTDLP_EXE_PATH = os.path.normpath(os.path.join(BIN_PATH, 'yt-dlp.exe'))
# הגדרת שרת ונתיב להורדה אוטומטית של מנוע ה-JS החסר בווינדוס
QJS_EXE_PATH = os.path.normpath(os.path.join(BIN_PATH, 'qjs.exe'))
QJS_API_LATEST_URL = "https://api.github.com" + "/repos/quickjs-ng/quickjs" + "/releases/latest"



QJS_EXE_PATH = os.path.normpath(os.path.join(BIN_PATH, 'qjs.exe'))


S = chr(47)
# הפניה ישירה לגרסה החדשה ביותר של המפתח nicolaasjan מבלי להתקבע על תאריך ישן
YTDLP_EXE_URL = "https:" + S + S + "github.com" + S + "nicolaasjan" + S + "yt-dlp" + S + "releases" + S + "latest" + S + "download" + S + "yt-dlp.exe"


def get_ffmpeg_path():
    if xbmcvfs.exists(FFMPEG_EXE):
        return FFMPEG_EXE
    return "ffmpeg"

CHANNELS_PATH = os.path.join(BASE_PATH, 'הקלטות_ערוצים/').replace('\\', '/')
MEDIA_PATH = os.path.join(BASE_PATH, 'הקלטות_מדיה/').replace('\\', '/')
SAVED_PATH = os.path.join(BASE_PATH, 'הורדות_שמורות/').replace('\\', '/')
DB_FILE = os.path.join(BASE_PATH, 'tasks.json')
SCHED_FILE = os.path.join(BASE_PATH, 'scheduled.json')
FOLDERS_DB = os.path.join(BASE_PATH, 'folders_meta.json')

for p in [CHANNELS_PATH, MEDIA_PATH, SAVED_PATH]:
    if not xbmcvfs.exists(p): xbmcvfs.mkdirs(p)

STOP_LIST = set()

def load_json(path):
    if xbmcvfs.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f: return json.loads(f.read())
        except: return {}
    return {}

def save_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f: json.dump(data, f, ensure_ascii=False, indent=4)
    except: pass

def clean_label_smart(text):
    if not text: return "הקלטה"
    text = str(text)
    text = re.sub(r'\[/?[Cc][Oo][Ll][Oo][Rr][^\]]*\]', '', text)
    text = re.sub(r'\d{2}:\d{2}-\d{2}:\d{2}', '', text)
    text = text.replace('[]', '').replace('()', '').replace('  ', ' ')
    text = text.replace('.ts', '').replace('.mp4', '').replace('.mkv', '').replace('.downloading', '')
    text = text.replace('-_-', ' ').replace('_', ' ')
    return " ".join(text.split()).strip()

def super_clean_name(text):
    if not text or text is None: 
        return "Advanced_Recording"
    
    text = str(text)
    
    # 1. הסרת קודי צבע של קודי
    text = re.sub(r'\[/?COLOR.*?\]', '', text, flags=re.I)
    
    # 2. הסרת סוגריים מרובעים ועגולים ריקים
    text = re.sub(r'\[\s*\]|\(\s*\)', '', text)
    
    # 3. הסרת טווחי שעות (כמו [14:00-16:00]) וטווחי שנים
    text = re.sub(r'\[\d{2}:\d{2}[.-]\d{2}:\d{2}\]', '', text)
    text = re.sub(r'\[\d{4}[.-]\d{4}\]', '', text)
    
    # 4. חוק ברזל: מחיקת פסיקים, גרשיים וסימני פיסוק בעייתים למניעת תופעות קריסה
    text = re.sub(r'[,;!?\'"”„’‘]', '', text)
    
    # 5. הגנה מוחלטת: הסרת תווים אסורים של מערכות קבצים (ווינדוס/אנדרואיד) למניעת שגיאות כתיבה לדיסק
    text = re.sub(r'[\\/*?:"<>|]', '', text)
    
    # בדיקה האם מדובר בשחרור רשמי (טורנט/VOD אנגלי)
    text_lower = text.lower()
    is_scene = any(q in text_lower for q in ['1080', '720', '2160', 'web', 'x264', 'h264', 'hdtv', 'bluray', 'ethel', 'galaxyrg', 'yts', 'yify'])
    
    if is_scene:
        # עבור טורנטים: מחליפים רק רווחים, מקפים ותתי-קווים בנקודות, ומשאירים את כל נתוני הגרסה של הכתוביות שלמות!
        text = text.replace(' ', '.').replace('_', '.').replace('-', '.')
    else:
        # עבור ערוצים רגילים וקישורים פשוטים: נשאר הניקוי המחמיר והמצוין המקורי שלך
        text = text.replace(' ', '.').replace('_', '.').replace('-', '.')
    
    # 6. צמצום רצף של נקודות לנקודה אחת בלבד
    text = re.sub(r'\.+', '.', text)
    
    return text.strip('.')





def get_file_size(path):
    try:
        target = path if xbmcvfs.exists(path) else path + ".downloading"
        size = xbmcvfs.Stat(target).st_size()
        if size > 1024**3: return "{:.1f} GB".format(size/(1024.0**3))
        return "{:.1f} MB".format(size/(1024.0*1024.0))
    except: return "0 MB"

def get_free_space():
    try:
        total, used, free = shutil.disk_usage(BASE_PATH)
        return f"{(free / (1024**3)):.1f} GB פנוי מתוך {(total / (1024**3)):.1f} GB"
    except: return "N/A"

def list_all_dirs(root, exclude_path=None):
    all_dirs = []
    def walk(path):
        dirs, fs = xbmcvfs.listdir(path)
        for d in dirs:
            full_p = os.path.join(path, d).replace('\\', '/') + '/'
            if exclude_path and full_p.startswith(exclude_path): continue
            all_dirs.append(full_p); walk(full_p)
    walk(root); return sorted(all_dirs)

def rmdir_recursive(path):
    dirs, files = xbmcvfs.listdir(path)
    for f in files: xbmcvfs.delete(os.path.join(path, f))
    for d in dirs: rmdir_recursive(os.path.join(path, d) + '/')
    xbmcvfs.rmdir(path)

def normalize_path(p):
    if not p: return ""
    return p.replace('\\', '/').rstrip('/')

def record_task(name, url, duration_mins, icon, is_live, final_p, rec_type="מדיה"):
    global STOP_LIST
    temp_p = final_p + ".downloading"
    
    # הבטחה שהקישור קיים והוא מחרוזת טקסט
    str_url = str(url) if url is not None else ""
    
    # --- הפרדה טוטאלית: המרת כתובת אלמנטום אך ורק אם זה פלאגין טורנט ---
    if str_url.startswith('plugin://plugin.video.elementum/play'):
        str_url = str_url.replace('plugin://plugin.video.elementum/play', 'http://127.0.0')
        xbmc.log(f"[Advanced_Rec] Elementum link converted: {str_url}", xbmc.LOGINFO)
    
    # חילוץ הקישור וה-Headers בשיטה מוגנת שלא פוגעת בטוקנים של קשת, רשת, או ברוייטקוב
    clean_url, _, h_part = str_url.partition('|')
    url_lower = clean_url.lower()
    
    from urllib.parse import urlparse
    try:
        domain = urlparse(clean_url).netloc
        referer = f"https://{domain}/"
    except:
        referer = "google.com"
        
    headers = {
        'User-Agent': UA,
        'Referer': referer,
        'Connection': 'keep-alive',
        'Accept': '*/*'
    }
    
    is_torrent = '127.0.0.1' in clean_url or ':652' in clean_url or 'localhost' in clean_url or 'elementum' in url_lower
    is_telegram = 'telegram' in url_lower or 'cdn' in url_lower
    
    # בניית מערך כותרות תקני ומלא (קריטי להאח הגדול, ערוץ 24 ומאקו)
    if h_part:
        try:
            pairs = h_part.split('&')
            for pair in pairs:
                if '=' in pair:
                    k, v = pair.split('=', 1)
                    headers[k] = v
        except: pass
        
    tasks = load_json(DB_FILE)
    tasks[final_p] = {'status': 'downloading', 'name': clean_label_smart(name), 'icon': icon or ICON, 'start_time': time.time()}
    save_json(DB_FILE, tasks)
    
    addon = xbmcaddon.Addon()
    setting_ffmpeg = addon.getSetting('use_ffmpeg') == 'true'
    ffmpeg_path = get_ffmpeg_path()
    
    # --- חוק הזרמת הלייב וה-VOD: הגדרה מורחבת שמכסה את כל סוגי הערוצים והמדיה ---
    is_m3u8 = (
        ".m3u8" in url_lower or 
        "playlist" in url_lower or 
        "chunklist" in url_lower or 
        "mako" in url_lower or 
        "cloudfront" in url_lower or 
        "brightcove" in url_lower or 
        "kaltura" in url_lower or 
        is_live
    )
    
    # כפיית שימוש ב-FFmpeg עבור כל זרם שאינו טורנט מקומי - מונע יצירת קובצי טקסט שקריים ב-VOD
    use_ffmpeg = setting_ffmpeg and is_m3u8 and not is_torrent and xbmcvfs.exists(ffmpeg_path)
    
    last_pause_notify = 0
    duration_seconds = int(duration_mins or 0) * 60
    ffmpeg_failed = False
    recording_started_successfully = False
    process = None

    temp_p_clean = re.sub(r'[*?"<>|]', '', temp_p)

    try:
        # --- שיטת א': הקלטה עם דני (FFmpeg - חובה לכל סוגי הערוצים וה-VOD המוגנים) ---
        if use_ffmpeg and xbmcvfs.exists(ffmpeg_path):
            import subprocess
            output_file = temp_p_clean.replace('/', '\\')
            
            headers_str = ""
            for key, val in headers.items():
                headers_str += f"{key}: {val}\r\n"
            
            t_limit = f"-t {duration_seconds} " if duration_seconds > 0 else ""
            
            cmd = [
                ffmpeg_path.replace('/', '\\'),
                '-headers', headers_str,
                '-protocol_whitelist', 'file,http,https,tcp,tls,crypto,plugin',
                '-i', clean_url, # שליחת הקישור הנקי כשהכותרות מוזרקות דרך שורת ה-headers_str
                '-c', 'copy',
                '-f', 'mp4',
                '-movflags', 'faststart',
                output_file,
                '-y'
            ]
            if t_limit:
                cmd.insert(1, '-t'); cmd.insert(2, str(duration_seconds))
                
            process = subprocess.Popen(cmd, creationflags=0x08000000)
            
            check_start = time.time()
            while time.time() - check_start < 6.0: 
                if process.poll() is not None:
                    ffmpeg_failed = True
                    break
                if os.path.exists(temp_p_clean) and os.path.getsize(temp_p_clean) > 0:
                    recording_started_successfully = True
                    break
                time.sleep(0.2)
            
            if not recording_started_successfully:
                ffmpeg_failed = True
                try: process.terminate()
                except: pass

            if not ffmpeg_failed:
                while process.poll() is None:
                    if xbmc.Monitor().abortRequested() or final_p in STOP_LIST:
                        process.terminate(); break
                        
                    if xbmc.getCondVisibility('Player.Paused') and (time.time() - last_pause_notify > 10):
                        try:
                            if os.path.exists(temp_p_clean):
                                cur_s = os.path.getsize(temp_p_clean) / (1024.0 * 1024.0)
                                xbmcgui.Dialog().notification("סטטוס הקלטה", f"גודל קובץ: {cur_s:.1f} MB", ICON, 3000, False)
                                last_pause_notify = time.time()
                        except: pass
                        
                    time.sleep(1)
                
        # --- שיטת ב': הורדה ישירה (עבור קבצי וידאו מלאים וטורנטים של אלמנטום) ---
        if not use_ffmpeg or ffmpeg_failed:
            session = requests.Session()
            session.verify = False
            session.headers.update(headers)
            
            r = session.get(clean_url, stream=True, timeout=30, verify=False)
            start_rec_time = time.time()
            
            with open(temp_p_clean, 'wb') as output:
                chunk_size = 128 * 1024 if is_torrent else 512 * 1024
                
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if final_p in STOP_LIST or xbmc.Monitor().abortRequested(): break
                    if duration_seconds > 0 and (time.time() - start_rec_time) >= duration_seconds: break
                    
                    if chunk: 
                        output.write(chunk)
                        if is_torrent: 
                            output.flush()
                            
                    if xbmc.getCondVisibility('Player.Paused') and (time.time() - last_pause_notify > 10):
                        try:
                            if os.path.exists(temp_p_clean):
                                cur_s = os.path.getsize(temp_p_clean) / (1024.0 * 1024.0)
                                if cur_s >= 1024:
                                    xbmcgui.Dialog().notification("סטטוס הקלטה", f"גודל קובץ: {(cur_s/1024.0):.2f} GB", ICON, 3000, False)
                                else:
                                    xbmcgui.Dialog().notification("סטטוס הקלטה", f"גודל קובץ: {cur_s:.1f} MB", ICON, 3000, False)
                                last_pause_notify = time.time()
                        except: pass
                                
    except Exception as e:
        xbmc.log(f"Advanced Rec Error: {str(e)}", xbmc.LOGERROR)
    finally:
        try:
            if process and process.poll() is None: process.kill()
        except: pass
        
        if os.path.exists(temp_p_clean):
            size = os.path.getsize(temp_p_clean)
            if size < 50000: 
                try: os.remove(temp_p_clean)
                except: pass
                if xbmcvfs.exists(final_p + ".meta"): xbmcvfs.delete(final_p + ".meta")
            else:
                xbmcvfs.rename(temp_p_clean, final_p)
                xbmcgui.Dialog().notification("Advanced Rec", f"סיום: {name}", icon or ICON, 5000)
        tsks = load_json(DB_FILE); tsks.pop(final_p, None); save_json(DB_FILE, tsks)












def wait_and_record_task(heb_name, eng_name, wait_min, duration_mins, icon, is_live, sid, saved_url=None, rec_type="מדיה"):
    if int(wait_min or 0) > 0:
        time.sleep(int(wait_min) * 60)
    
    file_n = eng_name if eng_name else super_clean_name(heb_name)
    pt = CHANNELS_PATH if (is_live or rec_type == "מתוזמן") else MEDIA_PATH
    ext = ".mp4"
    final_url = saved_url
    
    if not final_url:
        player = xbmc.Player()
        start_wait_time = time.time()
        while not player.isPlaying():
            if xbmc.Monitor().abortRequested() or (time.time() - start_wait_time > 90): return
            time.sleep(1)
        time.sleep(2) 
        final_url = player.getPlayingFile()

    if final_url:
        url_lower = str(final_url).lower()
        
        is_elementum = ('127.0.0.1' in url_lower or 'localhost' in url_lower or ':652' in url_lower or 'elementum' in url_lower)
        is_vod_or_telegram = 'telegram' in url_lower or 'cdn' in url_lower or rec_type == "מדיה"
        is_torrent_or_vod = is_elementum or is_vod_or_telegram

        if is_elementum: 
            ext = ".mkv"

        if is_torrent_or_vod and not is_live:
            try:
                clean_link, _, _ = str(final_url).partition('|')
                url_unquoted = unquote(clean_link)
                dn_match = re.search(r'[&?]dn=([^&]+)', url_unquoted, re.I)
                extracted_name = dn_match.group(1) if dn_match else url_unquoted.split('/')[-1].split('\\')[-1]
                
                if extracted_name and any(q in extracted_name.lower() for q in ['1080', '720', '2160', 'bluray', 'web', 'x264', 'h264', 'ethel', 'RELEASE']):
                    extracted_name = re.sub(r'\.(mp4|mkv|ts|avi|downloading)$', '', extracted_name, flags=re.I)
                    file_n = extracted_name.replace(' ', '.').replace('_', '.').replace('-', '.')
                    eng_name = file_n
                    xbmc.log(f"[Advanced_Rec] Saved exact release name for subtitles: {file_n}", xbmc.LOGINFO)
            except: pass

            xbmc.log("[Advanced_Rec] Torrent/VOD stability delay... 10 seconds", xbmc.LOGINFO)
            time.sleep(10)
            final_url = player.getPlayingFile() or final_url

        xbmcgui.Dialog().notification("Advanced Rec", f"הקלטה החלה: {heb_name}", icon or ICON, 4000)

        fp = os.path.join(pt, f"{file_n}{ext}").replace('\\', '/')
        if xbmcvfs.exists(fp):
            fp = os.path.join(pt, f"{file_n}_{sid}{ext}").replace('\\', '/')

        s = load_json(SCHED_FILE)
        s.pop(sid, None)
        save_json(SCHED_FILE, s)
        
        # --- תיקון חוק הברזל הגרפי: ניקוי שדה האייקון מקובץ ה-Meta המלווה ---
        # אנחנו מסירים לחלוטין את מפתח ה-"icon" מכאן! 
        # זה משחרר את הנעילה של קודי ומכריח אותו לחלץ פריים דינמי ישירות מהוידאו
        save_json(fp + ".meta", {
            "display_name": heb_name, 
            "original_name": eng_name,
            "timestamp": time.time(),
            "source_url": str(final_url)
        })
        
        record_task(heb_name, final_url, duration_mins, icon, is_live, fp, rec_type)














VERSION_FILE = os.path.normpath(os.path.join(BIN_PATH, 'version.txt'))
GITHUB_API_TAG_URL = "https://github.com"

def check_and_download_ytdlp_exe():
    """
    בודק מול GitHub אם קיימת גרסה חדשה ל-yt-dlp.exe.
    אם הקובץ חסר או יש גרסה חדשה, מוריד ודורס אוטומטית את הישן.
    """
    latest_tag = ""
    try:
        headers = {'User-Agent': UA}
        api_res = requests.get(GITHUB_API_TAG_URL, headers=headers, timeout=10)
        if api_res.status_code == 200:
            latest_tag = api_res.json().get('tag_name', '')
    except:
        pass

    # קריאת הגרסה המקומית שנשמרה בפעם הקודמת
    current_version = ""
    if os.path.exists(VERSION_FILE):
        try:
            with open(VERSION_FILE, 'r', encoding='utf-8') as f:
                current_version = f.read().strip()
        except:
            pass

    # האם צריך עדכון? (אם הקובץ לא קיים, או שהגרסה ב-GitHub שונה מהמקומית)
    needs_update = not os.path.exists(YTDLP_EXE_PATH) or (latest_tag and latest_tag != current_version)

    if not needs_update:
        return True

    xbmc.log(f"[Advanced_Rec] Updating yt-dlp.exe to version {latest_tag}...", xbmc.LOGINFO)
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Advanced Rec', 'מעדכן רכיב יוטיוב למשתמש...', 'מעדכן לגרסה החדשה ביותר, אנא המתן.')

    # מחיקת הקובץ הישן כדי לדרוס אותו נקי
    if os.path.exists(YTDLP_EXE_PATH):
        try: os.remove(YTDLP_EXE_PATH)
        except: pass

    try:
        headers = {'User-Agent': UA}
        response = requests.get(YTDLP_EXE_URL, headers=headers, stream=True, timeout=30)
        response.raise_for_status()
        total_size = int(response.headers.get('content-length', 0))
        
        with open(YTDLP_EXE_PATH, 'wb') as f:
            downloaded = 0
            for chunk in response.iter_content(chunk_size=8192):
                if pDialog.iscanceled():
                    pDialog.close()
                    return False
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = int((downloaded / total_size) * 100)
                        pDialog.update(percent, f"מעדכן רכיב יוטיוב... {percent}%")
                        
        pDialog.close()
        
        # שמירת מספר הגרסה החדש מקומית כדי שלא יעדכן שוב בחינם בפעם הבאה
        if latest_tag:
            with open(VERSION_FILE, 'w', encoding='utf-8') as f:
                f.write(latest_tag)
                
        xbmcgui.Dialog().notification("Advanced Rec", "הרכיב עודכן בהצלחה!", ICON, 4000)
        return True
    except Exception as e:
        pDialog.close()
        xbmc.log(f"[Advanced_Rec] Update failed: {str(e)}", xbmc.LOGERROR)
        return False




def download_youtube_direct(url, output_name, icon):
    """
    מוריד מיוטיוב באמצעות קובץ ה-EXE החיצוני בצורה שקטה וללא שאלות.
    האיכות נקבעת אוטומטית לפי הגדרות התוסף, והנוטיפיקציה כוללת את שם המדיה.
    """
    import subprocess
    import re
    
    # בדיקה מוקדמת אם רכיב ה-EXE קיים במערכת
    if not xbmcvfs.exists(YTDLP_EXE_PATH):
        xbmcgui.Dialog().ok(
            f"{RTL}רכיב חסר", 
            f"{RTL}הורדת יוטיוב דורשת את הרכיב yt-dlp.exe.\nאנא כנס למסך התחזוקה בתוסף כדי להתקין אותו."
        )
        return

    # קריאת הגדרת איכות ההורדה ישירות ממסך ההגדרות של התוסף
    try:
        is_max_quality = ADDON.getSetting('youtube_quality') == 'true'
    except:
        is_max_quality = True

    clean_filename = super_clean_name(output_name)
    final_p = os.path.join(MEDIA_PATH, f"{clean_filename}.mp4").replace('\\', '/')
    
    if xbmcvfs.exists(final_p):
        final_p = os.path.join(MEDIA_PATH, f"{clean_filename}_{int(time.time())}.mp4").replace('\\', '/')
        
    ffmpeg_bin = get_ffmpeg_path()
    has_ffmpeg = xbmcvfs.exists(ffmpeg_bin) or ffmpeg_bin == "ffmpeg"
    
    # חילוץ מזהה הסרטון (Video ID) בצורה חכמה ומאובטחת
    video_id = None
    
    # חילוץ ה-ID מתוך ה-url (גם אם הוא באותיות קטנות בגלל הבאג של התוסף)
    match = re.search(r'([a-zA-Z0-9_-]{11})', str(url))
    if match:
        video_id = match.group(1)

    # בניית כתובת אינטרנט או פקודת חיפוש חסינת תקלות עבור yt-dlp
    if video_id:
        # טריק מנצח: שולחים ל-yt-dlp פקודת חיפוש לפי ה-ID. 
        # יוטיוב תמיד ימצא את הסרטון המדויק ראשון, וזה עוקף לחלוטין את בעיית האותיות הקטנות/גדולות!
        clean_url = f"ytsearch1:{video_id}"
    else:
        clean_url = url
    
    # בניית ארגומנטים בסיסיים + עקיפת חסימת ה-JS והפעלת מנוע ה-QuickJS הפנימי מהתיקייה
    cmd = [
        YTDLP_EXE_PATH, clean_url, 
        '--no-update', '--quiet', 
        '--remote-components', 'ejs:github',
        '--js-runtimes', f'quickjs:{QJS_EXE_PATH}'
    ]

    # --- התיקון: הגדרת הנתיב הזמני כאן (לפני השימוש בו) כדי למנוע את שגיאת ה-NameError ---
    temp_output_p = os.path.join(MEDIA_PATH, f"ytdl_temp_{int(time.time())}").replace('\\', '/')


    # --- התיקון: הגדרת הנתיב הזמני כאן (לפני השימוש בו) כדי למנוע את שגיאת ה-NameError ---
    temp_output_p = os.path.join(MEDIA_PATH, f"ytdl_temp_{int(time.time())}").replace('\\', '/')

    # קביעת איכות ההורדה הדינמית לפי הגדרת המשתמש וקיום FFmpeg במערכת
    if is_max_quality and has_ffmpeg:
        xbmc.log(f"[Advanced_Rec] YouTube EXE: Max quality requested for {output_name}", xbmc.LOGINFO)
        cmd.extend(['-f', 'bestvideo+bestaudio/best', '--merge-output-format', 'mp4', '-o', temp_output_p + '.%(ext)s'])
        if ffmpeg_bin != "ffmpeg":
            cmd.extend(['--ffmpeg-location', os.path.dirname(ffmpeg_bin)])
        status_msg = "באיכות מקסימלית"
    else:
        xbmc.log(f"[Advanced_Rec] YouTube EXE: Standard combined MP4 requested for {output_name}", xbmc.LOGINFO)
        cmd.extend(['-f', 'best[ext=mp4]/best', '-o', temp_output_p + '.mp4'])
        status_msg = "באיכות רגילה"

    save_json(final_p + ".meta", {
        "display_name": output_name, 
        "original_name": output_name, 
        "icon": icon or ICON, 
        "timestamp": time.time()
    })


    def run_external_exe():
        try:
            xbmcgui.Dialog().notification("Advanced Rec", f"הקלטת יוטיוב החלה ({status_msg}): {output_name}", icon or ICON, 4000)
            
            tasks = load_json(DB_FILE)
            tasks[final_p] = {'status': 'downloading', 'name': output_name, 'icon': icon or ICON, 'start_time': time.time()}
            save_json(DB_FILE, tasks)
            
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                
            safe_cmd = [str(arg) for arg in cmd]
            process = subprocess.Popen(safe_cmd, startupinfo=startupinfo, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = process.communicate()
            
            if process.returncode == 0:
                # שינוי השם מהנתיב הזמני באנגלית לנתיב הסופי בעברית
                actual_temp_file = temp_output_p + ".mp4"
                if os.path.exists(actual_temp_file):
                    try:
                        if os.path.exists(final_p): os.remove(final_p)
                        os.rename(actual_temp_file, final_p)
                        xbmcgui.Dialog().notification("Advanced Rec", f"הורדת יוטיוב הסתיימה: {output_name}", icon or ICON, 5000)
                    except Exception as rename_err:
                        xbmc.log(f"[Advanced_Rec] YouTube Rename Failed: {str(rename_err)}", xbmc.LOGERROR)
                        raise Exception("שגיאה בשינוי שם הקובץ הסופי")
                else:
                    raise Exception("קובץ ההורדה הזמני לא נמצא במערכת")
            else:
                error_msg = stderr.decode('utf-8', errors='ignore')
                xbmc.log(f"[Advanced_Rec] YouTube EXE Error (Code {process.returncode}): {error_msg}", xbmc.LOGERROR)
                raise Exception(f"Exit code {process.returncode}")
                
        except Exception as e:
            xbmc.log(f"[Advanced_Rec] YouTube External Download Failed: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Advanced Rec", "הורדת יוטיוב נכשלה", ICON, 4000)
            if os.path.exists(final_p): os.remove(final_p)
            if os.path.exists(final_p + ".meta"): os.remove(final_p + ".meta")
            try:
                if os.path.exists(temp_output_p + ".mp4"): os.remove(temp_output_p + ".mp4")
            except: pass
        finally:
            tsks = load_json(DB_FILE)
            tsks.pop(final_p, None)
            save_json(DB_FILE, tsks)
            
    threading.Thread(target=run_external_exe).start()























def auto_update_ytdl():
    """בודק ומעדכן את ספריית yt_dlp לגרסה האחרונה ברקע."""
    current_addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
    if current_addon_path not in sys.path:
        sys.path.append(current_addon_path)
        
    def do_update():
        try:
            import yt_dlp
            from yt_dlp.update import run_updater
            xbmc.log("[Advanced_Rec] Checking for yt-dlp updates...", xbmc.LOGINFO)
            
            # הפעלת מנגנון העדכון הרשמי של yt-dlp שמעדכן את קבצי המקור בתוסף
            # המשתנה self_update=True אומר לו לעדכן את קבצי הפייתון המקומיים
            updater = run_updater(ydl=None, verbose=False, tag=None)
            if updater:
                xbmc.log("[Advanced_Rec] yt-dlp updated successfully to the latest version!", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Advanced_Rec] yt-dlp auto update failed: {str(e)}", xbmc.LOGWARNING)

    # הרצה ב-Thread נפרד כדי שלא יעכב את פתיחת התוסף או ההורדה
    threading.Thread(target=do_update).start()




def install_ytdlp_exe_from_maintenance():
    """
    מתקין או מעדכן את רכיב ה-yt-dlp.exe יחד עם מנוע ה-JS בגרסתו העדכנית ביותר ישירות מ-GitHub.
    """
    confirm = xbmcgui.Dialog().yesno(
        f"{RTL}התקנת רכיבי יוטיוב",
        f"{RTL}האם ברצונך להוריד ולהתקין את רכיבי יוטיוב העדכניים ביותר?\nפעולה זו תוריד אוטומטית את הגרסאות החדשות ביותר מהשרת לעקיפת החסימות."
    )
    if not confirm: return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Advanced Rec', 'מתחבר לשרתי GitHub לבדיקת גרסאות... אנא המתן.')
    
    # 1. פנייה ל-API של GitHub כדי למצוא את הקישור העדכני ביותר ל-qjs.exe
    qjs_download_url = None
    try:
        pDialog.update(5, "בודק מהי הגרסה האחרונה של מנוע ה-JS...")
        api_response = requests.get(QJS_API_LATEST_URL, timeout=15)
        api_response.raise_for_status()
        release_data = api_response.json()
        
        # סריקת הקבצים בגרסה האחרונה - מותאם לשמות הקבצים החדשים של GitHub
        for asset in release_data.get('assets', []):
            asset_name = asset.get('name', '').lower()
            if 'windows-x86_64.exe' in asset_name or 'win64.exe' in asset_name or 'win-x64' in asset_name:
                qjs_download_url = asset.get('browser_download_url')
                break
                
        # גיבוי מעודכן במידה וה-API נכשל: קישור ישיר לגרסה היציבה v0.15.0 העדכנית
        if not qjs_download_url:
            qjs_download_url = "https://github.com" + "/quickjs-ng/quickjs" + "/releases/download/v0.15.0" + "/qjs-windows-x86_64.exe"
    except Exception as api_err:
        xbmc.log(f"[Advanced_Rec] GitHub API failed, using fallback URL: {str(api_err)}", xbmc.LOGWARNING)
        qjs_download_url = "https://github.com" + "/quickjs-ng/quickjs" + "/releases/download/v0.15.0" + "/qjs-windows-x86_64.exe"

    # 2. הורדת קובץ ה-yt-dlp הראשי
    try:
        pDialog.update(20, "מוריד את רכיב ההורדה הראשי (yt-dlp.exe)...")
        res1 = requests.get(YTDLP_EXE_URL, stream=True, timeout=30)
        res1.raise_for_status()
        with open(YTDLP_EXE_PATH, 'wb') as f:
            for chunk in res1.iter_content(chunk_size=8192):
                if chunk: f.write(chunk)
                
        # 3. הורדת מנוע ה-JavaScript הדינמי שגילינו מה-API
        pDialog.update(60, "מוריד את הגרסה העדכנית ביותר של מנוע הריצה (qjs.exe)...")
        res2 = requests.get(qjs_download_url, stream=True, timeout=30)
        res2.raise_for_status()
        with open(QJS_EXE_PATH, 'wb') as f:
            for chunk in res2.iter_content(chunk_size=8192):
                if chunk: f.write(chunk)
                        
        pDialog.close()
        xbmcgui.Dialog().ok("Advanced Rec", "כל רכיבי יוטיוב ומנועי הריצה הותקנו והוגדרו בגרסתם העדכנית ביותר!")
    except Exception as e:
        pDialog.close()
        xbmc.log(f"[Advanced_Rec] Maintenance download failed: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Advanced Rec", f"ההתקנה נכשלה: {str(e)}\nודא חיבור לרשת ונסה שוב.")
        if os.path.exists(YTDLP_EXE_PATH): os.remove(YTDLP_EXE_PATH)
        if os.path.exists(QJS_EXE_PATH): os.remove(QJS_EXE_PATH)






def main():
    try: 
        handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
    except: 
        handle = -1
    
    arg_str = str(sys.argv[2]) if len(sys.argv) > 2 else ""
    if arg_str.startswith('?'): arg_str = arg_str[1:]
    params = parse_qs(arg_str)

    # --- מנגנון ניקוי ונרמול פרמטרים הרמטי למניעת בלאגן בקטגוריות ---
    # הופך את כל ערכי המפתח ממערך למחרוזת טקסט חלקה (String)
    act = params.get('action', [None])[0]
    mode = params.get('mode', [None])[0]
    # -----------------------------------------------------------------

    if act:
        db = load_json(FOLDERS_DB)

        if act == 'play_file':
            raw_file = params.get('file', [None])
            if raw_file and raw_file[0]:
                file_to_play = str(raw_file[0]).strip("[]'\"")
                # כפיית הפעלה ישירה של הנגן על הקובץ הפיזי בדיסק
                xbmc.Player().play(file_to_play)
            return

        if act == 'start_scheduled':
            sid = params.get('sid', [None])[0]
            new_dur = params.get('new_dur', [None])[0]
            s_db = load_json(SCHED_FILE)
            if sid and sid in s_db:
                t = s_db[sid]
                orig_url = t['url']
                final_dur = int(new_dur) if new_dur else t['dur']
                link_ok = False
                try:
                    r = requests.head(orig_url.split('|')[0], timeout=5, headers={'User-Agent': UA})
                    if r.status_code < 400: link_ok = True
                except: pass


                if not link_ok:
                    refresh_path = t.get('orig_path', orig_url)
                    xbmc.executebuiltin(f'PlayMedia({refresh_path})')
                    player = xbmc.Player(); start_w = time.time()
                    while time.time() - start_w < 30:
                        if player.isPlaying():
                            new_v = player.getPlayingFile()
                            if new_v and not new_v.startswith('plugin://'):
                                orig_url = new_v
                                break
                        time.sleep(1)

                threading.Thread(target=wait_and_record_task, args=(t['name'], t.get('eng_name', ""), 0, final_dur, ICON, True, sid, orig_url, "מתוזמן")).start()
            return

        elif act == 'add_folder':
            n = xbmcgui.Dialog().input(f"{RTL}שם התיקייה:")
            if n:
                np = os.path.join(SAVED_PATH, n.strip()) + '/'
                if xbmcvfs.mkdirs(np):
                    sel = xbmcgui.Dialog().select(f"{RTL}תמונה", ["מכתובת", "מקובץ", "מחדל"])
                    img = xbmcgui.Dialog().input("URL:") if sel == 0 else xbmcgui.Dialog().browse(2, "תמונה", 'files', '.jpg|.png') if sel == 1 else FOLDER_IMG
                    db[normalize_path(np)] = img; save_json(FOLDERS_DB, db)
        elif act == 'edit_folder':
            fp = params.get('path', [None])[0]
            if fp:
                choice = xbmcgui.Dialog().select(f"{RTL}עריכה", ["שם", "תמונה", "העבר תיקייה", "מחק"])
                if choice == 0:
                    nn = xbmcgui.Dialog().input("חדש:", os.path.basename(fp.rstrip('/')))
                    if nn:
                        new_p = os.path.join(os.path.dirname(fp.rstrip('/')), nn.strip()) + '/'
                        if xbmcvfs.rename(fp, new_p):
                            db[normalize_path(new_p)] = db.pop(normalize_path(fp), FOLDER_IMG); save_json(FOLDERS_DB, db)
                elif choice == 1:
                    sel = xbmcgui.Dialog().select("תמונה", ["מכתובת", "מקובץ", "מחדל"])
                    db[normalize_path(fp)] = xbmcgui.Dialog().input("URL:") if sel == 0 else xbmcgui.Dialog().browse(2, "תמונה", 'files', '.jpg|.png') if sel == 1 else FOLDER_IMG
                    save_json(FOLDERS_DB, db)
                elif choice == 2:
                    dirs = [SAVED_PATH] + list_all_dirs(SAVED_PATH, exclude_path=fp)
                    sel = xbmcgui.Dialog().select(f"{RTL}העבר אל:", [os.path.basename(o.rstrip('/')) or "ראשי" for o in dirs])
                    if sel >= 0:
                        dest = os.path.join(dirs[sel], os.path.basename(fp.rstrip('/'))) + '/'
                        if xbmcvfs.rename(fp, dest):
                            db[normalize_path(dest)] = db.pop(normalize_path(fp), FOLDER_IMG); save_json(FOLDERS_DB, db)
                elif choice == 3 and xbmcgui.Dialog().yesno("מחק", "מחק הכל?"):
                    rmdir_recursive(fp); db.pop(normalize_path(fp), None); save_json(FOLDERS_DB, db)
        elif act == 'move':
            if 'file' in params:
                raw_fp = params['file']
                fp = str(raw_fp) if isinstance(raw_fp, list) else str(raw_fp)
                fp = fp.strip("[]'\"")
            else: fp = ""

            if not fp or fp == "":
                xbmcgui.Dialog().notification("Advanced Rec", "שגיאה: נתיב קובץ לא תקין", ICON, 4000)
                return
                
            filename = os.path.basename(fp)
            
            # יצירה אוטומטית ושקטה של 5 תיקיות הברזל הראשיות בדיסק (כולל יוטיוב)
            categories = {
                "סרטים": os.path.join(SAVED_PATH, "סרטים").replace('\\', '/') + '/',
                "סדרות": os.path.join(SAVED_PATH, "סדרות").replace('\\', '/') + '/',
                "ערוצים": os.path.join(SAVED_PATH, "ערוצים").replace('\\', '/') + '/',
                "VOD עידן": os.path.join(SAVED_PATH, "VOD עידן").replace('\\', '/') + '/',
                "יוטיוב": os.path.join(SAVED_PATH, "יוטיוב").replace('\\', '/') + '/'
            }
            for c_path in categories.values():
                if not xbmcvfs.exists(c_path): xbmcvfs.mkdirs(c_path)

            # שלב א': הצגת 5 התיקיות הראשיות למשתמש בדו-שיח הבחירה
            cat_keys = list(categories.keys())
            cat_sel = xbmcgui.Dialog().select(f"{RTL}העבר אל קטגוריה ראשית:", [f">>> {k}" for k in cat_keys])
            
            if cat_sel >= 0:
                chosen_cat = cat_keys[cat_sel]
                base_dir = categories[chosen_cat]
                dest_folder = ""

                # --- קטגוריית סדרות (מיון אוטומטי לפי עונות) ---
                if chosen_cat == "סדרות":
                    se_match = re.search(r'\.S(\d+)[E\d+]|עונה\.(\d+)\.פרק', filename, re.I)
                    
                    meta_p = fp + ".meta"
                    meta_data = load_json(meta_p) if xbmcvfs.exists(meta_p) else {}
                    clean_show_name = meta_data.get('original_name', filename)
                    
                    clean_show_name = re.sub(r'\.(mp4|mkv|ts|avi|downloading)$', '', clean_show_name, flags=re.I)
                    clean_show_name = re.sub(r'[\._ ]?([Ss]\d+[Ee]\d+|עונה\s*\d+|פרק\s*\d+|1080p|720p|WEB|h264|x264|ETHEL).*$', '', clean_show_name, flags=re.I)
                    clean_show_name = clean_show_name.replace('.', ' ').replace('_', ' ').replace('-', ' ').strip()
                    if not clean_show_name: clean_show_name = "סדרה מוקלטת"

                    show_folder_path = os.path.join(base_dir, clean_show_name).replace('\\', '/') + '/'
                    
                    if not xbmcvfs.exists(show_folder_path):
                        if xbmcgui.Dialog().yesno("Advanced Rec", f"{RTL}האם ליצור תיקייה חדשה עבור הסדרה:\n[COLOR lime]{clean_show_name}[/COLOR]?"):
                            xbmcvfs.mkdirs(show_folder_path)
                        else: show_folder_path = base_dir

                    if show_folder_path != base_dir:
                        s_num = int(se_match.group(1) or se_match.group(2)) if se_match else 1
                        season_folder_path = os.path.join(show_folder_path, f"{clean_show_name} עונה {s_num}").replace('\\', '/') + '/'
                        if not xbmcvfs.exists(season_folder_path): xbmcvfs.mkdirs(season_folder_path)
                        dest_folder = season_folder_path
                    else:
                        dest_folder = base_dir

                # --- קטגוריית VOD עידן (מקלדת ידנית + בחירה) ---
                elif chosen_cat == "VOD עידן":
                    idan_opts = [f"{RTL}1. בחר סדרה קיימת ב-VOD עידן", f"{RTL}2. צור סדרה חדשה (פתח מקלדת)"]
                    idan_sel = xbmcgui.Dialog().select(f"{RTL}ניהול תיקיות VOD עידן", idan_opts)
                    
                    if idan_sel == 0:
                        try: existing_shows, _ = xbmcvfs.listdir(base_dir)
                        except: existing_shows = []
                        if not existing_shows:
                            xbmcgui.Dialog().ok("Advanced Rec", "לא נמצאו סדרות. הנך מועבר למקלדת.")
                            idan_sel = 1
                        else:
                            show_sel = xbmcgui.Dialog().select(f"{RTL}בחר סדרה:", existing_shows)
                            if show_sel >= 0:
                                show_path = os.path.join(base_dir, existing_shows[show_sel]).replace('\\', '/') + '/'
                                try: existing_seasons, _ = xbmcvfs.listdir(show_path)
                                except: existing_seasons = []
                                
                                if existing_seasons:
                                    season_sel = xbmcgui.Dialog().select(f"{RTL}בחר עונה:", existing_seasons)
                                    if season_sel >= 0: dest_folder = os.path.join(show_path, existing_seasons[season_sel]).replace('\\', '/') + '/'
                                    else: return
                                else:
                                    season_input = xbmcgui.Dialog().input(f"{RTL}הזן מספר עונה:")
                                    season_str = f"עונה {season_input}" if season_input else "עונה 1"
                                    dest_folder = os.path.join(show_path, f"{existing_shows[show_sel]} {season_str}").replace('\\', '/') + '/'
                                    if not xbmcvfs.exists(dest_folder): xbmcvfs.mkdirs(dest_folder)
                            else: return
                    if idan_sel == 1:
                        show_input = xbmcgui.Dialog().input(f"{RTL}מה שם הסדרה החדשה של עידן?")
                        if show_input:
                            season_input = xbmcgui.Dialog().input(f"{RTL}איזו עונה (מספר)?")
                            season_str = f"עונה {season_input}" if season_input else "עונה 1"
                            custom_show_dir = os.path.join(base_dir, show_input.strip()).replace('\\', '/') + '/'
                            dest_folder = os.path.join(custom_show_dir, f"{show_input.strip()} {season_str}").replace('\\', '/') + '/'
                            if not xbmcvfs.exists(custom_show_dir): xbmcvfs.mkdirs(custom_show_dir)
                            if not xbmcvfs.exists(dest_folder): xbmcvfs.mkdirs(dest_folder)
                        else: return

                # --- קטגוריות סרטים, ערוצים ויוטיוב (הצגת תתי-תיקיות/ז'אנרים פנימיים) ---
                else:
                    try: sub_dirs, _ = xbmcvfs.listdir(base_dir)
                    except: sub_dirs = []
                    
                    if sub_dirs:
                        sub_opts = [f"{RTL}[COLOR lime]+ צור תת-תיקייה חדשה כאן[/COLOR]"] + [f"> {sd}" for sd in sub_dirs]
                        sub_sel = xbmcgui.Dialog().select(f"{RTL}בחר מיקום בתוך {chosen_cat}:", sub_opts)
                        if sub_sel == 0:
                            new_sub = xbmcgui.Dialog().input(f"{RTL}שם תת-התיקייה החדשה:")
                            if new_sub:
                                dest_folder = os.path.join(base_dir, new_sub.strip()).replace('\\', '/') + '/'
                                if not xbmcvfs.exists(dest_folder): xbmcvfs.mkdirs(dest_folder)
                            else: return
                        elif sub_sel > 0:
                            dest_folder = os.path.join(base_dir, sub_dirs[sub_sel - 1]).replace('\\', '/') + '/'
                        else: return
                    else:
                        if xbmcgui.Dialog().yesno("Advanced Rec", f"{RTL}האם ליצור תת-תיקייה פנימית (כמו נושא/ז'אנר) בתוך {chosen_cat}?"):
                            new_sub = xbmcgui.Dialog().input(f"{RTL}שם תת-התיקייה:")
                            if new_sub:
                                dest_folder = os.path.join(base_dir, new_sub.strip()).replace('\\', '/') + '/'
                                if not xbmcvfs.exists(dest_folder): xbmcvfs.mkdirs(dest_folder)
                            else: return
                        else:
                            dest_folder = base_dir

                # ביצוע ההעברה הפיזית בדיסק
                if dest_folder:
                    dest = os.path.join(dest_folder, filename).replace('\\', '/')
                    if xbmcvfs.copy(fp, dest):
                        xbmcvfs.delete(fp)
                        if xbmcvfs.exists(fp + ".meta"):
                            xbmcvfs.copy(fp + ".meta", dest + ".meta")
                            xbmcvfs.delete(fp + ".meta")
                        xbmcgui.Dialog().notification("Advanced Rec", "הקובץ הועבר ומוין בהצלחה", ICON, 3000)
            else: return









        elif act == 'delete_one':
            fp = params.get('file', [None])[0]
            sid = params.get('sid', [None])[0]
            if fp and fp != 'none':
                for e in ['', '.downloading', '.meta']:
                    if xbmcvfs.exists(fp + e): xbmcvfs.delete(fp + e)
                tsks = load_json(DB_FILE); tsks.pop(fp, None); save_json(DB_FILE, tsks)
            if sid and sid != 'none':
                s_db = load_json(SCHED_FILE)
                s_db.pop(sid, None); save_json(SCHED_FILE, s_db)
        elif act == 'clear_all':
            p = params.get('path', [None])[0]
            if p and xbmcgui.Dialog().yesno("מחיקה", "למחוק הכל?"):
                _, fs = xbmcvfs.listdir(p)
                for f in fs: xbmcvfs.delete(os.path.join(p, f))
        elif act == 'install_ffmpeg': download_ffmpeg()
        elif act == 'install_ytdlp': install_ytdlp_exe_from_maintenance()
        elif act == 'show_space':
            xbmcgui.Dialog().ok(f"{RTL}מצב זיכרון", f"{RTL}שטח פנוי בדיסק: {get_free_space()}")
            
        elif act == 'toggle_darksubs':
            try:
                xml_p = xbmcvfs.translatePath('special://profile/addon_data/service.subtitles.All_Subs/settings.xml')
                if not xbmcvfs.exists(xml_p):
                    xbmcgui.Dialog().ok("שגיאה", "תוסף DarkSubs לא נמצא במערכת"); return

                with xbmcvfs.File(xml_p, 'r') as f: content = f.read()
                match = re.search(r'id="ExcludedAddons">(.*?)</setting>', content)
                curr_val = match.group(1) if match else ""
                ex_list = [x.strip() for x in curr_val.split(',') if x.strip()]
                
                if ADDON_ID in ex_list:
                    ex_list = [x for x in ex_list if x != ADDON_ID]
                    msg = "[B][COLOR lime]הכתוביות הופעלו![/COLOR][/B]"
                else:
                    ex_list.append(ADDON_ID)
                    msg = "[B][COLOR red]הכתוביות נוטרלו![/COLOR][/B]"
                
                new_content = re.sub(r'id="ExcludedAddons">.*?</setting>', f'id="ExcludedAddons">{",".join(ex_list)}</setting>', content)
                with xbmcvfs.File(xml_p, 'w') as f: f.write(new_content)
                
                xbmcgui.Dialog().ok("Advanced Rec", f"{msg}\n\n[COLOR yellow]יש להפעיל מחדש את קודי (Restart)\nכדי שהשינוי ייכנס לתוקף.[/COLOR]")
            except Exception as e:
                xbmcgui.Dialog().notification("שגיאה", str(e), ICON, 4000)
        
        xbmc.executebuiltin('Container.Refresh'); return

    # --- מנגנון תצוגת הקטגוריות והתפריטים (handle != -1) ---
    if handle != -1:
        if not mode: mode = 'root'
        xbmcplugin.setContent(handle, 'movies')
        
        if mode == 'root':
            for l, m in [('ערוצים', 'channels'), ('מדיה', 'media'), ('תחזוקה', 'tools')]:
                li = xbmcgui.ListItem(label=f"{RTL}[B]{l}[/B]"); li.setArt({'icon': ICON, 'fanart': FANART})
                xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?mode={m}", li, True)
        
        elif mode == 'tools':
            is_excluded = False
            try:
                xml_check = xbmcvfs.translatePath('special://profile/addon_data/service.subtitles.All_Subs/settings.xml')
                if xbmcvfs.exists(xml_check):
                    with xbmcvfs.File(xml_check, 'r') as f:
                        if ADDON_ID in f.read(): is_excluded = True
            except: pass

            # --- 1. שלוש הקטגוריות המובילות---
            # תיקון קריטי: שימוש ב-sys.argv[0] כדי לבנות נתיב תוסף תקני לחלוטין לקודי
            for l, m, c in [("הורדות שמורות", "saved", "aqua"), ("משימות הקלטה מתוזמנות", "scheduled", "lime"), ("הורדות פעילות ברקע", "active", "yellow")]:
                li = xbmcgui.ListItem(label=f"{RTL}[COLOR {c}]{l}[/COLOR]"); li.setArt({'icon': ICON, 'fanart': FANART})
                xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?mode={m}", li, True)
            
            # --- 2. בדיקת זיכרון פנוי בדיסק  ---
            li = xbmcgui.ListItem(label=f"{RTL}[COLOR white]בדיקת שטח זיכרון פנוי בדיסק[/COLOR]"); li.setArt({'icon': ICON, 'fanart': FANART})
            xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?action=show_space", li, False)

            # --- 3. כפתור DarkSubs ---
            sub_text = f"נטרל כתוביות אוטומטיות (DarkSubs)" if not is_excluded else f"הפעל כתוביות אוטומטיות (DarkSubs)"
            li = xbmcgui.ListItem(label=f"{RTL}[COLOR white]{sub_text}[/COLOR]"); li.setArt({'icon': ICON, 'fanart': FANART})
            xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?action=toggle_darksubs", li, False)

            # --- 4. התקנות ועדכוני רכיבי מערכת ---
            li = xbmcgui.ListItem(label=f"{RTL}[COLOR lime]התקן / עדכן רכיב הקלטה (FFmpeg)[/COLOR]"); li.setArt({'icon': ICON, 'fanart': FANART})
            xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?action=install_ffmpeg", li, False)

            # בדיקה חכמה ששני הרכיבים (המנקה ומנוע ה-JS) קיימים במערכת
            is_installed = xbmcvfs.exists(YTDLP_EXE_PATH) and xbmcvfs.exists(QJS_EXE_PATH)
            
            status_color = "lime" if is_installed else "red"
            status_text = "מותקן" if is_installed else "חסר"
            
            li = xbmcgui.ListItem(label=f"{RTL}[COLOR {status_color}]התקן / עדכן רכיבי יוטיוב ({status_text})[/COLOR]"); li.setArt({'icon': ICON, 'fanart': FANART})
            xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?action=install_ytdlp", li, False)





        elif mode == 'active':
            for p, d in load_json(DB_FILE).items():
                li = xbmcgui.ListItem(label=f"{RTL}[COLOR yellow]{d['name']}[/COLOR]", label2=f"{RTL}{get_file_size(p)}")
                li.setArt({'icon': d.get('icon', ICON)}); li.addContextMenuItems([('ביטול', f'RunPlugin({sys.argv[0]}?action=delete_one&file={p})')])
                xbmcplugin.addDirectoryItem(handle, p, li, False)

        elif mode == 'scheduled':
            s_db = load_json(SCHED_FILE)
            for sid, d in s_db.items():
                li = xbmcgui.ListItem(label=f"{RTL}[COLOR lime]{d['name']}[/COLOR]", label2=f"בעוד {d['wait']} דקות")
                li.setArt({'icon': ICON, 'fanart': FANART}); li.addContextMenuItems([('בטל', f'RunPlugin({sys.argv[0]}?action=delete_one&file=none&sid={sid})')])
                xbmcplugin.addDirectoryItem(handle, sys.argv[0], li, False)

        elif mode in ['channels', 'media', 'saved']:
            path = CHANNELS_PATH if mode == 'channels' else MEDIA_PATH if mode == 'media' else SAVED_PATH
            
            # חילוץ מחרוזת טקסט נקייה מהמערך למניעת קריסות דיסק
            param_folder = params.get('folder', [None])
            if param_folder and param_folder[0]: 
                path = str(param_folder[0]).strip("[]'\"")
            
            # סוג תוכן movies המקורי והיציב שמבטיח חילוץ תמונות דינמיות מהסרטון ב-100%
            xbmcplugin.setContent(handle, 'movies')
            
            # יצירת 5 תיקיות האם הראשיות (כולל יוטיוב) בשקט בדיסק ללא שום הודעות קופצות
            if mode == 'saved' and not param_folder[0]:
                for folder_name in ["סרטים", "סדרות", "ערוצים", "VOD עידן", "יוטיוב"]:
                    p_check = os.path.join(SAVED_PATH, folder_name).replace('\\', '/') + '/'
                    if not xbmcvfs.exists(p_check): xbmcvfs.mkdirs(p_check)
            
            li = xbmcgui.ListItem(label=f"{RTL}[COLOR red]מחק הכל[/COLOR]")
            li.setArt({'icon': DELETE_ICON, 'fanart': FANART})
            xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?action=clear_all&path={path}", li, False)
            
            # כפתור יצירה אחד ויחיד בקטגוריית הורדות שמורות בלבד (ללא עומס בפנים)
            if mode == 'saved' and not param_folder[0]:
                li = xbmcgui.ListItem(label=f"{RTL}[COLOR lime]+ יצירת תיקייה חדשה[/COLOR]")
                li.setArt({'icon': FOLDER_IMG, 'fanart': FANART})
                xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?action=add_folder", li, False)
                
            db_img = load_json(FOLDERS_DB); dirs, fs = xbmcvfs.listdir(path)
            
            # הצגת התיקיות (במראה נקי, ללא המשולשים המיותרים >>>)
            for d in dirs:
                p = os.path.join(path, d).replace('\\', '/') + '/'
                
                # תצוגה נקייה ומיושרת של שם התיקייה ללא שום סימנים עודפים
                li = xbmcgui.ListItem(label=f"{RTL}{d}")
                
                folder_icon = db_img.get(normalize_path(p), FOLDER_IMG)
                li.setArt({'icon': folder_icon, 'thumb': folder_icon, 'fanart': FANART})
                li.addContextMenuItems([('עריכה/מחיקה', f'RunPlugin({sys.argv[0]}?action=edit_folder&path={p})')])
                
                # תיקון הקישור לתיקייה פנימית באמצעות sys.argv[0] התקני של קודי
                xbmcplugin.addDirectoryItem(handle, f"{sys.argv[0]}?mode=saved&folder={p}", li, True)
                
            # הצגת הקבצים המוקלטים (טאמבניילס דינמיים פנימיים מהסרטון)
            for f in sorted(fs, reverse=True):
                if f.endswith(('.mp4', '.ts', '.mkv', '.downloading')):
                    p = os.path.join(path, f).replace('\\', '/'); meta = load_json(p + ".meta")
                    color = "yellow" if f.endswith('.downloading') else "deepskyblue"
                    
                    li = xbmcgui.ListItem(label=f"{RTL}[COLOR {color}]{meta.get('display_name', clean_label_smart(f))}[/COLOR]")
                    li.setLabel2(f"{RTL}{get_file_size(p)}")
                    
                    # נתיב וידאו פיזי נקי ב-100% כדי להחזיר את הניגון והסריקה למצב עבודה תקין
                    video_url = p
                    
                    # משאירים את הארט נקי מאייקונים קשיחים כדי לאפשר לקודי לחלץ לבד Thumbnail מהוידאו
                    li.setArt({'fanart': FANART})
                    li.setProperty('IsPlayable', 'true')
                    
                    li.addContextMenuItems([
                        ('מחק', f'RunPlugin({sys.argv[0]}?action=delete_one&file={p})'), 
                        ('העבר', f'RunPlugin({sys.argv[0]}?action=move&file={p})')
                    ])
                    xbmcplugin.addDirectoryItem(handle, video_url, li, False)
                    
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

        xbmcplugin.endOfDirectory(handle); return


























    # --- חילוץ ועיבוד מידע לכתוביות והקלטה (גרסה מוגנת ואוניברסלית - מניעת כפל מטא מוחלטת) ---
    try: 
        handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
    except: 
        handle = -1

    label = xbmc.getInfoLabel('ListItem.Label')
    path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    
    # חילוץ סטטוס הנגן לבדיקת הפעלה פנימית של באפר
    is_player_running = xbmc.Player().isPlaying()
    
    # חסימה חכמה: חוסם ריצות רקע רק אם הנגן באמת מנגן קובץ פנימי של ההרחבה. 
    # זה משאיר את תפריט ההקשר (קליק ימני) פתוח ופעיל לחלוטין בכל רחבי קודי!
    if handle == -1 and is_player_running and (not path or path == "" or ADDON_ID in str(path)):
        xbmc.log("[Advanced_Rec] Player background execution blocked safely.", xbmc.LOGINFO)
        return

    original_path = path 
    tv_heb = xbmc.getInfoLabel('ListItem.TVShowTitle') or label

    
    # חילוץ שנה
    year = xbmc.getInfoLabel('ListItem.Year')
    if not year or year == '0':
        year_match = re.search(r'(19|20)\d{2}', str(label) + " " + str(path))
        year = year_match.group(0) if year_match else ""

    # חילוץ עונה ופרק
    file_name = path.split('/')[-1].split('\\')[-1] if path else ""
    s, e = "", ""
    if file_name and label:
        se_match = re.search(r'season=(\d+)&episode=(\d+)|(\d+)x(\d+)|S(\d+)E(\d+)', file_name + " " + label, re.I)
        if se_match:
            matches = [g for g in se_match.groups() if g]
            if len(matches) >= 2:
                temp_s, temp_e = matches[0], matches[1]
                resolutions = ['480', '540', '576', '720', '1080', '1920', '2160', '3840']
                if temp_s not in resolutions and temp_e not in resolutions:
                    s, e = temp_s, temp_e

    s_e = f"S{int(s):02d}E{int(e):02d}" if (s and e and str(s).isdigit()) else ""

    # --- שלב 2 הסופי: בידוד הרמטי של שמות טורנטים ו-VOD לטובת כתוביות ובטיחות דיסק ---
    raw_filename = ""
    smart_eng = ""
    clean_name = ""
    
    if path and not str(path).startswith('plugin://'):
        try:
            url_parts = str(path).split('|')
            clean_url_part = url_parts[0]
            raw_filename = unquote(clean_url_part.split('/')[-1].split('\\')[-1])
        except:
            raw_filename = ""
            
    url_lower = str(path).lower()
    is_scene_release = any(q in url_lower for q in ['1080', '720', '2160', 'bluray', 'web', 'x264', 'h264', 'hdtv', 'ethel', 'galaxyrg', 'yts', 'yify'])

    # --- חוק ברזל: אם זה טורנט/VOD אנגלי מקורי - מעבירים ישירות לסופר-מחיקה המשופרת ---
    if is_scene_release and raw_filename:
        try:
            name_pure = re.sub(r'\.(mp4|mkv|ts|avi|downloading)$', '', raw_filename, flags=re.I)
            # הרצה ישירה של הפונקציה החדשה ששומרת על האיכות והגרסה
            smart_eng = super_clean_name(name_pure)
            clean_name = smart_eng
            xbmc.log(f"[Advanced_Rec] Exact torrent scene release mapped safely: {smart_eng}", xbmc.LOGINFO)
        except:
            smart_eng = ""

    # גיבוי - רק לערוצים חיים או קישורים ישראליים פשוטים
    if not smart_eng:
        eng_base = xbmc.getInfoLabel('ListItem.OriginalTitle') or xbmc.getInfoLabel('ListItem.TVShowTitle') or label
        clean_name = super_clean_name(eng_base)
        
        detected_res = ""
        for res in ['1080p', '720p', '2160p', '4k', '540p', '480p', '1080', '720']:
            if path and res in str(path).lower():
                detected_res = f".{res if 'p' in res else res + 'p'}"
                break

        if not year or str(year) in ['1920', '1080', '720'] or str(year) == '0':
            year_str = ""
        else:
            year_str = str(year)
            
        if year_str and year_str in clean_name:
            y_dot = ""
        else:
            y_dot = f".{year_str}" if year_str else ""
            
        season_episode_part = f".{s_e}" if s_e else ""
        smart_eng = f"{clean_name}{y_dot}{season_episode_part}{detected_res}"
        smart_eng = re.sub(r'\.+', '.', smart_eng).strip('.')

    if not clean_name:
        clean_name = smart_eng

    if not year or str(year) in ['1920', '1080', '720'] or str(year) == '0':
        year_str = ""
    else:
        year_str = str(year)
        
    if year_str and year_str in str(tv_heb):
        smart_heb = f"{tv_heb} {s_e}".strip()
    else:
        smart_heb = f"{tv_heb}{f' ({year_str})' if year_str else ''} {s_e}".strip()
        
    smart_heb = " ".join(smart_heb.split())

    if handle != -1 and 'mode' in params:
        listitem = xbmcgui.ListItem(label=label)
        display_title = clean_name.replace('.', ' ') if any(u'\u0590' <= c <= u'\u05ea' for c in clean_name) else clean_name
        
        listitem.setInfo('video', {
            'title': display_title,
            'year': int(year) if (year and str(year).isdigit()) else 0,
            'season': int(s or 0),
            'episode': int(e or 0),
            'tagline': smart_eng
        })
        xbmcplugin.endOfDirectory(handle)
        return





    # --- 6. תחילת תהליך ההקלטה ---


    if label and ADDON_ID not in path:
        path_lower = path.lower()
        
        is_youtube = (
            "youtube.com" in path_lower or 
            "youtu.be" in path_lower or 
            "googlevideo" in path_lower or 
            "plugin.video.youtube" in path_lower
        )
        
        if is_youtube:
            xbmc.log("[Advanced_Rec] YouTube source detected. Skipping time dialogs.", xbmc.LOGINFO)
            
            youtube_url = path
            if "plugin.video.youtube" in path_lower:
                try:
                    parsed_params = parse_qs(path.split('?')[-1])
                    video_id_list = parsed_params.get('video_id', [None])
                    
                    # וידאו ID חילוץ נקי מתוך רשימת הפרמטרים
                    if video_id_list and isinstance(video_id_list, list) and video_id_list[0]:
                        video_id = video_id_list[0]
                        # תיקון קריטי: הוספת פרוטוקול ולוכסן מפריד לבניית כתובת אינטרנט מלאה ותקנית
                        youtube_url = f"youtube.com/watch?v={video_id}"
                        xbmc.log(f"[Advanced_Rec] Converted plugin path to correct URL: {youtube_url}", xbmc.LOGINFO)
                except Exception as e:

                    xbmc.log(f"[Advanced_Rec] Failed to parse YouTube plugin parameters: {str(e)}", xbmc.LOGWARNING)

            youtube_title = label if label else "YouTube Video"
            
            download_youtube_direct(youtube_url, youtube_title, ICON)
            return  # סיום פונקציית main עבור מקור יוטיוב ומניעת פתיחת הדיאלוגים

        # --- בלוק בחירת סוג הקלטה הרגיל שלך (סרטים/סדרות/ערוצים) ממשיך מכאן ללא שינוי ---
        opts = [f"{RTL}1. ערוץ מתוזמן", f"{RTL}2. ערוץ מיידי", f"{RTL}3. הקלטת מדיה"]


        sel = xbmcgui.Dialog().select(f"{RTL}סוג הקלטה", opts)
        if sel >= 0:
            w, d, r_t = (0, 0, "מדיה")
            if sel == 0:
                r_t = "מתוזמן"
                w = int(xbmcgui.Dialog().numeric(0, 'בעוד (דקות)?', '0') or 0)
                d = int(xbmcgui.Dialog().numeric(0, 'למשך (דקות)?', '0') or 0)
            elif sel == 1:
                r_t = "ערוץ מיידי"
                d = int(xbmcgui.Dialog().numeric(0, 'למשך (דקות)?', '0') or 0)
            
            heb_in = xbmcgui.Dialog().input('שם להקלטה:', clean_label_smart(smart_heb))
            if heb_in:
                sid = str(int(time.time()))
                saved_url = None
                
                # מפעילים את הערוץ בשקט ברקע
                xbmc.executebuiltin(f'PlayMedia({path})')
                
                if sel in [0, 1]:
                    player = xbmc.Player(); start_wait = time.time()
                    while time.time() - start_wait < 25:
                        if player.isPlaying():
                            tmp = player.getPlayingFile()
                            if tmp and not tmp.startswith('plugin://'):
                                saved_url = tmp
                                break # מצאנו את הלינק! יוצאים מיד מבלי לכבות את הנגן (ללא PlayerControl Stop!)
                        time.sleep(1)
                    
                    if sel == 0 and saved_url:
                        sd = load_json(SCHED_FILE)
                        sd[sid] = {
                            'name': heb_in, 
                            'eng_name': smart_eng, 
                            'wait': w, 
                            'dur': d, 
                            'url': saved_url,
                            'orig_path': path
                        }
                        save_json(SCHED_FILE, sd)
                        # --- הוספת הודעת המערכת המבוקשת והחשובה שלך ---
                        xbmcgui.Dialog().notification("Advanced Rec", f"ההקלטה תוזמנה לעוד {w} דקות!", ICON, 5000)
                
                # הרצת משימת wait_and_record_task ב-Thread נפרד כדי שלא יתקע את קודי
                threading.Thread(target=wait_and_record_task, args=(heb_in, smart_eng, w, d, ICON, (sel != 2), sid, saved_url, r_t)).start()













def download_ffmpeg():
    def background_download():
        import zipfile, shutil, requests
        
        # --- תיקון סופי והחלטי: כתובות ישירות ושלמות ללא שום שיבושי לוכסנים ---
        url1 = "https://" + "www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
        url2 = "https://" + "github.com/GyanD/codexffmpeg/releases/download/2026-05-13-git-a327bc0561/ffmpeg-2026-05-13-git-a327bc0561-essentials_build.zip"
        url3 = "https://" + "github.com/nicolaasjan/yt-dlp/releases/download/2026.04.20.075853/ffmpeg.zip"
        
        mirrors = [url1, url2, url3]
        tmp_zip = os.path.join(BASE_PATH, 'ffmpeg_temp.zip')
        download_success = False
        
        for index, url in enumerate(mirrors):
            try:
                xbmc.log(f"[Advanced_Rec] Trying ffmpeg mirror {index + 1}: {url}", xbmc.LOGINFO)
                xbmc.executebuiltin(f'Notification(Advanced Rec, מנסה להוריד שרת גיבוי {index + 1}..., 4000, {ICON})')
                
                headers = {'User-Agent': UA, 'Accept': '*/*'}
                r = requests.get(url, stream=True, timeout=45, headers=headers, verify=False)
                r.raise_for_status()
                
                with open(tmp_zip, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=1024*1024):
                        if chunk: f.write(chunk)
                
                download_success = True
                xbmc.log(f"[Advanced_Rec] Successfully downloaded from mirror {index + 1}", xbmc.LOGINFO)
                break
                
            except Exception as e:
                xbmc.log(f"[Advanced_Rec] Mirror {index + 1} failed: {str(e)}", xbmc.LOGWARNING)
                if os.path.exists(tmp_zip):
                    try: os.remove(tmp_zip)
                    except: pass
                continue
        
        if not download_success:
            xbmc.executebuiltin(f'Notification(Advanced Rec, כל שרתי ההורדה נכשלו. נסה שוב מאוחר יותר, 5000, {ICON})')
            return

        # --- שלב החילוץ והתקנת ה-EXE ---
        try:
            xbmc.executebuiltin(f'Notification(Advanced Rec, מחלץ ומתקין קובצי מערכת..., 4000, {ICON})')
            
            with zipfile.ZipFile(tmp_zip, 'r') as z:
                for m in z.namelist():
                    if m.lower().endswith('ffmpeg.exe'):
                        with z.open(m) as src, open(FFMPEG_EXE, 'wb') as tgt:
                            shutil.copyfileobj(src, tgt)
                        break
            
            if os.path.exists(tmp_zip): os.remove(tmp_zip)
            
            if xbmcvfs.exists(FFMPEG_EXE):
                xbmc.executebuiltin(f'Notification(Advanced Rec, התקנת FFmpeg הסתיימה בהצלחה!, 5000, {ICON})')
            else:
                raise Exception("קובץ ה-ffmpeg.exe לא נמצא בתוך מבנה ה-ZIP שהורד")
            
        except Exception as e:
            xbmc.log(f"[Advanced_Rec] Extraction Error: {str(e)}", xbmc.LOGERROR)
            if os.path.exists(tmp_zip):
                try: os.remove(tmp_zip)
                except: pass
            xbmc.executebuiltin(f'Notification(Advanced Rec, חילוץ הרכיב נכשל, 5000, {ICON})')

    import threading
    threading.Thread(target=background_download).start()
    xbmcgui.Dialog().ok("Advanced Rec", "מערכת המירורים היציבה הופעלה ברקע.\nההרחבה תסרוק את השרתים ותוריד את הטוב ביותר.\nתוכל להמשיך להשתמש בקודי, הודעה תופיע בסיום.")










if __name__ == '__main__':
    main()

