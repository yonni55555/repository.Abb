# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcvfs, os, json, time

# הגדרות ליבה
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ICON = ADDON.getAddonInfo('icon')
BASE_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
SCHED_FILE = os.path.join(BASE_PATH, 'scheduled.json')
DB_FILE = os.path.join(BASE_PATH, 'tasks.json')

def load_json(path=SCHED_FILE):
    if xbmcvfs.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f: return json.load(f)
        except: return {}
    return {}

def save_json(data, path=SCHED_FILE):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except: pass

def check_tasks():
    sched = load_json(SCHED_FILE)
    if not sched: return
    now = time.time()
    changed = False
    missed_count = 0
    for sid, task in list(sched.items()):
        wait_sec = int(task.get('wait', 0)) * 60
        dur_sec = int(task.get('dur', 60)) * 60
        start_at = int(sid) + wait_sec
        end_at = start_at + dur_sec
        if now > end_at:
            missed_count += 1
            sched.pop(sid)
            changed = True
            continue
        if now >= start_at:
            xbmc.executebuiltin(f"RunPlugin(plugin://{ADDON_ID}/?action=start_scheduled&sid={sid})")
    if changed: save_json(sched, SCHED_FILE)
    if missed_count > 0:
        xbmc.executebuiltin(f'Notification(Advanced Rec, פוספסו {missed_count} הקלטות, 6000, {ICON})')

if __name__ == '__main__':
    monitor = xbmc.Monitor()
    
    if xbmcvfs.exists(DB_FILE):
        try: save_json({}, DB_FILE)
        except: pass

    xbmc.executebuiltin(f'Notification(Advanced Rec, הקלטות פעיל, 4000, {ICON})')
    
    while not monitor.abortRequested():
        check_tasks()
        if monitor.waitForAbort(60):
            break
