import os
import shutil
import sys
import json
from datetime import datetime
import time
import urllib.request
import ssl
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xbmcplugin

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')

ICON_PATH = os.path.join(ADDON_PATH, 'icon.png')
FANART_PATH = os.path.join(ADDON_PATH, 'fanart.jpg')

try:
    PLUGIN_URL = sys.argv[0] if len(sys.argv) > 0 else ""
    PLUGIN_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
    PLUGIN_QUERY = sys.argv[2] if len(sys.argv) > 2 else ""
except Exception:
    PLUGIN_URL = ""
    PLUGIN_HANDLE = -1
    PLUGIN_QUERY = ""

USERDATA_DIR = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
LOG_FILE_PATH = os.path.join(USERDATA_DIR, 'cleaner_history.log')
SETTINGS_JSON_PATH = os.path.join(USERDATA_DIR, 'addon_settings.json')
RECYCLE_BIN_DIR = os.path.join(USERDATA_DIR, 'RecycleBin')
MAPPING_PATH = os.path.join(USERDATA_DIR, 'recycle_map.json')

# יצירת התיקיות הנדרשות באופן אוטומטי
for path in [USERDATA_DIR, RECYCLE_BIN_DIR]:
    if not os.path.exists(path):
        try: os.makedirs(path)
        except: xbmcvfs.mkdir(path)

EXCLUDED_EXTENSIONS = ['.xml', '.db', '.txt', '.log']
KNOWN_ADDONS_GARBAGE = [
    {"name": "זבל מטמון מתוספי IPTV (Simple Client)", "path": "special://profile/addon_data/pvr.iptvsimple/cache/"},
    {"name": "מטמון וידאו ותמונות מיוטיוב", "path": "special://profile/addon_data/plugin.video.youtube/cache/"},
    {"name": "קבצים זמניים של עידן פלוס", "path": "special://profile/addon_data/plugin.video.idanplus/cache/"},
    {"name": "יומני רישום זמניים של טלמדיה", "path": "special://profile/addon_data/plugin.video.telemedia/logo/"},
    {"name": "טורנטים זמניים מהרחבת אלמנטום", "path": "special://profile/addon_data/plugin.video.elementum/torrents/"},
    {"name": "מטמון כללי של ספריות הרחבה (Simple Cache)", "path": "special://profile/addon_data/script.module.simplecache/db/"}
]

import os
import shutil
import sys
import json
from datetime import datetime
import time
import urllib.request
import ssl
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xbmcplugin

# הגדרות הרחבה בסיסיות
ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')

ICON_PATH = os.path.join(ADDON_PATH, 'icon.png')
FANART_PATH = os.path.join(ADDON_PATH, 'fanart.jpg')

# === קבלת פרמטרי הניווט של קודי - מתוקן, מופרד ובטוח לחלוטין ===
PLUGIN_URL = sys.argv[0] if len(sys.argv) > 0 else ""
PLUGIN_HANDLE = -1
PLUGIN_QUERY = ""

# קבלת ה-Handle בצורה מבודדת שלא קורסת
if len(sys.argv) > 1:
    try:
        # ניקוי סימנים נסתרים במידה וקודי מעביר אותם (כמו ? או רווחים)
        clean_handle = str(sys.argv[1]).replace('?', '').strip()
        PLUGIN_HANDLE = int(clean_handle)
    except:
        PLUGIN_HANDLE = -1

# קבלת השאילתה בצורה מבודדת
if len(sys.argv) > 2:
    PLUGIN_QUERY = sys.argv[2]



# הגדרת נתיבי עבודה פנימיים
USERDATA_DIR = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
LOG_FILE_PATH = os.path.join(USERDATA_DIR, 'cleaner_history.log')
RECYCLE_BIN_DIR = os.path.join(USERDATA_DIR, 'RecycleBin')
MAPPING_PATH = os.path.join(USERDATA_DIR, 'recycle_map.json')

# יצירת התיקיות הנדרשות באופן אוטומטי בדיסק
for path in [USERDATA_DIR, RECYCLE_BIN_DIR]:
    if not os.path.exists(path):
        try: os.makedirs(path)
        except: xbmcvfs.mkdir(path)

EXCLUDED_EXTENSIONS = ['.xml', '.db', '.txt', '.log']
COLORS_MAP = [
    {"name": "לבן", "hex": "FFFFFFFF"},
    {"name": "צהוב", "hex": "FFFFFF00"},
    {"name": "תכלת", "hex": "FF00FFFF"},
    {"name": "ירוק", "hex": "FF00FF00"},
    {"name": "אדום", "hex": "FFFF0000"},
    {"name": "ורוד", "hex": "FFFFC1CC"}
]

# --- פונקציות ליבה לשליטה וקריאה של הגדרות קודי ---

def update_kodi_setting(setting_name, value):
    """החזרה למצב המקורי שעבד מושלם - מעדכנת הגדרה פנימית בקודי באמצעות JSON-RPC"""
    try:
        import json
        cmd = f'{{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{{"setting":"{setting_name}","value":{json.dumps(value)}}},"id":1}}'
        xbmc.executeJSONRPC(cmd)
        return True
    except: 
        return False

def get_kodi_setting(setting_name):
    """החזרה למצב המקורי שעבד מושלם - קוראת הגדרה פנימית מתוך ה-RAM של קודי באמצעות JSON-RPC"""
    try:
        import json
        cmd = f'{{"jsonrpc":"2.0","method":"Settings.GetSettingValue","params":{{"setting":"{setting_name}"}},"id":1}}'
        response = json.loads(xbmc.executeJSONRPC(cmd))
        return response.get('result', {}).get('value', None)
    except: 
        return None




def write_to_private_log(message):
    """כותבת שורת תיעוד לתוך קובץ הלוג הפרטי של התוסף"""
    # קורא ישירות מהגדרות קודי הרשמיות
    enable_logging = ADDON.getSetting('enable_logging').lower() == 'true' if ADDON.getSetting('enable_logging') else True
    if not enable_logging: return
    
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        with open(LOG_FILE_PATH, 'a', encoding='utf-8') as f: 
            f.write(f"[{timestamp}] {message}\n")
    except: pass

def load_settings():
    """טוענת את הגדרות התוסף הרשמיות של קודי ומחזירה דיקשנרי"""
    try:
        paths_raw = ADDON.getSetting('custom_paths_list')
        paths_list = [p.strip() for p in paths_raw.split('|') if p.strip()] if paths_raw else []
        return {
            'auto_clean_startup': ADDON.getSetting('auto_clean_startup').lower() == 'true',
            'auto_cache_startup': ADDON.getSetting('auto_cache_startup').lower() == 'true',
            'min_size_trigger': int(ADDON.getSetting('min_size_trigger')) if ADDON.getSetting('min_size_trigger').isdigit() else 0, 
            'custom_paths_list': paths_list,
            'enable_logging': ADDON.getSetting('enable_logging').lower() == 'true',
            'clean_kodi_logs': ADDON.getSetting('clean_kodi_logs').lower() == 'true',
            'thumbs_size_trigger': int(ADDON.getSetting('thumbs_size_trigger')) if ADDON.getSetting('thumbs_size_trigger').isdigit() else 500,
            'auto_thumbs_clean_startup': ADDON.getSetting('auto_thumbs_clean_startup').lower() == 'true', # השורה החדשה
            'cache_optimized': ADDON.getSetting('cache_optimized').lower() == 'true'
        }
    except:
        return {
            'auto_clean_startup': False, 'auto_cache_startup': False, 'min_size_trigger': 0, 
            'custom_paths_list': [], 'enable_logging': True, 'clean_kodi_logs': True, 
            'thumbs_size_trigger': 500, 'auto_thumbs_clean_startup': False, 'cache_optimized': False
        }

def save_settings(settings_dict):
    """שומרת את הגדרות התוסף חזרה אל מנוע קודי"""
    try:
        ADDON.setSetting('auto_clean_startup', str(settings_dict.get('auto_clean_startup', False)).lower())
        ADDON.setSetting('auto_cache_startup', str(settings_dict.get('auto_cache_startup', False)).lower())
        ADDON.setSetting('min_size_trigger', str(settings_dict.get('min_size_trigger', 0)))
        ADDON.setSetting('enable_logging', str(settings_dict.get('enable_logging', True)).lower())
        ADDON.setSetting('clean_kodi_logs', str(settings_dict.get('clean_kodi_logs', True)).lower())
        ADDON.setSetting('thumbs_size_trigger', str(settings_dict.get('thumbs_size_trigger', 500)))
        ADDON.setSetting('auto_thumbs_clean_startup', str(settings_dict.get('auto_thumbs_clean_startup', False)).lower()) # השורה החדשה
        ADDON.setSetting('cache_optimized', str(settings_dict.get('cache_optimized', False)).lower())
        paths_raw = "|".join(settings_dict.get('custom_paths_list', []))
        ADDON.setSetting('custom_paths_list', paths_raw)
    except: pass


# --- פונקציות לניהול תפריט והגדרות הכתוביות ---

def show_subtitles_menu():
    """מציג תפריט כתוביות מתקדם המציג את הסטטוסים הנוכחיים בירוק"""
    current_size = get_kodi_setting("subtitles.fontsize") or "לא מוגדר"
    
    current_color_hex = get_kodi_setting("subtitles.colorpick")
    current_color_name = "לבן"
    for c in COLORS_MAP:
        if c['hex'] == current_color_hex:
            current_color_name = c['name']
            break
            
    current_langs = get_kodi_setting("subtitles.languages") or []
    current_lang_str = ", ".join(current_langs) if isinstance(current_langs, list) else str(current_langs)
    if "Hebrew" in current_lang_str and "English" in current_lang_str: current_lang_str = "עברית ואנגלית"
    elif "Hebrew" in current_lang_str: current_lang_str = "עברית"
    elif "English" in current_lang_str: current_lang_str = "אנגלית"
    elif "Original" in current_lang_str: current_lang_str = "שפת המקור"

    # מפת רקע: 0=ללא רקע, 2=רקע לכתוביות
    try: current_bg_val = int(get_kodi_setting("subtitles.backgroundtype"))
    except: current_bg_val = 0
    
    if current_bg_val == 2: 
        current_bg_str = "רקע לכתוביות"
    else: 
        current_bg_str = "ללא רקע"


    sub_menu_data = [
        {"label": f"שינוי גודל כתוביות: [COLOR lime]({current_size})[/COLOR]", "action": "sub_size"},
        {"label": f"שינוי צבע כתוביות: [COLOR lime]({current_color_name})[/COLOR]", "action": "sub_color"},
        {"label": f"שפת כתוביות מועדפת: [COLOR lime]({current_lang_str})[/COLOR]", "action": "sub_lang"},
        {"label": f"הגדרות רקע ושקיפות: [COLOR lime]({current_bg_str})[/COLOR]", "action": "sub_bg"}
    ]
    
    for item in sub_menu_data:
        url = f"{PLUGIN_URL}?action={item['action']}"
        list_item = xbmcgui.ListItem(label=item["label"])
        list_item.setArt({'icon': ICON_PATH, 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def select_subtitle_size():
    sizes = [20, 24, 28, 32, 36, 42, 48, 54, 60, 65, 70]
    current = get_kodi_setting("subtitles.fontsize")
    labels = [f"{s} (נוכחי)" if s == current else str(s) for s in sizes]
    selected = xbmcgui.Dialog().select("בחר גודל כתוביות", labels)
    if selected != -1:
        if update_kodi_setting("subtitles.fontsize", sizes[selected]):
            write_to_private_log(f"[כתוביות] גודל הגופן שונה מ-{current} ל-{sizes[selected]}")
            xbmcgui.Dialog().notification(ADDON_NAME, f"גודל הכתוביות שונה ל-{sizes[selected]}", ICON_PATH, 3000)

def select_subtitle_color():
    current = get_kodi_setting("subtitles.colorpick")
    labels = [f"{c['name']} (נוכחי)" if c['hex'] == current else c['name'] for c in COLORS_MAP]
    selected = xbmcgui.Dialog().select("בחר צבע כתוביות", labels)
    if selected != -1:
        chosen_color = COLORS_MAP[selected]
        if update_kodi_setting("subtitles.colorpick", chosen_color['hex']):
            write_to_private_log(f"[כתוביות] צבע הכתוביות שונה ל-{chosen_color['name']} ({chosen_color['hex']})")
            xbmcgui.Dialog().notification(ADDON_NAME, f"צבע הכתוביות שונה ל-{chosen_color['name']}", ICON_PATH, 3000)

def select_subtitle_language():
    languages = [
        {"name": "עברית", "val": ["Hebrew"]},
        {"name": "אנגלית", "val": ["English"]},
        {"name": "עברית ואנגלית", "val": ["Hebrew", "English"]},
        {"name": "שפת המקור (Original)", "val": ["Original"]}
    ]
    labels = [lang["name"] for lang in languages]
    selected = xbmcgui.Dialog().select("שפת כתוביות מועדפת להורדה", labels)
    if selected != -1:
        chosen_lang = languages[selected]
        if update_kodi_setting("subtitles.languages", chosen_lang["val"]):
            write_to_private_log(f"[כתוביות] שפת הורדה שונתה ל-{chosen_lang['name']}")
            xbmcgui.Dialog().notification(ADDON_NAME, f"שפת ההורדה שונתה ל-{chosen_lang['name']}", ICON_PATH, 3000)

def select_subtitle_background():
    bg_options = [
        {"name": "ללא רקע", "val": 0},
        {"name": "רקע לכתוביות", "val": 2}
    ]

    
    # הבאת הנתון פעם אחת בלבד והמרה ל-int לצורך השוואה נכונה
    try:
        current = int(get_kodi_setting("subtitles.backgroundtype"))
    except:
        current = 0
        
    labels = [f"{b['name']} (נוכחי)" if b['val'] == current else b['name'] for b in bg_options]
    selected = xbmcgui.Dialog().select("בחר סגנון רקע", labels)
    
    if selected != -1:
        chosen_bg = bg_options[selected]
        if update_kodi_setting("subtitles.backgroundtype", chosen_bg['val']):
            write_to_private_log(f"[כתוביות] סגנון רקע עודכן ל-{chosen_bg['name']}")
            xbmcgui.Dialog().notification(ADDON_NAME, "רקע הכתוביות עודכן בהצלחה", ICON_PATH, 3000)

# --- פונקציות לניהול תפריט והגדרות מערכת ושמע ---

def show_system_menu():
    """מציג תפריט מערכת ושמע המציג את הסטטוסים הנוכחיים בירוק"""
    # קריאת רמת המערכת דרך RPC
    expert_status = "בסיסי"
    try:
        import json
        rpc = '{"jsonrpc":"2.0","method":"Settings.GetSettingValue","params":{"setting":"settings.level"},"id":1}'
        res = json.loads(xbmc.executeJSONRPC(rpc))
        lvl = res.get('result', {}).get('value', 0)
        if lvl == 3: expert_status = "מומחה"
        elif lvl == 2: expert_status = "מתקדם"
        elif lvl == 1: expert_status = "רגיל"
    except: pass
    
    passthrough_val = get_kodi_setting("audiooutput.passthrough")
    passthrough_status = "מופעל" if passthrough_val is True else "כבוי"
    
    # התיקון המדויק לקריאת קצב הרענון בקודי 21
    refresh_val = get_kodi_setting("videoscreen.adjustrefreshrate")
    if refresh_val is None:
        refresh_val = get_kodi_setting("videoplayer.adjustrefreshrate")
        
    refresh_status = "כבוי"
    if refresh_val == 1: refresh_status = "תמיד"
    elif refresh_val == 2: refresh_status = "בעת התחלה ועצירה"
    elif refresh_val == 3: refresh_status = "בהפעלה בלבד"

    
    # מפת ערוצים: 1=2.0, 2=2.1, 3=3.0, 4=3.1, 5=4.0, 6=4.1, 7=5.0, 8=5.1, 9=7.0, 10=7.1
    channels_map = {1: "2.0", 2: "2.1", 3: "3.0", 4: "3.1", 5: "4.0", 6: "4.1", 7: "5.0", 8: "5.1", 9: "7.0", 10: "7.1"}
    channels_val = get_kodi_setting("audiooutput.channels")
    channels_status = channels_map.get(channels_val, "לא ידוע")
    
    # שימוש בפרמטר הנכון locale.audiolanguage שראינו ב-XML שלך
    audio_lang_val = get_kodi_setting("locale.audiolanguage") or "original"
    audio_lang_status = str(audio_lang_val)
    if "original" in audio_lang_status.lower(): audio_lang_status = "שפת המקור"
    elif "hebrew" in audio_lang_status.lower(): audio_lang_status = "עברית"
    elif "english" in audio_lang_status.lower(): audio_lang_status = "אנגלית"

    sys_menu_data = [
        #{"label": f"מצב מומחה במערכת קודי: [COLOR lime]({expert_status})[/COLOR]", "action": "sys_expert"},
        {"label": f"העברת שמע ישירה לרסיבר: [COLOR lime]({passthrough_status})[/COLOR]", "action": "sys_passthrough"},
        {"label": f"התאמת קצב רענון מסך: [COLOR lime]({refresh_status})[/COLOR]", "action": "sys_refresh"},
        {"label": f"קביעת מספר ערוצי שמע: [COLOR lime]({channels_status} ערוצים)[/COLOR]", "action": "sys_channels"},
        {"label": f"שפת שמע מועדפת אוטומטית: [COLOR lime]({audio_lang_status})[/COLOR]", "action": "sys_audiolang"}
    ]
    
    for item in sys_menu_data:
        url = f"{PLUGIN_URL}?action={item['action']}"
        list_item = xbmcgui.ListItem(label=item["label"])
        list_item.setArt({'icon': ICON_PATH, 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def select_refresh_rate():
    options = [
        {"name": "כבוי", "val": "0"},
        {"name": "תמיד", "val": "1"},
        {"name": "בעת התחלה ועצירה", "val": "2"},
        {"name": "בהפעלה בלבד", "val": "3"}
    ]
    
    userdata_path = xbmcvfs.translatePath('special://profile/')
    gui_settings_xml = os.path.join(userdata_path, 'guisettings.xml')
    
    current_val = "2"
    if os.path.exists(gui_settings_xml):
        try:
            import xml.etree.ElementTree as ET
            tree = ET.parse(gui_settings_xml)
            root = tree.getroot()
            for setting in root.findall('.//setting'):
                if setting.get('id') == 'videoplayer.adjustrefreshrate':
                    current_val = setting.text or "2"
                    break
        except: pass

    labels = [f"{o['name']} (נוכחי)" if o['val'] == str(current_val) else o['name'] for o in options]
    selected = xbmcgui.Dialog().select("התאמת קצב רענון מסך", labels)
    
    if selected != -1:
        chosen_option = options[selected]
        
        # חלון הבחירה למשתמש - מונע יציאה פתאומית ומסביר את חשיבות הסגירה
        dialog = xbmcgui.Dialog()
        user_approved = dialog.yesno("שינוי קצב רענון מסך", 
                  f"קצב הרענון עודכן ל-{chosen_option['name']} בדיסק.\n"
                  "מומלץ לבצע כיבוי מהיר כעת כדי שקודי לא יבטל את השינוי מהזיכרון.\n\n"
                  "[B][COLOR yellow]האם לסגור את קודי כעת לנעילת ההגדרה?[/COLOR][/B]",
                  nolabel="בטל (אל תסגור)", 
                  yeslabel="כן, סגור כעת")
        
        # השינוי והכיבוי יתבצעו רק אם המשתמש לחץ "כן"
        if user_approved:
            if os.path.exists(gui_settings_xml):
                try:
                    import xml.etree.ElementTree as ET
                    tree = ET.parse(gui_settings_xml)
                    root = tree.getroot()
                    
                    for setting in root.findall('.//setting'):
                        setting_id = setting.get('id')
                        if setting_id in ['videoplayer.adjustrefreshrate', 'videoscreen.adjustrefreshrate']:
                            setting.text = str(chosen_option['val'])
                            setting.set('default', 'false')
                    
                    tree.write(gui_settings_xml, encoding="utf-8", xml_declaration=True)
                    write_to_private_log(f"[מערכת] קצב רענון מסך שונה בדיסק ל-{chosen_option['name']}")
                except Exception as e:
                    write_to_private_log(f"שגיאה בכתיבת קצב רענון ל-XML: {str(e)}")

            # ביצוע הכיבוי המהיר והבטוח שלך
            quick_kodi_exit()
        else:
            write_to_private_log("[מערכת] המשתמש ביטל את הסגירה המהירה, השינוי לא ננעל בדיסק.")
            xbmc.executebuiltin("Container.Refresh")









def select_audio_channels():
    channels = [2.0, 2.1, 3.0, 3.1, 4.0, 4.1, 5.0, 5.1, 7.0, 7.1]
    kodi_values = {2.0: 1, 2.1: 2, 3.0: 3, 3.1: 4, 4.0: 5, 4.1: 6, 5.0: 7, 5.1: 8, 7.0: 9, 7.1: 10}
    current = get_kodi_setting("audiooutput.channels")
    
    current_channel_str = "לא ידוע"
    for k, v in kodi_values.items():
        if v == current: current_channel_str = str(k)
        
    labels = [f"{c} ערוצים (נוכחי)" if kodi_values[c] == current else f"{c} ערוצים" for c in channels]
    selected = xbmcgui.Dialog().select("בחר מספר ערוצי שמע", labels)
    if selected != -1:
        chosen_channel = channels[selected]
        actual_value = kodi_values[chosen_channel]
        if update_kodi_setting("audiooutput.channels", actual_value):
            write_to_private_log(f"[שמע] מספר ערוצי שמע שונה מ-{current_channel_str} ל-{chosen_channel} ערוצים")
            xbmcgui.Dialog().notification(ADDON_NAME, f"מספר הערוצים שונה ל: {chosen_channel}", ICON_PATH, 3000)

def select_audio_language():
    languages = [
        {"name": "עברית", "val": "Hebrew"},
        {"name": "אנגלית", "val": "English"},
        {"name": "שפת המקור של הווידאו", "val": "original"}
    ]
    current = get_kodi_setting("locale.audiolanguage") or "original"
    labels = [f"{l['name']} (נוכחי)" if l['val'].lower() == str(current).lower() else l['name'] for l in languages]
    selected = xbmcgui.Dialog().select("בחר שפת שמע מועדפת", labels)
    if selected != -1:
        chosen_lang = languages[selected]
        if update_kodi_setting("locale.audiolanguage", chosen_lang['val']):
            write_to_private_log(f"[מערכת] שפת שמע מועדפת נקבעה ל-{chosen_lang['name']}")
            xbmcgui.Dialog().notification(ADDON_NAME, f"שפת שמע נקבעה ל: {chosen_lang['name']}", ICON_PATH, 3000)

def set_kodi_expert_mode():
    if update_kodi_setting("settings.level", 3):
        write_to_private_log("[מערכת] מצב מומחה (Expert Mode) הופעל במערכת קודי")
        xbmcgui.Dialog().notification(ADDON_NAME, "מצב מומחה הופעל בהצלחה", ICON_PATH, 3000)




def get_folder_size_mb(folder_path):
    total_size = 0
    if not os.path.exists(folder_path): return 0.0
    for root, dirs, files in os.walk(folder_path):
        for f in files:
            try: 
                fp = os.path.join(root, f)
                if os.path.exists(fp): total_size += os.path.getsize(fp)
            except: continue
    return round(total_size / (1024 * 1024), 2)

def write_to_private_log(message):
    settings = load_settings()
    if not settings.get('enable_logging', True): return
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        with open(LOG_FILE_PATH, 'a', encoding='utf-8') as f: 
            f.write(f"[{timestamp}] {message}\n")
    except: pass

def run_thumbnails_cleaner(silent=False, force=False):
    dialog = xbmcgui.Dialog()
    thumbs_path = xbmcvfs.translatePath("special://home/userdata/Thumbnails/")
    db_path = xbmcvfs.translatePath("special://home/userdata/Database/")
    
    current_thumbs_size = get_folder_size_mb(thumbs_path)
    
    if not force:
        settings = load_settings()
        size_trigger = settings.get('thumbs_size_trigger', 500)
        if current_thumbs_size < size_trigger:
            write_to_private_log(f"ניקוי תמונות דולג: המשקל הנוכחי ({current_thumbs_size} MB) נמוך מהסף ({size_trigger} MB)")
            return

    if not silent and not force:
        if not dialog.yesno(ADDON_NAME, f"תיקיית התמונות שוקלת כעת {current_thumbs_size} MB.\n\nהאם להמשיך בניקוי עמוק ויסודי? קודי ייסגר מיידית לצורך רענון מוחלט של כל הפוסטרים."):
            return
            
    if force and not silent:
        if not dialog.yesno(ADDON_NAME, "האם אתה בטוח שברצונך לאפס את כל התמונות במכשיר כעת?\n\n[B][COLOR yellow]שים לב: קודי ייסגר מיידית לאחר האישור לצורך טעינה מחדש נקייה מהאינטרנט.[/COLOR][/B]"):
            return
            
    write_to_private_log(f"=== תחילת ניקוי עמוק ידני === נפח: {current_thumbs_size} MB | בכפייה: {force}")
    
    # 1. מחיקה פיזית של תיקיית התמונות
    if os.path.exists(thumbs_path):
        try:
            shutil.rmtree(thumbs_path)
            os.makedirs(thumbs_path, exist_ok=True)
        except Exception as e:
            write_to_private_log(f"שגיאה במחיקת תיקיית תמונות: {str(e)}")

    # 2. מחיקה פיזית של קובץ ה-Database באותה השנייה
    if os.path.exists(db_path):
        try:
            for f in os.listdir(db_path):
                if "textures" in f.lower() and f.endswith(".db"):
                    file_to_del = os.path.join(db_path, f)
                    try: 
                        os.remove(file_to_del)
                    except: 
                        xbmcvfs.delete(file_to_del)
        except Exception as e:
            write_to_private_log(f"שגיאה במחיקת מסד נתונים: {str(e)}")

    write_to_private_log("=== סיום ניקוי תמונות ידני === מבצע סגירה קשיחה מיידית.")
    
    # הוסר הדיאלוג השני (dialog.ok). קודי נסגר כעת מיד ובאופן חלק!
    quick_kodi_exit()










def run_cleaner(silent=False, force=False):
    if not force and not silent:
        if not xbmcgui.Dialog().yesno(ADDON_NAME, "האם ברצונך להפעיל ניקוי רגיל כעת?"):
            return

    if not silent: write_to_private_log("=== תחילת סשן ניקוי ידני ===")
    
    settings = load_settings()
    total_deleted = 0
    total_bytes = 0.0
    
    cache_path = xbmcvfs.translatePath("special://home/cache/")
    if os.path.exists(cache_path):
        c, b = delete_files_in_folder(cache_path, protect_important_files=True)
        total_deleted += c
        total_bytes += b
        
    packages_path = xbmcvfs.translatePath("special://home/addons/packages/")
    if os.path.exists(packages_path):
        c, b = delete_files_in_folder(packages_path, protect_important_files=False)
        total_deleted += c
        total_bytes += b

    if settings.get('clean_kodi_logs', True):
        log_dir = xbmcvfs.translatePath("special://home/")
        if os.path.exists(log_dir):
            for f in os.listdir(log_dir):
                if f.endswith(".log") and f != "kodi.log":
                    try:
                        fp = os.path.join(log_dir, f)
                        total_bytes += os.path.getsize(fp)
                        os.remove(fp)
                        total_deleted += 1
                    except: pass

    custom_paths = settings.get('custom_paths_list', [])
    for path in custom_paths:
        translated = xbmcvfs.translatePath(path)
        if translated and os.path.exists(translated):
            c, b = delete_files_in_folder(translated, protect_important_files=True, is_custom_user_path=True)
            total_deleted += c
            total_bytes += b
                
    total_mb = round(total_bytes / (1024 * 1024), 2)
    write_to_private_log(f"=== סיום סשן ניקוי. נמחקו: {total_deleted} פריטים במשקל {total_mb} MB ===")
    
    try: auto_purge_old_recycle_files()
    except: pass
    
    # שליפת המצב של הכפתור החדש שהוספת להגדרות
    # שים לב: אם הפונקציה load_settings() מחזירה מילון רגיל, משתמשים ב-.get(). 
    # אם היא מחזירה אובייקט של קודי, יש להשתמש ב-settings.getBool('show_startup_notification')
    try:
        show_notif = settings.get('show_startup_notification', False)
    except:
        show_notif = settings.getBool('show_startup_notification')
    
    # הצגת ההודעה למשך 3 שניות עם לא ניטרלתי
    if not silent or show_notif: 
        xbmcgui.Dialog().notification(
            ADDON_NAME, 
            f'הניקוי הסתיים! נמחקו {total_deleted} פריטים ({total_mb} MB).', 
            icon=ICON_PATH, 
            time=3000
        )


def delete_files_in_folder(folder_path, protect_important_files=True, is_custom_user_path=False):
    deleted_count = 0
    deleted_bytes = 0.0
    
    # תיקון קריטי: תרגום הנתיב הווירטואלי של קודי לנתיב פיזי אמיתי בדיסק של המכשיר
    physical_folder_path = xbmcvfs.translatePath(folder_path)
    
    if not os.path.exists(physical_folder_path): 
        return deleted_count, deleted_bytes

    recycle_map = {}
    if os.path.exists(MAPPING_PATH):
        try:
            with open(MAPPING_PATH, 'r', encoding='utf-8') as f: 
                recycle_map = json.load(f)
        except: 
            pass

    # שימוש בנתיב הפיזי המתורגם לצורך סריקת התיקייה
    for root, dirs, files in os.walk(physical_folder_path, topdown=False):
        for f in files:
            file_path = os.path.join(root, f)
            
            if protect_important_files and not is_custom_user_path:
                if os.path.splitext(f)[1].lower() in EXCLUDED_EXTENSIONS: 
                    continue

            try:
                f_size = os.path.getsize(file_path)
                unique_name = f"{int(time.time())}_{f}"
                dest_path = os.path.join(RECYCLE_BIN_DIR, unique_name)
                
                # העברה בטוחה לסל המחזור בדיסק
                shutil.move(file_path, dest_path)
                
                # שמירת המיפוי של הנתיב המקורי (נשמור את המקורי כדי שנוכל לשחזר)
                recycle_map[unique_name] = file_path
                deleted_count += 1
                deleted_bytes += f_size
            except Exception as e:
                write_to_private_log(f"שגיאה בהעברה לסל מחזור: {str(e)}")
                try:
                    # אם shutil נכשל מסיבה כלשהי, ננסה מחיקה ישירה דרך קודי
                    if xbmcvfs.delete(file_path): 
                        deleted_count += 1
                except: 
                    pass

        for d in dirs:
            dir_path = os.path.join(root, d)
            try:
                if not os.listdir(dir_path): 
                    os.rmdir(dir_path)
            except: 
                pass

    try:
        with open(MAPPING_PATH, 'w', encoding='utf-8') as f: 
            json.dump(recycle_map, f, indent=4, ensure_ascii=False)
    except: 
        pass

    return deleted_count, deleted_bytes


def clean_known_addons_garbage():
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(ADDON_NAME, "האם ברצונך לנקות קבצי זבל ומטמון של הרחבות מוכרות?"): 
        return

    write_to_private_log("=== תחילת ניקוי הרחבות ידועות ===")
    total_c = 0
    total_b = 0.0
    
    for item in KNOWN_ADDONS_GARBAGE:
        try:
            # תרגום בטוח של נתיבי התוספים לפני בדיקת קיום
            translated = xbmcvfs.translatePath(item["path"])
            if translated and os.path.exists(translated):
                c, b = delete_files_in_folder(translated, protect_important_files=False, is_custom_user_path=True)
                total_c += c
                total_b += b
        except Exception as e:
            write_to_private_log(f"דילוג או שגיאה בניקוי {item.get('name', 'תוסף')}: {str(e)}")
            continue
                
    total_mb = round(total_b / (1024 * 1024), 2)
    write_to_private_log(f"=== סיום ניקוי הרחבות ידועות: {total_mb} MB ===")
    
    try:
        dialog.notification(ADDON_NAME, f"ניקוי תוספים הסתיים! נמחקו {total_mb} MB.", icon=ICON_PATH, time=4000)
    except:
        dialog.notification(ADDON_NAME, f"ניקוי תוספים הסתיים! נמחקו {total_mb} MB.", xbmcgui.NOTIFICATION_INFO, 4000)



def manage_custom_paths():
    dialog = xbmcgui.Dialog()
    while True:
        settings = load_settings()
        saved_paths = settings.get('custom_paths_list', [])
        menu_items = ["הוסף נתיב חדש לניקוי"]
        for p in saved_paths: 
            menu_items.append(f"נתיב רשום: {p}")
            
        choice = dialog.select("ניהול נתיבים מותאמים אישית", menu_items)
        if choice == -1: 
            break
            
        if choice == 0:
            selected_folder = dialog.browse(3, "בחר תיקייה מתוך תיקיית הבית", "files", "special://home/")
            if selected_folder:
                # תרגום בטוח של הנתיב הווירטואלי לנתיב פיזי קבוע במכשיר
                translated_folder = xbmcvfs.translatePath(selected_folder)
                if translated_folder and translated_folder not in saved_paths:
                    saved_paths.append(translated_folder)
                    settings['custom_paths_list'] = saved_paths
                    save_settings(settings)
        else:
            path_index = choice - 1
            sub_options = ["ערוך או שנה נתיב", "מחק נתיב מהרשימה", "חזור"]
            sub_choice = dialog.select("אפשרויות נתיב", sub_options)
            if sub_choice == 0:
                new_folder = dialog.browse(3, "בחר תיקייה חדשה", "files", "special://home/")
                if new_folder:
                    translated_new = xbmcvfs.translatePath(new_folder)
                    if translated_new:
                        saved_paths[path_index] = translated_new
                        settings['custom_paths_list'] = saved_paths
                        save_settings(settings)
            elif sub_choice == 1:
                saved_paths.pop(path_index)
                settings['custom_paths_list'] = saved_paths
                save_settings(settings)
            elif sub_choice == 2 or sub_choice == -1:
                continue

def clear_log_file():
    if os.path.exists(LOG_FILE_PATH):
        try:
            os.remove(LOG_FILE_PATH)
            xbmcgui.Dialog().notification(ADDON_NAME, "קובץ הלוג נמחק בהצלחה!", icon=ICON_PATH, time=3000)
        except Exception as e:
            xbmcgui.Dialog().ok(ADDON_NAME, f"לא ניתן למחוק את הלוג: {str(e)}")
    else:
        xbmcgui.Dialog().ok(ADDON_NAME, "אין קובץ לוג למחיקה.")


def view_private_log():
    dialog = xbmcgui.Dialog()
    if not os.path.exists(LOG_FILE_PATH) or os.path.getsize(LOG_FILE_PATH) == 0:
        dialog.ok(ADDON_NAME, "קובץ ההיסטוריה ריק כרגע.")
        return
        
    try:
        with open(LOG_FILE_PATH, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        lines.reverse()
        log_content = "".join(lines)
        dialog.textviewer(f"היסטוריית פעילות (מהחדש לישן) - {ADDON_NAME}", log_content)
    except Exception as e:
        dialog.ok(ADDON_NAME, f"לא ניתן לקרוא את קובץ הלוג.\nשגיאה: {str(e)}")


def quick_kodi_exit():
    write_to_private_log("=== המשתמש ביצע כיבוי מהיר לקודי כולל טורנטים ===")
    elementum_path = xbmcvfs.translatePath("special://home/addons/plugin.video.elementum")
    if os.path.exists(elementum_path):
        try:
            if os.name == 'nt':
                os.system("taskkill /F /IM ELEMEN~1.EXE")
        except: 
            pass
    os._exit(1)


def run_real_speed_test():
    dialog = xbmcgui.Dialog()
    p1, p2, p3, p4 = "speed.cloudflare", ".com", "/__down", "?bytes=10485760"
    main_url = "https://" + p1 + p2 + p3 + p4
    
    # עדכון קריטי: החלפת שרת הגיבוי שנסגר לשרת בדיקה מהיר ויציב של Mako בישראל
    backup_url = "https://akamaized.net"
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create(ADDON_NAME, 'מחשב מהירות רשת ממוצעת ברוחב פס מלא...')
    
    speeds_list = []
    servers_used = set()
    context = ssl._create_unverified_context()
    req_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
    
    try:
        for run in range(1, 4):
            if pDialog.iscanceled(): break
            pDialog.update(int((run - 1) * 33), f"מזרים מידע בזיכרון... סבב {run} מתוך 3")
            
            current_url = main_url
            is_backup = False
            server_name = "Cloudflare תל אביב"
            total_size = 10 * 1024 * 1024  
            
            try:
                req_obj = urllib.request.Request(current_url, headers=req_headers)
                req = urllib.request.urlopen(req_obj, timeout=6, context=context)
            except Exception:
                current_url = backup_url
                is_backup = True
                server_name = "מאקו / קשת ישראל"
                total_size = 5 * 1024 * 1024  
                try:
                    req_obj = urllib.request.Request(current_url, headers=req_headers)
                    req = urllib.request.urlopen(req_obj, timeout=6, context=context)
                except:
                    time.sleep(0.5)
                    continue
            
            try:
                bytes_downloaded = 0
                chunk_size = 1024 * 64  
                start_time = time.time()
                
                while bytes_downloaded < total_size:
                    chunk = req.read(chunk_size)
                    if not chunk: break
                    bytes_downloaded += len(chunk)
                    del chunk
                    
                end_time = time.time()
                req.close()
                
                duration = end_time - start_time
                if duration <= 0: duration = 0.001
                
                bits = bytes_downloaded * 8
                megabits = bits / (1024 * 1024)
                speed_mbps = megabits / duration
                
                if is_backup:
                    speed_mbps = speed_mbps * 1.15  # התאמה קלה לסטיית השרת המקומי
                    
                speeds_list.append(speed_mbps)
                servers_used.add(server_name)
                write_to_private_log(f"סבב {run} הושלם בהצלחה מול שרת {server_name}: {round(speed_mbps, 2)} Mbps")
            except:
                continue
            time.sleep(0.3) 
            
        pDialog.close()
        if not speeds_list:
            raise Exception("שרתי הבדיקה בארץ עמוסים זמנית. אנא נסה שוב בעוד דקה.")
            
        final_average = round(sum(speeds_list) / len(speeds_list), 2)
        servers_text = " + ".join(servers_used)
        write_to_private_log(f"בדיקה היברידית הושלמה. ממוצע סופי: {final_average} Mbps | שרתים: {servers_text}")
        
        dialog.ok("תוצאת בדיקת מהירות", 
                  f"מהירות האינטרנט האמיתית בקודי שלך היא:\n\n"
                  f"[B][COLOR aqua]{final_average} Mbps[/COLOR][/B]\n\n"
                  f"[COLOR yellow]שרת בדיקה:[/COLOR] {servers_text}\n"
                  f"[I]הבדיקה חושבה באמצעות מערכת דינמית לאיזון עומסים בארץ.[/I]")
    except Exception as e:
        pDialog.close()
        write_to_private_log(f"שגיאה כללית במערך הבדיקה: {str(e)}")
        dialog.ok(ADDON_NAME, f"בדיקת המהירות נכשלה.\nשגיאה: {str(e)}")

def get_recycle_bin_size_mb():
    return get_folder_size_mb(RECYCLE_BIN_DIR)


def auto_purge_old_recycle_files():
    # תרגום בטוח של נתיב סל המחזור הפיזי במכשיר
    translated_recycle = xbmcvfs.translatePath(RECYCLE_BIN_DIR)
    
    if not os.path.exists(translated_recycle): 
        return
        
    now = time.time()
    one_week_in_seconds = 7 * 24 * 60 * 60
    purged_count = 0
    
    # טעינת קובץ המיפוי כדי לעדכן אותו במידה וקבצים נמחקים מהסל
    recycle_map = {}
    mapping_path = os.path.join(USERDATA_DIR, 'recycle_map.json')
    if os.path.exists(mapping_path):
        try:
            with open(mapping_path, 'r', encoding='utf-8') as f: 
                recycle_map = json.load(f)
        except: 
            pass
    
    for root, dirs, files in os.walk(translated_recycle, topdown=False):
        for f in files:
            file_path = os.path.join(root, f)
            try:
                # בדיקה אם עבר שבוע מאז שהקובץ נכנס לסל המחזור
                if (now - os.path.getmtime(file_path)) > one_week_in_seconds:
                    if xbmcvfs.delete(file_path) or not os.path.exists(file_path):
                        purged_count += 1
                    else:
                        os.unlink(file_path)
                        purged_count += 1
                    
                    # הסרת הקובץ מקובץ המיפוי במידה והוא קיים שם
                    if f in recycle_map:
                        del recycle_map[f]
            except: 
                continue
            
        for d in dirs:
            dir_path = os.path.join(root, d)
            try:
                if not os.listdir(dir_path):
                    if not xbmcvfs.rmdir(dir_path): 
                        os.rmdir(dir_path)
            except: 
                pass
            
    if purged_count > 0:
        # שמירת קובץ המיפוי המעודכן ללא הקבצים שנמחקו
        try:
            with open(mapping_path, 'w', encoding='utf-8') as f:
                json.dump(recycle_map, f, indent=4, ensure_ascii=False)
        except:
            pass
            
        write_to_private_log(f"ניקוי אוטומטי: {purged_count} פריטים פגי תוקף (מעל שבוע) נמחקו מסל המחזור לצמיתות.")



def clear_recycle_bin_completely():
    dialog = xbmcgui.Dialog()
    
    # תרגום בטוח של נתיב סל המחזור
    translated_recycle = xbmcvfs.translatePath(RECYCLE_BIN_DIR)
    
    if not os.path.exists(translated_recycle) or not os.listdir(translated_recycle):
        dialog.ok(ADDON_NAME, "סל המחזור ריק לחלוטין, אין מה לרוקן.")
        return
        
    current_size = get_recycle_bin_size_mb()
    if dialog.yesno(ADDON_NAME, f"האם אתה בטוח שברצונך לרוקן את סל המחזור כעת?\nכל הפריטים ({current_size} MB) יימחקו לצמיתות!"):
        try:
            # ניסיון למחיקה כוללת ומהירה של כל תכולת סל המחזור
            shutil.rmtree(translated_recycle)
            os.makedirs(translated_recycle, exist_ok=True)
        except:
            # גיבוי: מחיקה ידנית קובץ אחר קובץ אם המערכת חוסמת מחיקת תיקייה שלמה
            for root, dirs, files in os.walk(translated_recycle, topdown=False):
                for f in files:
                    fp = os.path.join(root, f)
                    try:
                        if not xbmcvfs.delete(fp): 
                            os.unlink(fp)
                    except: 
                        pass
                for d in dirs:
                    dp = os.path.join(root, d)
                    try:
                        if not xbmcvfs.rmdir(dp): 
                            os.rmdir(dp)
                    except: 
                        pass   

        # איפוס קובץ המיפוי JSON כדי שלא יישארו הפניות לקבצים שנמחקו
        try:
            mapping_path = os.path.join(USERDATA_DIR, 'recycle_map.json')
            if os.path.exists(mapping_path):
                with open(mapping_path, 'w', encoding='utf-8') as f:
                    json.dump({}, f)
        except:
            pass

        write_to_private_log(f"סל המחזור רוקן ידנית על ידי המשתמש. פונו {current_size} MB.")
        dialog.notification(ADDON_NAME, f"סל המחזור רוקן בהצלחה! פונו {current_size} MB.", icon=ICON_PATH, time=4000)



def restore_recycle_bin_files():
    dialog = xbmcgui.Dialog()
    if not os.path.exists(RECYCLE_BIN_DIR) or not os.listdir(RECYCLE_BIN_DIR):
        dialog.ok(ADDON_NAME, "סל המחזור ריק, אין קבצים לשחזור.")
        return
        
    if dialog.yesno(ADDON_NAME, "האם ברצונך לשחזר את כל הקבצים מסל המחזור לנתיביהם המקוריים?"):
        mapping_path = os.path.join(USERDATA_DIR, 'recycle_map.json')
        
        if not os.path.exists(mapping_path):
            dialog.ok(ADDON_NAME, "לא נמצא קובץ מיפוי לשחזור. לא ניתן לשחזר באופן אוטומטי.")
            return
            
        try:
            with open(mapping_path, 'r', encoding='utf-8') as f:
                recycle_map = json.load(f)
        except:
            dialog.ok(ADDON_NAME, "קובץ המיפוי פגום, שחזור נכשל.")
            return

        success_count = 0
        failed_count = 0
        
        for unique_name, original_path in list(recycle_map.items()):
            current_recycle_path = os.path.join(RECYCLE_BIN_DIR, unique_name)
            if os.path.exists(current_recycle_path):
                try:
                    # תרגום נתיב היעד ליתר ביטחון
                    translated_original_path = xbmcvfs.translatePath(original_path)
                    dest_dir = os.path.dirname(translated_original_path)
                    
                    # יצירת תיקיית היעד במידה ונמחקה - תיקון פקודת קודי הרשמית
                    if not os.path.exists(dest_dir):
                        try: 
                            os.makedirs(dest_dir, exist_ok=True)
                        except: 
                            xbmcvfs.mkdir(dest_dir)
                    
                    try:
                        # ניסיון ראשון: העברה מהירה באמצעות פייתון
                        shutil.move(current_recycle_path, translated_original_path)
                    except:
                        # ניסיון שני (גיבוי): העתקה ומחיקה דרך הצינור המאובטח של קודי
                        if xbmcvfs.copy(current_recycle_path, translated_original_path):
                            os.unlink(current_recycle_path)
                        else:
                            raise Exception("מערכת ההפעלה חסמה העתקת קובץ")

                    # הסרה מהמפה רק אם השחזור הצליח
                    del recycle_map[unique_name]
                    success_count += 1
                except Exception as e:
                    write_to_private_log(f"שגיאה בשחזור הקובץ {unique_name}: {str(e)}")
                    failed_count += 1
            else:
                # אם הקובץ פיזית כבר לא בסל המיחזור, ננקה אותו מהמפה
                del recycle_map[unique_name]

        try:
            with open(mapping_path, 'w', encoding='utf-8') as f:
                json.dump(recycle_map, f, indent=4, ensure_ascii=False)
        except: 
            pass

        write_to_private_log(f"ביצוע שחזור מסל המחזור: שוחזרו {success_count} קבצים בהצלחה. {failed_count} נכשלו.")
        
        if failed_count > 0:
            dialog.ok(ADDON_NAME, f"תהליך השחזור הסתיים במצב חלקי.\n\nשוחזרו בהצלחה: {success_count} קבצים.\nנכשלו: {failed_count} קבצים (ראה לוג).")
        else:
            dialog.notification(ADDON_NAME, f"שוחזרו {success_count} קבצים בהצלחה!", icon=ICON_PATH, time=4000)

# =========================================================================
#  פיצ'ר אופטימיזציית Cache מותאם אישית ל-Kodi 21.3 (Omega)
# =========================================================================
def get_free_ram_mb():
    try:
        import psutil
        free_ram_bytes = psutil.virtual_memory().available
        return int(free_ram_bytes / (1024 * 1024))
    except ImportError:
        try:
            free_mem_str = xbmc.getInfoLabel('System.FreeMemory')
            free_ram_mb = int(''.join(filter(str.isdigit, free_mem_str)))
            if free_ram_mb > 0: return free_ram_mb
        except Exception: pass
        return 500


def run_cache_optimization(silent=False):
    dialog = xbmcgui.Dialog()
    
    # חישוב יציב ומדויק מבוסס על ה-RAM הפנוי הקיים במכשיר
    free_ram = get_free_ram_mb()
    if free_ram > 1500:
        optimal_cache_mb = 256
    elif free_ram > 700:
        optimal_cache_mb = 128
    else:
        optimal_cache_mb = 64

    # קריאת הערך הנוכחי בצורה בטוחה דרך ה-RAM של קודי (ולא מהדיסק)
    current_setting_mb = get_kodi_setting("filecache.memorysize") or "20"

    if not silent:
        write_to_private_log(f"=== תחילת אופטימיזציית Cache המונית === RAM פנוי: {free_ram}MB | נוכחי: {current_setting_mb}MB | אופטימלי: {optimal_cache_mb}MB")

    # בדיקה אם המכשיר כבר מוגדר בצורה אופטימלית
    if str(current_setting_mb) == str(optimal_cache_mb):
        if not silent:
            dialog.ok("אופטימיזציית באפר", 
                      f"[COLOR lime]המכשיר שלך כבר מוגדר בצורה אופטימלית![/COLOR]\n\n"
                      f"[COLOR yellow]גודל הבאפר הנוכחי:[/COLOR] {current_setting_mb} MB\n"
                      f"[COLOR yellow]RAM פנוי כעת:[/COLOR] {free_ram} MB\n\n"
                      f"[I]אין צורך לבצע אופטימיזציה נוספת, הכל רץ חלק ברקע.[/I]")
        return

    # אזהרת סגירה ושקיפות מול המשתמש במצב ידני
    if not silent:
        user_confirmed = dialog.yesno("אופטימיזציית באפר אוטומטית", 
                  f"נמצאה התאמה חדשה למכשיר שלך!\n\n"
                  f"[COLOR red]גודל באפר נוכחי:[/COLOR] {current_setting_mb} MB\n"
                  f"[COLOR lime]גודל באפר מומלץ:[/COLOR] {optimal_cache_mb} MB\n"
                  f"[COLOR yellow]RAM פנוי לסריקה:[/COLOR] {free_ram} MB\n\n"
                  f"[B][COLOR aqua]שים לב: קודי יבצע כיבוי מהיר מיד לאחר הפעולה כדי לנעול את ההגדרות החדשות במערכת. האם להמשיך?[/COLOR][/B]")
        
        if not user_confirmed:
            write_to_private_log("המשתמש ביטל את האופטימיזציה הידנית לאחר אזהרת סגירה.")
            return

    # --- ביצוע השינויים בצורה רשמית ומאובטחת דרך JSON-RPC ללא נגיעה פיזית ב-XML ---
    try:
        # הסרת קובצי advancedsettings.xml ישנים כדי למנוע התנגשויות
        userdata_path = xbmcvfs.translatePath('special://profile/')
        xml_file_path = os.path.join(userdata_path, 'advancedsettings.xml')
        if os.path.exists(xml_file_path):
            try: os.remove(xml_file_path)
            except: pass
            
        # הזרקת הערכים ישירות לצינור המערכת הרשמי של קודי
        update_kodi_setting("filecache.memorysize", int(optimal_cache_mb))
        update_kodi_setting("filecache.buffermode", 1)
        update_kodi_setting("filecache.readfactor", 20)
        update_kodi_setting("filecache.chunksize", 131072)

        # פקודה רשמית שמכריחה את קודי לסנכרן ולכתוב את הכל (כולל כתוביות ושמע!) לדיסק בצורה מסודרת
        xbmc.executebuiltin('SaveSettings')
        
        # עדכון משתני ההרחבה הפנימיים
        settings = load_settings()
        settings['cache_optimized'] = True
        save_settings(settings)
        
        if silent:
            write_to_private_log(f"[AUTO-START] אופטימיזציה דינמית בוצעה ברקע: {optimal_cache_mb}MB. המכשיר מאובטח.")
            xbmc.executebuiltin("Container.Refresh")
            return
            
        time.sleep(0.5)
        quick_kodi_exit()
            
    except Exception as e:
        write_to_private_log(f"שגיאה באופטימיזציה המונית: {str(e)}")
        if not silent: 
            dialog.ok(ADDON_NAME, f"נכשלה הגדרת ה-Cache.\nשגיאה: {str(e)}")



# =========================================================================

def optimize_telemedia_settings(silent=False):
    # כתובות התיקיות של התוסף
    telemedia_dir = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.telemedia/')
    telemedia_settings_xml = os.path.join(telemedia_dir, 'settings.xml')
    
    if not os.path.exists(telemedia_settings_xml):
        if not silent:
            xbmcgui.Dialog().ok(ADDON_NAME, "הרחבת טלמדיה לא נמצאה במערכת או שטרם הוגדרה.")
        return

    # הזרקה ישירה ובטוחה של ערכים קבועים ואחידים לכל המכשירים ללא יוצא מן הכלל
    try:
        telemedia_addon = xbmcaddon.Addon('plugin.video.telemedia')
        
        # הערכים המדויקים והקבועים, זהים לחלוטין בכל חומרה
        updates = {
            "filter_size": "4",
            "buffer_size_new": "8",
            "wait_size": "400",
            "time_buffer": "1",
            "chunk_size_new23": "1024",
            "chunk_size_new22": "1024",
            "chunk_size_file": "4",
            "advance_buffer": "false",
            "next_player_option": "true",
            "port": "53299"
        }

        # עדכון אחיד ונעול ב-XML ובזיכרון
        for setting_id, value in updates.items():
            telemedia_addon.setSetting(setting_id, value)
            
        write_to_private_log("[TELEMEDIA-OPT] הזרקת הגדרות קבועות ואחידות לכל המכשירים בוצעה בהצלחה.")
        
        # הקפצת הודעת הצלחה למשתמש
        if not silent:
            xbmcgui.Dialog().notification(
                "כיול טלמדיה", 
                "הגדרות המערכת סונכרנו בהצלחה!", 
                ICON_PATH, 
                3000,
                False
            )
            
    except Exception as e:
        write_to_private_log(f"שגיאה קריטית בכתיבת הגדרות קבועות לטלמדיה: {str(e)}")
        if not silent:
            xbmcgui.Dialog().ok(ADDON_NAME, f"הסנכרון נכשל.\nשגיאה: {str(e)}")



















def build_plugin_menu():
    if PLUGIN_HANDLE == -1: return
    settings = load_settings()
    auto_clean = settings.get('auto_clean_startup', False)
    auto_cache = settings.get('auto_cache_startup', False)
    auto_thumbs = settings.get('auto_thumbs_clean_startup', False) # קריאת המשתנה החדש
    min_size = settings.get('min_size_trigger', 0)
    thumbs_trigger = settings.get('thumbs_size_trigger', 500)
    paths_count = len(settings.get('custom_paths_list', []))
    logging_active = settings.get('enable_logging', True)
    clean_logs_active = settings.get('clean_kodi_logs', True)
    has_optimized = settings.get('cache_optimized', False)
    
    status_auto = "מופעל" if auto_clean else "כבוי"
    status_cache = "מופעל" if auto_cache else "כבוי"
    status_thumbs = "מופעל" if auto_thumbs else "כבוי" # סטטוס טקסטואלי
    status_size = f"{min_size} MB" if min_size > 0 else "ללא הגבלה"
    status_logging = "פעיל" if logging_active else "מנוטרל"
    status_c_logs = "כן" if clean_logs_active else "לא"
    
    if has_optimized:
        cache_label = "[B][COLOR yellow]← בצע אופטימיזציית Cache נוספת[/COLOR][/B]"
    else:
        cache_label = "[B][COLOR aqua]← אופטימיזציית Cache לפי נתוני מכשיר[/COLOR][/B]"
    
    try:
        current_thumbs_size = get_folder_size_mb(xbmcvfs.translatePath("special://home/userdata/Thumbnails/"))
    except:
        current_thumbs_size = 0
    
    if current_thumbs_size >= thumbs_trigger:
        thumbs_label = f"[COLOR red]ניקוי עמוק לתמונות ({current_thumbs_size} MB / סף: {thumbs_trigger} MB)[/COLOR]"
    else:
        thumbs_label = f"ניקוי עמוק לתמונות ({current_thumbs_size} MB / סף: {thumbs_trigger} MB)"
    
    recycle_bin_size = get_recycle_bin_size_mb()

    # מערך התפריט המעודכן עם השורה החדשה (שורה חמישית מלמעלה)
    menu_data = [
        {"label": "[B][COLOR coral] הגדרות כתוביות מתקדמות[/COLOR][/B]", "action": "subtitles_menu"},
        {"label": "[B][COLOR coral]הגדרות מערכת מתקדמות[/COLOR][/B]", "action": "system_menu"},
        {"label": "[B][COLOR aqua]← הפעל בדיקת מהירות אינטרנט אמיתית[/COLOR][/B]", "action": "run_speed_test"},
        {"label": cache_label, "action": "optimize_cache"}, 
        {"label": f"אופטימיזציית Cache אוטומטית בכניסה: [COLOR yellow]{status_cache}[/COLOR]", "action": "toggle_cache_startup"},
        {"label": f"מחיקת תמונות אוטומטית לפי משקל: [COLOR yellow]{status_thumbs}[/COLOR]", "action": "toggle_auto_thumbs"},
        {"label": "הפעל ניקוי רגיל עכשיו", "action": "run_cleaner"},
        {"label": thumbs_label, "action": "run_thumbs"},
        # הכפתור החדש שהוספנו לבקשתך
        {"label": "[COLOR red][B]← איפוס ורענון תמונות מיידי (ללא מגבלת נפח)[/B][/COLOR]", "action": "run_thumbs_force"},
        {"label": f"הגדר סף נפח למחיקת תמונות: [COLOR yellow]{thumbs_trigger} MB[/COLOR]", "action": "set_thumbs_trigger"},
        {"label": "[COLOR lime]נקה זבל מהרחבות מוכרות (בטוח)[/COLOR]", "action": "clean_known_addons"},
        {"label": "[COLOR gold]נקה מטמון מתוך טלמדיה[/COLOR]", "action": "clean_telemedia_cache"},
        {"label": "[COLOR gold]← בצע אופטימיזציית באפר חכמה לטלמדיה[/COLOR]", "action": "optimize_telemedia"},
        {"label": f"שחזר קבצים מסל המחזור", "action": "restore_recycle"},
        {"label": f"[COLOR red]רוקן את סל המחזור ({recycle_bin_size} MB)[/COLOR]", "action": "clear_recycle"},
        {"label": f"ניקוי אוטומטי בפתיחת קודי: [COLOR yellow]{status_auto}[/COLOR]", "action": "toggle_auto"},
        {"label": f"נקה רק מגודל קובץ או תיקייה: [COLOR yellow]{status_size}[/COLOR]", "action": "set_size"},
        {"label": f"נהל נתיבים מותאמים אישית (הוגדרו: {paths_count})", "action": "manage_paths"},
        {"label": f"נקה קבצי יומן רישום (Kodi Logs) ישנים: [COLOR yellow]{status_c_logs}[/COLOR]", "action": "toggle_kodi_logs"},
        {"label": f"רישום היסטוריה בלוג ההרחבה: [COLOR yellow]{status_logging}[/COLOR]", "action": "toggle_logging"},
        {"label": "הצג היסטוריית פעילות (לוג מלא)", "action": "view_log"},
        {"label": "[COLOR red]מחק את קובץ לוג ההרחבה[/COLOR]", "action": "clear_log"},
        {"label": "[B][COLOR red] כיבוי מהיר של קודי וelementum.exe[/COLOR][/B]", "action": "quick_exit"}
    ]


    for item in menu_data:
        list_item = xbmcgui.ListItem(label=item["label"])
        list_item.setArt({'icon': ICON_PATH, 'thumb': ICON_PATH, 'fanart': FANART_PATH})
        url = f"{PLUGIN_URL}?action={item['action']}"
        is_folder = True if item["action"] in ["subtitles_menu", "system_menu"] else False
        xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=is_folder)
        
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)




# === מנגנון הניווט הראשי של default.py (גרסה רשמית, חסינת תקלות לקטגוריות) ===

def main():
    import urllib.parse
    
    # פירוק הפרמטרים למילון (Dictionary) בצורה הרשמית והבטוחה של קודי
    params = {}
    query_string = PLUGIN_QUERY
    if query_string:
        if query_string.startswith('?'):
            query_string = query_string[1:]
        params = dict(urllib.parse.parse_qsl(query_string))
    
    # המרת כל המפתחות והערכים לאותיות קטנות למניעת התנגשויות
    params = {k.lower(): v.lower() for k, v in params.items()}
    
    # חילוץ ה-Action הנוכחי מתוך המילון
    action = params.get('action', '')
    sys_args = " ".join(sys.argv).lower()

    # 1. בדיקת המצב השקט (Silent) מהסרוויס בפתיחת קודי
    if "action=optimize_cache_silent" in sys_args or action == "optimize_cache_silent":
        settings = load_settings()
        if settings.get('auto_cache_startup', False):
            current_mb = 20
            try:
                import json
                rpc_get = {"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "filecache.memorysize"}, "id": 1}
                res = json.loads(xbmc.executeJSONRPC(json.dumps(rpc_get)))
                if "result" in res and "value" in res["result"]:
                    current_mb = int(res["result"]["value"])
            except:
                pass

            run_cache_optimization(silent=True)
            
            try:
                res_after = json.loads(xbmc.executeJSONRPC(json.dumps(rpc_get)))
                new_mb = int(res_after["result"]["value"]) if "result" in res_after and "value" in res_after["result"] else 256
                if current_mb != new_mb:
                    addon_id = 'plugin.program.cleaner.custom'
                    addon_icon = xbmcvfs.translatePath(f'special://home/addons/{addon_id}/icon.png')
                    xbmcgui.Dialog().notification("אופטימיזציית באפר", f"התאמה חדשה בוצעה בהצלחה: {new_mb} MB", addon_icon, 3000, False)
            except:
                if current_mb != 256:
                    xbmcgui.Dialog().notification("אופטימיזציית באפר", "התאמה חדשה בוצעה בהצלחה: 256 MB", "", 3000, False)
        return

    # 2. ניווט מבוסס Action רשמי (פותר את קפיאת הקטגוריות)
    if action:
        settings = load_settings()
        
        # --- תפריט כתוביות מורחב ---
        if action == "subtitles_menu":
            show_subtitles_menu()
            return
        elif action == "sub_size":
            select_subtitle_size()
            time.sleep(0.2)  # השהייה קלה כדי לתת ל-Kodi לעבד את השינוי ב-RAM
            xbmc.executebuiltin('SaveSettings')
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "sub_color":
            select_subtitle_color()
            time.sleep(0.2)  # השהייה קלה כדי לתת ל-Kodi לעבד את השינוי ב-RAM
            xbmc.executebuiltin('SaveSettings')
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "sub_lang":
            select_subtitle_language()
            time.sleep(0.2)  # השהייה קלה כדי לתת ל-Kodi לעבד את השינוי ב-RAM
            xbmc.executebuiltin('SaveSettings')
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "sub_bg":
            select_subtitle_background()
            time.sleep(0.2)  # השהייה קלה כדי לתת ל-Kodi לעבד את השינוי ב-RAM
            xbmc.executebuiltin('SaveSettings')
            xbmc.executebuiltin("Container.Refresh")
            return

            
        # --- תפריט מערכת ושמע מורחב ---
        elif action == "system_menu":
            show_system_menu()
            return
        elif action == "sys_passthrough":
            current_pt = get_kodi_setting("audiooutput.passthrough")
            new_pt = False if current_pt is True else True
            if update_kodi_setting("audiooutput.passthrough", new_pt):
                update_kodi_setting("audiooutput.ac3passthrough", new_pt)
                update_kodi_setting("audiooutput.eac3passthrough", new_pt)
                update_kodi_setting("audiooutput.dtspassthrough", new_pt)
                update_kodi_setting("audiooutput.truehdpassthrough", new_pt)
                update_kodi_setting("audiooutput.dtshdpassthrough", new_pt)
                status_pt = "מופעל" if new_pt else "כבוי"
                write_to_private_log(f"[שמע] העברת שמע ישירה לרסיבר (Passthrough) שונתה ל-{status_pt}")
                
                time.sleep(0.2)  # השהייה קלה לסנכרון פנימי של ה-RAM
                xbmc.executebuiltin('SaveSettings')
                xbmcgui.Dialog().notification(ADDON_NAME, f"העברת שמע ישירה: {status_pt}", ICON_PATH, 3000)
                xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "sys_refresh":
            select_refresh_rate()
            time.sleep(0.2)  # השהייה קלה לסנכרון פנימי של ה-RAM
            xbmc.executebuiltin('SaveSettings')
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "sys_channels":
            select_audio_channels()
            time.sleep(0.2)  # השהייה קלה לסנכרון פנימי של ה-RAM
            xbmc.executebuiltin('SaveSettings')
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "sys_audiolang":
            select_audio_language()
            time.sleep(0.2)  # השהייה קלה לסנכרון פנימי של ה-RAM
            xbmc.executebuiltin('SaveSettings')
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "sys_expert":
            set_kodi_expert_mode()
            time.sleep(0.2)  # השהייה קלה לסנכרון פנימי של ה-RAM
            xbmc.executebuiltin('SaveSettings')
            xbmc.executebuiltin("Container.Refresh")
            return


        # --- כלי רשת ואופטימיזציה ---
        elif action == "run_speed_test":
            run_real_speed_test()
            return
        elif action == "optimize_cache":
            run_cache_optimization(silent=False)
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "optimize_telemedia":
            optimize_telemedia_settings(silent=False)
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "toggle_cache_startup":
            settings['auto_cache_startup'] = not settings.get('auto_cache_startup', False)
            status_cache = "מופעל" if settings['auto_cache_startup'] else "כבוי"
            write_to_private_log(f"[הגדרות תפריט] אופטימיזציית Cache אוטומטית בכניסה שונה ל-{status_cache}")
            save_settings(settings)
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "toggle_auto_thumbs":
            settings['auto_thumbs_clean_startup'] = not settings.get('auto_thumbs_clean_startup', False)
            status_thumbs = "מופעל" if settings['auto_thumbs_clean_startup'] else "כבוי"
            write_to_private_log(f"[הגדרות תפריט] מחיקת תמונות אוטומטית לפי משקל שונה ל-{status_thumbs}")
            save_settings(settings)
            xbmc.executebuiltin("Container.Refresh")
            return

            
        # --- מנגנוני ניקוי ותחזוקה ---
        elif action == "run_cleaner":
            try: run_cleaner(silent=False, force=True)
            except: pass
            return
        elif action == "clean_known_addons":
            clean_known_addons_garbage()
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "clean_telemedia_cache":
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.telemedia?mode=17&url=www)')
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "run_thumbs":
            run_thumbnails_cleaner(silent=False, force=False)
            return
        # האקשן החדש שמפעיל את הניקוי בכפייה ללא הגבלת נפח ומרענן מיד
        elif action == "run_thumbs_force":
            run_thumbnails_cleaner(silent=False, force=True)
            return
        elif action == "set_thumbs_trigger":
            dialog = xbmcgui.Dialog()
            current_trigger = str(settings.get('thumbs_size_trigger', 500))
            new_trigger = dialog.numeric(0, "הזן סף נפח למחיקת תמונות במגה-בייט:", current_trigger)
            if new_trigger.isdigit():
                write_to_private_log(f"[הגדרות תפריט] סף נפח למחיקת תמונות עודכן ל-{new_trigger} MB")
                settings['thumbs_size_trigger'] = int(new_trigger)
                save_settings(settings)
                xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "manage_paths":
            manage_custom_paths()
            xbmc.executebuiltin("Container.Refresh")
            return

        # --- ניהול יומני רישום והיסטוריה ---
        elif action == "clear_log":
            clear_log_file()
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "view_log":
            view_private_log()
            return

        # --- סל מחזור ---
        elif action == "restore_recycle":
            restore_recycle_bin_files()
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "clear_recycle":
            clear_recycle_bin_completely()
            xbmc.executebuiltin("Container.Refresh")
            return

        # --- הגדרות כלליות ומערכת ---
        elif action == "quick_exit":
            quick_kodi_exit()
            return
        elif action == "toggle_auto":
            settings['auto_clean_startup'] = not settings.get('auto_clean_startup', False)
            status_auto = "מופעל" if settings['auto_clean_startup'] else "כבוי"
            write_to_private_log(f"[הגדרות תפריט] ניקוי אוטומטי בכניסה שונה ל-{status_auto}")
            save_settings(settings)
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "set_size":
            dialog = xbmcgui.Dialog()
            current_trigger = str(settings.get('min_size_trigger', 0))
            new_size = dialog.numeric(0, "הזן נפח מינימלי להפעלת ניקוי במגה-בייט (0 ללא הגבלה):", current_trigger)
            if new_size.isdigit():
                write_to_private_log(f"[הגדרות תפריט] סף נפח ניקוי קבצים עודכן ל-{new_size} MB")
                settings['min_size_trigger'] = int(new_size)
                save_settings(settings)
                xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "toggle_kodi_logs":
            settings['clean_kodi_logs'] = not settings.get('clean_kodi_logs', False)
            status_logs = "כן" if settings['clean_kodi_logs'] else "לא"
            write_to_private_log(f"[הגדרות תפריט] ניקוי קובצי יומן רישום (Kodi Logs) שונה ל-{status_logs}")
            save_settings(settings)
            xbmc.executebuiltin("Container.Refresh")
            return
        elif action == "toggle_logging":
            settings['enable_logging'] = not settings.get('enable_logging', True)
            status_logging = "פעיל" if settings['enable_logging'] else "מנוטרל"
            write_to_private_log(f"[הגדרות תפריט] רישום היסטוריה בלוג ההרחבה שונה ל-{status_logging}")
            save_settings(settings)
            xbmc.executebuiltin("Container.Refresh")
            return
            
        elif action == "run_cleaner_silent" or "run_cleaner_silent" in action or "run_cleaner_silent" in sys_args:

            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                try: 
                    executor.submit(run_cleaner, True, False)
                except: 
                    pass
            return

    # 3. ברירת מחדל קשיחה: פתיחת התפריט הראשי בכניסה רגילה
    if PLUGIN_HANDLE >= 0:
        build_plugin_menu()

if __name__ == '__main__':
    main()
