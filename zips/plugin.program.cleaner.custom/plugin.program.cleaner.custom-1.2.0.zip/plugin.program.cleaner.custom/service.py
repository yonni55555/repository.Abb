import os
import shutil
import sys
import time
from datetime import datetime
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

def get_folder_size_mb(folder_path):
    """חישוב יציב ומאובטח של נפח התיקייה"""
    total_size = 0
    try:
        physical_path = xbmcvfs.translatePath(folder_path)
        if not os.path.exists(physical_path): return 0.0
        for root, dirs, files in os.walk(physical_path):
            for f in files:
                try: 
                    fp = os.path.join(root, f)
                    if os.path.exists(fp): total_size += os.path.getsize(fp)
                except: continue
    except:
        pass
    return round(total_size / (1024 * 1024), 2)

def run_service():
    addon = xbmcaddon.Addon('plugin.program.cleaner.custom')
    addon_id = addon.getAddonInfo('id')
    
    # --- שלב 1: מחיקת textures.db מיידית בשנייה ה-0 של עליית קודי ---
    try:
        purge_trigger = addon.getSetting('cache_optimized')
        if purge_trigger == 'need_textures_purge':
            db_path = xbmcvfs.translatePath("special://home/userdata/Database/")
            if os.path.exists(db_path):
                for f in os.listdir(db_path):
                    if "textures" in f.lower() and f.endswith(".db"):
                        try: os.remove(os.path.join(db_path, f))
                        except: xbmcvfs.delete(os.path.join(db_path, f))
            addon.setSetting('cache_optimized', 'false')
    except:
        pass

    # --- שלב 2: המתנה של 3 שניות בלבד להתייצבות המערכת והרשת ---
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(3):
        return  

    # פונקציית עזר לחילוץ הגדרות חסין תקלות
    def get_boolean_setting(setting_id):
        try:
            val = addon.getSetting(setting_id)
            if isinstance(val, bool): return val
            val_str = str(val).lower().strip()
            return val_str in ['true', '1', 'yes', 'on']
        except:
            return False

    auto_clean_active = get_boolean_setting('auto_clean_startup')
    auto_cache_active = get_boolean_setting('auto_cache_startup')
    show_notification = get_boolean_setting('show_startup_notification')
    auto_thumbs_active = get_boolean_setting('auto_thumbs_clean_startup')

    try:
        thumbs_trigger_int = int(addon.getSetting('thumbs_size_trigger'))
    except:
        thumbs_trigger_int = 500

    # --- שלב 3: בדיקה ומחיקה אוטומטית של תמונות לפי משקל ---
    if auto_thumbs_active:
        thumbs_path = "special://home/userdata/Thumbnails/"
        current_thumbs_size = get_folder_size_mb(thumbs_path)
        
        if current_thumbs_size >= thumbs_trigger_int:
            try:
                dialog = xbmcgui.Dialog()
                user_approved = dialog.yesno("תחזוקת מערכת אוטומטית", 
                          f"נפח תיקיית התמונות הגיע ל-{int(current_thumbs_size)} MB ועבר את הסף המוגדר.\n"
                          "חובה לסגור את קודי כעת כדי לאפשר בנייה מחדש תקינה של כל הפוסטרים.\n\n"
                          "[B][COLOR yellow]האם לסגור את קודי כעת להשלמת הניקוי והרענון?[/COLOR][/B]",
                          nolabel="דחה מחיקה", 
                          yeslabel="כן, סגור כעת")
                
                if user_approved:
                    # מחיקה פיזית של תיקיית התמונות
                    physical_thumbs = xbmcvfs.translatePath(thumbs_path)
                    if os.path.exists(physical_thumbs):
                        try:
                            shutil.rmtree(physical_thumbs)
                            os.makedirs(physical_thumbs, exist_ok=True)
                        except:
                            pass
                    
                    # מחיקה פיזית של ה-Database באותה השנייה
                    db_path = xbmcvfs.translatePath("special://home/userdata/Database/")
                    if os.path.exists(db_path):
                        for f in os.listdir(db_path):
                            if "textures" in f.lower() and f.endswith(".db"):
                                try: os.remove(os.path.join(db_path, f))
                                except: xbmcvfs.delete(os.path.join(db_path, f))

                    # סימון מראש למחיקת מאגר התמונות בעלייה הבאה (גיבוי)
                    addon.setSetting('cache_optimized', 'need_textures_purge')

                    # כתיבה בטוחה ללוג עם המשתנה הנכון
                    try:
                        log_dir = xbmcvfs.translatePath(f'special://profile/addon_data/{addon_id}/')
                        log_file = os.path.join(log_dir, 'cleaner_history.log')
                        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        with open(log_file, 'a', encoding='utf-8') as f_log:
                            f_log.write(f"[{timestamp}] [אוטומטי] המשתמש אישר מחיקה. מתבצעת סגירה לצורך רענון ({int(current_thumbs_size)} MB).\n")
                    except:
                        pass

                    # פקודת סגירה מערכתית מוחלטת
                    xbmc.executebuiltin('SaveSettings')
                    xbmc.executebuiltin('Quit')
                    time.sleep(0.5)
                    os._exit(1)
                else:
                    try:
                        log_dir = xbmcvfs.translatePath(f'special://profile/addon_data/{addon_id}/')
                        log_file = os.path.join(log_dir, 'cleaner_history.log')
                        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        with open(log_file, 'a', encoding='utf-8') as f_log:
                            f_log.write(f"[{timestamp}] [אוטומטי] המשתמש דחה את המחיקה מהסרוויס.\n")
                    except:
                        pass
            except:
                pass

    # --- שלב 4: הפעלת שאר רכיבי התחזוקה (באפר וניקוי כללי) ---
    if auto_cache_active:
        xbmc.executebuiltin(f'RunPlugin(plugin://{addon_id}/?action=optimize_cache_silent)')

    if auto_clean_active:
        if show_notification:
            xbmc.executebuiltin(f'RunPlugin(plugin://{addon_id}/?action=run_cleaner)')
        else:
            xbmc.executebuiltin(f'RunPlugin(plugin://{addon_id}/?action=run_cleaner_silent)')

if __name__ == '__main__':
    run_service()
