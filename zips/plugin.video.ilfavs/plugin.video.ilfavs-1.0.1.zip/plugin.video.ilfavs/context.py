# context.py המתוקן
import xbmc, sys, urllib.parse

def get_arg(prop):
    try: return xbmc.getInfoLabel('ListItem.' + prop)
    except: return ''

if __name__ == '__main__':
    label = get_arg('Label')
    path = get_arg('FileNameAndPath')
    thumb = get_arg('Icon')
    folder_path = get_arg('FolderPath')
    is_folder = xbmc.getCondVisibility('ListItem.IsFolder')
    
    # זיהוי באיזו פקודה המשתמש בחר לפי התווית (Label)
    chosen_label = xbmc.getInfoLabel('Visual.Label') if hasattr(xbmc, 'getInfoLabel') else ""
    
    if "מותאם אישית" in sys.argv[0] or "custom" in str(sys.argv):
        # פקודה להוספת פריט ידני לתוך הקטגוריה הנוכחית
        cat_path = ""
        if "cat_path=" in folder_path:
            cat_path = folder_path.split("cat_path=")[1].split("&")[0]
        cmd = 'RunPlugin(plugin://plugin.video.ilfavs/?mode=add_custom_item&cat_path={0})'.format(cat_path)
        xbmc.executebuiltin(cmd)
    elif label and path:
        # הוספה רגילה של פריט קיים
        cmd = 'RunPlugin(plugin://plugin.video.ilfavs/?mode=add_to_fav&name={0}&path={1}&thumb={2}&isfolder={3})'.format(
            urllib.parse.quote_plus(label),
            urllib.parse.quote_plus(path),
            urllib.parse.quote_plus(thumb),
            'true' if is_folder else 'false'
        )
        xbmc.executebuiltin(cmd)
