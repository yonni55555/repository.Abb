# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs, sys, json, urllib.parse, os, re, urllib.request, time, random

# הגדרות מערכת
ADDON = xbmcaddon.Addon('plugin.video.ilfavs')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_FANART = ADDON.getAddonInfo('fanart')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
USER_FAVS_FILE = os.path.join(PROFILE, 'user_favourites.json')
BACKUP_G_FOLDER = os.path.join(ADDON_PATH, 'G')
BACKUP_G_FILE = os.path.join(BACKUP_G_FOLDER, 'user_favourites_bak.json')
M3U_ICON = os.path.join(MEDIA_PATH, 'livetv.png')
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"

if not xbmcvfs.exists(PROFILE): xbmcvfs.mkdirs(PROFILE)
if not xbmcvfs.exists(BACKUP_G_FOLDER): xbmcvfs.mkdirs(BACKUP_G_FOLDER)

def resolve_icon_path(icon_val):
    if not icon_val or icon_val == "": return ADDON_ICON
    if icon_val.startswith('http'): return icon_val
    if icon_val.startswith('special://'): return xbmcvfs.translatePath(icon_val)
    local = os.path.join(MEDIA_PATH, icon_val)
    if xbmcvfs.exists(local): return local
    return icon_val

def select_image_dialog():
    options = ["כתובת אינטרנט (URL)", "נתיב מקומי (קודי)", "מדיה של ההרחבה"]
    sel = xbmcgui.Dialog().select("בחר מקור לאייקון", options)
    if sel == 0: return xbmcgui.Dialog().input("הכנס URL:")
    if sel == 1: return xbmcgui.Dialog().browse(2, 'בחר תמונה', 'pictures')
    if sel == 2:
        try:
            dirs, files = xbmcvfs.listdir(MEDIA_PATH)
            imgs = [f for f in files if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            if not imgs: return None
            f_sel = xbmcgui.Dialog().select("בחר קובץ", imgs)
            return imgs[f_sel] if f_sel != -1 else None
        except: return None
    return None

def show_help_dialog():
    # עיצוב הטקסט עם ירידות שורה מסודרות
    msg = "[COLOR yellow]• הוספה:[/COLOR] קליק ימני על תוכן > [COLOR red]הוסף למועדפי IL[/COLOR]\n"
    msg += "[COLOR yellow]• פקודות:[/COLOR] קליק ימני בפנים > [COLOR orange]הוסף פריט ידני[/COLOR]\n"
    msg += "[COLOR yellow]• ניהול:[/COLOR] קליק ימני לשינוי מיקום, שם או הזזה\n"
    msg += "[COLOR yellow]• סוג:[/COLOR] אם פריט לא מגיב > [COLOR orange]לחץ 'סוג' ונסה שוב[/COLOR]"
    
    # שימוש ב-okdialog שמציג את האייקון בצד ימין/שמאל בצורה מינימלית
    dialog = xbmcgui.Dialog()
    dialog.ok("[B][COLOR aqua]מנהל מועדפים IL - מדריך[/COLOR][/B]", msg)


def get_icon(name):
    icons = {"תחזוקה": "settings.png", "כללי": "favorites.png", "חיפוש": "search.png", "כיבוי": "power.png"}
    icon_path = os.path.join(MEDIA_PATH, icons.get(name, ""))
    return icon_path if xbmcvfs.exists(icon_path) else ADDON_ICON

def clean_name(name):
    name = name.replace('&quot;', '"').replace('&amp;', '&')
    name = re.sub(r'\[COLOR.*?\]|\[/COLOR\]|\[B\]|\[/B\]|\[I\]|\[/I\]', '', name, flags=re.I)
    name = re.sub(r'[\(\[].*?[\)\]]', '', name)
    name = re.sub(r'\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}', '', name)
    name = re.sub(r'\d{1,2}:\d{2}', '', name)
    if ' - ' in name: name = name.split(' - ')[0]
    return name.strip(" -")

def get_data():
    default_structure = {"order": [{"type": "cat", "name": "כללי"}], "categories": {"כללי": {"items": [], "categories": {}, "order": [], "icon": "favorites.png"}, "תחזוקה": {"items": [], "categories": {"קטגוריות מנוטרלות": {"items": [], "categories": {}, "order": []}}, "order": [{"type": "cat", "name": "קטגוריות מנוטרלות"}], "is_system": True, "icon": "settings.png"}}, "items": [], "settings": {"show_search": True, "show_exit": True, "first_run": True}}
    if xbmcvfs.exists(USER_FAVS_FILE):
        try:
            f = xbmcvfs.File(USER_FAVS_FILE); c = f.read(); f.close()
            if c: return json.loads(c)
        except: pass
    return default_structure

def save_data(data):
    try:
        f = xbmcvfs.File(USER_FAVS_FILE, 'w'); f.write(json.dumps(data, indent=4, ensure_ascii=False)); f.close()
    except: pass

def navigate_to_category(data, path_str):
    if not path_str or path_str in ["/", "root", ""]: return data
    curr = data
    for p in path_str.strip('/').split('/'):
        if p:
            if "categories" not in curr: curr["categories"] = {}
            if p not in curr["categories"]: curr["categories"][p] = {"items": [], "categories": {}, "order": []}
            curr = curr["categories"][p]
    return curr

def check_is_playable(path):
    low = path.lower()
    if any(cmd in low for cmd in ["activatewindow", "runscript", "runplugin", "system.", "action(", "execute(", "startandroidactivity"]): return False
    if any(p in low for p in ["addons://", "plugin.program.", "script.module.", "plugin.close."]): return False
    if any(ext in low for ext in [".mp4", ".mkv", ".m3u8", ".mp3", ".ts", ".avi"]): return True
    if any(pattern in low for pattern in ["/p/", "/ch/", "is_playable=true", "action=play", "play=true"]): return True
    if low.startswith("plugin://"):
        if low.endswith('/') or '?' not in low: return False
        if any(cmd in low for cmd in ["play", "video", "audio", "live"]): return True
        return len(low.split('/')) > 5
    return False

def import_m3u_logic(data, source_type="file", existing_path=None, existing_name=None):
    file_path = existing_path or (xbmcgui.Dialog().input("URL:") if source_type == "url" else xbmcgui.Dialog().browse(1, 'בחר M3U', 'files', '.m3u|.m3u8'))
    if not file_path: return
    cat_name = existing_name or xbmcgui.Dialog().input("שם לרשימה:")
    if not cat_name: return
    if "רשימות M3U" not in data["categories"]:
        data["categories"]["רשימות M3U"] = {"items": [], "categories": {}, "order": [], "icon": M3U_ICON}
        data["order"].append({"type": "cat", "name": "רשימות M3U"})
    try:
        if file_path.startswith("http"):
            req = urllib.request.Request(file_path, headers={'User-Agent': UA})
            with urllib.request.urlopen(req) as r: content = r.read().decode('utf-8', errors='ignore')
        else:
            f = xbmcvfs.File(file_path); content = f.read(); f.close()
            if isinstance(content, bytes): content = content.decode('utf-8', errors='ignore')
        lines = content.splitlines(); new_items, new_order = [], []; name, thumb = "ללא שם", ""
        for line in lines:
            line = line.strip()
            if line.startswith("#EXTINF"):
                t_m = re.search(r'tvg-logo=["\'](.*?)["\']', line) or re.search(r'tvg-logo=(.*?)(\s|,)', line)
                thumb = t_m.group(1) if t_m else ""
                n_m = re.search(r',([^,]+)$', line)
                if n_m: name = clean_name(n_m.group(1).strip())
            elif line and (line.startswith("http") or line.startswith("plugin://")):
                is_p = check_is_playable(line)
                final_url = (line + f"|User-Agent={urllib.parse.quote(UA)}") if (is_p and line.startswith("http") and "|" not in line) else line
                new_items.append({"name": name, "url": final_url, "thumbnail": thumb, "is_playable": is_p})
                new_order.append({"type": "item", "name": name, "url": final_url})
                name, thumb = "ללא שם", ""
        if new_items:
            data["categories"]["רשימות M3U"]["categories"][cat_name] = {"items": new_items, "categories": {}, "order": new_order, "is_m3u_list": True, "icon": M3U_ICON, "source": file_path}
            if not any(o["name"] == cat_name for o in data["categories"]["רשימות M3U"]["order"]):
                data["categories"]["רשימות M3U"]["order"].append({"type": "cat", "name": cat_name})
            save_data(data)
            xbmcgui.Dialog().notification("M3U", f"עודכן: {cat_name}", M3U_ICON, 3000)
    except: pass
def global_search(node, query, current_path="", results=None):
    if results is None: results = {"items": [], "cats": []}
    q = query.lower()
    for item in node.get("items", []):
        if q in item["name"].lower(): results["items"].append(item)
    for cat_name, cat_data in node.get("categories", {}).items():
        if cat_name == "קטגוריות מנוטרלות": continue
        if q in cat_name.lower(): results["cats"].append({"name": cat_name, "path": f"{current_path}/{cat_name}".strip('/')})
        global_search(cat_data, query, f"{current_path}/{cat_name}".strip('/'), results)
    return results

def select_category_recursive(data, current_path=""):
    curr_data = navigate_to_category(data, current_path)
    cats = sorted([k for k in curr_data.get("categories", {}).keys() if k != "קטגוריות מנוטרלות"])
    sel = xbmcgui.Dialog().select(f"יעד: {current_path or 'ראשי'}", ["בחר כאן", "תיקייה חדשה"] + cats)
    if sel == -1: return None
    if sel == 0: return current_path
    elif sel == 1:
        new = xbmcgui.Dialog().input("שם תיקייה:")
        if not new: return None
        curr_data.setdefault("categories", {})[new] = {"items": [], "categories": {}, "order": [], "icon": ADDON_ICON}
        curr_data.setdefault("order", []).append({"type": "cat", "name": new}); save_data(data)
        return f"{current_path}/{new}" if current_path else new
    else: return select_category_recursive(data, f"{current_path}/{cats[sel-2]}" if current_path else cats[sel-2])

def list_folder_content(handle, base_url, folder_data, current_path):
    data = get_data()
    # הוספת רקע (Fanart) לפריטי תחזוקה
    if current_path == "תחזוקה":
        items = [("קטגוריות מנוטרלות", "list_cat&cat_path=תחזוקה/קטגוריות מנוטרלות"), ("ניהול M3U", "list_cat&cat_path=תחזוקה/M3U"), ("גיבוי ושחזור", "list_cat&cat_path=תחזוקה/גיבוי ושחזור"), ("הסבר על ההרחבה", "show_help"), (f"חיפוש: {'[COLOR green]V[/COLOR]' if data['settings'].get('show_search',True) else '[COLOR red]X[/COLOR]'}", "toggle_search_btn"), (f"כיבוי: {'[COLOR green]V[/COLOR]' if data['settings'].get('show_exit',True) else '[COLOR red]X[/COLOR]'}", "toggle_exit_btn")]
        for n, m in items:
            li = xbmcgui.ListItem(n); li.setArt({'icon': get_icon("תחזוקה"), 'fanart': ADDON_FANART})
            xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode={m}", li, True if "list_cat" in m else False)
        return
    if current_path == "תחזוקה/M3U":
        for n, m in [("הוספה מקובץ", "import_m3u_file"), ("הוספה מכתובת URL", "import_m3u_url"), ("רענון כל הרשימות", "refresh_all_m3u")]:
            li = xbmcgui.ListItem(n); li.setArt({'icon': M3U_ICON, 'fanart': ADDON_FANART})
            xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode={m}", li, False)
        return
    if current_path == "תחזוקה/גיבוי ושחזור":
        for n, m in [("גיבוי נתונים לתיקייה G", "backup_dialog"), ("שחזור נתונים מתיקייה G", "restore_dialog"), ("[COLOR red]איפוס כל הנתונים[/COLOR]", "factory_reset")]:
            li = xbmcgui.ListItem(n); li.setArt({'icon': get_icon("תחזוקה"), 'fanart': ADDON_FANART})
            xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode={m}", li, False)
        return

    p_items = [i for i in folder_data.get("items", []) if i.get('is_playable', False)]
    media_files = [i for i in p_items if any(ext in i['url'].lower() for ext in ['.mp3', '.mp4', '.mkv', '.avi'])]
    if media_files and len(media_files) > 1 and "תחזוקה" not in current_path:
        li_shuf = xbmcgui.ListItem("[COLOR orange]ניגון אקראי של הרשימה[/COLOR]")
        li_shuf.setArt({'icon': 'DefaultMusicPlaylists.png', 'fanart': ADDON_FANART})
        xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode=shuffle_play&cat_path={urllib.parse.quote_plus(current_path)}", li_shuf, False)

    is_disabled_folder = "קטגוריות מנוטרלות" in current_path
    for i, entry in enumerate(folder_data.get("order", [])):
        if entry["type"] == "cat":
            name = entry["name"]; info = folder_data["categories"].get(name, {})
            li = xbmcgui.ListItem(f"[COLOR cyan]{name}[/COLOR]")
            icon = resolve_icon_path(info.get('icon') or get_icon(name))
            li.setArt({'icon': icon, 'thumb': icon, 'fanart': ADDON_FANART})
            m_url = f"{base_url}?mode=manage_cat&cat_name={urllib.parse.quote_plus(name)}&parent_path={urllib.parse.quote_plus(current_path)}&idx={i}"
            label_dis = "[COLOR green]שחזר[/COLOR]" if is_disabled_folder else "[COLOR yellow]ניטרול[/COLOR]"
            li.addContextMenuItems([("[COLOR yellow]מיקום[/COLOR]", f"RunPlugin({m_url}&action=reorder)"), ("[COLOR yellow]אייקון[/COLOR]", f"RunPlugin({m_url}&action=set_thumb)"), ("[COLOR yellow]מחק[/COLOR]", f"RunPlugin({m_url}&action=delete)"), ("[COLOR yellow]שנה שם[/COLOR]", f"RunPlugin({m_url}&action=rename)"), ("[COLOR yellow]הזז[/COLOR]", f"RunPlugin({m_url}&action=move_cat)"), (label_dis, f"RunPlugin({m_url}&action=disable_cat)"), ("[COLOR orange]הוסף פריט ידני[/COLOR]", f"RunPlugin({base_url}?mode=add_custom_item&cat_path={urllib.parse.quote_plus(current_path+'/'+name if current_path else name)})")])
            xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode=list_cat&cat_path={urllib.parse.quote_plus(current_path+'/'+name if current_path else name)}", li, True)
        else:
            items_m = [x for x in folder_data.get("items", []) if x["url"] == entry["url"]]
            if not items_m: continue
            item = next((x for x in items_m if x["name"] == entry["name"]), items_m)
            li = xbmcgui.ListItem(f"[COLOR red]{item['name']}[/COLOR]")
            li.setArt({'icon': resolve_icon_path(item.get('thumbnail')), 'thumb': resolve_icon_path(item.get('thumbnail')), 'fanart': ADDON_FANART})
            is_p = item.get('is_playable', False)
            url_low = item['url'].lower()
            is_sys = any(x in url_low for x in ["activatewindow", "runscript", "runplugin", "system.", "action(", "execute(", "startandroidactivity"])
            if is_sys:
                p_url = f"{base_url}?mode=exec_sys&url={urllib.parse.quote_plus(item['url'])}"
                is_folder_item = False
            elif is_p:
                li.setProperty('IsPlayable', 'true')
                p_url = f"{base_url}?mode=play_media&url={urllib.parse.quote_plus(item['url'])}&name={urllib.parse.quote_plus(item['name'])}"
                is_folder_item = False
            else:
                p_url = item['url']
                is_folder_item = True
            m_url = f"{base_url}?mode=manage_item&idx={i}&cat_path={urllib.parse.quote_plus(current_path)}"
            li.addContextMenuItems([("[COLOR yellow]מחק[/COLOR]", f"RunPlugin({m_url}&action=delete)"), ("[COLOR yellow]הזז[/COLOR]", f"RunPlugin({m_url}&action=move)"), ("[COLOR yellow]שם[/COLOR]", f"RunPlugin({m_url}&action=rename)"), ("[COLOR yellow]אייקון[/COLOR]", f"RunPlugin({m_url}&action=set_thumb)"), ("[COLOR yellow]סוג[/COLOR]", f"RunPlugin({m_url}&action=toggle_type)"), ("[COLOR yellow]מיקום[/COLOR]", f"RunPlugin({m_url}&action=reorder)")])
            xbmcplugin.addDirectoryItem(handle, p_url, li, is_folder_item)

    if not current_path:
        if data["settings"].get("show_search", True):
            li = xbmcgui.ListItem("חיפוש"); li.setArt({'icon': get_icon("חיפוש"), 'fanart': ADDON_FANART})
            xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode=ask_search", li, False)
        li_t = xbmcgui.ListItem("[COLOR green]תחזוקה[/COLOR]"); li_t.setArt({'icon': get_icon("תחזוקה"), 'fanart': ADDON_FANART})
        xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode=list_cat&cat_path=תחזוקה", li_t, True)
        if data["settings"].get("show_exit", True):
            li_e = xbmcgui.ListItem("[COLOR orange]כיבוי קודי[/COLOR]"); li_e.setArt({'icon': get_icon("כיבוי"), 'fanart': ADDON_FANART})
            xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode=force_exit", li_e, False)

if __name__ == '__main__':
    base_url = sys.argv[0] if len(sys.argv) > 0 else ""
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    mode, data = params.get('mode'), get_data()
    if data.get('settings', {}).get('first_run', True): show_help_dialog(); data['settings']['first_run'] = False; save_data(data)

    if mode == 'list_cat':
        p = urllib.parse.unquote_plus(params.get('cat_path', ""))
        list_folder_content(handle, base_url, navigate_to_category(data, p), p); xbmcplugin.endOfDirectory(handle)
    
    elif mode == 'exec_sys':
        u = urllib.parse.unquote_plus(params.get('url', ''))
        xbmc.executebuiltin(u)

    elif mode == 'add_custom_item':
        p_path = urllib.parse.unquote_plus(params.get('cat_path', ""))
        choice = xbmcgui.Dialog().select("בחר סוג פריט", ["הזנה ידנית (פקודה/URL)", "פקודות מערכת מוכנות"])
        n, u = None, None
        if choice == 0:
            n = xbmcgui.Dialog().input("שם הפריט:")
            if n: u = xbmcgui.Dialog().input("הכנס פקודה או כתובת:")
        elif choice == 1:
            sys_items = [
                ("ישומי אנדרואיד (אנדרואיד)", "StartAndroidActivity(com.android.settings)"),
                ("חלון תצוגה (ווינדוס)", "Action(togglefullscreen)"),
                ("הגדרות", "ActivateWindow(Settings)"),
                ("הגדרות שמע", "ActivateWindow(SystemSettings,Audio)"),
                ("הגדרות נגן", "ActivateWindow(PlayerSettings)"),
                ("פרטי מערכת", "ActivateWindow(SystemInfo)"),
                ("טלויזיה חיה", "ActivateWindow(TVChannels)"),
                ("לוח שידורים", "ActivateWindow(TVGuide)"),
                ("עדכונים זמינים", "ActivateWindow(AddonBrowser,addons://outdated/)"),
                ("סייר ההרחבות", "ActivateWindow(AddonBrowser)"),
                ("הגדרת כתוביות", "ActivateWindow(PlayerSettings,Subtitles)"),
                ("הגדרות מעטפת", "ActivateWindow(SkinSettings)"),
                ("מנהל הקבצים", "ActivateWindow(FileManager)")
            ]
            # הצגת שמות הפקודות בלבד למשתמש
            sel = xbmcgui.Dialog().select("בחר פקודה", [i[0] for i in sys_items])
            if sel != -1: n, u = sys_items[sel]
        if n and u:
            t = select_image_dialog() or ADDON_ICON
            dest = navigate_to_category(data, p_path)
            dest["items"].append({"name": n, "url": u, "thumbnail": t, "is_playable": check_is_playable(u)})
            dest["order"].append({"type": "item", "name": n, "url": u})
            save_data(data); xbmc.executebuiltin("Container.Refresh")

    elif mode == 'play_media':
        u, n = urllib.parse.unquote_plus(params.get('url', '')), urllib.parse.unquote_plus(params.get('name', ''))
        if u.startswith('http'):
            u = urllib.parse.quote(urllib.parse.unquote(u), safe=':/?&=|')
            u += f"|User-Agent={urllib.parse.quote(UA)}&verifypeer=false" if '|' not in u else ""
        li = xbmcgui.ListItem(n); li.setPath(u); xbmcplugin.setResolvedUrl(handle, True, li)

    elif mode == 'shuffle_play':
        p_path = urllib.parse.unquote_plus(params.get('cat_path', ""))
        target = navigate_to_category(get_data(), p_path)
        p_items = [i for i in target.get("items", []) if i.get('is_playable', False)]
        if p_items:
            random.shuffle(p_items)
            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO); pl.clear()
            for item in p_items: pl.add(url=item['url'], listitem=xbmcgui.ListItem(item['name']))
            xbmc.Player().play(pl)

    elif mode == 'manage_cat':
        act, idx, p_p = params.get('action'), int(params.get('idx', -1)), urllib.parse.unquote_plus(params.get('parent_path', ""))
        cat_n, parent = urllib.parse.unquote_plus(params.get('cat_name', "")), navigate_to_category(data, p_p)
        if act == 'delete' and xbmcgui.Dialog().yesno("מחיקה", "למחוק?"): parent["categories"].pop(cat_n, None); parent["order"].pop(idx)
        elif act == 'rename':
            new = xbmcgui.Dialog().input("שם:", defaultt=cat_n)
            if new: parent["categories"][new] = parent["categories"].pop(cat_n); parent["order"][idx]["name"] = new
        elif act == 'set_thumb':
            img = select_image_dialog()
            if img: parent["categories"][cat_n]["icon"] = img
        elif act == 'move_cat':
            new_p = select_category_recursive(data)
            if new_p is not None:
                obj, ent = parent["categories"].pop(cat_n), parent["order"].pop(idx)
                dest = navigate_to_category(data, new_p); dest["categories"][cat_n] = obj; dest["order"].append(ent)
        elif act == 'disable_cat':
            dest_p = "" if "קטגוריות מנוטרלות" in p_p else "תחזוקה/קטגוריות מנוטרלות"
            dest = navigate_to_category(data, dest_p); obj, ent = parent["categories"].pop(cat_n), parent["order"].pop(idx)
            dest["categories"][cat_n] = obj; dest["order"].append(ent)
        elif act == 'reorder':
            v = xbmcgui.Dialog().input("מיקום:", type=xbmcgui.INPUT_NUMERIC)
            if v: parent["order"].insert(max(0, int(v)-1), parent["order"].pop(idx))
        save_data(data); xbmc.executebuiltin("Container.Refresh")

    elif mode == 'manage_item':
        act, idx, p_p = params.get('action'), int(params.get('idx', -1)), urllib.parse.unquote_plus(params.get('cat_path', ""))
        target = navigate_to_category(data, p_p); ent = target["order"][idx]
        if act == 'delete':
            target["order"].pop(idx); target["items"] = [i for i in target["items"] if not (i["url"] == ent["url"] and i["name"] == ent["name"])]
        elif act == 'move':
            new_p = select_category_recursive(data)
            if new_p is not None:
                item_obj = next((i for i in target["items"] if i["url"] == ent["url"] and i["name"] == ent["name"]), None)
                if item_obj:
                    dest = navigate_to_category(data, new_p); dest["items"].append(item_obj); dest["order"].append(ent); target["order"].pop(idx); target["items"].remove(item_obj)
        elif act == 'rename':
            new = xbmcgui.Dialog().input("שם:", defaultt=ent["name"])
            if new:
                old = ent["name"]; ent["name"] = new
                for i in target["items"]:
                    if i["name"] == old and i["url"] == ent["url"]: i["name"] = new; break
        elif act == 'set_thumb':
            img = select_image_dialog()
            if img:
                for i in target["items"]:
                    if i["name"] == ent["name"] and i["url"] == ent["url"]: i["thumbnail"] = img; break
        elif act == 'toggle_type':
            for i in target["items"]:
                if i["name"] == ent["name"] and i["url"] == ent["url"]: i['is_playable'] = not i.get('is_playable', False); break
        elif act == 'reorder':
            v = xbmcgui.Dialog().input("מיקום:", type=xbmcgui.INPUT_NUMERIC)
            if v: target["order"].insert(max(0, int(v)-1), target["order"].pop(idx))
        save_data(data); xbmc.executebuiltin("Container.Refresh")

    elif mode == 'add_to_fav':
        n, p = clean_name(urllib.parse.unquote_plus(params.get('name', ''))), urllib.parse.unquote_plus(params.get('path', ''))
        t, is_f = urllib.parse.unquote_plus(params.get('thumb', '')), params.get('isfolder', 'false') == 'true'
        final_p = select_category_recursive(data)
        if final_p is not None:
            dest = navigate_to_category(data, final_p)
            dest["items"].append({"name": n, "url": p, "thumbnail": t, "is_playable": not is_f})
            dest["order"].append({"type": "item", "name": n, "url": p})
            save_data(data)
            xbmcgui.Dialog().notification(n, "התווסף בהצלחה", resolve_icon_path(t), 3000)

    elif mode == 'ask_search':
        q = xbmcgui.Dialog().input("חיפוש:")
        if q: xbmc.executebuiltin(f"Container.Update({base_url}?mode=do_search&query={urllib.parse.quote_plus(q)})")
    
    elif mode == 'do_search':
        q = urllib.parse.unquote_plus(params.get('query', "")); res = global_search(get_data(), q)
        for itm in res["items"]:
            li = xbmcgui.ListItem(f"[COLOR red]{itm['name']}[/COLOR]"); li.setArt({'icon': resolve_icon_path(itm.get('thumbnail'))})
            if itm.get('is_playable', False): li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, itm['url'], li, not itm.get('is_playable', False))
        for cat in res["cats"]:
            li = xbmcgui.ListItem(f"[COLOR cyan]{cat['name']}[/COLOR]"); xbmcplugin.addDirectoryItem(handle, f"{base_url}?mode=list_cat&cat_path={urllib.parse.quote_plus(cat['path'])}", li, True)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    
    elif mode == 'refresh_all_m3u':
        m3u_cat = data.get("categories", {}).get("רשימות M3U", {}).get("categories", {})
        for name, info in m3u_cat.items():
            if "source" in info: import_m3u_logic(data, "file", info["source"], name)
        xbmcgui.Dialog().notification("M3U", "כל הרשימות עודכנו")
    
    elif mode in ['toggle_search_btn', 'toggle_exit_btn']:
        if "search" in mode: data["settings"]["show_search"] = not data["settings"].get("show_search", True)
        else: data["settings"]["show_exit"] = not data["settings"].get("show_exit", True)
        save_data(data); xbmc.executebuiltin("Container.Refresh")
    
    elif mode == 'backup_dialog':
        if xbmcvfs.copy(USER_FAVS_FILE, BACKUP_G_FILE): xbmcgui.Dialog().notification("גיבוי", "גובה בהצלחה")
    elif mode == 'restore_dialog':
        if xbmcvfs.exists(BACKUP_G_FILE) and xbmcvfs.copy(BACKUP_G_FILE, USER_FAVS_FILE): xbmcgui.Dialog().notification("שחזור", "בוצע"); xbmc.executebuiltin("Container.Refresh")
    elif mode == 'factory_reset':
        if xbmcgui.Dialog().yesno("איפוס", "למחוק הכל?"):
            if xbmcvfs.exists(USER_FAVS_FILE): xbmcvfs.delete(USER_FAVS_FILE)
            xbmc.executebuiltin("Container.Refresh")
    elif mode == 'force_exit': os._exit(1)
    elif mode == 'show_help': show_help_dialog()
    elif mode in ['import_m3u_file', 'import_m3u_url']: import_m3u_logic(data, "url" if "url" in mode else "file")
    else:
        list_folder_content(handle, base_url, data, "")
        xbmcplugin.endOfDirectory(handle)
